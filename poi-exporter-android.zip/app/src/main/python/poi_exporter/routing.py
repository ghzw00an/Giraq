"""التوجيه وتحليل الشبكة عبر خادم OSRM (الافتراضي العام؛ يمكن تغييره من الإعدادات). يحتاج إنترنت."""
from __future__ import annotations

import json
import math
import urllib.request
from typing import List, Sequence, Tuple

from .geo import haversine

DEFAULT_URL = "https://router.project-osrm.org"


def _get(url: str) -> dict:                       # نقطة واحدة للشبكة كي تُستبدل في الاختبارات
    req = urllib.request.Request(url, headers={"User-Agent": "POIExporter/3"})
    with urllib.request.urlopen(req, timeout=25) as r:
        return json.loads(r.read().decode("utf-8"))


def _co(pts: Sequence[Tuple[float, float]]) -> str:
    return ";".join("%.6f,%.6f" % (lon, lat) for lat, lon in pts)


class RouteError(Exception):
    pass


def _check(j: dict):
    if j.get("code") != "Ok":
        raise RouteError({"NoRoute": "لا يوجد طريق بين النقطتين (قد تكون إحداهما بعيدة عن الشوارع)", "NoSegment": "إحدى النقاط بعيدة عن أقرب شارع", "TooBig": "عدد النقاط كبير على الخادم"}.get(j.get("code"), "تعذّر التوجيه: %s" % (j.get("message") or j.get("code"))))
    return j


def route(stops: Sequence[Tuple[float, float]], base: str = DEFAULT_URL, optimize: bool = False) -> dict:
    """stops: [(lat,lon)…] → {coords:[(lon,lat)…], km, min, order, legs:[{km,min}]}"""
    if len(stops) < 2:
        raise RouteError("حدّد نقطتين على الأقل")
    base = (base or DEFAULT_URL).rstrip("/")
    if optimize and len(stops) > 2:
        j = _check(_get(f"{base}/trip/v1/driving/{_co(stops)}?overview=full&geometries=geojson&source=first&destination=last&roundtrip=false"))
        t = j["trips"][0]
        order = [i for i, _ in sorted(enumerate(j["waypoints"]), key=lambda x: x[1]["waypoint_index"])]
    else:
        j = _check(_get(f"{base}/route/v1/driving/{_co(stops)}?overview=full&geometries=geojson&steps=false"))
        t = j["routes"][0]
        order = list(range(len(stops)))
    return {"coords": [tuple(c) for c in t["geometry"]["coordinates"]], "km": round(t["distance"] / 1000, 3), "min": round(t["duration"] / 60, 2),
            "order": order, "legs": [{"km": round(l["distance"] / 1000, 3), "min": round(l["duration"] / 60, 2)} for l in t.get("legs", [])]}


def table(src: Sequence[Tuple[float, float]], dst: Sequence[Tuple[float, float]], base: str = DEFAULT_URL):
    """مصفوفة (زمن ثانية، مسافة م) من src إلى dst."""
    base = (base or DEFAULT_URL).rstrip("/")
    pts = list(src) + list(dst)
    s = ";".join(map(str, range(len(src)))); d = ";".join(str(len(src) + i) for i in range(len(dst)))
    j = _check(_get(f"{base}/table/v1/driving/{_co(pts)}?sources={s}&destinations={d}&annotations=duration,distance"))
    return j["durations"], j.get("distances")


def closest(origin, cands, k: int = 3, base: str = DEFAULT_URL, limit: int = 40):
    """أقرب k منشآت زمنياً: ترشيح بخط مستقيم ثم مصفوفة OSRM. cands: [(lat,lon,payload)]"""
    pre = sorted(cands, key=lambda c: haversine(origin[0], origin[1], c[0], c[1]))[:limit]
    if not pre:
        raise RouteError("لا توجد منشآت في الطبقات المحددة")
    dur, dist = table([origin], [(c[0], c[1]) for c in pre], base)
    rows = []
    for c, t, d in zip(pre, dur[0], (dist or [[None] * len(pre)])[0]):
        if t is not None:
            rows.append((t, d, c))
    rows.sort(key=lambda r: r[0])
    return rows[:k]


def service_area(origin, minutes: Sequence[float], base: str = DEFAULT_URL, bearings: int = 16, steps: int = 6, kmh: float = 80.0):
    """منطقة خدمة تقريبية: نأخذ عينات على اتجاهات ومسافات ونستخرج أبعد عينة ضمن الزمن لكل اتجاه."""
    rmax = max(minutes) / 60.0 * kmh * 1000
    ds = [rmax * (i + 1) / steps for i in range(steps)]
    pts = []
    for b in range(bearings):
        a = 2 * math.pi * b / bearings
        for d in ds:
            pts.append((origin[0] + d * math.cos(a) / 110574.0, origin[1] + d * math.sin(a) / (111320.0 * max(0.05, math.cos(math.radians(origin[0]))))))
    dur, _ = table([origin], pts, base)
    dur = dur[0]
    res = []
    for m in minutes:
        lim = m * 60.0
        ring = []
        for b in range(bearings):
            a = 2 * math.pi * b / bearings
            r, prev_t, prev_d = 0.0, 0.0, 0.0
            for i, d in enumerate(ds):
                t = dur[b * steps + i]
                if t is None:
                    break
                if t <= lim:
                    r, prev_t, prev_d = d, t, d
                else:
                    if t > prev_t:
                        r = prev_d + (d - prev_d) * (lim - prev_t) / (t - prev_t)
                    break
            ring.append((origin[1] + r * math.sin(a) / (111320.0 * max(0.05, math.cos(math.radians(origin[0])))), origin[0] + r * math.cos(a) / 110574.0))
        ring.append(ring[0])
        res.append((m, ring))
    return res
