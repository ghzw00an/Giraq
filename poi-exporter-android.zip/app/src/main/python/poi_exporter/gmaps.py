"""يفهم روابط خرائط Google (طويلة وقصيرة) ورموز Plus Code ويستخرج الإحداثيات منها."""
from __future__ import annotations

import re
import urllib.parse
import urllib.request

from . import pluscode

_URL = re.compile(r"https?://[^\s<>\"']+", re.I)
_NUM = r"(-?\d{1,3}(?:\.\d+)?)"
_PAIR = re.compile(_NUM + r"\s*,\s*" + _NUM)
_P_AT = re.compile(r"@" + _NUM + r",\s*" + _NUM)
_P_3D = re.compile(r"!3d" + _NUM + r"!4d" + _NUM)
_P_Q = re.compile(r"[?&](?:q|ll|query|destination|daddr|saddr|center|sll|origin|viewpoint|map_action)=([^&#]+)", re.I)
_SHORT_HOSTS = ("maps.app.goo.gl", "goo.gl", "g.co", "share.google", "app.goo.gl")


def _ok(lat, lon):
    return -90 <= lat <= 90 and -180 <= lon <= 180 and not (lat == 0 and lon == 0)


def _from_text(s: str):
    m = _PAIR.search(s)
    if m:
        a, b = float(m.group(1)), float(m.group(2))
        if _ok(a, b):
            return a, b
    return None


def expand(url: str, timeout: int = 8) -> str:
    """يتتبّع التحويلات للروابط القصيرة. يرجع الرابط النهائي (أو نفسه عند الفشل)."""
    try:
        host = urllib.parse.urlparse(url).netloc.lower()
        if not any(host == h or host.endswith("." + h) for h in _SHORT_HOSTS):
            return url
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Linux; Android 13) POIExporter"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.geturl()
    except Exception:  # noqa: BLE001
        return url


def points_from_url(url: str):
    """كل النقاط الممكنة في الرابط بترتيب ظهورها: قائمة (lat, lon)."""
    u = urllib.parse.unquote(url)
    pts = []
    low = u.lower()
    if "/dir/" in low:                                  # مسار: من/إلى
        seg = u.split("/dir/", 1)[1].split("?")[0].split("/@")[0]
        for part in seg.split("/"):
            c = _from_text(part.replace("+", " "))
            if c:
                pts.append(c)
    for rx in (_P_3D,):
        for m in rx.finditer(u):
            c = (float(m.group(1)), float(m.group(2)))
            if _ok(*c) and c not in pts:
                pts.append(c)
    for m in _P_Q.finditer(u):
        v = m.group(1).replace("+", " ")
        c = _from_text(v)
        if c and c not in pts:
            pts.append(c)
    if not pts:
        m = _P_AT.search(u)
        if m:
            c = (float(m.group(1)), float(m.group(2)))
            if _ok(*c):
                pts.append(c)
    if not pts:
        m = re.search(r"/(?:search|place)/" + _NUM + r",\s*\+?" + _NUM, u)
        if m:
            c = (float(m.group(1)), float(m.group(2)))
            if _ok(*c):
                pts.append(c)
    return pts


def place_name(url: str) -> str:
    u = urllib.parse.unquote(url)
    m = re.search(r"/maps/place/([^/@?]+)", u) or re.search(r"[?&]q=([^&#]+)", u)
    n = m.group(1).replace("+", " ").strip() if m else ""
    return "" if _from_text(n) else n


def plus_in(text: str):
    """يبحث عن Plus Code داخل نص أو رابط (plus.codes/…): يرجع (code, باقي النص)."""
    t = urllib.parse.unquote(text).replace("+", "+")
    m = re.search(r"plus\.codes/([^\s/?#]+)", t, re.I)
    if m and pluscode.is_code(m.group(1)):
        return m.group(1), ""
    for tok in re.finditer(r"(?<![\w+])([23456789CFGHJMPQRVWX0]{2,8}\+[23456789CFGHJMPQRVWX]{2,})(?![\w+])", t, re.I):
        rest = (t[:tok.start()] + " " + t[tok.end():]).strip(" ,،\n\t")
        return tok.group(1), rest
    return "", ""


def resolve(text: str, ref=None, locate=None):
    """يرجع dict: kind, lat, lon, points?, name?  أو يرفع ValueError.
    ref = (lat, lon) مرجع للرموز المختصرة؛ locate(name) → (lat, lon) أو None للبحث عن اسم المنطقة."""
    t = (text or "").strip()
    if not t:
        raise ValueError("empty")
    m = _URL.search(t)
    if m:
        url = m.group(0).rstrip(").,،")
        full = expand(url)
        code, rest = plus_in(full)
        pts = points_from_url(full)
        if pts:
            return {"kind": "gmaps", "lat": pts[0][0], "lon": pts[0][1], "points": [list(p) for p in pts], "name": place_name(full), "url": full}
        if code:
            return _from_code(code, rest, ref, locate, "gmaps")
        code, rest = plus_in(t.replace(url, " "))
        if code:
            return _from_code(code, rest, ref, locate, "pluscode")
        nm = place_name(full)
        if nm:
            return {"kind": "gmaps-name", "name": nm, "url": full}
        raise ValueError("لم أجد إحداثيات في الرابط")
    code, rest = plus_in(t)
    if code:
        return _from_code(code, rest, ref, locate, "pluscode")
    if t.lower().startswith("geo:"):
        c = _from_text(t[4:].split("?")[0])
        if c:
            return {"kind": "geo", "lat": c[0], "lon": c[1]}
    raise ValueError("unrecognized")


def _from_code(code, rest, ref, locate, kind):
    if pluscode.is_short(code):
        base = None
        if rest and locate:
            base = locate(rest)
        if base is None:
            base = ref
        if base is None:
            raise ValueError("الرمز مختصر: اكتب اسم المنطقة بعده (مثل: 9G8F+6W بغداد) أو حرّك الخريطة لتحديد المرجع")
        lat, lon = pluscode.recover(code, base[0], base[1])
    else:
        lat, lon = pluscode.decode(code)
    return {"kind": kind, "lat": lat, "lon": lon, "code": code.upper()}
