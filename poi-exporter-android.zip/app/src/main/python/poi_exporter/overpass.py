"""تحليل استجابة Overpass وبناء المعالم + خط التنزيل المتوازي (4 طلبات معاً)."""
from __future__ import annotations

import json
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence, Set

from . import catalog
from .geo import AreaSpec, build_rings, decimate, set_representative
from .model import LINE, POINT, POLYGON, Feature, Layer

SERVERS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
    "https://lz4.overpass-api.de/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
]
INDEX_MAX_VERTICES = 20000


@dataclass
class Member:
    type: str = ""
    role: str = ""
    geom: Optional[List[tuple]] = None
    lat: float = float("nan")
    lon: float = float("nan")


@dataclass
class Elem:
    type: str = ""
    id: int = 0
    tags: Dict[str, str] = field(default_factory=dict)
    lat: float = float("nan")
    lon: float = float("nan")
    geom: Optional[List[tuple]] = None
    members: Optional[List[Member]] = None

    def tag(self, k: str) -> str:
        return self.tags.get(k, "")


def _geometry(arr) -> List[tuple]:
    out = []
    for p in arr or []:
        if p and "lat" in p and "lon" in p:
            out.append((float(p["lon"]), float(p["lat"])))
    return out


def parse(data) -> List[Elem]:
    """data: نص JSON أو bytes أو dict جاهز."""
    if isinstance(data, (bytes, bytearray)):
        data = data.decode("utf-8")
    if isinstance(data, str):
        data = json.loads(data)
    remark = data.get("remark", "") or ""
    out: List[Elem] = []
    for e in data.get("elements", []):
        el = Elem(type=e.get("type", ""), id=int(e.get("id", 0)), tags=dict(e.get("tags") or {}))
        if "lat" in e:
            el.lat, el.lon = float(e["lat"]), float(e["lon"])
        c = e.get("center")
        if c:
            el.lat, el.lon = float(c["lat"]), float(c["lon"])
        if "geometry" in e:
            el.geom = _geometry(e["geometry"])
        if "members" in e:
            el.members = []
            for m in e["members"]:
                mm = Member(type=m.get("type", ""), role=m.get("role", ""))
                if "geometry" in m:
                    mm.geom = _geometry(m["geometry"])
                if "lat" in m:
                    mm.lat, mm.lon = float(m["lat"]), float(m["lon"])
                el.members.append(mm)
        out.append(el)
    if not out and "error" in remark.lower():
        raise IOError(remark)
    return out


# ---------------------------------------------------------------------------- بناء المعالم
def name_of(e: Elem) -> str:
    return e.tag("name:ar") or e.tag("name") or e.tag("name:en")


def point_from(e: Elem) -> Optional[Feature]:
    lat, lon = e.lat, e.lon
    if lat != lat or lon != lon:  # NaN
        if e.geom:
            tmp = Feature(geom=LINE)
            tmp.add_part(e.geom)
            set_representative(tmp)
            lat, lon = tmp.lat, tmp.lon
        else:
            return None
    f = Feature.point(lat, lon)
    f.id = f"{e.type}/{e.id}"
    f.name = name_of(e)
    return f


def line_from(e: Elem) -> Optional[Feature]:
    if not e.geom or len(e.geom) < 2:
        return None
    f = Feature(geom=LINE, id=f"{e.type}/{e.id}", name=name_of(e))
    f.add_part(e.geom)
    set_representative(f)
    return f


def polygon_from(e: Elem) -> Optional[Feature]:
    f = Feature(geom=POLYGON, id=f"{e.type}/{e.id}", name=name_of(e))
    if e.members is not None:
        outers, inners = [], []
        for m in e.members:
            if m.type != "way" or not m.geom or len(m.geom) < 2:
                continue
            if m.role == "inner":
                inners.append(m.geom)
            elif m.role in ("", "outer"):
                outers.append(m.geom)
        o = build_rings(outers)
        if not o:
            return None
        for r in o:
            f.add_part(r, False)
        for r in build_rings(inners):
            f.add_part(r, True)
    elif e.geom and len(e.geom) >= 4:
        if e.geom[0] != e.geom[-1]:
            return None
        f.add_part(e.geom)
    else:
        return None
    set_representative(f)
    return f


def build_layer_features(elems: Sequence[Elem], d: catalog.LayerDef, arabic: bool = True) -> List[Feature]:
    out, seen = [], set()
    for e in elems:
        if d.geom == POINT:
            f = point_from(e)
        elif d.geom == LINE:
            if e.type != "way":
                continue
            f = line_from(e)
        else:
            f = polygon_from(e)
        if f is None or f.id in seen:
            continue
        seen.add(f.id)
        f.type = ""
        for c in d.clauses:
            if c.matches(e.tags):
                f.type = f"{c.key}={e.tag(c.key)}"
                break
        f.category = d.label(arabic)
        out.append(f)
    return out


def build_pois(elems: Sequence[Elem], cat_ids: Sequence[str], custom: str = "", arabic: bool = True) -> List[Feature]:
    out, seen = [], set()
    cs = catalog.custom_selector(custom)
    custom_key = custom.strip().split("=", 1)[0] if cs else None
    for e in elems:
        f = point_from(e)
        if f is None or f.id in seen:
            continue
        seen.add(f.id)
        done = False
        for cid in cat_ids:
            c = catalog.poi(cid)
            if not c:
                continue
            for cl in c.clauses:
                if cl.matches(e.tags):
                    f.type = f"{cl.key}={e.tag(cl.key)}"
                    f.category = c.label(arabic)
                    done = True
                    break
            if done:
                break
        if not done and custom_key and e.tag(custom_key):
            f.type = f"{custom_key}={e.tag(custom_key)}"
            f.category = "مخصص" if arabic else "Custom"
        out.append(f)
    return out


def admin_level(tags: Dict[str, str]) -> int:
    try:
        return int(tags.get("admin_level", ""))
    except ValueError:
        return -1


# ---------------------------------------------------------------------------- فهرس إداري محلي
class AdminIndex:
    """بحث محلي عن المنطقة الإدارية التي تحوي نقطة (حدود من OSM)."""

    def __init__(self):
        self.entries = []

    def add(self, level: int, poly: Feature) -> None:
        if poly.geom == POLYGON and poly.parts:
            from .geo import bbox
            self.entries.append((level, poly, bbox(poly)))

    def __len__(self):
        return len(self.entries)

    def find(self, level: int, lat: float, lon: float) -> str:
        from .geo import in_polygon
        for lv, poly, bb in self.entries:
            if lv != level or lon < bb[0] or lon > bb[2] or lat < bb[1] or lat > bb[3]:
                continue
            if in_polygon(poly, lon, lat):
                return poly.name
        return ""


def fill_admin(f: Feature, idx: AdminIndex, levels: Sequence[int]) -> None:
    if idx is None or len(idx) == 0:
        return
    if not f.governorate:
        f.governorate = idx.find(levels[0], f.lat, f.lon)
    if not f.qadaa:
        f.qadaa = idx.find(levels[1], f.lat, f.lon)
    if not f.nahiya:
        f.nahiya = idx.find(levels[2], f.lat, f.lon)


def _simplified(poly: Feature) -> Feature:
    c = Feature(geom=POLYGON, name=poly.name, lat=poly.lat, lon=poly.lon)
    for i, p in enumerate(poly.parts):
        c.add_part(decimate(p, INDEX_MAX_VERTICES), poly.is_hole(i))
    return c


# ---------------------------------------------------------------------------- الاستعلامات
HEADER = "[out:json][timeout:180][maxsize:536870912];"   # قيم أصغر ⇒ يجدولها الخادم أسرع


@dataclass
class Params:
    area: AreaSpec = None
    poi_cats: List[str] = field(default_factory=list)
    custom: str = ""
    include_unnamed: bool = False
    layer_ids: Set[str] = field(default_factory=set)
    fill_admin: bool = False
    admin_levels: Sequence[int] = (4, 5, 6)
    arabic: bool = True


@dataclass
class Result:
    layers: List[Layer] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    cancelled: bool = False

    def feature_count(self) -> int:
        return sum(len(l.features) for l in self.layers)


def poi_query(p: Params) -> Optional[str]:
    st = catalog.poi_statements(p.poi_cats, p.custom, p.include_unnamed, p.area)
    return HEADER + "(" + "".join(st) + ");out center qt;" if st else None


def layer_query(d: catalog.LayerDef, a: AreaSpec) -> str:
    typ = "way" if d.geom == LINE else "nwr"
    body = "".join(typ + c.selector() + d.extra + a.overpass() + ";" for c in d.clauses)
    return HEADER + "(" + body + ");" + ("out center qt;" if d.geom == POINT else "out geom qt;")


def admin_query(levels: Sequence[int], a: AreaSpec) -> str:
    lv = "|".join(str(x) for x in dict.fromkeys(levels))
    return HEADER + f'rel["boundary"="administrative"]["admin_level"~"^({lv})$"]' + a.overpass() + ";out geom qt;"


Fetcher = Callable[[str], bytes]


def http_fetcher(servers: Sequence[str] = SERVERS, timeout: int = 180, retries: int = 2,
                 cache_dir: Optional[str] = None, ttl: int = 86400, stagger: float = 3.0) -> Fetcher:
    """ينشئ دالة تنفذ استعلام Overpass بسرعة:
    • طلبات متدرجة (hedged): يبدأ بالخادم الأول، وإن لم يردّ خلال `stagger` ثوانٍ يبدأ الثاني معه، والأسرع يفوز.
    • ضغط gzip (أصغر بـ5–10 مرات على شبكة الهاتف).
    • ذاكرة على القرص لنفس الاستعلام لمدة `ttl` ثانية."""
    import gzip
    import hashlib
    import os
    from concurrent.futures import FIRST_COMPLETED, wait

    def one(url: str, body: bytes) -> bytes:
        req = urllib.request.Request(url, data=body, headers={"User-Agent": "poi-exporter-py/3.6", "Accept-Encoding": "gzip"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = r.read()
            if r.headers.get("Content-Encoding", "").lower() == "gzip" or data[:2] == b"\x1f\x8b":
                data = gzip.decompress(data)
        if data[:1] not in (b"{", b" ", b"\n"):
            raise IOError("استجابة غير صالحة من الخادم")
        head = data[:600].decode("utf-8", "ignore")
        if '"remark"' in data[-1500:].decode("utf-8", "ignore") or '"remark"' in head:
            tail = data[-1500:].decode("utf-8", "ignore")
            if "runtime error" in tail or "timed out" in tail or "out of memory" in tail or "rate_limited" in tail:
                raise IOError("الخادم مشغول أو انتهت مهلته؛ جرّب منطقة أصغر")
        return data

    def fetch(query: str) -> bytes:
        cfile = None
        if cache_dir:
            os.makedirs(cache_dir, exist_ok=True)
            cfile = os.path.join(cache_dir, hashlib.sha1(query.encode()).hexdigest() + ".json.gz")
            try:
                if time.time() - os.path.getmtime(cfile) < ttl:
                    return gzip.decompress(open(cfile, "rb").read())
            except (OSError, EOFError):
                pass
        body = urllib.parse.urlencode({"data": query}).encode()
        last: Exception = IOError("no server")
        for attempt in range(retries + 1):
            ex = ThreadPoolExecutor(max_workers=len(servers))
            pending, idx = set(), 0
            try:
                pending.add(ex.submit(one, servers[idx], body))
                idx += 1
                while pending:
                    done, _ = wait(pending, timeout=stagger, return_when=FIRST_COMPLETED)
                    for f in done:
                        pending.discard(f)
                        try:
                            data = f.result()
                        except Exception as e:  # noqa: BLE001
                            last = e
                            continue
                        if cfile and b'"elements": []' not in data[:400].replace(b'"elements":[]', b'"elements": []'):
                            try:
                                open(cfile, "wb").write(gzip.compress(data, 3))
                            except OSError:
                                pass
                        return data
                    if idx < len(servers):
                        pending.add(ex.submit(one, servers[idx], body))
                        idx += 1
            finally:
                ex.shutdown(wait=False)
            time.sleep(1.0)
        raise IOError("تعذّر الاتصال بكل خوادم الخرائط (%s)" % last)
    return fetch


def _fetch_elems(fetcher: Fetcher, q: str) -> List[Elem]:
    return parse(fetcher(q))


def run(p: Params, fetcher: Fetcher, progress: Optional[Callable[[str, int, int], None]] = None,
        cancelled: Callable[[], bool] = lambda: False) -> Result:
    """ينزّل كل الطبقات المحددة بالتوازي ويجهزها للعرض والتصدير."""
    res = Result()
    defs = [d for d in catalog.LAYERS if d.id in p.layer_ids]
    admin_wanted = [i in p.layer_ids for i in catalog.ADMIN_IDS]
    need_admin = p.fill_admin or any(admin_wanted)
    poi_q = poi_query(p) if (p.poi_cats or (p.custom and p.custom.strip())) else None
    steps = (1 if poi_q else 0) + len(defs) + (1 if need_admin else 0)
    counter = [0]
    note = progress or (lambda *_: None)

    def step(name):
        counter[0] += 1
        note(name, counter[0], steps)

    def admin_task():
        step("admin")
        try:
            by_level = [[], [], []]
            idx = AdminIndex()
            for e in _fetch_elems(fetcher, admin_query(p.admin_levels, p.area)):
                lv = admin_level(e.tags)
                poly = polygon_from(e)
                if poly is None:
                    continue
                poly.type = f"admin_level={lv}"
                for i in range(3):
                    if p.admin_levels[i] == lv:
                        by_level[i].append(poly)
                        idx.add(lv, _simplified(poly))
            return by_level, idx, ("admin:none" if len(idx) == 0 else None)
        except IOError as e:
            return None, None, f"admin:{e}"

    def poi_task():
        step("poi")
        try:
            feats = build_pois(_fetch_elems(fetcher, poi_q), p.poi_cats, p.custom, p.arabic)
            return Layer(catalog.K_POI, "المعالم" if p.arabic else "Landmarks", POINT, feats, kind="download"), None
        except IOError as e:
            return None, f"poi:{e}"

    def layer_task(d):
        step(d.id)
        try:
            feats = build_layer_features(_fetch_elems(fetcher, layer_query(d, p.area)), d, p.arabic)
            return Layer(d.id, d.label(p.arabic), d.geom, feats, kind="download"), None
        except IOError as e:
            return None, f"{d.id}:{e}"

    with ThreadPoolExecutor(max_workers=6) as ex:
        admin_f = ex.submit(admin_task) if need_admin else None
        poi_f = ex.submit(poi_task) if poi_q else None
        layer_fs = [ex.submit(layer_task, d) for d in defs]
        by_level, index = None, None
        if admin_f:
            by_level, index, warn = admin_f.result()
            if warn:
                res.warnings.append(warn)
        for fut in ([poi_f] if poi_f else []) + layer_fs:
            layer, warn = fut.result()
            if layer:
                res.layers.append(layer)
            if warn:
                res.warnings.append(warn)
    if by_level:
        for i in range(3):
            if not admin_wanted[i]:
                continue
            l = Layer(catalog.ADMIN_IDS[i], catalog.admin_label(i, p.arabic), POLYGON, kind="reference")
            for f in by_level[i]:
                f.category = catalog.admin_label(i, p.arabic)
                l.features.append(f)
            res.layers.append(l)
    res.cancelled = cancelled()
    for l in res.layers:
        is_admin = l.id.startswith("admin_")
        if (p.area.circle or p.area.is_rotated()) and not is_admin:
            l.features = [f for f in l.features if f.geom != POINT or p.area.contains(f.lat, f.lon)]
        if p.fill_admin and index is not None and not is_admin:
            for f in l.features:
                fill_admin(f, index, p.admin_levels)
    return res


# ------------------------------------------------------------------ مناطق كبيرة جداً: تقسيم تلقائي إلى بلاطات
TILE_KM2 = 200.0


def plan_tiles(a: AreaSpec, tile_km: float = 14.0):
    """يقسّم صندوق المنطقة إلى مستطيلات متقاربة الحجم (بلا حدّ أقصى للمنطقة)."""
    import math
    lat_mid = (a.south + a.north) / 2
    dlat = tile_km / 111.32
    dlon = tile_km / (111.32 * max(0.1, math.cos(math.radians(lat_mid))))
    ny = max(1, math.ceil((a.north - a.south) / dlat))
    nx = max(1, math.ceil((a.east - a.west) / dlon))
    hy, hx = (a.north - a.south) / ny, (a.east - a.west) / nx
    out = []
    for j in range(ny):
        for i in range(nx):
            s, w = a.south + j * hy, a.west + i * hx
            t = AreaSpec.rect(s, w, s + hy, w + hx)
            if a.circle:                                    # تجاهل البلاطات خارج الدائرة
                cy = min(max(a.clat, s), s + hy)
                cx = min(max(a.clon, w), w + hx)
                from .geo import haversine
                if haversine(a.clat, a.clon, cy, cx) > a.radius:
                    continue
            out.append(t)
    return out


PROFILES = {
    # قبل قبل الإضافة: خادم واحد بالتتابع، بلاطات متتابعة، بلا ذاكرة
    "old":  dict(stagger=45.0, retries=1, cache=False, workers=1, tile_km=14.0),
    # قبل هذه الإضافة: طلبات متدرجة مع بلاطات متتابعة
    "prev": dict(stagger=3.0, retries=2, cache=True, workers=1, tile_km=14.0),
    # هذه الإضافة: بلاطات متوازية + استئناف من الذاكرة + بلاطات أكبر + إعادة محاولة أكثر
    "fast": dict(stagger=1.5, retries=4, cache=True, workers=3, tile_km=22.0),
}


def profile_of(name) -> dict:
    return PROFILES.get(name) or PROFILES["fast"]


def run_tiled(p: Params, fetcher: Fetcher, progress=None, cancelled=lambda: False, workers: int = 1, tile_km: float = 14.0) -> Result:
    """يشغّل `run` على كل بلاطة (بالتوازي عند workers>1) ثم يدمج النتائج بلا تكرار (حسب معرّف OSM)."""
    import threading
    tiles = plan_tiles(p.area, tile_km)
    merged: Dict[str, Layer] = {}
    seen: Dict[str, set] = {}
    out = Result()
    okc = [0]
    donec = [0]
    lock = threading.Lock()
    special = bool(p.area.circle or p.area.is_rotated())

    def work(i, t):
        if cancelled():
            return
        sub = Params(area=t, poi_cats=p.poi_cats, custom=p.custom, include_unnamed=p.include_unnamed, layer_ids=p.layer_ids,
                     fill_admin=p.fill_admin, admin_levels=p.admin_levels, arabic=p.arabic)
        try:
            r = run(sub, fetcher, None, cancelled)
        except IOError as e:
            with lock:
                out.warnings.append(f"tile {i + 1}: {e}")
                donec[0] += 1
                if progress:
                    progress("tile", donec[0], len(tiles))
            return
        with lock:
            okc[0] += 1
            donec[0] += 1
            out.warnings += [w for w in r.warnings if w not in out.warnings]
            for l in r.layers:
                M = merged.get(l.id)
                if M is None:
                    M = merged[l.id] = Layer(l.id, l.label, l.geom, [], kind=l.kind)
                    seen[l.id] = set()
                for f in l.features:
                    key = f.id or f"{f.name}|{round(f.lat, 6)}|{round(f.lon, 6)}"
                    if key in seen[l.id]:
                        continue
                    seen[l.id].add(key)
                    if f.geom == POINT and special and not p.area.contains(f.lat, f.lon) and not l.id.startswith("admin_"):
                        continue
                    M.features.append(f)
            if progress:
                progress("tile", donec[0], len(tiles))

    if progress:
        progress("tile", 0, len(tiles))
    with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        list(ex.map(lambda it: work(*it), enumerate(tiles)))
    if cancelled():
        out.cancelled = True
    if not okc[0] and tiles and not out.cancelled:
        raise IOError(out.warnings[0] if out.warnings else "تعذّر الجلب")
    out.layers = list(merged.values())
    return out
