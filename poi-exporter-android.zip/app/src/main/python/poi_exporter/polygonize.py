"""تحويل شبكة خطوط (متقاطعة/مغلقة) إلى مضلعات — Feature To Polygon. بايثون خالص بلا shapely."""
from __future__ import annotations

import math
from collections import defaultdict
from typing import Dict, List, Sequence, Tuple

from .geoops import Local
from .model import Feature

MAX_SEGS = 40000


def _key(p, q=1e-3):
    return (round(p[0] / q), round(p[1] / q))


def _inter(a, b, c, d):
    """نقطة تقاطع القطعتين ab وcd (t على ab) أو None."""
    r = (b[0] - a[0], b[1] - a[1]); s = (d[0] - c[0], d[1] - c[1])
    den = r[0] * s[1] - r[1] * s[0]
    if abs(den) < 1e-12:
        return None
    qp = (c[0] - a[0], c[1] - a[1])
    t = (qp[0] * s[1] - qp[1] * s[0]) / den
    u = (qp[0] * r[1] - qp[1] * r[0]) / den
    e = 1e-9
    if -e <= t <= 1 + e and -e <= u <= 1 + e:
        return min(1.0, max(0.0, t)), min(1.0, max(0.0, u))
    return None


def polygonize(lines: Sequence[Feature]) -> List[List[Tuple[float, float]]]:
    """يرجع قائمة حلقات (lon,lat) مغلقة؛ الثقوب غير مطروحة (كل وجه مضلع مستقل)."""
    loc = Local(lines)
    segs = []
    for f in lines:
        for part in f.parts:
            pts = [loc.to(p) for p in part]
            segs += [(pts[i], pts[i + 1]) for i in range(len(pts) - 1) if pts[i] != pts[i + 1]]
    if not segs:
        return []
    if len(segs) > MAX_SEGS:
        raise ValueError("عدد القطع كبير جداً (%d)" % len(segs))
    xs = [p[0] for s in segs for p in s]; ys = [p[1] for s in segs for p in s]
    cell = max(max(xs) - min(xs), max(ys) - min(ys), 1.0) / 64.0
    grid: Dict[tuple, list] = defaultdict(list)
    for i, (a, b) in enumerate(segs):
        for gx in range(int(min(a[0], b[0]) // cell), int(max(a[0], b[0]) // cell) + 1):
            for gy in range(int(min(a[1], b[1]) // cell), int(max(a[1], b[1]) // cell) + 1):
                grid[(gx, gy)].append(i)
    cuts: List[List[float]] = [[0.0, 1.0] for _ in segs]
    seen = set()
    for ids in grid.values():
        for ii in range(len(ids)):
            for jj in range(ii + 1, len(ids)):
                i, j = ids[ii], ids[jj]
                if (i, j) in seen:
                    continue
                seen.add((i, j))
                r = _inter(segs[i][0], segs[i][1], segs[j][0], segs[j][1])
                if r:
                    cuts[i].append(r[0]); cuts[j].append(r[1])
    pos: Dict[tuple, Tuple[float, float]] = {}
    adj: Dict[tuple, set] = defaultdict(set)
    for (a, b), ts in zip(segs, cuts):
        pts = []
        for t in sorted(set(round(t, 9) for t in ts)):
            p = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
            k = _key(p)
            pos.setdefault(k, p)
            pts.append(k)
        for u, v in zip(pts, pts[1:]):
            if u != v:
                adj[u].add(v); adj[v].add(u)
    # إزالة النهايات المعلّقة
    stack = [k for k, v in adj.items() if len(v) < 2]
    while stack:
        k = stack.pop()
        for n in list(adj.get(k, ())):
            adj[n].discard(k)
            if len(adj[n]) < 2:
                stack.append(n)
        adj.pop(k, None)
    order = {}
    for u, ns in adj.items():
        order[u] = sorted(ns, key=lambda v: math.atan2(pos[v][1] - pos[u][1], pos[v][0] - pos[u][0]))
    used = set()
    out = []
    for u in list(adj):
        for v in adj[u]:
            if (u, v) in used:
                continue
            ring, a, b, guard = [], u, v, 0
            while (a, b) not in used and guard < 200000:
                used.add((a, b)); ring.append(a); guard += 1
                lst = order[b]
                i = lst.index(a)
                a, b = b, lst[(i - 1) % len(lst)]
            if len(ring) >= 3:
                pts = [pos[k] for k in ring]
                area = sum(pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1] for i in range(len(pts))) / 2
                if area > 1e-6:
                    r = [loc.back(p) for p in pts]
                    r.append(r[0])
                    out.append(r)
    return out
