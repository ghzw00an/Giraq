"""أسماء عربية لحقل النوع (Type) بدل رموز OSM مثل highway=tertiary."""
from __future__ import annotations

from typing import Dict

HIGHWAY = {
    "motorway": "طريق سريع (أوتوستراد)", "trunk": "طريق رئيسي سريع", "primary": "طريق رئيسي", "secondary": "طريق ثانوي",
    "tertiary": "طريق فرعي رئيسي", "unclassified": "طريق غير مصنف", "residential": "طريق سكني", "living_street": "طريق محلي",
    "service": "طريق خدمة", "track": "طريق ترابي / زراعي", "road": "طريق غير محدد",
    "motorway_link": "وصلة طريق سريع", "trunk_link": "وصلة طريق رئيسي سريع", "primary_link": "وصلة طريق رئيسي",
    "secondary_link": "وصلة طريق ثانوي", "tertiary_link": "وصلة طريق فرعي", "path": "مسار مشاة", "footway": "ممر مشاة",
    "pedestrian": "منطقة مشاة", "steps": "درج", "cycleway": "مسار دراجات", "bridleway": "مسار خيول", "construction": "طريق قيد الإنشاء",
    "proposed": "طريق مقترح", "busway": "مسار حافلات", "raceway": "حلبة سباق", "bus_stop": "موقف حافلات", "crossing": "عبور مشاة",
    "traffic_signals": "إشارة مرور", "rest_area": "منطقة استراحة", "services": "محطة خدمات طريق", "turning_circle": "دوّار رجوع",
    "street_lamp": "عمود إنارة", "milestone": "علامة مسافة", "speed_camera": "كاميرا سرعة",
}
POWER = {"line": "خط كهرباء (نقل ضغط عالٍ)", "minor_line": "خط كهرباء (توزيع)", "cable": "كابل كهرباء", "tower": "برج كهرباء", "pole": "عمود كهرباء",
         "substation": "محطة تحويل كهرباء", "plant": "محطة توليد كهرباء", "generator": "مولّد كهرباء", "transformer": "محوّلة كهرباء",
         "switch": "مفتاح كهرباء", "portal": "بوابة خطوط كهرباء", "terminal": "نهاية خط كهرباء"}
RAILWAY = {"rail": "سكة قطار", "light_rail": "سكة قطار خفيف", "narrow_gauge": "سكة ضيقة", "subway": "مترو", "tram": "ترام", "monorail": "قطار أحادي السكة",
           "construction": "سكة قيد الإنشاء", "disused": "سكة غير مستخدمة", "abandoned": "سكة مهجورة", "station": "محطة قطار", "halt": "محطة توقف",
           "stop": "نقطة توقف قطار", "tram_stop": "محطة ترام", "subway_entrance": "مدخل مترو", "level_crossing": "تقاطع سكة", "crossing": "عبور سكة"}
WATERWAY = {"river": "نهر", "canal": "قناة", "dam": "سد", "stream": "جدول", "wadi": "وادٍ جاف", "drain": "مصرف", "ditch": "ساقية", "weir": "ناظم", "waterfall": "شلال",
            "lock_gate": "بوابة هويس", "riverbank": "ضفة نهر", "dock": "رصيف مائي", "boatyard": "ورشة قوارب"}
WATER = {"lake": "بحيرة", "reservoir": "خزان مائي", "pond": "بركة", "basin": "حوض", "lagoon": "بحيرة ساحلية", "river": "مجرى نهر", "canal": "قناة", "oxbow": "بحيرة هلالية",
         "stream_pool": "بركة جدول", "wastewater": "مياه صرف", "moat": "خندق مائي", "fountain": "نافورة", "pool": "مسبح"}
BRIDGE = {"yes": "جسر", "viaduct": "جسر علوي (فياض)", "movable": "جسر متحرك", "cantilever": "جسر ناتئ", "suspension": "جسر معلّق", "aqueduct": "جسر قناة مائية",
          "boardwalk": "ممشى خشبي", "culvert": "عبّارة"}
MAN_MADE = {"mast": "صارية / برج اتصالات", "tower": "برج", "communications_tower": "برج اتصالات", "chimney": "مدخنة", "water_tower": "برج مياه", "storage_tank": "خزان",
            "silo": "صومعة", "pier": "رصيف بحري", "bridge": "جسر", "wastewater_plant": "محطة معالجة مياه الصرف", "water_works": "محطة مياه", "works": "معمل / مصنع",
            "petroleum_well": "بئر نفط", "windmill": "طاحونة", "lighthouse": "منارة", "survey_point": "نقطة مسح", "breakwater": "حاجز أمواج", "dyke": "سدة ترابية",
            "embankment": "ساتر", "flare": "شعلة غاز", "crane": "رافعة", "reservoir_covered": "خزان مغطى", "pumping_station": "محطة ضخ", "monitoring_station": "محطة رصد",
            "obelisk": "مسلة", "cutline": "قطع خطي", "gasometer": "خزان غاز", "kiln": "فرن", "mineshaft": "فتحة منجم", "adit": "نفق منجم", "pipeline": "خط أنابيب",
            "antenna": "هوائي", "beacon": "منارة إرشاد", "street_cabinet": "خزانة شارع", "telescope": "منظار", "tunnel": "نفق", "wellhead": "رأس بئر", "outfall": "مصب صرف"}
NATURAL = {"peak": "قمة جبل", "hill": "تل", "spring": "عين ماء", "cave_entrance": "مدخل كهف", "volcano": "بركان", "saddle": "ممر جبلي", "tree": "شجرة", "rock": "صخرة",
           "stone": "حجر", "wood": "غابة", "scrub": "أحراش", "grassland": "مراعي", "heath": "أرض عشبية", "wetland": "أهوار ومستنقعات", "beach": "شاطئ", "sand": "رمال",
           "bare_rock": "صخور مكشوفة", "scree": "منحدر صخري", "mud": "طين", "shingle": "حصى", "cliff": "جرف", "ridge": "سلسلة جبلية", "valley": "وادٍ", "arete": "حافة جبلية",
           "bay": "خليج", "cape": "رأس بحري", "strait": "مضيق", "coastline": "خط الساحل", "glacier": "جليد", "water": "مسطح مائي", "plateau": "هضبة",
           "mountain_range": "سلسلة جبال", "mountain": "جبل", "plain": "سهل", "dune": "كثبان رملية", "desert": "صحراء", "gully": "مجرى سيل", "tree_row": "صف أشجار"}
LANDUSE = {"forest": "غابات", "meadow": "مروج", "farmland": "أرض زراعية", "orchard": "بستان", "farmyard": "مزرعة", "cemetery": "مقبرة", "residential": "منطقة سكنية",
           "commercial": "منطقة تجارية", "industrial": "منطقة صناعية", "military": "منطقة عسكرية", "retail": "منطقة تسوق", "grass": "عشب", "basin": "حوض", "reservoir": "خزان",
           "quarry": "محجر", "landfill": "مكب نفايات", "railway": "أراضي سكك", "religious": "منطقة دينية", "construction": "قيد الإنشاء", "brownfield": "أرض متروكة"}
TOURISM = {"attraction": "معلم سياحي", "museum": "متحف", "viewpoint": "نقطة مشاهدة", "zoo": "حديقة حيوانات", "theme_park": "مدينة ألعاب", "gallery": "معرض فني",
           "hotel": "فندق", "guest_house": "بيت ضيافة", "motel": "موتيل", "hostel": "نُزل", "information": "مركز معلومات", "picnic_site": "موقع نزهة", "camp_site": "مخيم",
           "artwork": "عمل فني", "apartment": "شقق سياحية", "resort": "منتجع"}
HISTORIC = {"archaeological_site": "موقع أثري", "castle": "قلعة", "ruins": "أطلال", "monument": "نصب تذكاري", "memorial": "نصب تذكاري", "fort": "حصن", "tomb": "ضريح",
            "wayside_shrine": "مزار", "city_gate": "بوابة مدينة", "manor": "قصر", "ship": "سفينة تاريخية", "building": "مبنى تاريخي", "yes": "موقع تاريخي", "wall": "سور تاريخي",
            "tower": "برج تاريخي", "shrine": "مقام", "church": "كنيسة تاريخية", "mosque": "جامع تاريخي", "palace": "قصر"}
AMENITY = {"hospital": "مستشفى", "clinic": "مستوصف", "pharmacy": "صيدلية", "doctors": "عيادة طبيب", "dentist": "عيادة أسنان", "school": "مدرسة", "kindergarten": "روضة",
           "university": "جامعة", "college": "كلية", "library": "مكتبة", "place_of_worship": "دار عبادة", "bank": "مصرف", "atm": "صراف آلي", "restaurant": "مطعم", "fast_food": "وجبات سريعة",
           "cafe": "مقهى", "fuel": "محطة وقود", "police": "مركز شرطة", "fire_station": "محطة إطفاء", "post_office": "مكتب بريد", "townhall": "بلدية", "courthouse": "محكمة",
           "marketplace": "سوق", "bus_station": "كراج / محطة حافلات", "parking": "موقف سيارات", "toilets": "مرافق صحية", "embassy": "سفارة", "theatre": "مسرح", "cinema": "سينما",
           "arts_centre": "مركز فني", "community_centre": "مركز مجتمعي", "social_facility": "دار رعاية", "bureau_de_change": "صيرفة", "bar": "بار", "pub": "نادٍ ليلي",
           "drinking_water": "مصدر مياه شرب", "waste_basket": "سلة نفايات", "bench": "مقعد", "shelter": "مظلة", "taxi": "موقف تكسي", "car_wash": "مغسلة سيارات", "car_rental": "تأجير سيارات",
           "veterinary": "عيادة بيطرية", "training": "معهد تدريب", "research_institute": "معهد بحثي", "recycling": "نقطة تدوير", "fountain": "نافورة", "grave_yard": "مقبرة", "ferry_terminal": "مرسى عبّارات"}
SHOP = {"supermarket": "سوبرماركت", "mall": "مول", "convenience": "بقالة", "bakery": "مخبز", "butcher": "ملحمة", "clothes": "ملابس", "shoes": "أحذية", "mobile_phone": "موبايلات",
        "electronics": "إلكترونيات", "hairdresser": "حلاق / صالون", "car_repair": "تصليح سيارات", "car": "معرض سيارات", "jewelry": "مجوهرات", "furniture": "أثاث", "hardware": "مواد بناء وأدوات",
        "greengrocer": "خضرة وفواكه", "pharmacy": "صيدلية", "kiosk": "كشك", "books": "مكتبة تجارية", "florist": "محل ورد", "confectionery": "حلويات", "general": "محل عام", "yes": "محل"}
LEISURE = {"park": "متنزه", "garden": "حديقة", "stadium": "ملعب", "pitch": "ملعب صغير", "sports_centre": "مركز رياضي", "swimming_pool": "مسبح", "playground": "ملعب أطفال",
           "fitness_centre": "نادٍ رياضي", "golf_course": "ملعب غولف", "marina": "مرسى قوارب", "nature_reserve": "محمية طبيعية", "track": "مضمار", "water_park": "مدينة مائية"}
OFFICE = {"government": "دائرة حكومية", "telecommunication": "شركة اتصالات", "company": "شركة", "ngo": "منظمة", "association": "جمعية", "political_party": "مكتب حزب",
          "lawyer": "مكتب محاماة", "estate_agent": "مكتب عقارات", "insurance": "تأمين", "employment_agency": "مكتب توظيف", "yes": "مكتب"}
HEALTHCARE = {"laboratory": "مختبر", "hospital": "مستشفى", "clinic": "مستوصف", "pharmacy": "صيدلية", "doctor": "عيادة طبيب", "dentist": "عيادة أسنان"}
GENERIC = {"amenity": "مرفق", "shop": "محل", "tourism": "موقع سياحي", "leisure": "ترفيه", "office": "مكتب", "building": "مبنى", "man_made": "منشأة", "natural": "عنصر طبيعي",
           "landuse": "استعمال أرض", "highway": "طريق", "railway": "سكة قطار", "power": "منشأة كهرباء", "waterway": "مجرى مائي", "historic": "موقع تاريخي", "healthcare": "مرفق صحي",
           "military": "منشأة عسكرية", "barrier": "حاجز", "emergency": "خدمة طوارئ", "craft": "حرفة", "aeroway": "منشأة مطار", "public_transport": "نقل عام", "place": "موقع",
           "telecom": "اتصالات", "tower:type": "برج", "communication:mobile_phone": "برج اتصالات", "bridge": "جسر", "diplomatic": "تمثيل دبلوماسي", "internet_access": "نقطة انترنت",
           "communication:internet": "برج انترنت", "communication:radio": "برج بث", "operator:type": "جهة مشغّلة", "industrial": "موقع صناعي", "farm": "مزرعة", "water": "مسطح مائي"}
BUILDING = {"yes": "مبنى", "house": "منزل", "apartments": "عمارة سكنية", "school": "مبنى مدرسة", "hospital": "مبنى مستشفى", "mosque": "جامع", "church": "كنيسة", "commercial": "مبنى تجاري",
            "industrial": "مبنى صناعي", "warehouse": "مخزن", "retail": "مبنى تجاري", "telecom_exchange": "بدالة اتصالات", "government": "مبنى حكومي", "public": "مبنى عام", "service": "مبنى خدمات"}
TELECOM = {"exchange": "بدالة", "data_center": "مركز بيانات", "central_office": "بدالة مركزية", "internet_exchange_point": "نقطة تبادل انترنت", "service_device": "جهاز خدمة اتصالات"}
RELIGION = {"muslim": "جامع", "christian": "كنيسة", "yazidi": "معبد إيزيدي", "jewish": "كنيس", "sabian": "معبد صابئي"}

TABLES: Dict[str, Dict[str, str]] = {"highway": HIGHWAY, "power": POWER, "railway": RAILWAY, "waterway": WATERWAY, "man_made": MAN_MADE, "natural": NATURAL, "landuse": LANDUSE,
                                     "tourism": TOURISM, "historic": HISTORIC, "amenity": AMENITY, "shop": SHOP, "leisure": LEISURE, "office": OFFICE, "healthcare": HEALTHCARE,
                                     "building": BUILDING, "telecom": TELECOM}
SUBSTANCE = {"oil": "نفط", "gas": "غاز", "water": "مياه", "sewage": "صرف صحي", "fuel": "وقود", "petroleum": "نفط", "hydrogen": "هيدروجين", "steam": "بخار"}


def ar_type(tags: Dict[str, str], key: str, value: str) -> str:
    """يرجع اسماً عربياً للنوع. القيم المجهولة تأخذ اسم المفتاح العربي العام (وليس رمز OSM)."""
    v = (value or "").strip()
    if key == "man_made" and v == "pipeline":
        s = SUBSTANCE.get((tags.get("substance") or "").split(";")[0].strip().lower(), "")
        return f"خط أنابيب {s}".strip()
    if key == "bridge":
        foot = tags.get("highway") in ("footway", "path", "pedestrian", "steps", "cycleway")
        return "جسر مشاة" if foot else BRIDGE.get(v, "جسر")
    if key == "natural" and v == "water":
        return WATER.get((tags.get("water") or "").lower(), "مسطح مائي")
    if key == "amenity" and v == "place_of_worship":
        return RELIGION.get((tags.get("religion") or "").lower(), "دار عبادة")
    if key == "highway" and (v in ("footway", "path", "pedestrian", "steps", "cycleway")) and tags.get("bridge") not in (None, "", "no"):
        return "جسر مشاة" if v != "cycleway" else "جسر دراجات"
    t = TABLES.get(key)
    if t and v in t:
        return t[v]
    if key in GENERIC:
        return GENERIC[key]
    return "عنصر"
