"""الجيل الثالث: إعادة الضبط، الدمج، التنقيط (نقاط/خطوط/مساحات)، محوّل الملفات، الملفات الواردة من تطبيقات أخرى."""
from __future__ import annotations

import os
import re
import shutil
import tempfile
import threading
import time
import uuid

from flask import jsonify, request, send_file

from . import apiv2, formats
from .model import LINE, POINT, POLYGON, Feature, Layer
from .coords import Crs

_CONV: dict = {}
_LOCK = threading.Lock()


def _db_path() -> str:
    return os.environ.get("POI_DB") or os.path.join(os.path.expanduser("~"), "poi_workspace.db")


def _incoming_dir() -> str:
    d = os.path.join(os.path.expanduser("~"), "incoming")
    os.makedirs(d, exist_ok=True)
    return d


def _fill(feats):
    try:
        from .webapp import fast_fill
        fast_fill([f for f in feats if f.geom == POINT])
    except Exception:  # noqa: BLE001
        pass


def _layer_by_name(w, name: str, geom: int):
    for d in apiv2.datasets(w):
        if d["label"] == name and d["kind"] == "user":
            r = w.db.execute("SELECT geom FROM layer WHERE id=?", (d["id"],)).fetchone()
            if r and r["geom"] == geom:
                return d["id"]
    return w.add_layer(name, geom).id


def _parse(path: str, crs):
    """يقرأ ملفاً (أي صيغة مدعومة)، ومع الجداول يجرّب مناطق UTM العراقية تلقائياً."""
    err = None
    res = None
    try:
        res = formats.import_file(path, src_crs=crs)
    except (ValueError, KeyError, IOError) as e:
        err = str(e)
    if (res is None or res.feature_count() == 0) and crs is None and path.lower().endswith((".csv", ".xlsx", ".xls", ".txt")):
        best, best_n = None, 0
        for ep in (32638, 32637, 32639):
            try:
                r2 = formats.import_file(path, src_crs=Crs.of(ep))
            except (ValueError, KeyError, IOError):
                continue
            n = sum(1 for l in r2.layers for f in l.features if 28 < f.lat < 38 and 38 < f.lon < 49.5)
            if n > best_n:
                best, best_n = r2, n
        if best is not None:
            res = best
    if res is None:
        raise ValueError(err or "تعذّرت قراءة الملف")
    if res.feature_count() == 0:
        raise ValueError("لا توجد عناصر في الملف")
    return res


def register(app):
    # ------------------------------------------------------------ إعادة ضبط البرنامج
    @app.post("/api/reset")
    def reset_all():
        if (request.get_json(force=True, silent=True) or {}).get("confirm") != "RESET":
            return jsonify(error="التأكيد مطلوب"), 400
        home = os.path.expanduser("~")
        for suffix in ("", "-wal", "-shm", "-journal"):
            try:
                os.remove(_db_path() + suffix)
            except OSError:
                pass
        for d in (os.path.join(home, "poi_data"), os.path.join(home, "incoming")):
            shutil.rmtree(d, ignore_errors=True)
        _CONV.clear()
        return jsonify(ok=True)

    # ------------------------------------------------------------ الدمج
    @app.post("/api/merge")
    def merge():
        """يدمج مجموعات كاملة و/أو معالم محددة في مجموعة واحدة (جديدة أو موجودة)."""
        j = request.get_json(force=True)
        lids, fids, target = j.get("layers") or [], j.get("ids") or [], j.get("target") or ""
        name = (j.get("name") or "").strip() or "مجموعة مدمجة"
        copy_only = bool(j.get("copy"))
        w = apiv2._ws()
        try:
            feats = []
            for lid in lids:
                l = apiv2._layer_obj(w, lid)
                if l:
                    feats += l.features
            have = {f.id for f in feats}
            for fid in fids:
                if fid not in have:
                    f = w.feature(fid)
                    if f:
                        feats.append(f)
            if len(feats) < 2 and not target:
                return jsonify(error="اختر معلمين أو أكثر للدمج"), 400
            by_geom = {}
            for f in feats:
                by_geom.setdefault(f.geom, []).append(f)
            made = []
            for g, fs in by_geom.items():
                suffix = "" if len(by_geom) == 1 else {POINT: " (نقاط)", LINE: " (خطوط)", POLYGON: " (مساحات)"}[g]
                if target:
                    r = w.db.execute("SELECT geom FROM layer WHERE id=? AND deleted=0", (target,)).fetchone()
                    if r and r["geom"] == g:
                        tid = target
                    else:
                        tid = w.add_layer(name + suffix, g).id
                else:
                    tid = w.add_layer(name + suffix, g).id
                made.append(tid)
                ids = [f.id for f in fs]
                if copy_only:
                    cp = []
                    for f in fs:
                        c = f.copy()
                        c.id = Feature.new_id()
                        cp.append(c)
                    w.add_features(tid, cp, "دمج")
                else:
                    w.move_features(ids, tid, "دمج")
            if j.get("delete_sources") and not copy_only:
                for lid in lids:
                    if lid not in made and not apiv2._layer_obj(w, lid).features:
                        w.delete_layer(lid)
            return jsonify(ok=True, layers=made, n=len(feats))
        finally:
            w.close()

    # ------------------------------------------------------------ التنقيط
    @app.post("/api/digitize")
    def digitize():
        """يحفظ ما رُسم على الخريطة: نقاط أو خط أو مساحة في طبقة باسم يختاره المستخدم."""
        j = request.get_json(force=True)
        kind = j.get("kind", "point")
        pts = j.get("points") or []
        layer = (j.get("layer") or "").strip() or "التنقيط"
        base = dict(name=(j.get("name") or "").strip(), type=(j.get("type") or "").strip(), category=(j.get("Gategory") or "").strip())
        feats = []
        if kind == "point":
            for i, p in enumerate(pts):
                nm = base["name"] + (f" {i + 1}" if base["name"] and len(pts) > 1 else "")
                feats.append(Feature.point(float(p[0]), float(p[1]), id=Feature.new_id(), **{**base, "name": nm}))
            geom = POINT
        else:
            if len(pts) < (2 if kind == "line" else 3):
                return jsonify(error="نقاط غير كافية"), 400
            geom = LINE if kind == "line" else POLYGON
            f = Feature(geom=geom, id=Feature.new_id(), **base)
            coords = [(float(p[1]), float(p[0])) for p in pts]
            if geom == POLYGON and coords[0] != coords[-1]:
                coords.append(coords[0])
            f.add_part(coords)
            from .geo import set_representative
            set_representative(f)
            if j.get("attrs"):
                f.attrs.update({str(k): str(v) for k, v in j["attrs"].items()})
            feats.append(f)
        _fill(feats)
        w = apiv2._ws()
        try:
            lid = _layer_by_name(w, layer, geom)
            w.add_features(lid, feats, "تنقيط")
        finally:
            w.close()
        return jsonify(ok=True, layer=lid, n=len(feats))

    # ------------------------------------------------------------ محوّل الملفات
    @app.post("/api/convert2")
    def convert2_open():
        up = request.files["file"]
        d = tempfile.mkdtemp()
        src = os.path.join(d, os.path.basename(up.filename or "file"))
        up.save(src)
        try:
            crs = Crs.of(request.form["crs"]) if request.form.get("crs") else None
            res = _parse(src, crs)
        except (ValueError, KeyError, IOError) as e:
            return jsonify(error=str(e)), 400
        cid = uuid.uuid4().hex[:12]
        with _LOCK:
            for k in list(_CONV)[:-8]:
                _CONV.pop(k, None)
            _CONV[cid] = res.layers
        gj = {"type": "FeatureCollection", "features": []}
        for i, l in enumerate(res.layers):
            gj["features"] += apiv2.to_geojson(l, apiv2.PALETTE[i % len(apiv2.PALETTE)])["features"]
        return jsonify(cid=cid, layers=[{"label": l.label, "count": len(l.features), "geom": Layer.geom_name(l.geom)} for l in res.layers],
                       count=sum(len(l.features) for l in res.layers), warnings=res.warnings[:5], geojson=gj)

    @app.get("/api/convert2/<cid>/export")
    def convert2_export(cid):
        layers = _CONV.get(cid)
        if not layers:
            return jsonify(error="انتهت الجلسة؛ افتح الملف من جديد"), 404
        fmt = request.args.get("format", "geojson")
        if fmt not in formats.FORMATS:
            return jsonify(error="صيغة غير مدعومة"), 400
        o = formats.ExportOptions()
        if request.args.get("crs"):
            try:
                o.target = Crs.of(request.args["crs"])
            except ValueError as e:
                return jsonify(error=str(e)), 400
        if request.args.get("mgrs") == "1" or request.args.get("dd") == "1":
            from .coords import format_coord
            import copy as _copy
            layers = _copy.deepcopy(layers)
            for l in layers:
                for f in l.features:
                    if request.args.get("mgrs") == "1":
                        f.attrs["MGRS"] = format_coord("MGRS", f.lat, f.lon)
                    if request.args.get("dd") == "1":
                        f.attrs["lat"], f.attrs["lon"] = "%.7f" % f.lat, "%.7f" % f.lon
        d = tempfile.mkdtemp()
        base = re.sub(r"[^\w\-]+", "_", request.args.get("name") or layers[0].label)[:40] or "converted"
        path = os.path.join(d, base + formats.EXT[fmt])
        try:
            formats.export_layers(layers, fmt, path, o)
        except (ValueError, KeyError, IOError) as e:
            return jsonify(error=str(e)), 400
        return send_file(path, as_attachment=True, download_name=base + formats.EXT[fmt])

    @app.post("/api/convert2/<cid>/add")
    def convert2_add(cid):
        layers = _CONV.get(cid)
        if not layers:
            return jsonify(error="انتهت الجلسة؛ افتح الملف من جديد"), 404
        ids = []
        w = apiv2._ws()
        try:
            for l in layers:
                for f in l.features:
                    f.id = f.id or Feature.new_id()
                _fill(l.features)
                l.kind = "import"
                l.label = f"{l.label} — {time.strftime('%Y-%m-%d %H:%M')}"
                ids.append(w.add_layer_with_features(l).id)
        finally:
            w.close()
        return jsonify(ok=True, layers=ids)

    @app.delete("/api/convert2/<cid>")
    def convert2_del(cid):
        _CONV.pop(cid, None)
        return jsonify(ok=True)

    # ------------------------------------------------------------ ملفات واردة من «فتح بواسطة» و«مشاركة»
    @app.get("/api/incoming")
    def incoming_list():
        d = _incoming_dir()
        return jsonify([{"name": n, "size": os.path.getsize(os.path.join(d, n))} for n in sorted(os.listdir(d))])

    @app.get("/api/incoming/file/<path:name>")
    def incoming_file(name):
        p = os.path.join(_incoming_dir(), os.path.basename(name))
        if not os.path.isfile(p):
            return jsonify(error="غير موجود"), 404
        return send_file(p)

    @app.delete("/api/incoming/<path:name>")
    def incoming_del(name):
        try:
            os.remove(os.path.join(_incoming_dir(), os.path.basename(name)))
        except OSError:
            pass
        return jsonify(ok=True)
