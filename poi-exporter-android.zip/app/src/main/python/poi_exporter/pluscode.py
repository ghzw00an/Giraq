"""Open Location Code (Plus Code): فك الترميز الكامل والمختصر (مع نقطة مرجعية) والترميز."""
from __future__ import annotations

import math
import re

ALPHABET = "23456789CFGHJMPQRVWX"
SEP, PAD = "+", "0"
_PAIR_RES = [20.0, 1.0, 0.05, 0.0025, 0.000125]
_GRID_ROWS, _GRID_COLS = 5, 4
_LAT_MAX, _LON_MAX = 90, 180
_RE = re.compile(r"^[23456789CFGHJMPQRVWX0]{2,8}\+[23456789CFGHJMPQRVWX]{0,}$", re.I)


def is_code(s: str) -> bool:
    return bool(_RE.match((s or "").strip()))


def is_short(s: str) -> bool:
    s = s.strip().upper()
    return is_code(s) and s.index(SEP) < 8


def decode(code: str):
    """يرجع (lat, lon) لمركز المنطقة. الرمز يجب أن يكون كاملاً."""
    c = code.strip().upper()
    if not is_code(c) or c.index(SEP) < 8:
        raise ValueError("رمز Plus Code غير كامل")
    c = c.replace(SEP, "").replace(PAD, "")
    lat, lon = -_LAT_MAX, -_LON_MAX
    pair = c[:10]
    for i in range(0, len(pair), 2):
        r = _PAIR_RES[i // 2]
        lat += ALPHABET.index(pair[i]) * r
        lon += ALPHABET.index(pair[i + 1]) * r
    lat_res = _PAIR_RES[(len(pair) // 2) - 1]
    lon_res = lat_res
    grid = c[10:15]
    lr, cr = lat_res, lon_res
    for ch in grid:
        lr /= _GRID_ROWS
        cr /= _GRID_COLS
        d = ALPHABET.index(ch)
        lat += (d // _GRID_COLS) * lr
        lon += (d % _GRID_COLS) * cr
        lat_res, lon_res = lr, cr
    return lat + lat_res / 2, lon + lon_res / 2


def recover(short: str, ref_lat: float, ref_lon: float):
    """يستعيد الرمز الكامل الأقرب إلى النقطة المرجعية ثم يفكّه."""
    s = short.strip().upper()
    if not is_short(s):
        return decode(s)
    pad = 8 - s.index(SEP)
    resolution = 20.0 ** (2 - (pad // 2))
    half = resolution / 2.0
    ref_lat = min(max(ref_lat, -90 + 1e-9), 90 - 1e-9)
    lat, lon = decode(encode(ref_lat, ref_lon)[:pad] + s)
    if ref_lat + half < lat and lat - resolution >= -90:
        lat -= resolution
    elif ref_lat - half > lat and lat + resolution <= 90:
        lat += resolution
    if ref_lon + half < lon:
        lon -= resolution
    elif ref_lon - half > lon:
        lon += resolution
    return lat, lon


def encode(lat: float, lon: float) -> str:
    """رمز بـ10 خانات (دقة نحو 14 م)."""
    lat_v = min(max(lat, -90.0), 90.0 - 1e-10) + 90.0
    lon_v = ((lon + 180.0) % 360.0)
    code = ""
    for r in _PAIR_RES:
        d = int(lat_v // r)
        lat_v -= d * r
        code += ALPHABET[d]
        d = int(lon_v // r)
        lon_v -= d * r
        code += ALPHABET[d]
    return code[:8] + SEP + code[8:10]
