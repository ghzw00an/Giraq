"""تصدير PostGIS (SQL) وCAD (DXF) من نفس بنية GeoJSON المستخدمة في بقية الصيغ."""
from __future__ import annotations

import json
import re
from typing import List, Sequence


def _flat(g) -> List[tuple]:
    """يفكّك هندسة GeoJSON إلى (نوع, حلقات/نقاط) بسيطة: ('P',[xy]) ('L',[xy..]) ('G',[xy..]) (مضلع مغلق)."""
    out = []
    if not g:
        return out
    t, c = g.get("type"), g.get("coordinates")
    if t == "Point":
        out.append(("P", [c]))
    elif t == "MultiPoint":
        out += [("P", [p]) for p in c]
    elif t == "LineString":
        out.append(("L", c))
    elif t == "MultiLineString":
        out += [("L", l) for l in c]
    elif t == "Polygon":
        out += [("G", r) for r in c]
    elif t == "MultiPolygon":
        out += [("G", r) for poly in c for r in poly]
    elif t == "GeometryCollection":
        for s in g.get("geometries", []):
            out += _flat(s)
    return out


# ------------------------------------------------------------------ PostGIS
def _ident(s: str) -> str:
    return '"' + str(s).replace('"', '""') + '"'


def _lit(v) -> str:
    return "NULL" if v is None or v == "" else "'" + str(v).replace("'", "''") + "'"


def to_postgis(layers: Sequence, o, geojson_fn) -> str:
    srid = o.crs().epsg or 4326
    lines = ["-- POI Exporter → PostGIS", "-- شغّله بـ: psql -d <db> -f ملف.sql", "CREATE EXTENSION IF NOT EXISTS postgis;", "BEGIN;"]
    used = set()
    for l in layers:
        gj = geojson_fn([l], o)
        feats = gj["features"]
        if not feats:
            continue
        base = re.sub(r"\W+", "_", l.label, flags=re.U).strip("_").lower() or "layer"
        name, i = base, 2
        while name in used:
            name, i = f"{base}_{i}", i + 1
        used.add(name)
        cols = []
        for f in feats:
            for k in f["properties"]:
                if k not in cols:
                    cols.append(k)
        lines.append(f"\nDROP TABLE IF EXISTS {_ident(name)};")
        lines.append(f"CREATE TABLE {_ident(name)} (gid serial PRIMARY KEY, " + "".join(f"{_ident(c)} text, " for c in cols) + f"geom geometry(Geometry,{srid}));")
        cl = ",".join(_ident(c) for c in cols)
        for f in feats:
            vals = ",".join(_lit(f["properties"].get(c)) for c in cols)
            g = json.dumps(f["geometry"], separators=(",", ":")) if f["geometry"] else None
            geom = f"ST_SetSRID(ST_GeomFromGeoJSON({_lit(g)}),{srid})" if g else "NULL"
            lines.append(f"INSERT INTO {_ident(name)} ({cl + ',' if cl else ''}geom) VALUES ({vals + ',' if vals else ''}{geom});")
        lines.append(f"CREATE INDEX {_ident(name + '_gix')} ON {_ident(name)} USING GIST (geom);")
    lines += ["COMMIT;", ""]
    return "\n".join(lines)


# ---------------------------------------------------------------------- DXF
def _lname(s: str) -> str:
    return re.sub(r'[<>/\\":;?*|=`,]', "_", str(s))[:200] or "0"


def to_dxf(layers: Sequence, o, geojson_fn) -> bytes:
    gj = geojson_fn(list(layers), o)
    names = [_lname(l.label) for l in layers]
    # تعيين كل عنصر لطبقته بحسب الترتيب
    per, k = [], 0
    for l in layers:
        n = len(geojson_fn([l], o)["features"])
        per.append(gj["features"][k:k + n])
        k += n
    d: List[str] = []

    def g(code, val):
        d.append(f"{code}\n{val}")

    g(0, "SECTION"); g(2, "HEADER"); g(9, "$ACADVER"); g(1, "AC1009"); g(9, "$DWGCODEPAGE"); g(3, "ANSI_1256"); g(0, "ENDSEC")
    g(0, "SECTION"); g(2, "TABLES"); g(0, "TABLE"); g(2, "LTYPE"); g(70, 1); g(0, "LTYPE"); g(2, "CONTINUOUS"); g(70, 0); g(3, "Solid line"); g(72, 65); g(73, 0); g(40, 0.0); g(0, "ENDTAB")
    g(0, "TABLE"); g(2, "LAYER"); g(70, len(names))
    for i, n in enumerate(names):
        g(0, "LAYER"); g(2, n); g(70, 0); g(62, 1 + i % 7); g(6, "CONTINUOUS")
    g(0, "ENDTAB"); g(0, "ENDSEC")
    g(0, "SECTION"); g(2, "ENTITIES")

    def pt(code_off, x, y):
        g(10 + code_off, f"{x:.4f}"); g(20 + code_off, f"{y:.4f}")

    for n, feats in zip(names, per):
        for f in feats:
            nm = str((f["properties"] or {}).get("name") or "")
            for kind, c in _flat(f["geometry"]):
                if kind == "P":
                    g(0, "POINT"); g(8, n); pt(0, c[0][0], c[0][1]); g(30, 0)
                    if nm:
                        g(0, "TEXT"); g(8, n); pt(0, c[0][0], c[0][1]); g(30, 0); g(40, 1.5 if (o.crs().epsg or 4326) != 4326 else 0.0001); g(1, nm)
                else:
                    ring = c[:-1] if kind == "G" and len(c) > 1 and c[0] == c[-1] else c
                    g(0, "POLYLINE"); g(8, n); g(66, 1); g(70, 1 if kind == "G" else 0)
                    for x, y in ring:
                        g(0, "VERTEX"); g(8, n); pt(0, x, y); g(30, 0)
                    g(0, "SEQEND"); g(8, n)
    g(0, "ENDSEC"); g(0, "EOF")
    return ("\n".join(d) + "\n").encode("cp1256", "replace")
