"""أدوات GIS الإضافية: Construct Points، Append، Feature To Polygon، Polygon To Line، Display XY، التحديد المكاني، الطرق والشبكة."""
from __future__ import annotations

import math
import os
import tempfile

from flask import jsonify, request

from . import apiv2, formats, polygonize, routing
from .apiv4 import _all_feats, pip
from .geo import haversine, set_representative
from .model import LINE, POINT, POLYGON, Feature

_XY = {}          # رمز مؤقت → مسار الملف المرفوع (Display XY)


def _path_len(p):
    return sum(haversine(p[i - 1][1], p[i - 1][0], p[i][1], p[i][0]) for i in range(1, len(p)))


def along(parts, interval=None, count=None, ends=True, closed=False):
    """نقاط (lon,lat,dist) موزعة بانتظام على مسارات. interval بالمتر أو count عدد النقاط لكل مسار."""
    out = []
    for p in parts:
        p = list(p)
        if closed and p and p[0] != p[-1]:
            p.append(p[0])
        total = _path_len(p)
        if total <= 0:
            continue
        if count:
            n = max(2, int(count))
            if closed:
                targets = [total * i / n for i in range(n)]
            elif ends:
                targets = [total * i / (n - 1) for i in range(n)]
            else:
                targets = [total * (i + 1) / (n + 1) for i in range(n)]
        else:
            step = float(interval)
            targets = [i * step for i in range(int(total // step) + 1)]
            if not ends:
                targets = targets[1:]
            elif total - targets[-1] > 1e-6 and not closed:
                targets.append(total)
        acc, i = 0.0, 1
        for tg in targets:
            while i < len(p) - 1 and acc + haversine(p[i - 1][1], p[i - 1][0], p[i][1], p[i][0]) < tg - 1e-9:
                acc += haversine(p[i - 1][1], p[i - 1][0], p[i][1], p[i][0]); i += 1
            seg = haversine(p[i - 1][1], p[i - 1][0], p[i][1], p[i][0]) or 1e-9
            u = min(1.0, max(0.0, (tg - acc) / seg))
            out.append((p[i - 1][0] + (p[i][0] - p[i - 1][0]) * u, p[i - 1][1] + (p[i][1] - p[i - 1][1]) * u, tg))
    return out


def register(app):
    def _save(w, label, geom, feats, note):
        nl = w.add_layer(label, geom)
        w.add_features(nl.id, feats, note)
        return nl.id

    def _label(w, lid):
        l = apiv2._layer_obj(w, lid)
        return l.label if l else "طبقة"

    def _pick(w, j):
        """المعالم المختارة: ids محددة، أو كل معالم طبقة."""
        ids = set(j.get("ids") or [])
        feats = _all_feats(w, j["layer"]) if j.get("layer") else []
        return [f for f in feats if not ids or f.id in ids]

    # ---------------------------------------------------------------- Construct Points
    @app.post("/api/gis/construct")
    def gis_construct():
        j = request.get_json(force=True)
        interval, count = j.get("interval"), j.get("count")
        if not (interval and float(interval) > 0) and not count:
            return jsonify(error="حدّد المسافة بين النقاط أو عدد النقاط"), 400
        w = apiv2._ws()
        try:
            srcs, name = [], "مسار"
            if j.get("coords"):                                   # مسار مرسوم/متتبَّع من الواجهة: [[lat,lon],…]
                srcs = [(None, [[(c[1], c[0]) for c in j["coords"]]], bool(j.get("closed")))]
            else:
                for f in _pick(w, j):
                    if f.geom in (LINE, POLYGON):
                        srcs.append((f, [p for p, h in zip(f.parts, f.holes or [False] * len(f.parts)) if not h or f.geom == POLYGON], f.geom == POLYGON))
                if j.get("layer"):
                    name = _label(w, j["layer"])
            feats = []
            for f, parts, closed in srcs:
                for lon, lat, d in along(parts, float(interval) if interval else None, int(count) if count else None, bool(j.get("ends", True)), closed):
                    g = Feature.point(lat, lon, id=Feature.new_id(), name=(f.name if f else "") or "", type=(f.type if f else ""), category=(f.category if f else ""))
                    g.attrs["dist_m"] = str(round(d, 1))
                    feats.append(g)
            if not feats:
                return jsonify(error="لا توجد خطوط أو مضلعات صالحة"), 400
            if len(feats) > 50000:
                return jsonify(error="العدد كبير (%d). كبّر المسافة" % len(feats)), 400
            lid = _save(w, "نقاط موزعة — " + name, POINT, feats, "Construct Points")
            return jsonify(ok=True, layer=lid, n=len(feats))
        finally:
            w.close()

    # ---------------------------------------------------------------- Append
    @app.post("/api/gis/append")
    def gis_append():
        j = request.get_json(force=True)
        target, srcs = j.get("target"), [s for s in (j.get("sources") or []) if s != j.get("target")]
        if not target or not srcs:
            return jsonify(error="اختر طبقة هدف وطبقة مصدر واحدة على الأقل"), 400
        w = apiv2._ws()
        try:
            tl = apiv2._layer_obj(w, target)
            if not tl:
                return jsonify(error="طبقة الهدف غير موجودة"), 400
            have = {(f.name, round(f.lat, 6), round(f.lon, 6)) for f in tl.features} if j.get("skip_dups") else set()
            add, skipped, bad = [], 0, 0
            for s in srcs:
                for f in _all_feats(w, s):
                    if f.geom != tl.geom:
                        bad += 1
                        continue
                    k = (f.name, round(f.lat, 6), round(f.lon, 6))
                    if k in have:
                        skipped += 1
                        continue
                    g = f.copy(); g.id = Feature.new_id(); add.append(g); have.add(k)
            if add:
                w.add_features(target, add, "Append")
            return jsonify(ok=True, added=len(add), skipped=skipped, wrong_geom=bad)
        finally:
            w.close()

    # ---------------------------------------------------------------- Feature To Polygon / Polygon To Line
    @app.post("/api/gis/feature_to_polygon")
    def gis_f2p():
        j = request.get_json(force=True)
        w = apiv2._ws()
        try:
            lines = [f for f in _pick(w, j) if f.geom == LINE]
            if not lines:
                return jsonify(error="الطبقة لا تحوي خطوطاً"), 400
            try:
                rings = polygonize.polygonize(lines)
            except ValueError as e:
                return jsonify(error=str(e)), 400
            if not rings:
                return jsonify(error="لم تتكوّن مضلعات: الخطوط لا تُغلق أي شكل (تحقّق من اتصال الأطراف)"), 400
            feats = []
            for k, r in enumerate(rings, 1):
                g = Feature(geom=POLYGON, id=Feature.new_id(), name="مضلع %d" % k)
                g.add_part(r); set_representative(g); feats.append(g)
            lid = _save(w, "مضلعات — " + (_label(w, j["layer"]) if j.get("layer") else ""), POLYGON, feats, "Feature To Polygon")
            return jsonify(ok=True, layer=lid, n=len(feats))
        finally:
            w.close()

    @app.post("/api/gis/polygon_to_line")
    def gis_p2l():
        j = request.get_json(force=True)
        w = apiv2._ws()
        try:
            feats = []
            for f in _pick(w, j):
                if f.geom != POLYGON:
                    continue
                for k, (p, h) in enumerate(zip(f.parts, f.holes or [False] * len(f.parts))):
                    g = f.copy(); g.id = Feature.new_id(); g.geom = LINE
                    g.parts, g.holes = [list(p)], [False]
                    if h:
                        g.attrs["ring"] = "hole"
                    set_representative(g); feats.append(g)
            if not feats:
                return jsonify(error="الطبقة لا تحوي مضلعات"), 400
            lid = _save(w, "حدود — " + (_label(w, j["layer"]) if j.get("layer") else ""), LINE, feats, "Polygon To Line")
            return jsonify(ok=True, layer=lid, n=len(feats))
        finally:
            w.close()

    # ---------------------------------------------------------------- Display XY Data
    @app.post("/api/gis/xy/preview")
    def xy_preview():
        up = request.files.get("file")
        if not up:
            return jsonify(error="لا يوجد ملف"), 400
        ext = os.path.splitext(up.filename or "")[1].lower() or ".csv"
        if ext not in (".csv", ".txt", ".tsv", ".xlsx", ".xlsm"):
            return jsonify(error="الصيغ المدعومة: CSV وTXT وXLSX"), 400
        p = os.path.join(tempfile.mkdtemp(), "t" + ext)
        up.save(p)
        try:
            header, rows = formats.read_table(p)
        except Exception as e:  # noqa: BLE001
            return jsonify(error="تعذّرت قراءة الجدول: %s" % e), 400
        if not header:
            return jsonify(error="الجدول فارغ"), 400
        m = formats.guess_columns(header)
        tok = os.path.basename(os.path.dirname(p))
        _XY[tok] = (p, up.filename or "table")
        return jsonify(token=tok, header=header, rows=rows[:5], total=len(rows), guess={"x": m.x, "y": m.y, "name": m.name, "combined": m.combined})

    @app.post("/api/gis/xy/run")
    def xy_run():
        j = request.get_json(force=True)
        ent = _XY.get(j.get("token"))
        if not ent:
            return jsonify(error="انتهت جلسة الملف؛ اخترْه من جديد"), 400
        path, fname = ent
        from .coords import Crs
        m = formats.Mapping(x=int(j.get("x", -1)), y=int(j.get("y", -1)), name=int(j.get("name", -1)), combined=int(j.get("combined", -1)))
        crs = None
        try:
            ep = int(j.get("epsg") or 4326)
            crs = None if ep == 4326 else Crs.of(ep)
            layer, rep = formats.table_to_layer(path, m, crs, j.get("label") or fname)
        except ValueError as e:
            return jsonify(error=str(e)), 400
        if not layer.features:
            return jsonify(error="لا توجد صفوف صالحة", bad=rep.bad[:10]), 400
        w = apiv2._ws()
        try:
            lid = _save(w, layer.label, POINT, layer.features, "Display XY")
        finally:
            w.close()
        return jsonify(ok=True, layer=lid, n=rep.ok, bad=len(rep.bad), bad_rows=rep.bad[:10])

    # ---------------------------------------------------------------- التحديد المكاني بقضاء
    @app.post("/api/gis/spatial_filter")
    def gis_spatial():
        from .admin import AdminRef
        j = request.get_json(force=True)
        ref = AdminRef.get()
        if not ref:
            return jsonify(error="طبقة الحدود غير متاحة"), 400
        lvl = int(j.get("level", 2))
        u = ref.find(lvl, float(j["lat"]), float(j["lon"]))
        if not u:
            return jsonify(error="لا توجد وحدة إدارية في هذا الموضع"), 404
        w = apiv2._ws()
        try:
            lids = j.get("layers") or [d["id"] for d in apiv2.datasets(w) if d["kind"] != "reference" and d["visible"]]
            hits, per = [], []
            for lid in lids:
                n = 0
                for f in _all_feats(w, lid):
                    if f.parts and u.covers(f.lat, f.lon):
                        hits.append(f); n += 1
                per.append({"layer": lid, "label": _label(w, lid), "n": n})
            res = {"unit": u.name(), "parent": u.parent(), "n": len(hits), "per": per, "ids": [f.id for f in hits][:20000],
                   "bbox": [u.bbox[0], u.bbox[1], u.bbox[2], u.bbox[3]]}
            if j.get("copy") and hits:
                geoms = {f.geom for f in hits}
                for g in geoms:
                    fs = []
                    for f in hits:
                        if f.geom == g:
                            c = f.copy(); c.id = Feature.new_id(); fs.append(c)
                    res["layer"] = _save(w, "داخل %s" % u.name() + ("" if len(geoms) == 1 else " (%d)" % g), g, fs, "تحديد مكاني")
            return jsonify(res)
        finally:
            w.close()

    # ---------------------------------------------------------------- الطرق وتحليل الشبكة
    def _base():
        return apiv2.settings().get("routing_url") or routing.DEFAULT_URL

    def _err(e):
        if isinstance(e, routing.RouteError):
            return jsonify(error=str(e)), 400
        return jsonify(error="تعذّر الاتصال بخادم الطرق. تحقّق من الإنترنت"), 502

    def _line(coords, name, **attrs):
        g = Feature(geom=LINE, id=Feature.new_id(), name=name)
        g.add_part([(c[0], c[1]) for c in coords]); set_representative(g)
        g.attrs.update({k: str(v) for k, v in attrs.items()})
        return g

    @app.post("/api/gis/route")
    def gis_route():
        j = request.get_json(force=True)
        stops = [(float(s[0]), float(s[1])) for s in j.get("stops") or []]
        try:
            r = routing.route(stops, _base(), bool(j.get("optimize")))
        except Exception as e:  # noqa: BLE001
            return _err(e)
        out = dict(r, coords=[list(c) for c in r["coords"]])
        if j.get("save", True):
            w = apiv2._ws()
            try:
                out["layer"] = _save(w, j.get("name") or "طريق", LINE, [_line(r["coords"], j.get("name") or "طريق", distance_km=r["km"], duration_min=r["min"], stops=len(stops))], "طريق عبر الشوارع")
            finally:
                w.close()
        return jsonify(out)

    @app.post("/api/gis/closest")
    def gis_closest():
        j = request.get_json(force=True)
        o = (float(j["lat"]), float(j["lon"]))
        w = apiv2._ws()
        try:
            cands = [(f.lat, f.lon, f) for lid in j.get("layers") or [] for f in _all_feats(w, lid) if f.parts]
            try:
                rows = routing.closest(o, cands, int(j.get("k", 3)), _base())
                res, feats = [], []
                for t, d, c in rows:
                    f = c[2]
                    r = routing.route([o, (f.lat, f.lon)], _base())
                    res.append({"name": f.name or f.type or "—", "min": round(t / 60, 1), "km": r["km"], "lat": f.lat, "lon": f.lon, "coords": [list(x) for x in r["coords"]]})
                    feats.append(_line(r["coords"], "→ " + (f.name or ""), distance_km=r["km"], duration_min=round(t / 60, 1)))
            except Exception as e:  # noqa: BLE001
                return _err(e)
            out = {"results": res}
            if j.get("save", True) and feats:
                out["layer"] = _save(w, "أقرب المنشآت", LINE, feats, "أقرب منشأة")
            return jsonify(out)
        finally:
            w.close()

    @app.post("/api/gis/od")
    def gis_od():
        j = request.get_json(force=True)
        w = apiv2._ws()
        try:
            pts, names = [], []
            for lid in j.get("layers") or []:
                for f in _all_feats(w, lid):
                    if f.parts:
                        pts.append((f.lat, f.lon)); names.append(f.name or f.id[:6])
            if len(pts) < 2:
                return jsonify(error="تحتاج نقطتين على الأقل"), 400
            if len(pts) > 60:
                return jsonify(error="الحد 60 نقطة (لديك %d)" % len(pts)), 400
            try:
                dur, dist = routing.table(pts, pts, _base())
            except Exception as e:  # noqa: BLE001
                return _err(e)
            return jsonify(names=names, minutes=[[None if v is None else round(v / 60, 1) for v in r] for r in dur],
                           km=[[None if v is None else round(v / 1000, 2) for v in r] for r in (dist or [])])
        finally:
            w.close()

    @app.post("/api/gis/service_area")
    def gis_service():
        j = request.get_json(force=True)
        mins = sorted({float(m) for m in j.get("minutes") or [10]})[:5]
        try:
            rings = routing.service_area((float(j["lat"]), float(j["lon"])), mins, _base())
        except Exception as e:  # noqa: BLE001
            return _err(e)
        w = apiv2._ws()
        try:
            feats = []
            for m, ring in reversed(rings):
                g = Feature(geom=POLYGON, id=Feature.new_id(), name="%g دقيقة" % m)
                g.add_part(ring); set_representative(g); g.attrs["minutes"] = "%g" % m; feats.append(g)
            lid = _save(w, "منطقة خدمة (تقريبية)", POLYGON, feats, "منطقة خدمة")
        finally:
            w.close()
        return jsonify(ok=True, layer=lid, n=len(feats))
