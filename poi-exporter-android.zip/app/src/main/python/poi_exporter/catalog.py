"""ما يمكن تنزيله: فئات المعالم (POI) وطبقات الخرائط الإضافية، وتوليد جمل Overpass."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

from .model import LINE, POINT, POLYGON
from .geo import AreaSpec


@dataclass(frozen=True)
class Clause:
    key: str
    values: tuple = ()

    def selector(self) -> str:
        if not self.values:
            return f'["{self.key}"]'
        return f'["{self.key}"~"^(' + "|".join(self.values) + ')$"]'

    def matches(self, tags: Dict[str, str]) -> bool:
        v = tags.get(self.key)
        if not v:
            return False
        return not self.values or v in self.values


def C(key: str, *values: str) -> Clause:
    return Clause(key, tuple(values))


@dataclass(frozen=True)
class PoiCat:
    id: str
    ar: str
    en: str
    clauses: tuple

    def label(self, arabic: bool = True) -> str:
        return self.ar if arabic else self.en


@dataclass(frozen=True)
class LayerDef:
    id: str
    ar: str
    en: str
    geom: int
    extra: str
    clauses: tuple

    def label(self, arabic: bool = True) -> str:
        return self.ar if arabic else self.en


K_POI = "poi"
K_ROADS_MAIN, K_ROADS_SEC, K_RIVERS = "roads_main", "roads_secondary", "rivers"
K_LAKES, K_DAMS, K_TOURISM = "lakes", "dams", "tourism"
K_ADMIN_GOV, K_ADMIN_QADAA, K_ADMIN_NAHIYA = "admin_gov", "admin_qadaa", "admin_nahiya"
ADMIN_IDS = [K_ADMIN_GOV, K_ADMIN_QADAA, K_ADMIN_NAHIYA]

POI: List[PoiCat] = [
    PoiCat("school", "مدارس", "Schools", (C("amenity", "school", "kindergarten"),)),
    PoiCat("university", "جامعات وكليات", "Universities and colleges", (C("amenity", "university", "college"),)),
    PoiCat("hospital", "مستشفيات", "Hospitals", (C("amenity", "hospital"),)),
    PoiCat("clinic", "عيادات ومراكز صحية", "Clinics", (C("amenity", "clinic", "doctors", "dentist"),)),
    PoiCat("pharmacy", "صيدليات", "Pharmacies", (C("amenity", "pharmacy"),)),
    PoiCat("worship", "مساجد ودور عبادة", "Places of worship", (C("amenity", "place_of_worship"),)),
    PoiCat("food", "مطاعم ومقاهي", "Restaurants and cafes", (C("amenity", "restaurant", "cafe", "fast_food"),)),
    PoiCat("bank", "مصارف", "Banks", (C("amenity", "bank"),)),
    PoiCat("fuel", "محطات وقود", "Fuel stations", (C("amenity", "fuel"),)),
    PoiCat("hotel", "فنادق", "Hotels", (C("tourism", "hotel", "guest_house", "motel"),)),
    PoiCat("police", "شرطة وأمن", "Police", (C("amenity", "police"),)),
    PoiCat("gov", "دوائر حكومية", "Government offices", (C("amenity", "townhall", "courthouse"), C("office", "government"))),
    PoiCat("shop", "متاجر وأسواق", "Shops", (C("shop"),)),
    PoiCat("market", "أسواق شعبية", "Marketplaces", (C("amenity", "marketplace"),)),
    PoiCat("sport", "ملاعب ورياضة", "Sports", (C("leisure", "stadium", "sports_centre"),)),
    PoiCat("airport", "مطارات", "Airports", (C("aeroway", "aerodrome"),)),
    PoiCat("military", "قواعد ومواقع عسكرية", "Military bases and sites", (C("military"), C("landuse", "military"))),
    PoiCat("embassy", "سفارات", "Embassies", (C("amenity", "embassy"), C("diplomatic", "embassy"), C("office", "diplomatic"))),
    PoiCat("consulate", "قنصليات", "Consulates", (C("diplomatic", "consulate"),)),
]

_WATER_NOT_RIVER = '["water"!~"^(river|stream|canal|ditch|drain|oxbow)$"]'

LAYERS: List[LayerDef] = [
    LayerDef(K_ROADS_MAIN, "الطرق الرئيسية", "Main roads", LINE, "",
             (C("highway", "motorway", "trunk", "primary", "motorway_link", "trunk_link", "primary_link"),)),
    LayerDef(K_ROADS_SEC, "الطرق الثانوية والفرعية", "Secondary & minor roads", LINE, "",
             (C("highway", "secondary", "tertiary", "secondary_link", "tertiary_link", "unclassified", "residential", "living_street", "road"),)),
    LayerDef(K_RIVERS, "الأنهار", "Rivers", LINE, "", (C("waterway", "river", "canal"),)),
    LayerDef(K_LAKES, "البحيرات", "Lakes", POLYGON, _WATER_NOT_RIVER, (C("natural", "water"),)),
    LayerDef(K_DAMS, "السدود", "Dams", POINT, "", (C("waterway", "dam"), C("man_made", "dam"))),
    LayerDef(K_TOURISM, "المعالم السياحية", "Tourist sites", POINT, "",
             (C("tourism", "attraction", "museum", "viewpoint", "zoo", "theme_park", "gallery"), C("historic"))),
    LayerDef("power_lines", "خطوط الكهرباء", "Power lines", LINE, "", (C("power", "line", "minor_line", "cable"),)),
    LayerDef("power_sites", "محطات وأبراج الكهرباء", "Power plants, substations and towers", POINT, "", (C("power", "plant", "substation", "generator", "tower", "transformer"),)),
    LayerDef("pipelines", "خطوط الأنابيب (نفط وغاز)", "Oil and gas pipelines", LINE, "", (C("man_made", "pipeline"),)),
    LayerDef("railways", "سكك القطارات", "Railways", LINE, "", (C("railway", "rail", "light_rail", "narrow_gauge", "subway", "tram", "monorail", "construction", "disused", "abandoned"),)),
    LayerDef("rail_stations", "محطات القطارات", "Railway stations", POINT, "", (C("railway", "station", "halt", "stop", "tram_stop", "subway_entrance"),)),
    LayerDef("telecom", "أبراج الاتصالات", "Telecom towers", POINT, "", (C("man_made", "mast", "tower", "communications_tower"), C("tower:type", "communication"), C("communication:mobile_phone"))),
    LayerDef("mm_tower", "برج", "Man-made: tower", POINT, "", (C("man_made", "tower"),)),
    LayerDef("mm_mast", "صارية", "Man-made: mast", POINT, "", (C("man_made", "mast"),)),
    LayerDef("mm_chimney", "مدخنة", "Man-made: chimney", POINT, "", (C("man_made", "chimney"),)),
    LayerDef("mm_water_tower", "برج مياه", "Man-made: water_tower", POINT, "", (C("man_made", "water_tower"),)),
    LayerDef("mm_storage_tank", "خزان", "Man-made: storage_tank", POINT, "", (C("man_made", "storage_tank"),)),
    LayerDef("mm_silo", "صومعة", "Man-made: silo", POINT, "", (C("man_made", "silo"),)),
    LayerDef("mm_pier", "رصيف بحري", "Man-made: pier", LINE, "", (C("man_made", "pier"),)),
    LayerDef("mm_bridge", "جسر", "Man-made: bridge", POLYGON, "", (C("man_made", "bridge"),)),
    LayerDef("mm_wastewater_plant", "محطة معالجة مياه", "Man-made: wastewater_plant", POLYGON, "", (C("man_made", "wastewater_plant"),)),
    LayerDef("mm_water_works", "محطة مياه", "Man-made: water_works", POLYGON, "", (C("man_made", "water_works"),)),
    LayerDef("mm_works", "معمل ومصنع", "Man-made: works", POLYGON, "", (C("man_made", "works"),)),
    LayerDef("mm_petroleum_well", "بئر نفط", "Man-made: petroleum_well", POINT, "", (C("man_made", "petroleum_well"),)),
    LayerDef("mm_windmill", "طاحونة", "Man-made: windmill", POINT, "", (C("man_made", "windmill"),)),
    LayerDef("mm_lighthouse", "منارة", "Man-made: lighthouse", POINT, "", (C("man_made", "lighthouse"),)),
    LayerDef("mm_survey_point", "نقطة مسح", "Man-made: survey_point", POINT, "", (C("man_made", "survey_point"),)),
    LayerDef("mm_breakwater", "حاجز أمواج", "Man-made: breakwater", LINE, "", (C("man_made", "breakwater"),)),
    LayerDef("mm_dyke", "سدة ترابية", "Man-made: dyke", LINE, "", (C("man_made", "dyke"),)),
    LayerDef("mm_embankment", "ساتر", "Man-made: embankment", LINE, "", (C("man_made", "embankment"),)),
    LayerDef("mm_flare", "شعلة غاز", "Man-made: flare", POINT, "", (C("man_made", "flare"),)),
    LayerDef("mm_crane", "رافعة", "Man-made: crane", POINT, "", (C("man_made", "crane"),)),
    LayerDef("mm_reservoir_covered", "خزان مغطى", "Man-made: reservoir_covered", POLYGON, "", (C("man_made", "reservoir_covered"),)),
    LayerDef("mm_pumping_station", "محطة ضخ", "Man-made: pumping_station", POINT, "", (C("man_made", "pumping_station"),)),
    LayerDef("mm_monitoring_station", "محطة رصد", "Man-made: monitoring_station", POINT, "", (C("man_made", "monitoring_station"),)),
    LayerDef("mm_obelisk", "مسلة", "Man-made: obelisk", POINT, "", (C("man_made", "obelisk"),)),
    LayerDef("mm_cutline", "قطع خطي", "Man-made: cutline", LINE, "", (C("man_made", "cutline"),)),
    LayerDef("mm_gasometer", "خزان غاز", "Man-made: gasometer", POINT, "", (C("man_made", "gasometer"),)),
    LayerDef("mm_kiln", "فرن", "Man-made: kiln", POINT, "", (C("man_made", "kiln"),)),
    LayerDef("mm_mineshaft", "فتحة منجم", "Man-made: mineshaft", POINT, "", (C("man_made", "mineshaft"),)),
    LayerDef("mm_adit", "نفق منجم", "Man-made: adit", POINT, "", (C("man_made", "adit"),)),
    LayerDef("nat_peak", "قمة جبل", "Natural: peak", POINT, "", (C("natural", "peak"),)),
    LayerDef("nat_hill", "تل", "Natural: hill", POINT, "", (C("natural", "hill"),)),
    LayerDef("nat_spring", "عين ماء", "Natural: spring", POINT, "", (C("natural", "spring"),)),
    LayerDef("nat_cave_entrance", "مدخل كهف", "Natural: cave_entrance", POINT, "", (C("natural", "cave_entrance"),)),
    LayerDef("nat_volcano", "بركان", "Natural: volcano", POINT, "", (C("natural", "volcano"),)),
    LayerDef("nat_saddle", "ممر جبلي", "Natural: saddle", POINT, "", (C("natural", "saddle"),)),
    LayerDef("nat_tree", "شجرة", "Natural: tree", POINT, "", (C("natural", "tree"),)),
    LayerDef("nat_rock", "صخرة", "Natural: rock", POINT, "", (C("natural", "rock"),)),
    LayerDef("nat_stone", "حجر", "Natural: stone", POINT, "", (C("natural", "stone"),)),
    LayerDef("nat_wood", "غابة", "Natural: wood", POLYGON, "", (C("natural", "wood"),)),
    LayerDef("nat_scrub", "أحراش", "Natural: scrub", POLYGON, "", (C("natural", "scrub"),)),
    LayerDef("nat_grassland", "مراعي", "Natural: grassland", POLYGON, "", (C("natural", "grassland"),)),
    LayerDef("nat_heath", "أرض عشبية", "Natural: heath", POLYGON, "", (C("natural", "heath"),)),
    LayerDef("nat_wetland", "أهوار ومستنقعات", "Natural: wetland", POLYGON, "", (C("natural", "wetland"),)),
    LayerDef("nat_beach", "شاطئ", "Natural: beach", POLYGON, "", (C("natural", "beach"),)),
    LayerDef("nat_sand", "رمال", "Natural: sand", POLYGON, "", (C("natural", "sand"),)),
    LayerDef("nat_bare_rock", "صخور مكشوفة", "Natural: bare_rock", POLYGON, "", (C("natural", "bare_rock"),)),
    LayerDef("nat_scree", "منحدر صخري", "Natural: scree", POLYGON, "", (C("natural", "scree"),)),
    LayerDef("nat_mud", "طين", "Natural: mud", POLYGON, "", (C("natural", "mud"),)),
    LayerDef("nat_shingle", "حصى", "Natural: shingle", POLYGON, "", (C("natural", "shingle"),)),
    LayerDef("nat_cliff", "جرف", "Natural: cliff", LINE, "", (C("natural", "cliff"),)),
    LayerDef("nat_ridge", "سلسلة جبلية", "Natural: ridge", LINE, "", (C("natural", "ridge"),)),
    LayerDef("nat_valley", "وادي", "Natural: valley", LINE, "", (C("natural", "valley"),)),
    LayerDef("nat_arete", "حافة جبلية", "Natural: arete", LINE, "", (C("natural", "arete"),)),
    LayerDef("nat_bay", "خليج", "Natural: bay", POLYGON, "", (C("natural", "bay"),)),
    LayerDef("nat_cape", "رأس", "Natural: cape", POINT, "", (C("natural", "cape"),)),
    LayerDef("nat_strait", "مضيق", "Natural: strait", POLYGON, "", (C("natural", "strait"),)),
    LayerDef("nat_coastline", "خط الساحل", "Natural: coastline", LINE, "", (C("natural", "coastline"),)),
    LayerDef("nat_glacier", "جليد", "Natural: glacier", POLYGON, "", (C("natural", "glacier"),)),
    LayerDef("nat_river_water", "المسطحات المائية الطبيعية", "Natural water bodies", POLYGON, "", (C("natural", "water"),)),
    LayerDef("nat_streams", "الجداول والقنوات الصغيرة", "Streams and drains", LINE, "", (C("waterway", "stream", "drain", "ditch"),)),
]


def admin_label(idx: int, arabic: bool = True) -> str:
    ar = ["حدود المحافظات", "حدود الأقضية", "حدود النواحي"]
    en = ["Governorate boundaries", "District (qadaa) boundaries", "Sub-district (nahiya) boundaries"]
    return (ar if arabic else en)[idx]


def poi(cat_id: str) -> Optional[PoiCat]:
    return next((c for c in POI if c.id == cat_id), None)


def layer(layer_id: str) -> Optional[LayerDef]:
    return next((d for d in LAYERS if d.id == layer_id), None)


_OK = re.compile(r"^[A-Za-z0-9_:\-|]+$")


def custom_selector(raw: Optional[str]) -> Optional[str]:
    """يقبل key=value أو key=a|b أو key؛ None إذا فارغ."""
    if raw is None or not raw.strip():
        return None
    raw = raw.strip()
    parts = raw.split("=", 1)
    if not _OK.match(parts[0]):
        raise ValueError(f"Invalid filter: {raw}")
    if len(parts) == 1 or not parts[1]:
        return f'["{parts[0]}"]'
    if not _OK.match(parts[1]):
        raise ValueError(f"Invalid filter: {raw}")
    if "|" in parts[1]:
        return f'["{parts[0]}"~"^({parts[1]})$"]'
    return f'["{parts[0]}"="{parts[1]}"]'


def poi_statements(ids: Sequence[str], custom: str, include_unnamed: bool, area: AreaSpec) -> List[str]:
    out = []
    named = "" if include_unnamed else '["name"]'
    for i in ids:
        c = poi(i)
        if not c:
            continue
        for cl in c.clauses:
            out.append("nwr" + cl.selector() + named + area.overpass() + ";")
    cs = custom_selector(custom)
    if cs:
        out.append("nwr" + cs + named + area.overpass() + ";")
    return out
