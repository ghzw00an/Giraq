"""جلب من القطاعات: لكل قطاع أنواعه ومحدِّدات OSM المقابلة، مع تسجيلها كفئات معالم ديناميكية (sx:<قطاع>|<نوع>)."""
from __future__ import annotations

import re
from typing import Dict, List, Optional

from . import catalog
from .catalog import C, PoiCat
from .model import Feature

OPERATORS = (("Zain IQ", r"zain|زين"), ("Asiacell", r"asia\s*cell|اسيا\s*سيل|آسيا\s*سيل|اسياسيل"), ("Korek", r"korek|كورك"),
             ("Iraqna", r"iraqna|عراقنا"), ("Earthlink", r"earthlink|ايرثلنك|ارثلنك"), ("Huawei", r"huawei|هواوي"), ("ITPC", r"itpc|اتصالات\s*العراق"))

# اسم القطاع -> [(النوع، [Clause…])]
SPEC: Dict[str, List[tuple]] = {
    "قطاع الاتصالات": [
        ("برج اتصال", (C("man_made", "mast", "tower", "communications_tower"), C("tower:type", "communication"), C("communication:mobile_phone", "yes"), C("communication:radio", "yes"))),
        ("شركة", (C("office", "telecommunication"), C("shop", "mobile_phone"), C("operator:type", "telecom"))),
        ("بدالة", (C("telecom", "exchange", "data_center", "central_office"), C("building", "telecom_exchange"))),
        ("برج انترنت", (C("communication:internet", "yes"), C("internet_access", "wlan", "wired", "yes"), C("telecom", "internet_exchange_point"))),
    ],
    "القطاع الصحي": [("مستشفى", (C("amenity", "hospital"),)), ("مستوصف", (C("amenity", "clinic"),)), ("صيدلية", (C("amenity", "pharmacy"),)), ("عيادة", (C("amenity", "doctors", "dentist"),)), ("مختبر", (C("healthcare", "laboratory"),))],
    "القطاع التربوي والتعليم": [("مدرسة", (C("amenity", "school"),)), ("روضة", (C("amenity", "kindergarten"),)), ("جامعة", (C("amenity", "university"),)), ("كلية", (C("amenity", "college"),)), ("معهد", (C("amenity", "training"),)), ("مكتبة", (C("amenity", "library"),))],
    "القطاع الديني": [("جامع", (C("amenity", "place_of_worship"),)), ("مقبرة", (C("landuse", "cemetery"), C("amenity", "grave_yard")))],
    "القطاع التجاري": [("محل", (C("shop"),)), ("سوق", (C("amenity", "marketplace"),)), ("مطعم", (C("amenity", "restaurant", "fast_food"),)), ("مقهى", (C("amenity", "cafe"),)), ("فندق", (C("tourism", "hotel", "guest_house", "motel"),)), ("مول", (C("shop", "mall"),))],
    "القطاع المالي": [("مصرف", (C("amenity", "bank"),)), ("صيرفة", (C("amenity", "bureau_de_change"),))],
    "القطاع الإداري": [("دائرة", (C("office", "government"),)), ("بلدية", (C("amenity", "townhall"),)), ("محكمة", (C("amenity", "courthouse"),)), ("مكتب", (C("office"),))],
    "القطاع السياسي": [("سفارة", (C("amenity", "embassy"), C("diplomatic", "embassy"))), ("قنصلية", (C("diplomatic", "consulate"),)), ("مكتب حزب", (C("office", "political_party"),))],
    "القطاع الرياضي": [("ملعب", (C("leisure", "stadium", "pitch"),)), ("نادي", (C("leisure", "sports_centre"),)), ("مسبح", (C("leisure", "swimming_pool"),))],
    "القطاع الترفيهي": [("متنزه", (C("leisure", "park"),)), ("حديقة", (C("leisure", "garden"),)), ("مدينة ألعاب", (C("tourism", "theme_park"),)), ("حديقة حيوانات", (C("tourism", "zoo"),))],
    "القطاع الصناعي": [("مصنع", (C("man_made", "works"), C("industrial", "factory"))), ("معمل", (C("craft"),)), ("مخزن", (C("building", "warehouse"),))],
    "القطاع الزراعي": [("حقل", (C("landuse", "farmland"),)), ("مزرعة", (C("landuse", "farmyard"), C("farm", "yes"))), ("بستان", (C("landuse", "orchard"),)), ("سايلو", (C("man_made", "silo"),))],
    "القطاع الثقافي": [("متحف", (C("tourism", "museum"),)), ("مسرح", (C("amenity", "theatre"),)), ("سينما", (C("amenity", "cinema"),)), ("مركز ثقافي", (C("amenity", "arts_centre"),))],
    "قطاع المواصلات": [("محطة وقود", (C("amenity", "fuel"),)), ("كراج", (C("amenity", "bus_station"),)), ("محطة قطار", (C("railway", "station"),)), ("سيطرة", (C("barrier", "checkpoint"), C("military", "checkpoint")))],
    "القطاع الخدماتي": [("محطة صرف صحي", (C("man_made", "wastewater_plant"),)), ("محطة مياه", (C("man_made", "water_works"),)), ("محطة كهرباء", (C("power", "substation", "plant"),))],
    "القطاع المدني": [("مؤسسة", (C("office", "ngo", "association"),)), ("دار رعاية", (C("amenity", "social_facility"),))],
}


def cid(sector: str, item: str) -> str:
    return f"sx:{sector}|{item}"


def register() -> None:
    have = {c.id for c in catalog.POI}
    for sec, items in SPEC.items():
        for item, clauses in items:
            i = cid(sec, item)
            if i not in have:
                catalog.POI.append(PoiCat(i, i[3:], i[3:], tuple(clauses)))


def listing() -> list:
    return [{"sector": s, "items": [{"id": cid(s, it), "name": it} for it, _ in items]} for s, items in SPEC.items()]


def operator_of(f: Feature) -> str:
    blob = " ".join([f.name, f.name_en] + [str(v) for v in f.attrs.values()])
    for nm, rx in OPERATORS:
        if re.search(rx, blob, re.I):
            return nm
    return ""


def post(features: List[Feature]) -> None:
    """يحوّل فئة 'قطاع|نوع' إلى Gategory/type ويضيف المشغّل (زين/آسياسيل/كورك) لأبراج الاتصالات."""
    for f in features:
        if "|" in (f.category or ""):
            sec, item = f.category.split("|", 1)
            f.category, f.type = sec, item
            if sec == "قطاع الاتصالات":
                op = operator_of(f)
                if op:
                    f.attrs["operator"] = op
                    if not f.name:
                        f.name = f"{item} {op}"
