"""الجيل الرابع: صور المعالم بلا حدّ للحجم، التراجع/الإعادة، النسخ الاحتياطي، تحليل مكاني، تنزيل البلاطات للعمل بلا إنترنت."""
from __future__ import annotations

import hashlib
import io
import json
import math
import os
import re
import shutil
import tempfile
import threading
import time
import urllib.request
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor

from flask import jsonify, request, send_file

from . import apiv2
from .geo import haversine
from .model import LINE, POINT, POLYGON, Feature, Layer

_TJOBS: dict = {}


def _home() -> str:
    d = os.path.join(os.path.expanduser("~"), "poi_data")
    os.makedirs(d, exist_ok=True)
    return d


def _pdir(fid: str) -> str:
    return hashlib.sha1(fid.encode("utf-8")).hexdigest()[:16]


def _safe(name: str) -> str:
    n = re.sub(r"[^\w.\-؀-ۿ]+", "_", os.path.basename(name or "photo")).strip("._") or "photo"
    return n[-80:]


def pip(lat, lon, f: Feature) -> bool:
    """نقطة داخل مضلع (مع الثقوب) بطريقة الشعاع."""
    inside = False
    for part, hole in zip(f.parts, f.holes or [False] * len(f.parts)):
        c = False
        n = len(part)
        j = n - 1
        for i in range(n):
            xi, yi = part[i]
            xj, yj = part[j]
            if (yi > lat) != (yj > lat) and lon < (xj - xi) * (lat - yi) / ((yj - yi) or 1e-18) + xi:
                c = not c
            j = i
        if c:
            inside = not inside if hole else True if not hole else inside
    return inside


def circle_ring(lat, lon, r, n=36):
    out = []
    for k in range(n):
        a = 2 * math.pi * k / n
        dy = r * math.cos(a) / 110574.0
        dx = r * math.sin(a) / (111320.0 * max(0.05, math.cos(math.radians(lat))))
        out.append((lon + dx, lat + dy))
    out.append(out[0])
    return out


def _all_feats(w, lid):
    l = apiv2._layer_obj(w, lid)
    return l.features if l else []


def register(app):
    # ------------------------------------------------------------------ صور المعالم (بلا حدّ للحجم)
    @app.get("/api/photos/<path:fid>")
    def photos_list(fid):
        w = apiv2._ws()
        try:
            f = w.feature(fid)
            return jsonify([{"ref": p, "url": "/api/photo/" + p} for p in (f.photos if f else [])])
        finally:
            w.close()

    @app.post("/api/photos/<path:fid>")
    def photos_add(fid):
        w = apiv2._ws()
        try:
            before = w.feature(fid)
            if before is None:
                return jsonify(error="المعلم غير موجود"), 404
            d = os.path.join(_home(), "photos", _pdir(fid))
            os.makedirs(d, exist_ok=True)
            after = before.copy()
            for up in request.files.getlist("file"):
                name = "%d_%s" % (int(time.time() * 1000) % 10 ** 10, _safe(up.filename))
                up.save(os.path.join(d, name))            # يُكتب مباشرة على القرص (لا حدّ للحجم)
                after.photos.append(_pdir(fid) + "/" + name)
            w.update_feature(before, after, "إضافة صورة")
            return jsonify(ok=True, photos=[{"ref": p, "url": "/api/photo/" + p} for p in after.photos])
        finally:
            w.close()

    @app.get("/api/photo/<dirn>/<name>")
    def photo_file(dirn, name):
        p = os.path.join(_home(), "photos", os.path.basename(dirn), os.path.basename(name))
        if not os.path.isfile(p):
            return jsonify(error="غير موجود"), 404
        return send_file(p, conditional=True)

    @app.delete("/api/photos/<path:fid>")
    def photos_del(fid):
        ref = request.args.get("ref", "")
        w = apiv2._ws()
        try:
            before = w.feature(fid)
            if before is None or ref not in before.photos:
                return jsonify(error="غير موجود"), 404
            after = before.copy()
            after.photos = [p for p in after.photos if p != ref]
            w.update_feature(before, after, "حذف صورة")
            try:
                os.remove(os.path.join(_home(), "photos", *ref.split("/")))
            except OSError:
                pass
            return jsonify(ok=True)
        finally:
            w.close()

    @app.get("/api/features/<path:fid>/geojson")
    def feature_geojson(fid):
        w = apiv2._ws()
        try:
            f = w.feature(fid)
            if f is None:
                return jsonify(error="غير موجود"), 404
            lay = Layer("x", "x", f.geom, [f])
            g = apiv2.to_geojson(lay, "#1e7bff")["features"][0]
            g["properties"]["attrs"] = f.attrs
            g["properties"]["photos"] = len(f.photos)
            return jsonify(g)
        finally:
            w.close()

    # ------------------------------------------------------------------ التراجع والإعادة
    @app.get("/api/history")
    def hist():
        w = apiv2._ws()
        try:
            return jsonify(can_undo=w.can_undo(), can_redo=w.can_redo(), undo=w.undo_label(),
                           items=[{"seq": s, "ts": t, "label": l, "undone": u} for s, t, l, u in w.history()[:60]])
        finally:
            w.close()

    @app.post("/api/undo")
    def undo():
        w = apiv2._ws()
        try:
            return jsonify(label=w.undo())
        finally:
            w.close()

    @app.post("/api/redo")
    def redo():
        w = apiv2._ws()
        try:
            return jsonify(label=w.redo())
        finally:
            w.close()

    # ------------------------------------------------------------------ نسخة احتياطية كاملة (معالم + صور + إعدادات)
    @app.get("/api/datasets/<lid>/quality")
    def ds_quality(lid):
        from . import quality
        w = apiv2._ws()
        try:
            lay = w.layer(lid)
            if lay is None:
                return jsonify(error="الطبقة غير موجودة"), 404
            r = quality.analyze(lay)
            extra = [f.id for g in r.duplicates for f in g.members[1:]]
            return jsonify(text=r.to_text(True), problems=r.problems(), total=r.total, dup_ids=extra,
                           invalid=len(r.invalid_geometry), outside=len(r.outside_iraq))
        finally:
            w.close()

    @app.post("/api/datasets/<lid>/dedupe")
    def ds_dedupe(lid):
        from . import quality
        w = apiv2._ws()
        try:
            lay = w.layer(lid)
            if lay is None:
                return jsonify(error="الطبقة غير موجودة"), 404
            ids = [f.id for g in quality.analyze(lay).duplicates for f in g.members[1:]]
            if ids:
                w.delete_features(lid, ids, "حذف المكررات")
            return jsonify(ok=True, removed=len(ids))
        finally:
            w.close()

    @app.post("/api/clienterror")
    def client_error():
        from .appstate import ErrorLog
        j = request.get_json(silent=True) or {}
        ErrorLog.add("واجهة: " + str(j.get("m", ""))[:300])
        return jsonify(ok=True)

    @app.get("/api/diag")
    def diag():
        from . import __version__
        from .appstate import ErrorLog
        w = apiv2._ws()
        try:
            ds = apiv2.datasets(w)
            lines = ["version: " + __version__, "layers: %d  features: %d" % (len(ds), sum(d["count"] for d in ds)),
                     "backups: " + str(len([f for f in os.listdir(os.path.join(_home(), "backups"))]) if os.path.isdir(os.path.join(_home(), "backups")) else 0),
                     "", "-- server errors --", ErrorLog.text() or "(none)"]
        finally:
            w.close()
        return jsonify(text="\n".join(lines))

    def _cs_path():
        return os.path.join(_home(), "client_state.json")

    @app.get("/api/clientstate")
    def clientstate_get():
        try:
            return jsonify(json.load(open(_cs_path(), encoding="utf-8")))
        except (OSError, ValueError):
            return jsonify({})

    @app.post("/api/clientstate")
    def clientstate_put():
        d = request.get_json(silent=True)
        if not isinstance(d, dict):
            return jsonify(error="بيانات غير صالحة"), 400
        d = {str(k): str(v) for k, v in d.items() if isinstance(v, str)}
        tmp = _cs_path() + ".tmp"
        os.makedirs(os.path.dirname(tmp), exist_ok=True)
        json.dump(d, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
        os.replace(tmp, _cs_path())
        return jsonify(ok=True, keys=len(d))

    @app.get("/api/backup")
    def backup():
        w = apiv2._ws()
        try:
            tmp = os.path.join(tempfile.mkdtemp(), "m.zip")
            w.backup(tmp)
            out = os.path.join(tempfile.mkdtemp(), "POI-backup-%s.poibak" % time.strftime("%Y%m%d-%H%M"))
            with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
                with zipfile.ZipFile(tmp) as zi:
                    z.writestr("manifest.json", zi.read("manifest.json"))
                sp = os.path.join(_home(), "settings.json")
                if os.path.isfile(sp):
                    z.write(sp, "settings.json")
                if os.path.isfile(_cs_path()):
                    z.write(_cs_path(), "client_state.json")
                pd = os.path.join(_home(), "photos")
                for r, _, fs in os.walk(pd):
                    for fn in fs:
                        full = os.path.join(r, fn)
                        z.write(full, "photos/" + os.path.relpath(full, pd).replace(os.sep, "/"), compress_type=zipfile.ZIP_STORED)
            return send_file(out, as_attachment=True, download_name=os.path.basename(out))
        finally:
            w.close()

    @app.post("/api/restore")
    def restore():
        up = request.files["file"]
        p = os.path.join(tempfile.mkdtemp(), "r.zip")
        up.save(p)
        try:
            z = zipfile.ZipFile(p)
            data = json.loads(z.read("manifest.json").decode("utf-8"))
        except Exception:  # noqa: BLE001
            return jsonify(error="الملف ليس نسخة احتياطية صالحة"), 400
        w = apiv2._ws()
        n = 0
        try:
            have = {r["id"] for r in w.db.execute("SELECT id FROM feature WHERE deleted=0")}
            for L in data.get("layers", []):
                feats = [w._load(d) for d in L["features"]]
                feats = [f for f in feats if f.id not in have]
                if not feats and L["features"]:
                    continue
                lay = Layer("", L["name"], L["geom"], feats, kind=L.get("kind", "user"), color=L.get("color", 0),
                            source=L.get("source", ""), source_date=L.get("source_date", ""))
                w.add_layer_with_features(lay)
                n += len(feats)
            w.db.commit()
        finally:
            w.close()
        pd = os.path.join(_home(), "photos")
        for name in z.namelist():
            if name.startswith("photos/") and not name.endswith("/"):
                dest = os.path.join(pd, *name[7:].split("/"))
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with z.open(name) as s, open(dest, "wb") as t:
                    shutil.copyfileobj(s, t)
        client = {}
        if "client_state.json" in z.namelist():
            try:
                client = json.loads(z.read("client_state.json").decode("utf-8"))
                json.dump(client, open(_cs_path(), "w", encoding="utf-8"), ensure_ascii=False)
            except ValueError:
                client = {}
        return jsonify(ok=True, restored=n, client=client)

    # ------------------------------------------------------------------ التحليل المكاني
    @app.post("/api/analysis")
    def analysis():
        j = request.get_json(force=True)
        op = j.get("op")
        w = apiv2._ws()
        try:
            if op == "stats":
                lid = j.get("layer")
                rows = {}
                feats = _all_feats(w, lid) if lid else [f for d in apiv2.datasets(w) if d["kind"] != "reference" for f in _all_feats(w, d["id"])]
                key = j.get("by", "qadaa")
                attr = {"qadaa": "qadaa", "sector": "category", "type": "type", "mohafadha": "governorate", "nahia": "nahiya"}.get(key, "qadaa")
                for f in feats:
                    k = getattr(f, attr) or "—"
                    rows[k] = rows.get(k, 0) + 1
                return jsonify(total=len(feats), rows=sorted(([k, v] for k, v in rows.items()), key=lambda x: -x[1]))

            if op in ("nearest", "radius"):
                lat, lon = float(j["lat"]), float(j["lon"])
                lids = j.get("layers") or [d["id"] for d in apiv2.datasets(w) if d["kind"] != "reference"]
                res = []
                for lid in lids:
                    for f in _all_feats(w, lid):
                        d = haversine(lat, lon, f.lat, f.lon)
                        res.append((d, f))
                res.sort(key=lambda x: x[0])
                if op == "radius":
                    res = [x for x in res if x[0] <= float(j.get("r", 500))]
                else:
                    res = res[: int(j.get("k", 5))]
                return jsonify([{**apiv2.row(f), "dist": round(d, 1), "geom": f.geom} for d, f in res[:500]])

            if op == "buffer":
                r = float(j["r"])
                src = _all_feats(w, j["layer"])
                nl = w.add_layer("%s — حرم %dم" % ((apiv2._layer_obj(w, j["layer"]).label), r), POLYGON)
                out = []
                for f in src:
                    g = Feature(geom=POLYGON, id=Feature.new_id(), name=f.name, type=f.type, category=f.category)
                    g.add_part(circle_ring(f.lat, f.lon, r))
                    g.lat, g.lon = f.lat, f.lon
                    g.attrs["radius_m"] = str(int(r))
                    out.append(g)
                w.add_features(nl.id, out, "حرم (Buffer)")
                return jsonify(ok=True, layer=nl.id, n=len(out))

            if op == "inside":                                  # اختيار بالموقع: نقاط طبقة داخل مضلعات طبقة أخرى
                polys = [f for f in _all_feats(w, j["polygons"]) if f.geom == POLYGON]
                pts = _all_feats(w, j["layer"])
                hit = [f for f in pts if any(pip(f.lat, f.lon, p) for p in polys)]
                if j.get("save"):
                    nl = w.add_layer(j.get("name") or "داخل المنطقة", POINT)
                    cp = []
                    for f in hit:
                        c = f.copy()
                        c.id = Feature.new_id()
                        cp.append(c)
                    w.add_features(nl.id, cp, "اختيار بالموقع")
                return jsonify(ok=True, n=len(hit), ids=[f.id for f in hit][:5000])

            if op == "duplicates":
                lid = j["layer"]
                dist = float(j.get("dist", 30))
                from . import sectors as sec
                groups, used = [], set()
                feats = [f for f in _all_feats(w, lid) if f.geom == POINT]
                for i, a in enumerate(feats):
                    if a.id in used:
                        continue
                    g = [a]
                    for b in feats[i + 1:]:
                        if b.id in used:
                            continue
                        same = (sec.norm_name(a.name) == sec.norm_name(b.name)) if (a.name or b.name) else True
                        if same and haversine(a.lat, a.lon, b.lat, b.lon) <= dist:
                            g.append(b)
                    if len(g) > 1:
                        for x in g:
                            used.add(x.id)
                        groups.append(g)
                if j.get("remove"):
                    ids = [x.id for g in groups for x in g[1:]]
                    if ids:
                        w.delete_features(lid, ids, "حذف المكرر")
                    return jsonify(ok=True, removed=len(ids))
                return jsonify(groups=[[apiv2.row(x) for x in g] for g in groups[:200]], n=len(groups))

            if op == "fill_admin":
                from .webapp import fast_fill
                feats = _all_feats(w, j["layer"])
                before = [f.copy() for f in feats]
                for f in feats:
                    if j.get("overwrite"):
                        f.qadaa = f.governorate = ""
                fast_fill([f for f in feats if f.geom == POINT])
                w.update_features([(b, a) for b, a in zip(before, feats) if (b.qadaa, b.governorate) != (a.qadaa, a.governorate)], "تعبئة إدارية")
                return jsonify(ok=True, n=len(feats))

            if op == "calc":                                    # حاسبة الحقول: {name} - {type} …
                tpl = j.get("template", "")
                field = j.get("field", "name")
                amap = {"name": "name", "type": "type", "Gategory": "category", "gathaa": "qadaa", "Nahia": "nahiya", "mohafadha": "governorate"}
                if field not in amap:
                    return jsonify(error="حقل غير مدعوم"), 400
                ids = set(j.get("ids") or [])
                feats = [f for f in _all_feats(w, j["layer"]) if not ids or f.id in ids]
                pairs = []

                class _D(dict):
                    def __missing__(self, k):
                        return ""
                for f in feats:
                    a = f.copy()
                    ctx = _D(name=f.name, type=f.type, Gategory=f.category, gathaa=f.qadaa, Nahia=f.nahiya, mohafadha=f.governorate,
                             x=round(f.lon, 6), y=round(f.lat, 6), lat=round(f.lat, 6), lon=round(f.lon, 6), n=len(pairs) + 1, **{k: v for k, v in f.attrs.items() if re.match(r"^\w+$", k)})
                    try:
                        setattr(a, amap[field], tpl.format_map(ctx).strip())
                    except (ValueError, IndexError, KeyError, AttributeError):
                        return jsonify(error="صيغة القالب غير صحيحة"), 400
                    pairs.append((f, a))
                w.update_features(pairs, "حاسبة الحقول")
                return jsonify(ok=True, n=len(pairs))
            return jsonify(error="عملية غير معروفة"), 400
        finally:
            w.close()

    # ------------------------------------------------------------------ تنزيل بلاطات للعمل بلا إنترنت
    @app.post("/api/offline/start")
    def off_start():
        SOURCES = app.config.get("TILE_SOURCES", {})
        j = request.get_json(force=True)
        src = j.get("src", "osm")
        tpl = SOURCES.get(src) or j.get("tpl")
        if not tpl:
            return jsonify(error="مصدر غير معروف"), 400
        s, w_, n, e = [float(x) for x in j["bbox"]]
        z0, z1 = int(j.get("zmin", 8)), min(19, int(j.get("zmax", 15)))
        tiles = []

        def tx(lon, z):
            return int((lon + 180.0) / 360.0 * 2 ** z)

        def ty(lat, z):
            lat = max(-85.0511, min(85.0511, lat))
            r = math.radians(lat)
            return int((1.0 - math.log(math.tan(r) + 1.0 / math.cos(r)) / math.pi) / 2.0 * 2 ** z)
        for z in range(z0, z1 + 1):
            for x in range(tx(w_, z), tx(e, z) + 1):
                for y in range(ty(n, z), ty(s, z) + 1):
                    tiles.append((z, x, y))
        cap = int(j.get("max_tiles", 60000))
        if len(tiles) > cap:
            return jsonify(error="العدد %d بلاطة أكبر من الحدّ %d؛ قلّل المنطقة أو أعلى تكبير" % (len(tiles), cap), tiles=len(tiles)), 400
        if j.get("dry"):
            return jsonify(tiles=len(tiles), mb=round(len(tiles) * 0.025, 1))
        jid = uuid.uuid4().hex[:10]
        st = {"state": "running", "done": 0, "fail": 0, "total": len(tiles), "cancel": False}
        _TJOBS[jid] = st
        tag = src

        def one(t):
            if st["cancel"]:
                return
            z, x, y = t
            f = os.path.join(_home(), "tiles", tag, str(z), str(x), str(y) + ".bin")
            if os.path.exists(f):
                st["done"] += 1
                return
            try:
                req = urllib.request.Request(tpl.format(z=z, x=x, y=y), headers={"User-Agent": "POIExporter/3.6 (personal use)"})
                with urllib.request.urlopen(req, timeout=15) as r:
                    data = r.read()
                os.makedirs(os.path.dirname(f), exist_ok=True)
                with open(f, "wb") as fh:
                    fh.write(data)
            except Exception:  # noqa: BLE001
                st["fail"] += 1
            st["done"] += 1

        def run():
            with ThreadPoolExecutor(max_workers=8) as ex:
                list(ex.map(one, tiles))
            st["state"] = "cancelled" if st["cancel"] else "done"
        threading.Thread(target=run, daemon=True).start()
        return jsonify(id=jid, tiles=len(tiles))

    @app.get("/api/offline/status/<jid>")
    def off_status(jid):
        st = _TJOBS.get(jid)
        return (jsonify({k: v for k, v in st.items()}) if st else (jsonify(error="غير موجود"), 404))

    @app.post("/api/offline/cancel/<jid>")
    def off_cancel(jid):
        if jid in _TJOBS:
            _TJOBS[jid]["cancel"] = True
        return jsonify(ok=True)
