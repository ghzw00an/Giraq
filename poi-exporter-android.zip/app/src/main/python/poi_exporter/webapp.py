"""واجهة ويب خفيفة (Flask + MapLibre) بديلة لواجهة الأندرويد: خريطة، تنزيل، تحويل إحداثيات، تحويل ملفات."""
from __future__ import annotations

import io
import os
import re
import tempfile

from flask import Flask, jsonify, render_template_string, request, send_file

from . import pluscode, catalog, convert as convmod, dashboard, formats, overpass, proj, report as reportmod
from .admin import AdminRef
from .coords import FMT_DD, Crs, format_coord, parse_coord
from .geo import AreaSpec

from .ui import PAGE


def fast_fill(feats, adm=None):
    """يملأ القضاء والمحافظة بسرعة: ذاكرة شبكية (~11 م) تتجنب إعادة البحث للنقاط المتجاورة."""
    adm = adm or AdminRef.get()
    memo = {}
    for f in feats:
        if f.qadaa and f.governorate:
            continue
        k = (round(f.lat, 4), round(f.lon, 4))
        hit = memo.get(k)
        if hit is None:
            adm.fill(f, True)
            memo[k] = (f.qadaa, f.governorate)
        else:
            f.qadaa = f.qadaa or hit[0]
            f.governorate = f.governorate or hit[1]


def create_app(fetcher=None) -> Flask:
    app = Flask(__name__)
    from werkzeug.exceptions import HTTPException

    @app.errorhandler(Exception)
    def _any_error(e):
        """أي خطأ غير متوقع يرجع JSON مفهوماً للواجهة بدل صفحة HTML."""
        if isinstance(e, HTTPException):
            return jsonify(error=e.description), e.code
        return jsonify(error="خطأ غير متوقع: %s" % e), 500

    app.json.sort_keys = False      # يحافظ على ترتيب الحقول التسعة في استجابات JSON
    app.config["JSON_AS_ASCII"] = False
    def get_fetcher(speed=None):
        if fetcher:
            return fetcher
        pf = overpass.profile_of(speed)
        return overpass.http_fetcher(timeout=300 if speed != "old" else 180, retries=pf["retries"], stagger=pf["stagger"],
                                     cache_dir=os.path.join(os.path.expanduser("~"), "poi_data", "overpass_cache") if pf["cache"] else None)

    @app.get("/")
    def index():
        from . import apiv2
        boot = {"cats": [{"id": c.id, "ar": c.ar, "en": c.en} for c in catalog.POI],
                "layers": [{"id": l.id, "ar": l.ar, "en": l.en, "g": ("mm" if l.id.startswith("mm_") else "nat" if l.id.startswith("nat_") else "main")} for l in catalog.LAYERS],
                "fmts": list(formats.FORMATS), "settings": apiv2.settings()}
        return render_template_string(PAGE, boot=boot)

    @app.get("/api/coords")
    def coords():
        from . import gmaps
        text = request.args.get("text", "")
        ref = None
        try:
            ref = (float(request.args["ref_lat"]), float(request.args["ref_lon"]))
        except (KeyError, ValueError):
            pass

        def locate(name):
            try:
                r = app.test_client().get("/api/search", query_string={"q": name}).get_json()
                return (r[0]["lat"], r[0]["lon"]) if r else None
            except Exception:  # noqa: BLE001
                return None
        extra = {}
        try:
            if re.search(r"https?://|\+|^\s*geo:", text, re.I) and not re.match(r"^\s*[\d.\-+°'\"NSEWnsew\s,;:]+$", text):
                g = gmaps.resolve(text, ref, locate)
                if g["kind"] == "gmaps-name":
                    p = locate(g["name"])
                    if not p:
                        return jsonify(error="الرابط يحوي اسم مكان فقط: " + g["name"], name=g["name"]), 400
                    g["lat"], g["lon"] = p
                extra = {k: g[k] for k in ("points", "name", "code", "url") if g.get(k)}
                lat, lon, det = g["lat"], g["lon"], g["kind"]
            else:
                p = parse_coord(text)
                lat, lon, det = p.lat, p.lon, p.fmt
        except ValueError as e:
            return jsonify(error=str(e)), 400
        return jsonify(detected=det, lat=lat, lon=lon, **extra, PLUS=pluscode.encode(lat, lon),
                       GMAPS="https://www.google.com/maps?q=%.6f,%.6f" % (lat, lon), **{f: format_coord(f, lat, lon) for f in ("DD", "DMS", "DDM", "UTM", "MGRS")})

    @app.get("/api/locate")
    def locate():
        h = AdminRef.get().locate(float(request.args["lat"]), float(request.args["lon"]))
        return jsonify(qadaa=h.qadaa(), governorate=h.governorate_name(), boundary_m=h.boundary_m)

    def _run_download(j, progress=None, cancelled=lambda: False):
        """ينفذ التنزيل. يرجع (مسار الملف أو "", اسمه, النتيجة, معرّفات المجموعات المحفوظة)."""
        from . import apiv2
        fmt = j.get("format", "geojson")
        if fmt not in formats.FORMATS:
            raise ValueError("صيغة غير مدعومة")
        s, w, n, e = j["bbox"]
        shape = j.get("shape", "rect")
        if shape == "circle":
            area = AreaSpec.make_circle(float(j["lat"]), float(j["lon"]), float(j.get("radius_m") or 1000)) if "lat" in j \
                else AreaSpec.make_circle((s + n) / 2, (w + e) / 2, float(j.get("radius_m") or 1000))
        elif shape == "rotated" or float(j.get("deg") or 0) % 360:
            area = AreaSpec.rotated(float(j["lat"]), float(j["lon"]), float(j["w_m"]), float(j["h_m"]), float(j.get("deg") or 0))
        else:
            area = AreaSpec.rect(s, w, n, e)
        p = overpass.Params(area=area, poi_cats=j.get("poi", []), layer_ids=set(j.get("layers", [])),
                            custom=j.get("custom", ""), include_unnamed=bool(j.get("unnamed")))
        speed = j.get("speed") or apiv2.settings().get("fetch_speed", "max")
        pf = overpass.profile_of(speed)
        if area.area_km2() > overpass.TILE_KM2:          # لا حدّ لحجم المنطقة: تُقسَّم تلقائياً إلى بلاطات
            res = overpass.run_tiled(p, get_fetcher(speed), progress, cancelled, workers=pf["workers"], tile_km=pf["tile_km"])
        else:
            res = overpass.run(p, get_fetcher(speed), progress, cancelled)
        if not res.layers:
            raise ValueError("; ".join(res.warnings) or "لا نتائج")
        if j.get("fill_admin"):
            for l in res.layers:
                if not l.id.startswith("admin_"):
                    fast_fill(l.features)
        saved = []
        if j.get("autosave", True):
            if progress:
                progress("save", 0, 0)
            saved = apiv2.autosave_fetch(res.layers)
        path, name = "", ""
        if j.get("export", True):
            if progress:
                progress("export", 0, 0)
            path = os.path.join(tempfile.mkdtemp(), "poi" + formats.EXT[fmt])
            formats.export_layers(res.layers, fmt, path)
            name = "poi" + formats.EXT[fmt]
        return path, name, res, saved

    @app.post("/api/download")
    def download():
        try:
            path, name, _, _s = _run_download(dict(request.get_json(force=True), autosave=False))
        except ValueError as e:
            return jsonify(error=str(e)), 400
        except IOError as e:
            return jsonify(error="تعذّر الاتصال بخوادم الخرائط: %s" % e), 502
        return send_file(path, as_attachment=True, download_name=name)

    _JOBS = {}

    @app.post("/api/download/start")
    def download_start():
        import threading
        import uuid
        j = request.get_json(force=True)
        jid = uuid.uuid4().hex[:10]
        st = {"state": "running", "step": "", "done": 0, "total": 0, "error": "", "path": "", "name": "", "count": 0}
        if len(_JOBS) > 12:
            _JOBS.pop(next(iter(_JOBS)))
        _JOBS[jid] = st

        def prog(name, i, n):
            st.update(step=name, done=i, total=n)

        def work():
            try:
                st["path"], st["name"], res, saved = _run_download(j, prog, lambda: st.get("cancel", False))
                st["datasets"] = saved
                st["layers"] = res.layers
                st["count"] = res.feature_count()
                st["warnings"] = res.warnings
                st["state"] = "done"
            except (ValueError, IOError) as e:
                st.update(state="error", error=str(e))
            except Exception as e:  # noqa: BLE001
                st.update(state="error", error="خطأ: %s" % e)
        threading.Thread(target=work, daemon=True).start()
        return jsonify(id=jid)

    @app.post("/api/download/cancel/<jid>")
    def download_cancel(jid):
        if jid in _JOBS:
            _JOBS[jid]["cancel"] = True
        return jsonify(ok=True)

    @app.get("/api/download/status/<jid>")
    def download_status(jid):
        st = _JOBS.get(jid)
        if not st:
            return jsonify(error="غير موجود"), 404
        return jsonify({k: v for k, v in st.items() if k not in ("path", "layers", "cancel")})

    @app.get("/api/download/geojson/<jid>")
    def download_geojson(jid):
        st = _JOBS.get(jid)
        if not st or st["state"] != "done":
            return jsonify(error="غير جاهز"), 404
        path = os.path.join(tempfile.mkdtemp(), "v.geojson")
        formats.export_layers(st["layers"], "geojson", path)
        return send_file(path, mimetype="application/json")

    @app.get("/api/download/result/<jid>")
    def download_result(jid):
        st = _JOBS.get(jid)
        if not st or st["state"] != "done" or not st["path"]:
            return jsonify(error="غير جاهز"), 404
        return send_file(st["path"], as_attachment=True, download_name=st["name"])

    @app.post("/api/convert")
    def convert():
        up = request.files["file"]
        fmt = request.form.get("format", "geojson")
        d = tempfile.mkdtemp()
        src = os.path.join(d, os.path.basename(up.filename))
        up.save(src)
        crs = Crs.of(request.form["crs"]) if request.form.get("crs") else None
        try:
            res = formats.import_file(src, src_crs=crs)
            out = os.path.join(d, "out" + formats.EXT[fmt])
            formats.export_layers(res.layers, fmt, out)
        except (ValueError, KeyError) as e:
            return jsonify(error=str(e)), 400
        return send_file(out, as_attachment=True, download_name="converted" + formats.EXT[fmt])

    def _save_upload(field="file"):
        up = request.files[field]
        d = tempfile.mkdtemp()
        path = os.path.join(d, os.path.basename(up.filename))
        up.save(path)
        return d, path

    @app.get("/api/crs")
    def crs_search():
        return jsonify([{"code": c, "name": n} for c, n in proj.search(request.args.get("q", ""), 30)])

    @app.get("/api/convert-coords")
    def convert_coords():
        try:
            src = Crs.of(request.args["src"]) if request.args.get("src") else None
            tgt = Crs.of(request.args["target"]) if request.args.get("target") else None
            r = convmod.convert(request.args.get("text", ""), src, request.args.get("lonfirst") != "1", tgt)
        except ValueError as e:
            return jsonify(error=str(e)), 400
        return jsonify(lat=r.lat, lon=r.lon, dd=r.dd, dms=r.dms, ddm=r.ddm, utm=r.utm, mgrs=r.mgrs, target=r.target_text,
                       detected=r.detected_format, precision=r.precision_note, warnings=r.warnings)

    @app.post("/api/batch-coords")
    def batch_coords():
        d, src = _save_upload()
        out = os.path.join(d, "converted.csv")
        try:
            rep = convmod.batch_convert(src, out, request.form.get("column") or None, request.form.get("x") or None,
                                        request.form.get("y") or None, Crs.of(request.form["src"]) if request.form.get("src") else None,
                                        Crs.of(request.form["target"]) if request.form.get("target") else None)
        except ValueError as e:
            return jsonify(error=str(e)), 400
        resp = send_file(out, as_attachment=True, download_name="converted.csv")
        resp.headers["X-Rows"], resp.headers["X-Errors"] = str(rep.rows), str(len(rep.errors))
        return resp

    @app.post("/api/dashboard")
    def dash():
        d, src = _save_upload()
        res = formats.import_file(src)
        data = dashboard.compute(res.layers, os.path.basename(src))
        return app.response_class(dashboard.to_html(data), mimetype="text/html")

    @app.post("/api/report")
    def make_report():
        d, src = _save_upload()
        res = formats.import_file(src)
        fmt = request.form.get("format", "pdf")
        out = os.path.join(d, "report." + fmt)
        reportmod.make_report(res.layers, out, title=request.form.get("title", ""), paper=request.form.get("paper", "A4"),
                              landscape=request.form.get("portrait") != "1", color_by_sector=request.form.get("by_sector") == "1",
                              grid=int(request.form.get("grid", 0)), dpi=int(request.form.get("dpi", 150)))
        return send_file(out, as_attachment=True, download_name="report." + fmt)


    # ---------------------------------------------------------------- المعالم المحفوظة (الحقول التسعة الثابتة)
    from . import landmark as lm, sectors as sec
    from .model import Feature, POINT
    from .workspace import Workspace

    def _ws():
        w = Workspace(os.environ.get("POI_DB") or os.path.join(os.path.expanduser("~"), "poi_workspace.db"))
        w.open_default()
        return w

    def _layer(w):
        for l in w.layers():
            if l.kind == "user" and l.label == "المعالم":
                return l
        return w.add_layer("المعالم", POINT)

    def _row(f):
        x, y = lm.xy(f)
        t = lm.text(f)
        return {"id": f.id, "name": t[0], "type": t[1], "Gategory": t[2], "gathaa": t[3], "Nahia": t[4], "mohafadha": t[5],
                "x": lm.num(x, 2), "y": lm.num(y, 2), "link": lm.link(f), "lat": f.lat, "lon": f.lon}

    def _layer_copy():
        """مصدر الأدوات والتحليل: كل نقاط الطبقات المرئية (المعالم المحفوظة والمجلوبة والمستوردة)."""
        from . import apiv2
        w = _ws()
        try:
            return apiv2.merged_points(w)
        finally:
            w.close()

    @app.get("/api/landmarks")
    def landmarks_list():
        w = _ws()
        try:
            return jsonify([_row(f) for f in _layer(w).features])
        finally:
            w.close()

    @app.post("/api/landmarks")
    def landmarks_add():
        j = request.get_json(force=True)
        try:
            lat, lon = float(j["lat"]), float(j["lon"])
        except (KeyError, TypeError, ValueError):
            return jsonify(error="إحداثيات غير صالحة"), 400
        f = Feature.point(lat, lon, id=Feature.new_id(), name=(j.get("name") or "").strip(), type=(j.get("type") or "").strip(),
                          category=(j.get("Gategory") or "").strip())
        AdminRef.get().fill(f, True)
        w = _ws()
        try:
            w.add_feature(_layer(w).id, f)
        finally:
            w.close()
        return jsonify(_row(f))

    @app.post("/api/landmarks/<path:fid>")
    def landmarks_edit(fid):
        j = request.get_json(force=True)
        w = _ws()
        try:
            before = w.feature(fid)
            if before is None:
                return jsonify(error="المعلم غير موجود"), 404
            after = before.copy()
            for k, attr in (("name", "name"), ("type", "type"), ("Gategory", "category"), ("gathaa", "qadaa"),
                            ("Nahia", "nahiya"), ("mohafadha", "governorate")):
                if k in j:
                    setattr(after, attr, (j[k] or "").strip())
            if "link" in j:
                lm.set_link(after, (j["link"] or "").strip())
            if "lat" in j and "lon" in j:
                try:
                    after.lat, after.lon = float(j["lat"]), float(j["lon"])
                except (TypeError, ValueError):
                    return jsonify(error="إحداثيات غير صالحة"), 400
                after.parts = [[(after.lon, after.lat)]]
                if j.get("refill_admin", True):
                    after.qadaa = after.governorate = ""
                    AdminRef.get().fill(after, True)
            w.update_feature(before, after)
        finally:
            w.close()
        return jsonify(_row(after))

    @app.delete("/api/landmarks/<path:fid>")
    def landmarks_del(fid):
        w = _ws()
        try:
            w.delete_features(_layer(w).id, [fid])
        finally:
            w.close()
        return jsonify(ok=True)

    @app.get("/api/landmarks/export")
    def landmarks_export():
        fmt = request.args.get("format", "xlsx")
        if fmt not in formats.FORMATS:
            return jsonify(error="صيغة غير مدعومة"), 400
        w = _ws()
        try:
            from . import apiv2
            layers = apiv2.visible_layers(w)
            if not layers:
                return jsonify(error="لا توجد معالم ظاهرة"), 400
            path = os.path.join(tempfile.mkdtemp(), "landmarks" + formats.EXT[fmt])
            formats.export_layers(layers, fmt, path)
        finally:
            w.close()
        return send_file(path, as_attachment=True, download_name="landmarks" + formats.EXT[fmt])


    @app.post("/api/landmarks/import")
    def landmarks_import():
        d, src = _save_upload()
        skip = request.form.get("skip_dup") == "1"
        try:
            crs = Crs.of(request.form["crs"]) if request.form.get("crs") else None
            res = formats.import_file(src, skip_duplicates=skip, src_crs=crs)
        except (ValueError, KeyError, IOError) as e:
            res = None
            err = str(e)
        if (res is None or res.feature_count() == 0) and not request.form.get("crs") and src.lower().endswith((".csv", ".xlsx", ".xls", ".txt")):
            # جداول X/Y بالمتر (UTM): جرّب مناطق العراق 38 ثم 37 ثم 39 واختر ما يقع داخل العراق
            best, best_n = None, 0
            for ep in (32638, 32637, 32639):
                try:
                    r2 = formats.import_file(src, skip_duplicates=skip, src_crs=Crs.of(ep))
                except (ValueError, KeyError, IOError):
                    continue
                n = sum(1 for l in r2.layers for f in l.features if 28 < f.lat < 38 and 38 < f.lon < 49.5)
                if n > best_n:
                    best, best_n = r2, n
            if best is not None:
                res = best
        if res is None:
            return jsonify(error=err), 400
        feats = [f for l in res.layers for f in l.features if f.geom == POINT]
        if not feats:
            return jsonify(error="لا توجد نقاط في الملف"), 400
        for f in feats:
            if not f.id:
                f.id = Feature.new_id()
        fast_fill(feats)
        w = _ws()
        try:
            w.add_features(_layer(w).id, feats, "استيراد")
        finally:
            w.close()
        return jsonify(added=len(feats), warnings=res.warnings[:5])

    def _report_extras():
        from . import apiplus
        st = apiplus.raster_store()
        rs = []
        for it in st.items:
            if it.visible:
                try:
                    rs.append((it, st.image(it)))
                except Exception:  # noqa: BLE001
                    pass
        return {"notes": apiplus.load_annotations().items, "images": apiplus.ann_images(), "rasters": rs}

    @app.get("/api/landmarks/report")
    def landmarks_report():
        fmt = request.args.get("format", "pdf")
        if fmt not in ("pdf", "png"):
            return jsonify(error="صيغة غير مدعومة"), 400
        w = _ws()
        try:
            from . import apiv2
            layers = apiv2.visible_layers(w)
            if not layers:
                return jsonify(error="لا توجد معالم ظاهرة"), 400
            out = os.path.join(tempfile.mkdtemp(), "report." + fmt)
            reportmod.make_report(layers, out, title=request.args.get("title", "") or "تقرير المعالم",
                                  paper=request.args.get("paper", "A4"), landscape=request.args.get("portrait") != "1",
                                  color_by_sector=request.args.get("by_sector", "1") == "1", grid=int(request.args.get("grid", 0)),
                                  legend=request.args.get("legend", "1") == "1", table=request.args.get("table", "1") == "1",
                                  dpi=int(request.args.get("dpi", 110 if fmt == "png" else 150)),
                                  **_report_extras())
        finally:
            w.close()
        return send_file(out, as_attachment=(request.args.get("inline") != "1"), download_name="report." + fmt)

    @app.get("/api/landmarks/analysis")
    def landmarks_analysis():
        from . import analysis as an
        w = _ws()
        try:
            from . import apiv2
            layer = apiv2.merged_points(w)
            n = len(layer.features)
            if not n:
                return jsonify(error="لا توجد معالم ظاهرة"), 400
            out = {"total": n,
                   "by_sector": an.summarize(layer, 2), "by_gathaa": an.summarize(layer, 3), "by_mohafadha": an.summarize(layer, 5)}
            c = an.mean_centre(layer)
            out["centre"] = {"lat": c.lat, "lon": c.lon, "utm": format_coord("UTM", c.lat, c.lon)}
            if n >= 3:
                try:
                    nn = an.nearest_neighbour(layer)
                    out["nn"] = {"mean_m": round(nn.mean_observed_m, 1), "ratio": round(nn.ratio, 3), "pattern": nn.pattern}
                except (ValueError, ArithmeticError):
                    pass                                    # نقاط على خط واحد/متطابقة: لا مؤشر
                try:
                    eps = float(request.args.get("eps", 500))
                    cl = an.clusters(layer, eps, 3)
                    out["clusters"] = {"eps_m": eps, "count": len(cl), "sizes": sorted((len(k.members) for k in cl), reverse=True)[:10]}
                except (ValueError, ArithmeticError):
                    pass
            return jsonify(out)
        finally:
            w.close()

    from . import apiplus, apiv2
    apiv2.register(app)
    from . import apiv3
    apiv3.register(app)
    from . import apiv4
    apiv4.register(app)
    apiplus.register(app, lambda: _layer_copy())

    return app
