"""الاستيراد والتصدير: CSV/TXT، Excel، GeoJSON، KML/KMZ، GPX، Shapefile (ZIP)، GeoPackage."""
from __future__ import annotations

import csv
import io
import json
import math
import os
import re
import sqlite3
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence, Tuple
from xml.sax.saxutils import escape

from . import landmark, mapper, quality, shapefile, wkb
from .coords import Crs, parse_coord
from .geo import set_representative, signed_area
from .model import LINE, POINT, POLYGON, Feature, Layer
from .sectors import color_hex

FORMATS = ("geojson", "kml", "kmz", "gpx", "shp", "csv", "xlsx", "gpkg", "sql", "dxf")
EXT = {"geojson": ".geojson", "kml": ".kml", "kmz": ".kmz", "gpx": ".gpx", "shp": ".zip",
       "csv": ".csv", "xlsx": ".xlsx", "gpkg": ".gpkg", "sql": ".sql", "dxf": ".dxf"}
WGS_ONLY = {"kml", "kmz", "gpx", "gpkg"}


@dataclass
class ExportOptions:
    target: Optional[Crs] = None      # None = WGS84 هندسةً، وx,y بـ UTM في الجداول
    attributes: bool = True
    doc_name: str = "POI Export"

    def crs(self) -> Crs:
        return self.target or Crs.wgs84()


# ---------------------------------------------------------------------------- مساعدات
def _geom_name(f: Feature) -> str:
    return "Point" if f.geom == POINT else "Line" if f.geom == LINE else "Polygon"


def _row_xy(f: Feature, o: ExportOptions):
    """(x, y, decimals) حسب الخيارات: UTM افتراضياً، وإلا بنظام الهدف."""
    if o.target is None:
        x, y = landmark.xy(f, None)
        return x, y, 2
    t = o.target
    if t.epsg == 4326:
        return f.lon, f.lat, 9
    return (*landmark.xy(f, t.transformer_from_wgs84()), 9 if t.geographic else 3)


def _extra_keys(layers: Sequence[Layer], limit: int = 200) -> List[str]:
    keys: List[str] = []
    for l in layers:
        for f in l.features:
            for k in f.attrs:
                if not landmark.is_std(k) and k not in keys:
                    keys.append(k)
            if len(keys) > limit:
                return keys
    return keys


def _table(layers: Sequence[Layer], o: ExportOptions):
    any_non_point = any(f.geom != POINT for l in layers for f in l.features)
    keys = _extra_keys(layers) if o.attributes else []
    header = list(landmark.NAMES) + keys + (["geometry"] if any_non_point else [])
    rows = []
    for l in layers:
        for f in l.features:
            if not f.parts:
                continue
            x, y, dec = _row_xy(f, o)
            if math.isnan(x) or math.isnan(y):
                continue
            row = landmark.text(f) + [x, y, dec, landmark.link(f)]
            rows.append(row[:6] + [x, y] + [row[-1]] + [f.attrs.get(k, "") for k in keys]
                        + ([_geom_name(f)] if any_non_point else []))
            rows[-1].append(dec)   # آخر عنصر مؤقت: عدد الخانات العشرية
    return header, rows


def preflight(layers: Sequence[Layer], fmt: str, o: ExportOptions) -> List[str]:
    """تحذيرات قبل الكتابة: هندسة غير صالحة، نظام غير مدعوم، حدود الحجم. قائمة فارغة = آمن."""
    w, n, empty, bad, selfx = [], 0, 0, 0, 0
    for l in layers:
        for f in l.features:
            n += 1
            c = quality.check(f, 0)
            if quality.EMPTY in c or quality.TOO_FEW_POINTS in c:
                empty += 1
            elif quality.OUT_OF_RANGE in c:
                bad += 1
            elif quality.SELF_INTERSECTION in c:
                selfx += 1
    if n == 0:
        w.append("لا توجد عناصر للتصدير.")
    if empty:
        w.append(f"{empty} عنصر بلا هندسة صالحة سيُتجاهل.")
    if bad:
        w.append(f"{bad} عنصر بإحداثيات خارج النطاق.")
    if selfx:
        w.append(f"{selfx} مضلع يتقاطع مع نفسه؛ قد ترفضه برامج GIS. استخدم «فحص الجودة» للإصلاح.")
    if fmt in WGS_ONLY and o.crs().epsg != 4326:
        w.append(f"{fmt.upper()} يدعم WGS84 فقط؛ اختر WGS84 أو صيغة أخرى (Shapefile / CSV / GeoJSON).")
    if fmt == "xlsx" and n > 1_000_000:
        w.append("سيُقسَّم الجدول على عدة أوراق (حد Excel مليون صف).")
    if fmt == "gpx" and any(f.geom == POLYGON for l in layers for f in l.features):
        w.append("GPX لا يدعم المضلعات؛ ستُكتب حدودها كمسارات.")
    return w


def _require_wgs(fmt: str, o: ExportOptions) -> None:
    if o.crs().epsg != 4326:
        raise ValueError(f"{fmt.upper()} يدعم WGS84 فقط")


# ---------------------------------------------------------------------------- CSV / XLSX
def write_csv(layers: Sequence[Layer], fh, o: Optional[ExportOptions] = None) -> None:
    """CSV بترميز UTF-8 مع BOM (يفتح صحيحاً في Excel). fh: ملف نصي مفتوح بـ newline=''."""
    o = o or ExportOptions()
    header, rows = _table(layers, o)
    fh.write("\ufeff")
    w = csv.writer(fh, lineterminator="\r\n", quoting=csv.QUOTE_MINIMAL)
    w.writerow(header)
    for r in rows:
        dec = r.pop()
        r[6], r[7] = "%.*f" % (dec, r[6]), "%.*f" % (dec, r[7])
        w.writerow(r)


def write_xlsx(layers: Sequence[Layer], path_or_file, o: Optional[ExportOptions] = None) -> None:
    from openpyxl import Workbook
    o = o or ExportOptions()
    header, rows = _table(layers, o)
    wb = Workbook(write_only=True)
    ws = wb.create_sheet("data")
    ws.sheet_view.rightToLeft = True
    ws.append(header)
    for r in rows:
        dec = r.pop()
        r[6], r[7] = round(r[6], dec), round(r[7], dec)
        ws.append(r)
    wb.save(path_or_file)


# ---------------------------------------------------------------------------- GeoJSON
def _round(v: float, dec: int) -> float:
    return round(v, dec)


def _geojson_geometry(f: Feature, tx, dec: int) -> dict:
    def c(p):
        x, y = tx(*p) if tx else p
        return [_round(x, dec), _round(y, dec)]
    if f.geom == POINT:
        return {"type": "Point", "coordinates": c(f.parts[0][0])}
    if f.geom == LINE:
        if len(f.parts) == 1:
            return {"type": "LineString", "coordinates": [c(p) for p in f.parts[0]]}
        return {"type": "MultiLineString", "coordinates": [[c(p) for p in part] for part in f.parts]}
    from .geo import oriented
    polys: List[list] = []
    for i, r in enumerate(f.parts):
        ring = [c(p) for p in oriented(r, clockwise=f.is_hole(i))]     # RFC 7946: خارجي CCW، ثقب CW
        if f.is_hole(i) and polys:
            polys[-1].append(ring)
        else:
            polys.append([ring])
    if len(polys) == 1:
        return {"type": "Polygon", "coordinates": polys[0]}
    return {"type": "MultiPolygon", "coordinates": polys}


def feature_properties(f: Feature, attributes: bool = True, o: Optional[ExportOptions] = None) -> dict:
    t = landmark.text(f)
    p = {landmark.NAMES[i]: t[i] for i in range(6)}
    x, y = landmark.xy(f, None)
    p["x"] = None if math.isnan(x) else round(x, 2)
    p["y"] = None if math.isnan(y) else round(y, 2)
    p["link"] = landmark.link(f)
    if attributes:
        for k, v in f.attrs.items():
            if not landmark.is_std(k) and v not in (None, ""):
                p[k] = v
    return p


def to_geojson(layers: Sequence[Layer], o: Optional[ExportOptions] = None) -> dict:
    o = o or ExportOptions()
    t = o.crs()
    tx = None if t.epsg == 4326 else t.transformer_from_wgs84()
    dec = 9 if t.geographic else 3
    feats = []
    for l in layers:
        for f in l.features:
            if not f.parts:
                continue
            ft = {"type": "Feature", "geometry": _geojson_geometry(f, tx, dec),
                  "properties": feature_properties(f, o.attributes, o)}
            if f.id:
                ft["id"] = f.id
            feats.append(ft)
    out = {"type": "FeatureCollection"}
    if t.epsg != 4326:
        out["crs"] = {"type": "name", "properties": {"name": f"urn:ogc:def:crs:EPSG::{t.epsg}"}}
    out["features"] = feats
    return out


def write_geojson(layers, fh, o=None) -> None:
    json.dump(to_geojson(layers, o), fh, ensure_ascii=False, separators=(",", ":"))
    fh.write("\n")


def _crs_from_geojson(root: dict) -> Optional[Crs]:
    name = ((root.get("crs") or {}).get("properties") or {}).get("name", "")
    m = re.search(r"EPSG:+(\d+)", name) or re.search(r"CRS84", name)
    if not m:
        return None
    return Crs.wgs84() if m.group(0).endswith("CRS84") else Crs.of(int(m.group(1)))


def _features_from_geometry(g: dict, to_wgs) -> List[Feature]:
    if not g:
        return []
    t, co = g.get("type"), g.get("coordinates")
    tr = (lambda p: to_wgs(p[0], p[1])) if to_wgs else (lambda p: (p[0], p[1]))
    out: List[Feature] = []

    def mk(geom, parts, holes):
        f = Feature(geom=geom, id=Feature.new_id())
        for p, h in zip(parts, holes):
            f.add_part([tr(c) for c in p], h)
        set_representative(f)
        out.append(f)

    if t == "Point":
        mk(POINT, [[co]], [False])
    elif t == "MultiPoint":
        for c in co:
            mk(POINT, [[c]], [False])
    elif t == "LineString":
        mk(LINE, [co], [False])
    elif t == "MultiLineString":
        mk(LINE, co, [False] * len(co))
    elif t == "Polygon":
        mk(POLYGON, co, [i > 0 for i in range(len(co))])
    elif t == "MultiPolygon":
        parts, holes = [], []
        for poly in co:
            for i, r in enumerate(poly):
                parts.append(r)
                holes.append(i > 0)
        mk(POLYGON, parts, holes)
    elif t == "GeometryCollection":
        for gg in g.get("geometries", []):
            out.extend(_features_from_geometry(gg, to_wgs))
    return out


def _group_into_layers(feats: List[Feature], label: str, source: str) -> List[Layer]:
    by: Dict[int, Layer] = {}
    names = {POINT: "نقاط", LINE: "خطوط", POLYGON: "مضلعات"}
    for f in feats:
        l = by.get(f.geom)
        if l is None:
            l = by[f.geom] = Layer(f"imp_{len(by)}_{abs(hash(label)) % 10**6}", label, f.geom, kind="import", source=source)
        l.features.append(f)
    if len(by) > 1:
        for g, l in by.items():
            l.label = f"{label} — {names[g]}"
    return list(by.values())


def read_geojson(text_or_bytes, label: str = "geojson") -> List[Layer]:
    if isinstance(text_or_bytes, (bytes, bytearray)):
        text_or_bytes = text_or_bytes.decode("utf-8-sig")
    root = json.loads(text_or_bytes)
    crs = _crs_from_geojson(root)
    to_wgs = crs.transformer_to_wgs84() if crs and crs.epsg != 4326 else None
    items = root.get("features") if root.get("type") == "FeatureCollection" else \
        [root] if root.get("type") == "Feature" else [{"type": "Feature", "geometry": root, "properties": {}}]
    feats: List[Feature] = []
    for it in items:
        props = {k: ("" if v is None else (v if isinstance(v, str) else json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else str(v)))
                 for k, v in (it.get("properties") or {}).items()}
        for f in _features_from_geometry(it.get("geometry"), to_wgs):
            mapper.apply(f, props)
            if it.get("id") not in (None, "") and not props.get("id"):
                f.id = str(it["id"])
            feats.append(f)
    return _group_into_layers(feats, label, label)


# ---------------------------------------------------------------------------- KML / KMZ
def _abgr(rgb: int, alpha: int = 0xFF) -> str:
    return "%02x%02x%02x%02x" % (alpha, rgb & 0xFF, (rgb >> 8) & 0xFF, (rgb >> 16) & 0xFF)


def _kml_coords(p) -> str:
    return " ".join("%.9g,%.9g,0" % c for c in p)


def to_kml(layers: Sequence[Layer], doc_name: str = "POI Export") -> str:
    parts = ['<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>',
             escape(doc_name), "</name>\n"]
    from .sectors import COLORS
    palette = [0xE8590C, 0x1C7ED6, 0x2B8A3E, 0xE03131, 0x862E9C, 0xF59F00]
    for i, l in enumerate(layers):
        c = l.color & 0xFFFFFF if l.color else palette[i % len(palette)]
        a = _abgr(c)
        parts.append(f'<Style id="s{i}"><IconStyle><color>{a}</color><scale>0.9</scale></IconStyle>'
                     f'<LineStyle><color>{a}</color><width>2</width></LineStyle>'
                     f'<PolyStyle><color>55{a[2:]}</color></PolyStyle></Style>\n')
    for i, l in enumerate(layers):
        parts.append(f"<Folder><name>{escape(l.label)}</name>\n")
        for f in l.features:
            if not f.parts:
                continue
            p = feature_properties(f, True)
            desc = "".join(f"<b>{escape(k)}</b>: {escape(str(v))}<br/>" for k, v in p.items() if v not in (None, ""))
            parts.append(f"<Placemark><name>{escape(f.name)}</name><styleUrl>#s{i}</styleUrl>"
                         f"<description><![CDATA[{desc}]]></description><ExtendedData>")
            for k, v in p.items():
                parts.append(f'<Data name="{escape(k, {chr(34): "&quot;"})}"><value>{escape("" if v is None else str(v))}</value></Data>')
            parts.append("</ExtendedData>")
            if f.geom == POINT:
                parts.append(f"<Point><coordinates>{_kml_coords(f.parts[0][:1])}</coordinates></Point>")
            elif f.geom == LINE:
                geoms = [f"<LineString><tessellate>1</tessellate><coordinates>{_kml_coords(p)}</coordinates></LineString>" for p in f.parts]
                parts.append(geoms[0] if len(geoms) == 1 else "<MultiGeometry>" + "".join(geoms) + "</MultiGeometry>")
            else:
                polys, cur = [], None
                for k, r in enumerate(f.parts):
                    ring = f"<LinearRing><coordinates>{_kml_coords(r)}</coordinates></LinearRing>"
                    if f.is_hole(k) and cur is not None:
                        cur.append(f"<innerBoundaryIs>{ring}</innerBoundaryIs>")
                    else:
                        cur = [f"<outerBoundaryIs>{ring}</outerBoundaryIs>"]
                        polys.append(cur)
                xml = ["<Polygon>" + "".join(c) + "</Polygon>" for c in polys]
                parts.append(xml[0] if len(xml) == 1 else "<MultiGeometry>" + "".join(xml) + "</MultiGeometry>")
            parts.append("</Placemark>\n")
        parts.append("</Folder>\n")
    parts.append("</Document></kml>\n")
    return "".join(parts)


def write_kml(layers, fh_bin, doc_name="POI Export", kmz=False) -> None:
    data = to_kml(layers, doc_name).encode("utf-8")
    if kmz:
        with zipfile.ZipFile(fh_bin, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("doc.kml", data)
    else:
        fh_bin.write(data)


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _kml_coord_list(text: str):
    out = []
    for tok in (text or "").split():
        v = tok.split(",")
        if len(v) >= 2:
            try:
                out.append((float(v[0]), float(v[1])))
            except ValueError:
                pass
    return out


def read_kml(data: bytes, label: str = "kml") -> List[Layer]:
    if data[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            name = next((n for n in z.namelist() if n.lower().endswith(".kml")), None)
            if not name:
                raise ValueError("KMZ لا يحوي ملف KML")
            data = z.read(name)
    root = ET.fromstring(data)
    layers: List[Layer] = []

    def folder_layers(node, fname):
        feats = []
        for pm in node.iter():
            if _local(pm.tag) != "Placemark":
                continue
            props = {}
            name = ""
            for ch in pm:
                lt = _local(ch.tag)
                if lt == "name":
                    name = (ch.text or "").strip()
                elif lt == "ExtendedData":
                    for d in ch.iter():
                        if _local(d.tag) == "Data":
                            v = next((x.text for x in d if _local(x.tag) == "value"), "")
                            props[d.get("name", "")] = v or ""
                        elif _local(d.tag) == "SimpleData":
                            props[d.get("name", "")] = d.text or ""
            for g in pm.iter():
                lt = _local(g.tag)
                if lt == "Point":
                    c = _kml_coord_list(next((x.text for x in g.iter() if _local(x.tag) == "coordinates"), ""))
                    if c:
                        f = Feature.point(c[0][1], c[0][0], id=Feature.new_id())
                        f.name = name
                        mapper.apply(f, props)
                        if name:
                            f.name = name
                        feats.append(f)
                elif lt == "LineString":
                    c = _kml_coord_list(next((x.text for x in g.iter() if _local(x.tag) == "coordinates"), ""))
                    if len(c) >= 2:
                        f = Feature(geom=LINE, id=Feature.new_id(), name=name)
                        f.add_part(c)
                        mapper.apply(f, props)
                        if name:
                            f.name = name
                        set_representative(f)
                        feats.append(f)
                elif lt == "Polygon":
                    f = Feature(geom=POLYGON, id=Feature.new_id(), name=name)
                    for b in g:
                        bl = _local(b.tag)
                        if bl in ("outerBoundaryIs", "innerBoundaryIs"):
                            c = _kml_coord_list(next((x.text for x in b.iter() if _local(x.tag) == "coordinates"), ""))
                            if len(c) >= 4:
                                f.add_part(c, bl == "innerBoundaryIs")
                    if f.parts:
                        mapper.apply(f, props)
                        if name:
                            f.name = name
                        set_representative(f)
                        feats.append(f)
        return _group_into_layers(feats, fname, label)

    folders = [n for n in root.iter() if _local(n.tag) == "Folder"]
    done = False
    for fo in folders:
        has_sub = any(_local(c.tag) == "Folder" for c in fo)
        if has_sub:
            continue
        nm = next((c.text for c in fo if _local(c.tag) == "name"), None) or label
        ls = folder_layers(fo, nm.strip())
        layers.extend(ls)
        done = done or bool(ls)
    if not done:
        layers = folder_layers(root, label)
    return layers


# ---------------------------------------------------------------------------- GPX
def to_gpx(layers: Sequence[Layer]) -> str:
    out = ['<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="POI Exporter" xmlns="http://www.topografix.com/GPX/1/1">\n']
    for l in layers:
        for f in l.features:
            if f.geom == POINT and f.parts:
                x, y = f.parts[0][0]
                out.append(f'<wpt lat="{y:.9f}" lon="{x:.9f}"><name>{escape(f.name)}</name>'
                           f'<desc>{escape(" | ".join(v for v in (f.category, f.type) if v))}</desc>'
                           f'<type>{escape(f.type)}</type></wpt>\n')
    for l in layers:
        for f in l.features:
            if f.geom in (LINE, POLYGON):
                out.append(f"<trk><name>{escape(f.name)}</name>")
                for p in f.parts:
                    out.append("<trkseg>" + "".join(f'<trkpt lat="{y:.9f}" lon="{x:.9f}"/>' for x, y in p) + "</trkseg>")
                out.append("</trk>\n")
    out.append("</gpx>\n")
    return "".join(out)


def read_gpx(data: bytes, label: str = "gpx") -> List[Layer]:
    root = ET.fromstring(data)
    wpts, rtes, trks = [], [], []
    for n in root:
        t = _local(n.tag)
        sub = {_local(c.tag): c for c in n}
        name = (sub["name"].text or "").strip() if "name" in sub else ""
        if t == "wpt":
            f = Feature.point(float(n.get("lat")), float(n.get("lon")), id=Feature.new_id(), name=name)
            if "type" in sub and sub["type"].text:
                f.type = sub["type"].text
            if "desc" in sub and sub["desc"].text:
                f.description = sub["desc"].text
            wpts.append(f)
        elif t in ("rte", "trk"):
            f = Feature(geom=LINE, id=Feature.new_id(), name=name)
            if t == "rte":
                pts = [(float(p.get("lon")), float(p.get("lat"))) for p in n if _local(p.tag) == "rtept"]
                if len(pts) >= 2:
                    f.add_part(pts)
            else:
                for seg in n:
                    if _local(seg.tag) == "trkseg":
                        pts = [(float(p.get("lon")), float(p.get("lat"))) for p in seg if _local(p.tag) == "trkpt"]
                        if len(pts) >= 2:
                            f.add_part(pts)
            if f.parts:
                set_representative(f)
                (rtes if t == "rte" else trks).append(f)
    layers = []
    for lab, g, fs in (("waypoints", POINT, wpts), ("routes", LINE, rtes), ("tracks", LINE, trks)):
        if fs:
            layers.append(Layer(f"imp_gpx_{lab}", f"{label} — {lab}", g, fs, kind="import", source=label))
    return layers


# ---------------------------------------------------------------------------- GeoPackage
_GPKG_APP_ID, _GPKG_USER_VERSION = 0x47504B47, 10300


def _gpkg_blob(f: Feature, srs: int = 4326) -> bytes:
    return b"GP" + bytes([0, 1]) + srs.to_bytes(4, "little", signed=True) + wkb.encode(f)


def write_gpkg(layers: Sequence[Layer], path: str, attributes: bool = True) -> List[str]:
    """يكتب GeoPackage (WGS84). جدول لكل (طبقة × نوع هندسة). يرجع أسماء الجداول."""
    if os.path.exists(path):
        os.remove(path)
    db = sqlite3.connect(path)
    db.execute(f"PRAGMA application_id={_GPKG_APP_ID}")
    db.execute(f"PRAGMA user_version={_GPKG_USER_VERSION}")
    db.executescript("""
CREATE TABLE gpkg_spatial_ref_sys(srs_name TEXT NOT NULL, srs_id INTEGER PRIMARY KEY, organization TEXT NOT NULL,
  organization_coordsys_id INTEGER NOT NULL, definition TEXT NOT NULL, description TEXT);
CREATE TABLE gpkg_contents(table_name TEXT PRIMARY KEY, data_type TEXT NOT NULL, identifier TEXT UNIQUE, description TEXT DEFAULT '',
  last_change DATETIME NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')), min_x DOUBLE, min_y DOUBLE, max_x DOUBLE, max_y DOUBLE, srs_id INTEGER);
CREATE TABLE gpkg_geometry_columns(table_name TEXT NOT NULL, column_name TEXT NOT NULL, geometry_type_name TEXT NOT NULL,
  srs_id INTEGER NOT NULL, z TINYINT NOT NULL, m TINYINT NOT NULL, PRIMARY KEY(table_name, column_name));
""")
    wgs = Crs.wgs84().wkt()
    db.executemany("INSERT INTO gpkg_spatial_ref_sys VALUES(?,?,?,?,?,?)", [
        ("Undefined cartesian SRS", -1, "NONE", -1, "undefined", None),
        ("Undefined geographic SRS", 0, "NONE", 0, "undefined", None),
        ("WGS 84", 4326, "EPSG", 4326, wgs, None)])
    tables, used = [], set()
    gname = {POINT: "POINT", LINE: "GEOMETRY", POLYGON: "GEOMETRY"}
    for l in layers:
        by: Dict[int, List[Feature]] = {}
        for f in l.features:
            if f.parts:
                by.setdefault(f.geom, []).append(f)
        for g, fs in by.items():
            base = shapefile.safe_name(l.label, l.id)
            if len(by) > 1:
                base += {POINT: "_points", LINE: "_lines", POLYGON: "_polygons"}[g]
            name, i = base, 2
            while name.lower() in used:
                name, i = f"{base}_{i}", i + 1
            used.add(name.lower())
            extra = []
            seen_cols = {"fid", "geom"} | {n.lower() for n in landmark.NAMES}
            if attributes:
                for f in fs:
                    for k in f.attrs:
                        col = re.sub(r"[^A-Za-z0-9_]", "_", k) or "f"
                        if k not in [e[0] for e in extra] and col.lower() not in seen_cols and not landmark.is_std(k):
                            extra.append((k, col))
                            seen_cols.add(col.lower())
            cols = ",".join(f'"{n}" TEXT' for n in landmark.NAMES[:6]) + ',"x" REAL,"y" REAL,"link" TEXT' + \
                   "".join(f',"{c}" TEXT' for _, c in extra)
            db.execute(f'CREATE TABLE "{name}"(fid INTEGER PRIMARY KEY AUTOINCREMENT, geom BLOB, {cols})')
            xs = [p[0] for f in fs for part in f.parts for p in part]
            ys = [p[1] for f in fs for part in f.parts for p in part]
            db.execute("INSERT INTO gpkg_contents(table_name,data_type,identifier,min_x,min_y,max_x,max_y,srs_id) VALUES(?,?,?,?,?,?,?,4326)",
                       (name, "features", name, min(xs), min(ys), max(xs), max(ys)))
            db.execute("INSERT INTO gpkg_geometry_columns VALUES(?,?,?,?,0,0)", (name, "geom", gname[g], 4326))
            ph = ",".join("?" * (1 + 6 + 3 + len(extra)))
            for f in fs:
                x, y = landmark.xy(f, None)
                db.execute(f'INSERT INTO "{name}"(geom,{",".join(chr(34)+n+chr(34) for n in landmark.NAMES[:6])},x,y,link'
                           f'{"".join(","+chr(34)+c+chr(34) for _, c in extra)}) VALUES({ph})',
                           [_gpkg_blob(f)] + landmark.text(f) + [None if math.isnan(x) else x, None if math.isnan(y) else y, landmark.link(f)]
                           + [f.attrs.get(k, "") for k, _ in extra])
            tables.append(name)
    db.commit()
    db.close()
    return tables


def read_gpkg(path: str, label: str = "gpkg") -> List[Layer]:
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    layers = []
    try:
        for gc in db.execute("SELECT table_name, column_name, srs_id FROM gpkg_geometry_columns").fetchall():
            t, col, srs = gc["table_name"], gc["column_name"], gc["srs_id"]
            crs = Crs.of(srs) if srs and srs > 0 else Crs.wgs84()
            to_wgs = crs.transformer_to_wgs84() if crs.epsg != 4326 else None
            by: Dict[int, Layer] = {}
            for row in db.execute(f'SELECT * FROM "{t}"'):
                blob = row[col]
                if not blob or blob[:2] != b"GP":
                    continue
                flags = blob[3]
                env = {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}.get((flags >> 1) & 7, 0)
                if flags & 0x10:      # هندسة فارغة
                    continue
                try:
                    fs = wkb.decode(blob[8 + env:])
                except Exception:  # noqa: BLE001
                    continue
                props = {k: ("" if row[k] is None else str(row[k])) for k in row.keys() if k not in (col, "fid")}
                for f in fs:
                    if to_wgs:
                        f.parts = [[to_wgs(x, y) for x, y in p] for p in f.parts]
                        set_representative(f)
                    f.id = Feature.new_id()
                    mapper.apply(f, props)
                    l = by.setdefault(f.geom, Layer(f"imp_{t}_{f.geom}", t, f.geom, kind="import", source=label))
                    l.features.append(f)
            layers.extend(by.values())
    finally:
        db.close()
    return layers


# ---------------------------------------------------------------------------- جداول (CSV/TXT/XLSX) للاستيراد
def read_table(path: str, sheet: Optional[str] = None) -> Tuple[List[str], List[List[str]]]:
    """يقرأ ملف CSV/TXT (يكتشف الفاصل والترميز) أو XLSX. يرجع (العناوين، الصفوف)."""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb[sheet] if sheet else wb.active
        rows = [["" if c is None else (("%r" % c).rstrip("0").rstrip(".") if isinstance(c, float) and c != int(c) else str(int(c)) if isinstance(c, float) else str(c)) for c in r]
                for r in ws.iter_rows(values_only=True)]
        wb.close()
        rows = [r for r in rows if any(x.strip() for x in r)]
        if not rows:
            return [], []
        return [h.strip() for h in rows[0]], rows[1:]
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "cp1256", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    rows = [r for r in csv.reader(io.StringIO(text), dialect) if any(c.strip() for c in r)]
    if not rows:
        return [], []
    return [h.strip() for h in rows[0]], rows[1:]


@dataclass
class RowReport:
    read: int = 0
    ok: int = 0
    bad: List[Tuple[int, str]] = field(default_factory=list)


@dataclass
class Mapping:
    x: int = -1
    y: int = -1
    name: int = -1
    combined: int = -1
    combined_lon_first: bool = False


def _hnorm(h: str) -> str:
    return re.sub(r"[\s_\-.()]", "", h.lower())


def guess_columns(header: Sequence[str]) -> Mapping:
    lat = lon = east = north = x = y = -1
    m = Mapping()
    for i, h0 in enumerate(header):
        h = _hnorm(h0)
        if h in ("lat", "latitude", "خطالعرض", "دائرةالعرض", "عرض", "latdd", "ycoord", "wgs84lat"):
            lat = i if lat < 0 else lat
        elif h in ("lon", "lng", "long", "longitude", "خطالطول", "طول", "londd", "xcoord", "wgs84lon"):
            lon = i if lon < 0 else lon
        elif h in ("easting", "east", "e", "شرقي", "إحداثيشرقي", "شرق"):
            east = i if east < 0 else east
        elif h in ("northing", "north", "n", "شمالي", "إحداثيشمالي", "شمال"):
            north = i if north < 0 else north
        elif h == "x":
            x = i if x < 0 else x
        elif h == "y":
            y = i if y < 0 else y
        elif m.name < 0 and (h in ("name", "اسم", "الاسم", "title", "label", "اسمالمعلم", "المعلم", "namear", "nameen") or h.startswith("name")):
            m.name = i
        elif m.combined < 0 and h in ("coord", "coords", "coordinates", "coordinate", "الاحداثيات", "الإحداثيات", "احداثيات",
                                      "إحداثيات", "location", "الموقع", "position", "mgrs", "utm", "latlon", "latlng"):
            m.combined = i
    if lat >= 0 and lon >= 0:
        m.x, m.y = lon, lat
    elif east >= 0 and north >= 0:
        m.x, m.y = east, north
    elif x >= 0 and y >= 0:
        m.x, m.y = x, y
    if m.x >= 0 and m.y >= 0:
        m.combined = -1
    return m


def parse_num(s: Optional[str]) -> float:
    """رقم بأرقام عربية/فارسية وفاصلة عشرية؛ NaN إن لم يكن رقماً."""
    if s is None:
        return float("nan")
    dot = "." in s or "٫" in s
    commas = s.count(",") + s.count("،")
    b = []
    for c in s:
        if "٠" <= c <= "٩":
            b.append(chr(48 + ord(c) - ord("٠")))
        elif "۰" <= c <= "۹":
            b.append(chr(48 + ord(c) - ord("۰")))
        elif c == "٫":
            b.append(".")
        elif c in ",،" and not dot and commas == 1:
            b.append(".")
        elif c in ",،٬ \u00a0":
            continue
        elif c in "−–":
            b.append("-")
        else:
            b.append(c)
    t = "".join(b).strip()
    if not t or not (t[0] in "-+." or t[0].isdigit()) or any(ch not in "0123456789.-+eE" for ch in t):
        return float("nan")
    try:
        v = float(t)
        return float("nan") if math.isinf(v) else v
    except ValueError:
        return float("nan")


def table_to_layer(path: str, m: Optional[Mapping] = None, src: Optional[Crs] = None, name: Optional[str] = None,
                   sheet: Optional[str] = None):
    """يحوّل جدولاً فيه أعمدة إحداثيات إلى طبقة نقاط. يرجع (Layer, RowReport)."""
    header, rows = read_table(path, sheet)
    m = m or guess_columns(header)
    geo = src is None or src.geographic
    to_wgs = src.transformer_to_wgs84() if src and src.epsg != 4326 else None
    use_comb = m.combined >= 0 and (m.x < 0 or m.y < 0)
    if not use_comb and (m.x < 0 or m.y < 0):
        raise ValueError("حدّد عمودي X وY أو عموداً واحداً للإحداثيات")
    label = re.sub(r"\.[A-Za-z0-9]+$", "", name or os.path.basename(path))
    layer = Layer(f"imp_{abs(hash(path)) % 10**8}", label, POINT, kind="import", source=name or os.path.basename(path))
    rep = RowReport()
    cell = lambda row, i: row[i] if 0 <= i < len(row) and row[i] is not None else ""
    for rn, row in enumerate(rows, 2):
        rep.read += 1
        try:
            if use_comb:
                s = cell(row, m.combined)
                p = parse_coord(s)
                lat, lon = p.lat, p.lon
                if m.combined_lon_first and p.fmt == "DD" and not re.search("[NSEW]", s.upper()):
                    lat, lon = lon, lat
                    if abs(lat) > 90:
                        raise ValueError("خط العرض خارج ±90")
            else:
                sa, sb = cell(row, m.x), cell(row, m.y)
                a, b = parse_num(sa), parse_num(sb)
                if math.isnan(a) or math.isnan(b):
                    raise ValueError(f"قيمة إحداثي غير رقمية أو فارغة ({sa} / {sb})")
                if geo:
                    if abs(b) > 90:
                        raise ValueError(f"خط العرض {sb} خارج المدى ±90 (هل عمودا الطول والعرض معكوسان؟)")
                    if abs(a) > 180:
                        raise ValueError(f"خط الطول {sa} خارج المدى ±180")
                    lon, lat = (to_wgs(a, b) if to_wgs else (a, b))
                else:
                    lon, lat = to_wgs(a, b)
            if math.isnan(lat) or math.isnan(lon) or abs(lat) > 90 or abs(lon) > 180:
                raise ValueError("الإحداثيات الناتجة خارج النطاق الجغرافي")
        except (ValueError, ArithmeticError) as e:
            rep.bad.append((rn, str(e)))
            continue
        f = Feature.point(lat, lon, id=Feature.new_id())
        nm = cell(row, m.name).strip() if m.name >= 0 else ""
        props = {header[c]: row[c] for c in range(min(len(row), len(header)))
                 if c not in (m.x, m.y, m.name, m.combined) and row[c] not in (None, "")}
        mapper.apply(f, props)
        if nm:
            f.name = nm
        layer.features.append(f)
        rep.ok += 1
    return layer, rep


# ---------------------------------------------------------------------------- مراكز الاستيراد والتصدير
def detect_format(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    with open(path, "rb") as fh:
        head = fh.read(4)
    if ext in (".geojson", ".json"):
        return "geojson"
    if ext == ".kml":
        return "kml"
    if ext == ".kmz":
        return "kmz"
    if ext == ".gpx":
        return "gpx"
    if ext == ".gpkg":
        return "gpkg"
    if ext in (".csv", ".txt", ".tsv"):
        return "csv"
    if ext in (".xlsx", ".xlsm"):
        return "xlsx"
    if ext == ".zip" or head[:2] == b"PK":
        with zipfile.ZipFile(path) as z:
            names = [n.lower() for n in z.namelist()]
        if any(n.endswith(".shp") for n in names):
            return "shp"
        if any(n.endswith(".kml") for n in names):
            return "kmz"
        if any(n.endswith(".poiproj") or n == "manifest.json" for n in names):
            return "poiproj"
    raise ValueError(f"صيغة غير معروفة: {path}")


@dataclass
class ImportResult:
    layers: List[Layer] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    report: Optional[RowReport] = None

    def feature_count(self) -> int:
        return sum(len(l.features) for l in self.layers)


def import_file(path: str, fmt: Optional[str] = None, mapping: Optional[Mapping] = None, src_crs: Optional[Crs] = None,
                skip_duplicates: bool = False, repair: bool = False, dup_meters: float = 5.0) -> ImportResult:
    fmt = fmt or detect_format(path)
    label = re.sub(r"\.[A-Za-z0-9]+$", "", os.path.basename(path))
    res = ImportResult()
    if fmt == "geojson":
        res.layers = read_geojson(open(path, "rb").read(), label)
    elif fmt in ("kml", "kmz"):
        res.layers = read_kml(open(path, "rb").read(), label)
    elif fmt == "gpx":
        res.layers = read_gpx(open(path, "rb").read(), label)
    elif fmt == "shp":
        res.layers, res.warnings = shapefile.read_zip(path, label)
    elif fmt == "gpkg":
        res.layers = read_gpkg(path, label)
    elif fmt in ("csv", "xlsx"):
        l, rep = table_to_layer(path, mapping, src_crs, os.path.basename(path))
        res.layers, res.report = [l], rep
        if rep.bad:
            res.warnings.append(f"{len(rep.bad)} صف مرفوض من {rep.read}")
            if rep.ok == 0 and src_crs is None and any("خارج المدى" in r for _, r in rep.bad):
                res.warnings.append("تبدو الإحداثيات مسقطة (UTM مثلاً)؛ حدّد نظامها، مثل --crs 32638 لـ UTM 38N")
    else:
        raise ValueError(f"لا يمكن استيراد الصيغة {fmt}")
    for l in res.layers:
        for f in l.features:
            if not f.id:
                f.id = Feature.new_id()
            if f.parts and not f.lat and not f.lon:
                set_representative(f)
        if repair:
            for f in l.features:
                quality.fix(f)
        if skip_duplicates and l.geom == POINT and len(l.features) > 1:
            drop = set(quality.duplicate_ids_to_remove(quality.find_duplicates(l.features, dup_meters, True)))
            if drop:
                res.warnings.append(f"{l.label}: تخطّي {len(drop)} مكرر")
                l.features = [f for f in l.features if f.id not in drop]
    return res


ZONE_HOOK = lambda: None      # يضبطه webapp: يرجع "auto" أو "38N" أو "39N"…


def _metric(layers, o: ExportOptions) -> ExportOptions:
    """DXF يُصدَّر بالمتر: إن لم يُحدَّد نظام فنختار UTM (حسب إعداد النطاق أو متوسط خط الطول)."""
    import dataclasses
    if o.target is not None:
        return o
    z = str(ZONE_HOOK() or "auto").upper().rstrip("N")
    if z.isdigit():
        zone = int(z)
    else:
        lons = [f.lon for l in layers for f in l.features if f.parts]
        from .coords import zone_for
        zone = zone_for(sum(lons) / len(lons)) if lons else 38
    return dataclasses.replace(o, target=Crs.of(32600 + zone))


def export_layers(layers: Sequence[Layer], fmt: str, path: str, o: Optional[ExportOptions] = None) -> List[str]:
    """يصدّر الطبقات إلى ملف. يرجع التحذيرات (preflight) ويرفع ValueError للأخطاء الحاسمة."""
    o = o or ExportOptions()
    fmt = fmt.lower()
    if fmt not in FORMATS:
        raise ValueError(f"صيغة تصدير غير مدعومة: {fmt}")
    warns = preflight(layers, fmt, o)
    if fmt in WGS_ONLY:
        _require_wgs(fmt, o)
    if fmt == "geojson":
        with open(path, "w", encoding="utf-8") as fh:
            write_geojson(layers, fh, o)
    elif fmt in ("kml", "kmz"):
        with open(path, "wb") as fh:
            write_kml(layers, fh, o.doc_name, fmt == "kmz")
    elif fmt == "gpx":
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(to_gpx(layers))
    elif fmt == "shp":
        with open(path, "wb") as fh:
            shapefile.write_zip(layers, fh, o.crs(), o.attributes, o.target)
    elif fmt == "csv":
        with open(path, "w", encoding="utf-8", newline="") as fh:
            write_csv(layers, fh, o)
    elif fmt == "xlsx":
        write_xlsx(layers, path, o)
    elif fmt == "gpkg":
        write_gpkg(layers, path, o.attributes)
    elif fmt == "sql":
        from . import cadsql
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(cadsql.to_postgis(layers, o, to_geojson))
    elif fmt == "dxf":
        from . import cadsql
        with open(path, "wb") as fh:
            fh.write(cadsql.to_dxf(layers, _metric(layers, o), to_geojson))
    return warns
