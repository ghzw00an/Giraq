"""v3.16: قوائم الحدود الإدارية (أقضية/محافظات/العراق) بصيغة حلقات لاستخدامها كمنطقة جلب."""
from __future__ import annotations

from flask import Flask, jsonify, request

from .admin import AdminRef


def _simplify(ring, tol=0.0008):
    """تبسيط خفيف (Douglas-Peucker تكراري مبسّط عبر تخطي النقاط القريبة) لتقليل الحجم."""
    out = [ring[0]]
    for p in ring[1:-1]:
        if abs(p[0] - out[-1][0]) > tol or abs(p[1] - out[-1][1]) > tol:
            out.append(p)
    out.append(ring[-1])
    return out if len(out) >= 4 else ring


def register(app: Flask) -> None:
    @app.get("/api/admin/list")
    def admin_list():
        ref = AdminRef.get()
        if ref is None:
            return jsonify(governorates=[], districts=[])
        gv = [{"en": u.name_en, "ar": u.name_ar} for u in ref.units(1)]
        ds = [{"en": u.name_en, "ar": u.name_ar, "gov_en": u.parent_en, "gov": u.parent_ar, "bbox": list(u.bbox)} for u in ref.units(2)]
        return jsonify(governorates=gv, districts=ds)

    @app.post("/api/admin/rings")
    def admin_rings():
        """{level: 1|2, names: [name_en…] | all: true, parent: gov_en} → {rings: [...], names: [...]}"""
        j = request.get_json(force=True)
        ref = AdminRef.get()
        level = int(j.get("level", 2))
        if ref is None or level not in (1, 2):
            return jsonify(error="لا توجد حدود"), 404
        names = set(j.get("names") or [])
        keys = set(j.get("keys") or [])
        units = [u for u in ref.units(level) if j.get("all") or u.name_en in names or u.name_ar in names
                 or f"{u.parent_en}|{u.name_en}" in keys]
        if j.get("parent"):
            units = [u for u in units if u.parent_en == j["parent"]]
        rings = [_simplify(r) for u in units for r in u.poly.parts]
        return jsonify(rings=rings, names=[u.name_ar or u.name_en for u in units], count=len(units))
