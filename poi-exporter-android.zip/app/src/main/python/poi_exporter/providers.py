"""مزودو البيانات الخارجية بمفتاح API (Google Places، أو أي خدمة REST عبر قالب عام مثل MapAtlas وغيرها).
المزوّد: {id, name, kind: basemap|data|both, type: google_places|template|xyz, url, key, attribution}"""
from __future__ import annotations

import json
import re
import urllib.parse
import urllib.error
import urllib.request
from typing import Callable, Dict, List, Optional

from .model import Feature

UA = {"User-Agent": "POIExporter/3.15"}


def _http(url: str, data: Optional[bytes] = None, headers: Optional[dict] = None) -> dict:      # نقطة الشبكة الوحيدة (تُستبدل في الاختبارات)
    req = urllib.request.Request(url, data=data, headers={**UA, **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", "replace")[:300]
        except Exception:
            body = ""
        raise ProviderError(f"HTTP {e.code}: {body or e.reason}")


class ProviderError(Exception):
    pass


def load(raw) -> List[dict]:
    try:
        v = json.loads(raw) if isinstance(raw, str) else raw
    except ValueError:
        return []
    return [p for p in v if isinstance(p, dict) and p.get("id")] if isinstance(v, list) else []


def find(settings: dict, pid: str) -> Optional[dict]:
    return next((p for p in load(settings.get("providers_json", "[]")) if p["id"] == pid), None)


def _grid(s, w, n, e, maxn=25):
    import math
    k = 1
    while k * k < maxn and ((n - s) / k > 0.12 or (e - w) / k > 0.12):
        k += 1
    for i in range(k):
        for j in range(k):
            yield (s + (n - s) * i / k, w + (e - w) * j / k, s + (n - s) * (i + 1) / k, w + (e - w) * (j + 1) / k)


def _num(d, *keys):
    for k in keys:
        if isinstance(d, dict) and k in d:
            try:
                return float(d[k])
            except (TypeError, ValueError):
                pass
    return None


def _name(d):
    for k in ("name", "title", "display_name", "label"):
        v = d.get(k) if isinstance(d, dict) else None
        if isinstance(v, dict):
            v = v.get("text") or v.get("ar") or v.get("en") or next(iter(v.values()), "")
        if isinstance(v, str) and v:
            return v
    return ""


def parse_generic(j) -> List[dict]:
    """يقبل GeoJSON FeatureCollection أو أي JSON فيه قائمة عناصر لها lat/lon."""
    out = []
    if isinstance(j, dict) and isinstance(j.get("features"), list):
        for f in j["features"]:
            g = (f or {}).get("geometry") or {}
            p = (f or {}).get("properties") or {}
            c = g.get("coordinates")
            if g.get("type") == "Point" and c and len(c) >= 2:
                out.append({"lat": c[1], "lon": c[0], "name": _name(p), "props": p})
        return out
    items = []
    if isinstance(j, list):
        items = j
    elif isinstance(j, dict):
        for k in ("results", "items", "data", "places", "elements", "pois", "hits"):
            if isinstance(j.get(k), list):
                items = j[k]
                break
    for it in items:
        if not isinstance(it, dict):
            continue
        lat = _num(it, "lat", "latitude", "y")
        lon = _num(it, "lon", "lng", "longitude", "x")
        if lat is None:
            g = it.get("geometry") or it.get("location") or it.get("position") or it.get("center") or {}
            if isinstance(g, dict):
                loc = g.get("location") if isinstance(g.get("location"), dict) else g
                lat, lon = _num(loc, "lat", "latitude"), _num(loc, "lng", "lon", "longitude")
                if lat is None and isinstance(g.get("coordinates"), list) and len(g["coordinates"]) >= 2:
                    lon, lat = g["coordinates"][0], g["coordinates"][1]
        if lat is None or lon is None:
            continue
        out.append({"lat": lat, "lon": lon, "name": _name(it), "props": it})
    return out


def google_search(key: str, query: str, tile, http=None) -> List[dict]:
    http = http or _http
    s, w, n, e = tile
    out, tok = [], None
    for _ in range(3):
        body = {"textQuery": query, "pageSize": 20, "languageCode": "ar",
                "locationRestriction": {"rectangle": {"low": {"latitude": s, "longitude": w}, "high": {"latitude": n, "longitude": e}}}}
        if tok:
            body["pageToken"] = tok
        j = http("https://places.googleapis.com/v1/places:searchText", json.dumps(body).encode(),
                 {"Content-Type": "application/json", "X-Goog-Api-Key": key,
                  "X-Goog-FieldMask": "places.displayName,places.location,places.formattedAddress,places.nationalPhoneNumber,places.types,nextPageToken"})
        for p in j.get("places", []):
            loc = p.get("location") or {}
            out.append({"lat": loc.get("latitude"), "lon": loc.get("longitude"), "name": (p.get("displayName") or {}).get("text", ""),
                        "props": {"address": p.get("formattedAddress", ""), "phone": p.get("nationalPhoneNumber", "")}})
        tok = j.get("nextPageToken")
        if not tok:
            break
    return out


def template_search(prov: dict, query: str, tile, http=None) -> List[dict]:
    http = http or _http
    s, w, n, e = tile
    url = prov["url"]
    rep = {"south": s, "west": w, "north": n, "east": e, "lat": (s + n) / 2, "lon": (w + e) / 2, "key": prov.get("key", ""), "appid": prov.get("appid", ""), "navkey": prov.get("navkey", ""), "q": urllib.parse.quote(query)}
    rad = int(max(abs(n - s), abs(e - w)) * 111320 / 2) or 500
    rep["radius"] = rad
    for k, v in rep.items():
        url = url.replace("{" + k + "}", str(v))
    hdr = {}
    if prov.get("key") and "{key}" not in prov["url"]:
        hdr["Authorization"] = "Bearer " + prov["key"]
        hdr["X-API-Key"] = prov["key"]
    return parse_generic(http(url, None, hdr))


def fetch_points(prov: dict, queries: List[tuple], area, http=None, progress: Callable = None) -> List[Feature]:
    """queries: [(نص البحث، النوع، الفئة)]. يقسّم المنطقة إلى بلاطات ويصفّي ما خرج عن المنطقة ويزيل المكرر."""
    typ = prov.get("type", "template")
    if typ == "google":
        typ = "google_places"
    if prov.get("kind") == "map":
        raise ProviderError("هذا المزوّد للخرائط فقط")
    if typ not in ("google_places", "template"):
        raise ProviderError("هذا المزوّد للخرائط فقط")
    if not prov.get("key") and typ == "google_places":
        raise ProviderError("مفتاح API مفقود")
    s, w, n, e = area.south, area.west, area.north, area.east
    tiles = list(_grid(s, w, n, e))
    seen, feats = set(), []
    total, done = len(tiles) * len(queries), 0
    for q, item, cat in queries:
        for t in tiles:
            done += 1
            if progress:
                progress("provider", done, total)
            try:
                rows = google_search(prov["key"], q, t, http) if typ == "google_places" else template_search(prov, q, t, http)
            except Exception as ex:                       # noqa: BLE001 — رسالة واضحة للمستخدم
                raise ProviderError(f"{prov.get('name', prov['id'])}: {ex}")
            for r in rows:
                if r["lat"] is None or r["lon"] is None or not area.contains(r["lat"], r["lon"]):
                    continue
                k = (round(r["lat"], 5), round(r["lon"], 5), r["name"])
                if k in seen:
                    continue
                seen.add(k)
                f = Feature.point(r["lat"], r["lon"], name=r["name"], type=item, category=cat, source=prov.get("name", prov["id"]))
                for a in ("address", "phone"):
                    if isinstance(r["props"], dict) and r["props"].get(a):
                        f.attrs[a] = str(r["props"][a])
                feats.append(f)
    return feats
