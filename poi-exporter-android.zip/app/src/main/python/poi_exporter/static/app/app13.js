"use strict";
/* ===== app13: خريطة الكثافة (Heatmap) للمعالم المعروضة ===== */
const HEAT = { on: false, r: 25 };
async function heatApply() {
  if (map.getLayer("heat")) map.removeLayer("heat"); if (map.getSource("heat")) map.removeSource("heat");
  if (!HEAT.on) return;
  const fs = []; for (const d of S.ds.filter(x => x.kind !== "reference" && x.visible !== false && x.geom === 1)) { try { await ensureDs(d); (GJ[d.id].features || []).forEach(f => fs.push({ type: "Feature", properties: {}, geometry: f.geometry })); } catch (e) { } }
  map.addSource("heat", { type: "geojson", data: { type: "FeatureCollection", features: fs } });
  map.addLayer({ id: "heat", type: "heatmap", source: "heat", paint: { "heatmap-radius": HEAT.r, "heatmap-intensity": 1.2, "heatmap-opacity": .75, "heatmap-color": ["interpolate", ["linear"], ["heatmap-density"], 0, "rgba(0,0,255,0)", .2, "#4dabf7", .4, "#69db7c", .6, "#ffe066", .8, "#ff922b", 1, "#e03131"] } });
  return fs.length;
}
function openHeat() {
  openSheet("heat", LL("خريطة الكثافة", "Heatmap"), b => {
    b.innerHTML = `<div class="hint">${LL("تظهر أماكن تجمّع المعالم المعروضة (النقاط فقط).", "Shows where the displayed points cluster.")}</div><div class="rowsw" id="h_s"></div>
    <label class="f">${LL("نصف القطر", "Radius")}: <b id="h_v">${HEAT.r}</b></label><input type="range" id="h_r" min="8" max="80" value="${HEAT.r}" style="width:100%">`;
    const sw = el(`<label style="display:flex;gap:10px;align-items:center;margin:10px 0"><input type="checkbox" id="h_c" ${HEAT.on ? "checked" : ""}> ${LL("تفعيل", "Enable")}</label>`, $("#h_s", b));
    $("#h_c", b).onchange = async e => { HEAT.on = e.target.checked; const n = await heatApply(); if (HEAT.on) toast((n || 0) + " " + LL("نقطة", "points")); };
    $("#h_r", b).oninput = e => { HEAT.r = +e.target.value; $("#h_v", b).textContent = HEAT.r; if (map.getLayer("heat")) map.setPaintProperty("heat", "heatmap-radius", HEAT.r); };
  });
}
const _openTools13 = openTools;
openTools = async function () {
  await _openTools13(); const b = $("#sh-b"); if (SHEET !== "tools" || !b) return; const g = $(".grid", b); if (!g || $("#tl_heat", b)) return;
  el(`<button class="tile" id="tl_heat">${I("layers")}<span>${LL("خريطة الكثافة", "Heatmap")}</span></button>`, g).onclick = openHeat;
};
