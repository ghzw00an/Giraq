"use strict";
/* ===== app17 (v3.14): تبويبات الأدوات + بحث/فلتر، أيقونات البوصلة، تحرير/تحويل الرسومات،
   شريط تحديد المنطقة المصغّر مع الأبعاد اللحظية ===== */
Object.assign(ICONS, {
  north: "M12 2l5 18-5-4-5 4zM12 2v14",
  phone: "M8 2h8a2 2 0 012 2v16a2 2 0 01-2 2H8a2 2 0 01-2-2V4a2 2 0 012-2zM10 19h4M10 5h4",
  sliders: "M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0M14 4v4M8 10v4M16 16v4"
});

/* ---------- نافذة الأدوات: 4 تبويبات + بحث + فلتر + شبكة 3 أعمدة ---------- */
const TTABS = [
  ["measure", "قياس وتحليل", "Measure & analyse", /قياس|مسطرة|مسار|تحليل|فحص|تحديد|كثافة|استعلام|شبكة|طريق|measure|ruler|track|analy|quality|select|density|heat|query|network|road|spatial/i],
  ["draw", "رسم وتمييز", "Draw & style", /رسم|تنقيط|دمج|الرسومات|تنسيق|أسماء|تراجع|إعادة|draw|stipple|merge|symbol|names|undo|redo/i],
  ["data", "بيانات وملفات", "Data & files", /.*/],
  ["out", "عرض وإخراج", "View & export", /Layout|باركود|إنترنت|الجديد|تقرير|barcode|offline|what's new|report/i]
];
const tabOf = x => {
  const s = x.textContent.trim(), id = x.id || "";
  if (/^tl_(lay|new|rep)$/.test(id) || TTABS[3][3].test(s)) return "out";
  if (TTABS[1][3].test(s) && !/خطوط|مضلعات/.test(s)) return "draw";
  if (TTABS[0][3].test(s)) return "measure";
  return "data";
};
const _openTools17 = openTools;
openTools = async function () {
  await _openTools17(); const b = $("#sh-b"); if (SHEET !== "tools" || !b || b.querySelector(".ttabs")) return;
  const tiles = $$(".tile", b); if (!tiles.length) return;
  const keep = tiles.map(x => ({ x, tab: tabOf(x) }));
  let cur = "measure", all = false; try { cur = localStorage.getItem("tl_tab") || "measure"; } catch (e) { }
  b.innerHTML = `<div class="tsearch"><div class="tsin">${I("search")}<input id="tl_q2" class="in" placeholder="${LL("ابحث عن أداة…", "Search tools…")}" autocomplete="off"></div><button class="ib tfil" id="tl_f" title="${LL("عرض الكل", "Show all")}">${I("sliders")}</button></div>
    <div class="ttabs" id="tl_tabs">${TTABS.map(t_ => `<button data-t="${t_[0]}">${LL(t_[1], t_[2])}</button>`).join("")}</div><div class="tgrid" id="tl_g"></div>`;
  const g = $("#tl_g", b), q = $("#tl_q2", b);
  const draw = () => {
    const s = q.value.trim().toLowerCase(); g.innerHTML = "";
    const show = keep.filter(k => s ? k.x.textContent.toLowerCase().includes(s) : (all || k.tab === cur));
    show.forEach(k => g.appendChild(k.x));
    if (!show.length) g.innerHTML = `<div class="hint" style="grid-column:1/-1;text-align:center">${LL("لا نتائج", "No results")}</div>`;
    $$("#tl_tabs button", b).forEach(x => x.classList.toggle("on", !s && !all && x.dataset.t === cur));
    $("#tl_f", b).classList.toggle("on", all);
  };
  $$("#tl_tabs button", b).forEach(x => x.onclick = () => { cur = x.dataset.t; all = false; q.value = ""; try { localStorage.setItem("tl_tab", cur); } catch (e) { } draw(); });
  q.oninput = draw; $("#tl_f", b).onclick = () => { all = !all; draw(); }; draw();
};

/* ---------- تحرير الرسم: متابعة، تحويل بين طريق/مسار/مساحة، إرسال ---------- */
const _openDraw17 = openDraw;
openDraw = function (id) {
  _openDraw17(id); const d = drOf(id), b = $("#sh-b"); if (!d || SHEET !== "draw" || !b || $("#dw_cv", b)) return;
  const isA = d.kind === "area", conv = [];
  if (isA) conv.push(["track", LL("تحويل إلى مسار", "Convert to track")], ["road", LL("تحويل إلى طريق", "Convert to road")]);
  else { if (d.pts.length >= 3) conv.push(["area", LL("تحويل إلى مساحة", "Convert to area")]); if (d.kind !== "track") conv.push(["track", LL("تحويل إلى مسار", "Convert to track")]); if (d.kind !== "road") conv.push(["road", LL("تحويل إلى طريق", "Convert to road")]); }
  const w = el(`<div class="card" id="dw_cv" style="margin-top:12px;padding:10px"><div class="hint" style="margin:0 0 8px">${LL("تحرير متقدم", "Advanced edit")}</div><div class="btns" style="margin:0">
    ${!isA ? `<button class="btn sec2" id="dw_go">${I("plus")}${LL("متابعة الرسم", "Continue drawing")}</button>` : ""}<button class="btn sec2" id="dw_sh">${I("share")}${LL("إرسال", "Send")}</button>
    ${conv.map(c => `<button class="btn sec2" data-cv="${c[0]}">${I("rot")}${c[1]}</button>`).join("")}</div></div>`);
  b.appendChild(w);
  const go = $("#dw_go", w); if (go) go.onclick = () => { drEdit(id); setTimeout(() => { const a = $("#e_a"); if (a) a.click(); }, 60); };
  $("#dw_sh", w).onclick = () => drShare(d);
  $$("[data-cv]", w).forEach(x => x.onclick = () => {
    const k = x.dataset.cv;
    if (k === "area") { if (d.pts.length < 3) return toast(LL("تحتاج 3 نقاط", "Need 3 points")); d.kind = "area"; delete d.rtype; if (!d.fillop) d.fillop = .25; }
    else if (k === "road") { d.kind = "road"; if (!d.rtype && typeof ROADS !== "undefined") { applyRoad(d, Object.keys(ROADS)[0]); } }
    else { d.kind = "track"; delete d.rtype; }
    drSave(); drRender(); toast(LL("تم التحويل", "Converted")); openDraw(id);
  });
};

/* ---------- شريط المنطقة المصغّر مع الأبعاد اللحظية ---------- */
const areaBar = () => {
  let bar = $("#abar");
  if (!A.show) { if (bar) bar.remove(); return; }
  if (!bar) {
    bar = el(`<div id="abar"><span id="ab_t"></span><button class="ib" id="ab_s" title="${LL("إعدادات", "Settings")}">${I("settings")}</button><button class="ib" id="ab_x" title="${LL("إخفاء", "Hide")}">${I("x")}</button></div>`, document.body);
    $("#ab_s", bar).onclick = () => openArea();
    $("#ab_x", bar).onclick = () => { A.show = false; setSet("area_on", false); drawArea(); };
  }
  bar.style.display = (MODE || document.body.classList.contains("sh")) ? "none" : "flex";
  $("#ab_t", bar).textContent = A.shape === "circle" ? `⌀ ${fm(A.r * 2)}` : `${fm(A.w)} × ${fm(A.h)} · ${Math.round(A.deg)}°`;
};
let _wasShow = A.show;
const _drawArea17 = drawArea; drawArea = function (l) { _drawArea17(l); if (A.show && !_wasShow && SHEET === "area") closeSheet(); _wasShow = A.show; areaBar(); };
const _openSheet17 = openSheet; openSheet = function (id, title, render, o) { _openSheet17(id, title, render, o); areaBar(); };
const _closeSheet17 = closeSheet; closeSheet = function () { _closeSheet17(); areaBar(); };
/* عند تفعيل «تحديد المنطقة» من نافذتها: تُصغَّر النافذة إلى الشريط السفلي ليظهر المستطيل كاملاً */
document.addEventListener("change", e => { if (SHEET === "area" && e.target && e.target.id === "ar_f") return; });
setTimeout(areaBar, 1500);

/* ---------- تبويبات الإعدادات: أيقونات + مؤشر منزلق + حركة انتقال ---------- */
Object.assign(ICONS, { globe: "M12 21a9 9 0 100-18 9 9 0 000 18zM3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z", mapi: "M9 4L3 6v14l6-2 6 2 6-2V4l-6 2zM9 4v14M15 6v14", shapes: "M7 3l4 7H3zM14 14h7v7h-7zM8 21a4 4 0 100-8 4 4 0 000 8z", server: "M4 5h16v5H4zM4 14h16v5H4zM8 7.5h.01M8 16.5h.01" });
const _os17 = openSettings;
openSettings = function () {
  _os17(); const b = $("#sh-b"); if (SHEET !== "set" || !b) return; const bar = $(".stabs", b); if (!bar || bar.querySelector(".sind")) return;
  const ic = { gen: "globe", map: "mapi", sym: "shapes", sys: "server" };
  $$("button", bar).forEach(x => { x.innerHTML = `${I(ic[x.dataset.k] || "settings")}<span>${x.textContent}</span>`; });
  const ind = el(`<i class="sind"></i>`); bar.insertBefore(ind, bar.firstChild);
  const place = () => { const a = $("button.on", bar); if (!a) return; ind.style.width = a.offsetWidth + "px"; ind._x = (ind._x || 0) + a.getBoundingClientRect().left - ind.getBoundingClientRect().left; ind.style.transform = `translateX(${ind._x}px)`; a.scrollIntoView({ inline: "center", block: "nearest", behavior: "smooth" }); };
  $$("button", bar).forEach(x => x.addEventListener("click", () => requestAnimationFrame(place)));
  setTimeout(() => { ind.style.transition = "none"; place(); setTimeout(() => ind.style.transition = "", 60); }, 380);
};

/* ---------- نافذة تحديد المنطقة: معاينة حيّة + بطاقات منسّقة ---------- */
const _oa17 = openArea;
openArea = function () {
  _oa17(); const b = $("#sh-b"); if (SHEET !== "area" || !b || $("#apv", b)) return;
  const seg = $("#ar_s", b), rect = $("#ar_rect", b), circ = $("#ar_circ", b); if (!seg || !rect || !circ) return;
  const pv = el(`<div id="apv" class="apv"><svg viewBox="0 0 240 150"><defs><pattern id="apg" width="12" height="12" patternUnits="userSpaceOnUse"><path d="M12 0H0V12" fill="none" stroke="currentColor" stroke-opacity=".12"/></pattern></defs><rect width="240" height="150" fill="url(#apg)"/><g id="apg2"><rect id="aps" rx="3"/><circle id="apc" r="0"/></g><line id="apn" x1="120" y1="8" x2="120" y2="22" stroke="var(--neon)" stroke-width="2"/></svg>
    <div class="apd"><div><small>${LL("الأبعاد", "Size")}</small><b id="apt1"></b></div><div><small>${LL("المساحة", "Area")}</small><b id="apt2"></b></div><div><small>${LL("الدوران", "Rotation")}</small><b id="apt3"></b></div></div></div>`);
  b.prepend(pv);
  const card = (title, ...ns) => { const c = el(`<div class="apc"><div class="apt">${title}</div></div>`); ns.forEach(n => n && c.appendChild(n)); return c; };
  const shapeCard = card(LL("الشكل", "Shape"), seg), dimCard = card(LL("الأبعاد والاتجاه", "Size & direction"), rect, circ);
  const rows = $$(":scope > .card", b), btns = $$(":scope > .btns", b);
  pv.after(shapeCard); shapeCard.after(dimCard);
  const ref = rows[0]; if (ref) { ref.classList.add("apc"); }
  const upd = () => {
    const c = $("#apv", b); if (!c || SHEET !== "area") return; const circle = A.shape === "circle", W = circle ? A.r * 2 : A.w, H = circle ? A.r * 2 : A.h, k = Math.min(150 / Math.max(W, 1), 100 / Math.max(H, 1)), w = W * k, h = H * k;
    const r = $("#aps", c), ci = $("#apc", c); r.style.display = circle ? "none" : ""; ci.style.display = circle ? "" : "none";
    r.setAttribute("x", 120 - w / 2); r.setAttribute("y", 78 - h / 2); r.setAttribute("width", w); r.setAttribute("height", h); ci.setAttribute("cx", 120); ci.setAttribute("cy", 78); ci.setAttribute("r", w / 2);
    $("#apg2", c).setAttribute("transform", `rotate(${circle ? 0 : A.deg} 120 78)`);
    $("#apt1", c).textContent = circle ? `⌀ ${fm(W)}` : `${fm(W)} × ${fm(H)}`; $("#apt2", c).textContent = fa(circle ? Math.PI * A.r * A.r : A.w * A.h); $("#apt3", c).textContent = circle ? "—" : Math.round(A.deg) + "°";
    const n = $("#apn", c); n.setAttribute("y1", 78 - h / 2 - 14); n.setAttribute("y2", 78 - h / 2 - 2); n.setAttribute("transform", `rotate(${circle ? 0 : A.deg} 120 78)`);
  };
  b.addEventListener("input", upd); b.addEventListener("change", upd); b.addEventListener("click", () => setTimeout(upd, 30));
  const _s = syncAreaUI; window.__apUpd = upd; upd();
};
const _sync17 = syncAreaUI; syncAreaUI = function () { _sync17(); if (window.__apUpd) window.__apUpd(); };
const _da17b = drawArea; drawArea = function (l) { _da17b(l); if (SHEET === "area" && window.__apUpd) window.__apUpd(); };
