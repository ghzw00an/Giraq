"use strict";
/* ===== app14: تصدير Layout كـ SVG متجهي — سياق رسم يسجّل أوامر Canvas ويحوّلها إلى SVG ===== */
class SvgCtx {
  constructor(w, h) {
    this.w = w; this.h = h; this.out = []; this.defs = []; this.n = 0; this.m = [1, 0, 0, 1, 0, 0]; this.stack = []; this.path = []; this.open = 0;
    this.fillStyle = "#000"; this.strokeStyle = "#000"; this.lineWidth = 1; this.font = "10px sans-serif"; this.textAlign = "start"; this.textBaseline = "alphabetic";
    this.globalAlpha = 1; this.lineJoin = "miter"; this.lineCap = "butt"; this.letterSpacing = "0px"; this.filter = "none"; this.shadowColor = "transparent"; this.shadowBlur = 0; this.shadowOffsetY = 0; this.shadowOffsetX = 0; this.dash = [];
    this._m = document.createElement("canvas").getContext("2d"); this.canvas = { width: w, height: h };
  }
  static esc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  _st() { return { fillStyle: this.fillStyle, strokeStyle: this.strokeStyle, lineWidth: this.lineWidth, font: this.font, textAlign: this.textAlign, textBaseline: this.textBaseline, globalAlpha: this.globalAlpha, lineJoin: this.lineJoin, lineCap: this.lineCap, letterSpacing: this.letterSpacing, filter: this.filter, shadowColor: this.shadowColor, shadowBlur: this.shadowBlur, shadowOffsetY: this.shadowOffsetY, dash: this.dash, m: this.m.slice(), open: this.open }; }
  save() { this.stack.push(this._st()); }
  restore() { const s = this.stack.pop(); if (!s) return; while (this.open > s.open) { this.out.push("</g>"); this.open--; } Object.assign(this, s); }
  /* التحويلات */
  _mul(a) { const m = this.m; this.m = [m[0] * a[0] + m[2] * a[1], m[1] * a[0] + m[3] * a[1], m[0] * a[2] + m[2] * a[3], m[1] * a[2] + m[3] * a[3], m[0] * a[4] + m[2] * a[5] + m[4], m[1] * a[4] + m[3] * a[5] + m[5]]; }
  translate(x, y) { this._mul([1, 0, 0, 1, x, y]); } scale(x, y) { this._mul([x, 0, 0, y, 0, 0]); } rotate(a) { const c = Math.cos(a), s = Math.sin(a); this._mul([c, s, -s, c, 0, 0]); }
  _p(x, y) { const m = this.m; return [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]]; }
  _f(n) { return +n.toFixed(2); }
  _sc() { const m = this.m; return Math.sqrt(Math.abs(m[0] * m[3] - m[1] * m[2])) || 1; }
  _mat() { return "matrix(" + this.m.map(v => +v.toFixed(5)).join(" ") + ")"; }
  /* المسارات (تُحوَّل نقاطها فوراً إلى إحداثيات الصفحة) */
  beginPath() { this.path = []; }
  moveTo(x, y) { const p = this._p(x, y); this.path.push("M" + this._f(p[0]) + " " + this._f(p[1])); this._cx = x; this._cy = y; }
  lineTo(x, y) { const p = this._p(x, y); this.path.push((this.path.length ? "L" : "M") + this._f(p[0]) + " " + this._f(p[1])); this._cx = x; this._cy = y; }
  closePath() { this.path.push("Z"); }
  rect(x, y, w, h) { this.moveTo(x, y); this.lineTo(x + w, y); this.lineTo(x + w, y + h); this.lineTo(x, y + h); this.closePath(); }
  ellipse(cx, cy, rx, ry, rot, a0, a1, ccw) {
    let d = a1 - a0; if (ccw) { while (d > 0) d -= 2 * Math.PI; } else { while (d < 0) d += 2 * Math.PI; } if (Math.abs(d) > 2 * Math.PI) d = Math.sign(d) * 2 * Math.PI;
    const n = Math.max(8, Math.ceil(Math.abs(d) / (Math.PI / 32))), cr = Math.cos(rot || 0), sr = Math.sin(rot || 0);
    for (let i = 0; i <= n; i++) { const a = a0 + d * i / n, ex = rx * Math.cos(a), ey = ry * Math.sin(a), x = cx + ex * cr - ey * sr, y = cy + ex * sr + ey * cr; if (i === 0 && !this.path.length) this.moveTo(x, y); else this.lineTo(x, y); }
  }
  arc(x, y, r, a0, a1, ccw) { this.ellipse(x, y, r, r, 0, a0, a1, ccw); }
  arcTo(x1, y1, x2, y2, r) {
    const x0 = this._cx, y0 = this._cy; if (x0 == null) return this.lineTo(x1, y1);
    const v1 = [x0 - x1, y0 - y1], v2 = [x2 - x1, y2 - y1], l1 = Math.hypot(...v1), l2 = Math.hypot(...v2); if (!l1 || !l2 || !r) return this.lineTo(x1, y1);
    const u1 = v1.map(v => v / l1), u2 = v2.map(v => v / l2), cos = u1[0] * u2[0] + u1[1] * u2[1], ang = Math.acos(Math.max(-1, Math.min(1, cos))); if (ang < 1e-4 || Math.abs(ang - Math.PI) < 1e-4) return this.lineTo(x1, y1);
    const t = r / Math.tan(ang / 2), p1 = [x1 + u1[0] * t, y1 + u1[1] * t], p2 = [x1 + u2[0] * t, y1 + u2[1] * t], b = [u1[0] + u2[0], u1[1] + u2[1]], bl = Math.hypot(...b), cd = r / Math.sin(ang / 2), c = [x1 + b[0] / bl * cd, y1 + b[1] / bl * cd];
    const s = Math.atan2(p1[1] - c[1], p1[0] - c[0]), e = Math.atan2(p2[1] - c[1], p2[0] - c[0]); this.lineTo(p1[0], p1[1]); let d = e - s; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; this.arc(c[0], c[1], r, s, s + d, d < 0); this._cx = p2[0]; this._cy = p2[1];
  }
  /* الألوان */
  _col(c) { c = String(c).trim(); const m = c.match(/^rgba?\(([^)]+)\)$/i); if (m) { const p = m[1].split(",").map(s => parseFloat(s)); const a = p.length > 3 ? p[3] : 1; return ["rgb(" + Math.round(p[0]) + "," + Math.round(p[1]) + "," + Math.round(p[2]) + ")", a]; } if (c === "transparent") return ["none", 0]; return [c, 1]; }
  _shadow() { if (!this.shadowColor || this.shadowColor === "transparent" || !this.shadowBlur) return ""; const [col, a] = this._col(this.shadowColor), id = "sh" + (++this.n); this.defs.push(`<filter id="${id}" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="${this._f(this.shadowOffsetY)}" stdDeviation="${this._f(this.shadowBlur / 2)}" flood-color="${col}" flood-opacity="${a}"/></filter>`); return ` filter="url(#${id})"`; }
  _gray() { return this.filter && this.filter.indexOf("grayscale") >= 0 ? ` style="filter:grayscale(1)"` : ""; }
  _paint(kind, pth, tr) {
    const SE = SvgCtx.esc; let at = "";
    if (kind === "fill") { const [c, a] = this._col(this.fillStyle); at = ` fill="${SE(c)}"` + (a * this.globalAlpha < 1 ? ` fill-opacity="${+(a * this.globalAlpha).toFixed(3)}"` : "") + ` stroke="none"`; }
    else { const [c, a] = this._col(this.strokeStyle), sc = tr ? 1 : this._sc(); at = ` fill="none" stroke="${SE(c)}" stroke-width="${this._f(this.lineWidth * sc)}"` + (a * this.globalAlpha < 1 ? ` stroke-opacity="${+(a * this.globalAlpha).toFixed(3)}"` : "") + ` stroke-linejoin="${this.lineJoin}" stroke-linecap="${this.lineCap === "butt" ? "butt" : this.lineCap}"` + (this.dash.length ? ` stroke-dasharray="${this.dash.map(v => this._f(v * sc)).join(" ")}"` : ""); }
    this.out.push(`<path d="${pth}"${tr ? ` transform="${tr}"` : ""}${at}${this._shadow()}/>`);
  }
  fill(p) { if (p && p.d) return this._paint("fill", p.d, this._mat()); if (this.path.length) this._paint("fill", this.path.join(""), null); }
  stroke(p) { if (p && p.d) return this._paint("stroke", p.d, this._mat()); if (this.path.length) this._paint("stroke", this.path.join(""), null); }
  fillRect(x, y, w, h) { const sv = this.path, c = this._cx, d = this._cy; this.path = []; this.rect(x, y, w, h); this.fill(); this.path = sv; this._cx = c; this._cy = d; }
  strokeRect(x, y, w, h) { const sv = this.path; this.path = []; this.rect(x, y, w, h); this.stroke(); this.path = sv; }
  setLineDash(a) { this.dash = a || []; }
  clip() { const id = "cl" + (++this.n); this.defs.push(`<clipPath id="${id}"><path d="${this.path.join("")}"/></clipPath>`); this.out.push(`<g clip-path="url(#${id})">`); this.open++; }
  /* النص */
  measureText(s) { this._m.font = this.font; try { this._m.letterSpacing = this.letterSpacing; } catch (e) { } return this._m.measureText(s); }
  _txt(s, x, y, stroke) {
    const SE = SvgCtx.esc, f = this.font, m = f.match(/(italic|oblique)?\s*(?:(bold|[1-9]00)\s+)?(?:(italic)\s+)?(\d*\.?\d+)px\s+(.+)$/i) || [], size = +m[4] || 10, fam = (m[5] || "sans-serif").replace(/"/g, "'"), bold = m[2], it = m[1] || m[3];
    const anc = { left: "start", start: "start", center: "middle", right: "end", end: "end" }[this.textAlign] || "start", bl = { top: "text-before-edge", hanging: "hanging", middle: "central", bottom: "text-after-edge", ideographic: "text-after-edge" }[this.textBaseline];
    const [c, a] = this._col(stroke ? this.strokeStyle : this.fillStyle), ls = parseFloat(this.letterSpacing) || 0, lw = this.lineWidth;
    this.out.push(`<text x="${this._f(x)}" y="${this._f(y)}" transform="${this._mat()}" font-family="${SE(fam)}" font-size="${size}"${bold ? ` font-weight="${bold}"` : ""}${it ? ` font-style="italic"` : ""} text-anchor="${anc}"${bl ? ` dominant-baseline="${bl}"` : ""}${ls ? ` letter-spacing="${ls}"` : ""} xml:space="preserve"` +
      (stroke ? ` fill="none" stroke="${SE(c)}" stroke-width="${lw}" stroke-linejoin="round"` : ` fill="${SE(c)}"`) + (a * this.globalAlpha < 1 ? ` opacity="${+(a * this.globalAlpha).toFixed(3)}"` : "") + `>${SE(s)}</text>`);
  }
  fillText(s, x, y) { this._txt(s, x, y, false); } strokeText(s, x, y) { this._txt(s, x, y, true); }
  /* الصور */
  drawImage(im, x, y, w, h) {
    let u; if (im instanceof HTMLCanvasElement) u = im.toDataURL("image/png"); else if (typeof im.src === "string" && im.src.startsWith("data:")) u = im.src; else { const cv = document.createElement("canvas"); cv.width = im.naturalWidth || im.width; cv.height = im.naturalHeight || im.height; cv.getContext("2d").drawImage(im, 0, 0); u = cv.toDataURL("image/png"); }
    if (w == null) { w = im.naturalWidth || im.width; h = im.naturalHeight || im.height; }
    this.out.push(`<image x="${this._f(x)}" y="${this._f(y)}" width="${this._f(w)}" height="${this._f(h)}" transform="${this._mat()}" preserveAspectRatio="none" href="${u}"${this._gray()}${this.globalAlpha < 1 ? ` opacity="${this.globalAlpha}"` : ""}/>`);
  }
  toSvg(wmm, hmm) { while (this.open > 0) { this.out.push("</g>"); this.open--; } return `<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${wmm}mm" height="${hmm}mm" viewBox="0 0 ${this.w} ${this.h}">\n<defs>${this.defs.join("")}</defs>\n${this.out.join("\n")}\n</svg>`; }
}
class FakeP2D { constructor(d) { this.d = d; } }
async function lySvg() {
  const [pw, ph] = lyPaper(), px = 4, sv = LY.sel, RP = window.Path2D; LY.sel = null; window.Path2D = FakeP2D;
  try { const c = new SvgCtx(Math.round(pw * px), Math.round(ph * px)); lyPaint(c, px, false); return new Blob([c.toSvg(pw, ph)], { type: "image/svg+xml" }); }
  finally { window.Path2D = RP; LY.sel = sv; }
}
const _lyRender14 = lyRender;
lyRender = async function (dpi, fmt) { return fmt === "svg" ? lySvg() : _lyRender14(dpi, fmt); };
