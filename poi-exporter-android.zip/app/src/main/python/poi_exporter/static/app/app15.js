"use strict";
/* ===== app15: إعادة هيكلة الإعدادات (4 تبويبات) + وحدات القياس + التقاط (Snapping) + إعدادات التسجيل + منطقة الخطر ===== */
Object.assign(TX.ar, { osm: "OSM قياسي", gm: "جوجل شوارع", gs: "جوجل قمر صناعي", gh: "جوجل هجين", gl: "جوجل بأسماء عربية", gt: "جوجل تضاريس", sat: "Esri قمر صناعي", hybrid: "Esri هجين", roads: "طرق فقط" });

/* ---------- الالتقاط المغناطيسي ---------- */
function snapEvt(e) {
  if (!S.set.snap || !e.point) return e; const px = +S.set.snap_px || 14, p = e.point; let best = null, bd = px;
  const test = (lng, lat) => { const q = map.project([lng, lat]), d = Math.hypot(q.x - p.x, q.y - p.y); if (d < bd) { bd = d; best = [lng, lat]; } };
  const walk = c => { if (typeof c[0] === "number") test(c[0], c[1]); else c.forEach(walk); };
  try {
    map.queryRenderedFeatures([[p.x - px, p.y - px], [p.x + px, p.y + px]]).forEach(f => { const id = (f.layer && f.layer.id) || ""; if (/^(m3-|area|bg|raster|sat|osm|gm|gs|gh|gl|gt|trans|ref|roads|custom)/.test(id) && !/^d-/.test(id)) return; f.geometry && walk(f.geometry.coordinates); });
    (typeof DR !== "undefined" ? DR.items : []).forEach(d => (d.pts || []).forEach(q => test(q[1], q[0])));
  } catch (er) { }
  return best ? Object.assign({}, e, { lngLat: new maplibregl.LngLat(best[0], best[1]) }) : e;
}

/* ---------- مساعدات الواجهة ---------- */
const lblOf = n => { const p = n && n.previousElementSibling; return p && p.tagName === "LABEL" ? p : null; };
const withLbl = n => n ? (lblOf(n) ? [lblOf(n), n] : [n]) : [];
function accord(title, nodes, open, cls) {
  const d = el(`<div class="acc ${open ? "open" : ""} ${cls || ""}"><button class="acch"><span>${title}</span><i>${I("more")}</i></button><div class="accb"></div></div>`); nodes.forEach(n => n && $(".accb", d).appendChild(n)); $(".acch", d).onclick = () => d.classList.toggle("open"); return d;
}
function segCtl(label, key, opts, def, extra) {
  const l = el(`<label class="f">${label}</label>`), s = el(`<div class="seg" data-key="${key}">${opts.map(([v, t_]) => `<button data-v="${v}" class="${(S.set[key] == null ? def : S.set[key]) === v ? "on" : ""}">${t_}</button>`).join("")}</div>`);
  $$("button", s).forEach(b => b.onclick = async () => { $$("button", s).forEach(x => x.classList.toggle("on", x === b)); await setSet(key, b.dataset.v); extra && extra(b.dataset.v); }); return [l, s];
}
const swRow = (title, sub, on, fn) => { const r = el(`<div class="row"><div class="t"><b>${title}</b>${sub ? `<small>${sub}</small>` : ""}</div></div>`); r.appendChild(sw(on, fn)); return r; };
const numRow = (label, key, def, min, max, step) => { const w = el(`<div><label class="f">${label}</label><input class="in" type="number" inputmode="decimal" min="${min}" max="${max}" step="${step || 1}" value="${S.set[key] == null ? def : S.set[key]}"></div>`); $("input", w).onchange = e => setSet(key, +e.target.value); return w; };

/* ---------- معاينة المؤشر الحية ---------- */
const _applyCross15 = applyCross;
applyCross = function () { _applyCross15(); const pv = $("#xp"), c = $("#cross"); if (pv && c) { pv.innerHTML = c.innerHTML; pv.style.width = pv.style.height = c.style.width || "34px"; pv.style.margin = `${-(parseFloat(c.style.width) || 34) / 2}px 0 0 ${-(parseFloat(c.style.width) || 34) / 2}px`; pv.style.opacity = c.style.opacity; pv.style.display = c.style.display; } };

/* ---------- إعادة التجميع ---------- */
function regroup(b) {
  const g = $("#st5", b); if (!g || b.querySelector(".stabs")) return;   /* لا نعتمد على علامة على #sh-b لأنه عنصر مشترك بين كل النوافذ */
  const T = { gen: el(`<div class="tabp"></div>`), map: el(`<div class="tabp"></div>`), sym: el(`<div class="tabp"></div>`), sys: el(`<div class="tabp"></div>`) };
  const put = (k, ...ns) => ns.flat().forEach(n => n && T[k].appendChild(n));
  const rowOf = id => { const x = $("#" + id, b); return x ? x.closest(".row") : null; };
  const xcard = g.querySelector("#st_cz").closest(".card"), icard = g.querySelector("#st_isl").closest(".card"), speed = [lblOf($("#st_fs", g)), $("#st_fs", g), $("#st_fs", g).nextElementSibling];
  const rcard = $("#st_rs", b).closest(".card"), ccard = $("#st_cc", b).closest(".row.card"), swcard = $("#so1", b).closest(".card");
  /* عام وإحداثيات */
  put("gen", withLbl($("#st_t", b)), withLbl($("#st_l", b)), withLbl($("#st_c", b)),
    segCtl(LL("وحدة المسافة", "Distance unit"), "units_d", [["m", LL("متر / كم", "m / km")], ["ft", LL("قدم / ميل", "ft / mi")], ["nm", LL("ميل بحري", "Nautical mi")]], "m"),
    segCtl(LL("وحدة المساحة", "Area unit"), "units_a", [["all", LL("الكل", "All")], ["m2", "م² / كم²"], ["du", LL("دونم عراقي", "Iraqi dunam")], ["ha", LL("هكتار", "Hectare")]], "all"),
    el(`<div class="hint">${LL("الدونم العراقي = 2500 م² · الهكتار = 10,000 م²", "Iraqi dunam = 2,500 m² · hectare = 10,000 m²")}</div>`),
    segCtl(LL("نطاق UTM لملفات DXF", "UTM zone for DXF files"), "export_utm", [["auto", LL("تلقائي", "Auto")], ["38N", LL("38N وسط/غرب", "38N centre/west")], ["39N", LL("39N شرق/البصرة", "39N east/Basra")]], "auto"),
    el(`<div class="hint">${LL("يحدد نظام الإحداثيات المتري لملفات الأوتوكاد DXF (متر).", "Metric CRS used for AutoCAD DXF files (metres).")}</div>`));
  /* الخريطة والمؤشر */
  const mapSw = el(`<div class="card"></div>`); [["so5"], ["so3"], ["so4"]].forEach(([i]) => { const r = rowOf(i); r && mapSw.appendChild(r); });
  const trk = el(`<div class="card"><div class="two"></div></div>`); const tw = $(".two", trk);
  tw.append(numRow(LL("نقطة كل (م)", "Point every (m)"), "trk_dist", 5, 1, 500), numRow(LL("أو كل (ثانية)", "Or every (s)"), "trk_time", 0, 0, 600), numRow(LL("تجاهل الدقة الأسوأ من (م)", "Ignore accuracy worse than (m)"), "trk_acc", 15, 3, 200));
  trk.appendChild(el(`<div class="hint">${LL("تسجيل المسار (GPS): الفاصل الأدنى بين النقاط وفلتر الإشارة الضعيفة. صفر في الثانية = تعطيل.", "GPS track recording: minimum spacing and weak-signal filter. 0 s = off.")}</div>`));
  const snap = el(`<div class="card"></div>`); snap.append(swRow(LL("الالتقاط المغناطيسي (Snapping)", "Snapping"), LL("أثناء الرسم والتنقيط: تنطبق النقطة على أقرب معلم أو رأس رسم أو حد", "While drawing: snaps to nearest landmark, vertex or boundary"), !!S.set.snap, v => setSet("snap", v)));
  snap.appendChild(el(`<div style="padding:4px 12px 10px"><label class="f">${LL("مدى الالتقاط (بكسل)", "Snap distance (px)")} <b id="sn_v">${S.set.snap_px || 14}</b></label><input type="range" class="rg" min="6" max="40" value="${S.set.snap_px || 14}" id="sn_r"></div>`));
  $("#sn_r", snap).oninput = e => { $("#sn_v", snap).textContent = e.target.value; }; $("#sn_r", snap).onchange = e => setSet("snap_px", +e.target.value);
  const pv = el(`<div class="xpv"><div id="xp"></div></div>`);
  xcard.querySelectorAll(":scope > b").forEach(x => x.remove()); xcard.insertBefore(pv, xcard.firstChild);
  put("map", withLbl($("#st_b", b)), mapSw, accord(LL("علامة + في مركز الخريطة", "Centre crosshair"), [xcard], false), accord(LL("تسجيل المسار (GPS)", "Track recording"), [trk], false), accord(LL("الالتقاط أثناء الرسم", "Snapping"), [snap], false));
  /* الرموز والقطاعات */
  const lbS = lblOf($("#st_isl", icard)), grid = $("#st_isl", icard), rst = icard.querySelector(".btns"), secBox = el(`<div></div>`);
  const srch = el(`<input class="in" placeholder="${LL("بحث في القطاعات…", "Search sectors…")}" style="margin-bottom:8px">`); secBox.append(srch, grid, rst);
  grid.classList.add("sgrid"); const off = () => new Set(S.set.sect_off || []);
  Array.from(grid.children).forEach((r, i) => { const n = SECT_NAMES[i]; if (!n) return; const w = sw(!off().has(n), async v => { const o = off(); v ? o.delete(n) : o.add(n); await setSet("sect_off", [...o]); restyleAll(); }); const sp = el(`<span class="sgsw"></span>`); sp.appendChild(w); sp.onclick = e => e.stopPropagation(); r.appendChild(sp); r.dataset.q = n; const bb = r.querySelector("b"); if (bb) bb.textContent = n.replace(/^(ال)?قطاع\s+(ال)?/, ""); });
  srch.oninput = () => { const q = srch.value.trim(); Array.from(grid.children).forEach(r => r.style.display = !q || (r.dataset.q || "").includes(q) ? "" : "none"); };
  if (lbS) lbS.remove(); icard.querySelector(":scope > b") && (icard.querySelector(":scope > b").style.display = "");
  icard.appendChild(accord(LL("رموز القطاعات (15)", "Sector icons (15)"), [secBox], false));
  put("sym", icard);
  /* النظام والبيانات */
  const sp = $("#st_fs", g), desc = speed[2], full = Array.from(sp.children).map(x => x.textContent), short = [["١×", LL("آمن", "Safe")], ["٣×", LL("متدرج", "Graded")], ["٦×", LL("سريع", "Fast")], ["٨×", LL("فائق", "Max")]];
  sp.classList.remove("col"); Array.from(sp.children).forEach((x, i) => { x.title = full[i]; x.innerHTML = `<b style="display:block;font-size:13px">${short[i][1]}</b><small style="opacity:.7">${short[i][0]}</small>`; });
  const upd = () => { const on = Array.from(sp.children).findIndex(x => x.classList.contains("on")); if (desc) desc.textContent = (full[on] || "").replace(/^[^—]*—\s*/, ""); }; Array.from(sp.children).forEach(x => x.addEventListener("click", () => setTimeout(upd, 0))); upd();
  const bk = el(`<div class="card"><div class="row"><div class="t"><b>${LL("نسخة احتياطية كاملة", "Full backup")}</b><small>${LL("المعالم والرسومات والتخطيطات وتخصيص الرموز والإعدادات", "Landmarks, drawings, layouts, icon choices and settings")}</small></div></div><div class="btns" style="padding:0 12px 12px"><button class="btn sec2" id="bk_s">${I("fetch")}${LL("تصدير نسخة", "Export backup")}</button><button class="btn sec2" id="bk_r">${I("imp")}${LL("استيراد نسخة", "Restore backup")}</button></div></div>`);
  $("#bk_s", bk).onclick = () => doBackup(); $("#bk_r", bk).onclick = () => doRestore();
  const dz = accord(LL("منطقة الخطر", "Danger zone"), [rcard], false, "danger");
  put("sys", speed.filter(Boolean), withLbl($("#st_f", b)), withLbl($("#st_x", b)), swcard, ccard, bk, swRow(LL("تأكيد عند الخروج", "Confirm on exit"), LL("يسأل قبل إغلاق البرنامج بزر الرجوع", "Asks before closing the app with Back"), S.set.exit_confirm !== false, v => setSet("exit_confirm", v)), dz);
  if (swcard) { Array.from(swcard.children).forEach(r => { if (!r.querySelector("#so1,#so2")) r.remove(); }); }
  g.remove();
  /* شريط التبويبات */
  const tabs = [["gen", LL("عام وإحداثيات", "General")], ["map", LL("الخريطة والمؤشر", "Map & cursor")], ["sym", LL("الرموز والقطاعات", "Symbols")], ["sys", LL("النظام والبيانات", "System")]];
  const bar = el(`<div class="stabs">${tabs.map(([k, l]) => `<button data-k="${k}">${l}</button>`).join("")}</div>`);
  const show = k => { $$("button", bar).forEach(x => x.classList.toggle("on", x.dataset.k === k)); Object.entries(T).forEach(([kk, n]) => n.style.display = kk === k ? "" : "none"); b.scrollTop = 0; S.set.set_tab = k; };
  $$("button", bar).forEach(x => x.onclick = () => { show(x.dataset.k); setSet("set_tab", x.dataset.k); });
  b.innerHTML = ""; b.append(bar, T.gen, T.sys, T.map, T.sym);   /* sys قبل map كي يبقى #st_cs (نص الكاش) أول تطابق */ show(T[S.set.set_tab] ? S.set.set_tab : "gen"); applyCross();
}
const _os15 = openSettings;
openSettings = function () { _os15(); const b = $("#sh-b"); if (SHEET === "set" && b) { try { regroup(b); } catch (e) { clientErr && clientErr("settings", e.message); } } };

/* ---------- مجلد الحفظ الافتراضي يصل إلى الأندرويد (لتنزيلات الباركود وغيرها) ---------- */
const syncFolder = () => { try { window.Android && Android.setFolder && Android.setFolder(S.set.folder || "POIExporter"); } catch (e) { } };
const _setSet15 = setSet; setSet = async function (k, v) { const r = await _setSet15(k, v); if (k === "folder") syncFolder(); return r; };
setTimeout(syncFolder, 2500); setTimeout(syncFolder, 7000);
