"use strict";
/* ===== app6: Layout، تحرير الطرق، روابط جوجل، الفلاش، تحسينات ===== */
Object.assign(TX.ar, { dr_kind_road: "طريق" }); Object.assign(TX.en, { dr_kind_road: "Road" });
const LL = (ar, en) => (S.set.lang === "en" ? en : ar);
const esc6 = s => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/* ---------- لمس مركز الخريطة يفتح إضافة معلم ---------- */
window.addEventListener("DOMContentLoaded", () => {
  map.on("click", e => {
    if (window.__mode || ADD.mode || window.__lpT && Date.now() - window.__lpT < 900) return;
    const r = map.getCanvas().getBoundingClientRect(), cx = r.width / 2, cy = r.height / 2, rad = Math.max(24, (+S.set.cross_size || 34) / 2 + 6);
    if (Math.hypot(e.point.x - cx, e.point.y - cy) > rad) return;
    setTimeout(() => { if (!e._fc && !(window.__drT && Date.now() - window.__drT < 400)) { ADD.at = null; openAdd(); } }, 40);
  });
});

/* ---------- نافذة الإضافة: الاسم أولاً ثم النوع ---------- */
const _openAdd6 = openAdd;
openAdd = function () {
  _openAdd6(); const b = $("#sh-b"), a = b && $("#a_name", b), ty = b && $("#a_type", b); if (!a || !ty) return;
  const first = b.firstElementChild; [a, ty].forEach(i => { const l = i.previousElementSibling; b.insertBefore(l, first); b.insertBefore(i, first); });
};

/* ---------- الفلاش: الانتقال من الجدول إلى المعلم مع توجيه ---------- */
function flashAt(lon, lat) {
  const e = document.createElement("div"); e.className = "flash"; e.innerHTML = "<i></i><i></i><i></i>";
  const m = new maplibregl.Marker({ element: e }).setLngLat([lon, lat]).addTo(map); setTimeout(() => m.remove(), 6500);
}
function goFlash(r) {
  closeSheet(); map.flyTo({ center: [r.lon, r.lat], zoom: Math.max(map.getZoom(), 17), speed: 1.6 }); marker("z", r.lon, r.lat); flashAt(r.lon, r.lat);
  toast((r.name || r.type || "") + " — " + (+r.lat).toFixed(5) + ", " + (+r.lon).toFixed(5), [[LL("توجيه", "Navigate"), () => navStart({ lat: +r.lat, lon: +r.lon, name: r.name || "" })]]);
}
const _loadRows6 = loadRows;
loadRows = async function (b, reset, norefetch) {
  await _loadRows6(b, reset, norefetch);
  $$("tbody tr", b).forEach((tr, i) => { const r = TB.rows[i], z = $("[data-a=z]", tr); if (r && z) z.onclick = ev => { ev.stopPropagation(); goFlash(r); }; });
};

/* ---------- خيارات الجلب: تحديد الكل / إلغاء التحديد ---------- */
const _openFetch6 = openFetch;
openFetch = function () {
  _openFetch6(); const b = $("#sh-b"), box = b && $("#f_l", b); if (!box) return;
  $$("details", box).forEach(d => {
    const old = $("summary button", d); if (!old) return; const chips = () => $$(".chip", d);
    const mk = (txt, want) => { const x = old.cloneNode(false); x.textContent = txt; x.onclick = e => { e.preventDefault(); e.stopPropagation(); chips().forEach(c => { if (c.classList.contains("on") !== want) c.click(); }); }; return x; };
    const wrap = document.createElement("span"); wrap.style.cssText = "display:flex;gap:6px"; wrap.append(mk(LL("تحديد الكل", "Select all"), true), mk(LL("إلغاء", "None"), false)); old.replaceWith(wrap);
  });
  const all = el(`<div class="btns" style="margin:0 0 8px"><button class="btn sec2" id="fl_a">${LL("تحديد كل العوارض", "Select all features")}</button><button class="btn sec2" id="fl_n">${LL("إلغاء تحديد الكل", "Clear all")}</button></div>`);
  box.parentNode.insertBefore(all, box); const each = w => $$(".chip", box).forEach(c => { if (c.classList.contains("on") !== w) c.click(); });
  $("#fl_a", all).onclick = () => each(true); $("#fl_n", all).onclick = () => each(false);
};

/* ---------- رسم الطرق: أنواع وقص/دمج/فصل/حذف ---------- */
const ROADS = {
  motorway: ["طريق سريع", "Motorway", "#e8590c", 7, "solid"], primary: ["طريق رئيسي", "Primary road", "#f59f00", 6, "solid"], secondary: ["طريق ثانوي", "Secondary road", "#fab005", 5, "solid"],
  local: ["طريق فرعي", "Local road", "#868e96", 4, "solid"], track: ["طريق ترابي", "Dirt track", "#a0764a", 3, "dashed"], foot: ["ممر مشاة", "Footpath", "#d6336c", 3, "dotted"],
  bridge: ["جسر", "Bridge", "#495057", 6, "solid"], rail: ["سكة قطار", "Railway", "#343a40", 4, "dashed"], river: ["نهر/قناة", "River/canal", "#1c7ed6", 5, "solid"], pipe: ["أنبوب", "Pipeline", "#7048e8", 3, "dashed"]
};
const rtName = k => (S.set.lang === "en" ? ROADS[k][1] : ROADS[k][0]);
function applyRoad(d, k) { const r = ROADS[k]; d.rtype = k; d.color = r[2]; d.width = r[3]; d.dash = r[4]; if (d.kind !== "area") d.kind = d.kind === "route" || d.kind === "track" ? d.kind : "road"; }
function startRoad() {
  const b = el(`<div><div class="hint">${LL("اختر نوع الطريق ثم ارسمه على الخريطة (اضغط النقاط ثم إنهاء)", "Pick a road type, then tap the points and finish")}</div><div class="icg" id="rd_g"></div></div>`);
  Object.keys(ROADS).forEach(k => { const x = el(`<button class="ig" style="flex-direction:column;gap:2px;min-height:58px"><svg width="46" height="14"><line x1="3" y1="7" x2="43" y2="7" stroke="${ROADS[k][2]}" stroke-width="${ROADS[k][3]}" stroke-linecap="round" ${ROADS[k][4] === "dashed" ? 'stroke-dasharray="8 5"' : ROADS[k][4] === "dotted" ? 'stroke-dasharray="1 6"' : ""}/></svg><span class="igt">${esc6(rtName(k))}</span></button>`, $("#rd_g", b)); x.onclick = () => { document.querySelector(".modal") && document.querySelector(".modal").remove(); window.__roadNext = k; measureMode("line"); }; });
  modal(LL("رسم طريق", "Draw road"), b, () => true, LL("إغلاق", "Close"));
}
function nearestOn(pts, ll) {
  const k = 111320, cl = Math.cos(ll.lat * Math.PI / 180); let best = { d: 1e18, i: 0, t: 0, q: pts[0] };
  for (let i = 0; i < pts.length - 1; i++) { const a = pts[i], b = pts[i + 1], ax = a[1] * k * cl, ay = a[0] * k, bx = b[1] * k * cl, by = b[0] * k, px = ll.lng * k * cl, py = ll.lat * k, dx = bx - ax, dy = by - ay, L = dx * dx + dy * dy;
    let tt = L ? ((px - ax) * dx + (py - ay) * dy) / L : 0; tt = Math.max(0, Math.min(1, tt)); const d = Math.hypot(px - ax - tt * dx, py - ay - tt * dy); if (d < best.d) best = { d, i, t: tt, q: [a[0] + (b[0] - a[0]) * tt, a[1] + (b[1] - a[1]) * tt] }; }
  return best;
}
const nearestVertex = (pts, ll) => { let bi = 0, bd = 1e18; pts.forEach((p, i) => { const d = hav(p, [ll.lat, ll.lng]); if (d < bd) { bd = d; bi = i; } }); return bi; };
function drShare(d) { const co = d.pts.map(p => [p[1], p[0]]), g = d.kind === "area" ? { type: "Polygon", coordinates: [co.concat([co[0]])] } : { type: "LineString", coordinates: co }; return saveBlob(new Blob([JSON.stringify(fc(ft(g, { name: d.name || "", type: d.rtype ? rtName(d.rtype) : "" })))], { type: "application/geo+json" }), (d.name || "road").replace(/[^\w؀-ۿ]+/g, "_") + ".geojson", "share"); }
function drTap(id, ll) {
  const d = drOf(id); if (!d) return; DR.sel = id; drRender();
  const pt = map.project(ll), r = map.getCanvas().getBoundingClientRect(), x = r.left + pt.x, y = r.top + pt.y, line = d.kind !== "area";
  const nr = line ? nearestOn(d.pts, ll) : null, items = [];
  items.push(["share", LL("مشاركة", "Share"), () => drShare(d)]);
  if (line && d.pts.length >= 2) {
    items.push(["edit", LL("قص (إبقاء ما قبل/بعد النقطة)", "Cut (keep before/after)"), () => menuAt([["pin", LL("إبقاء ما قبل الموضع", "Keep before point"), () => { d.pts = d.pts.slice(0, nr.i + 1).concat([nr.q]); drSave(); drRender(); }], ["pin", LL("إبقاء ما بعد الموضع", "Keep after point"), () => { d.pts = [nr.q].concat(d.pts.slice(nr.i + 1)); drSave(); drRender(); }]], x, y)]);
    items.push(["plus", LL("دمج مع خط آخر", "Merge with another"), () => { const others = DR.items.filter(o => o !== d && o.kind !== "area" && o.pts.length > 1); if (!others.length) return toast(LL("لا يوجد خط آخر للدمج", "No other line to merge")); menuAt(others.map(o => ["pin", o.name || drKindName(o), () => { drMerge(d, o); }]), x, y); }]);
    items.push(["x", LL("انفصال عند هذه النقطة", "Split here"), () => { const a = d.pts.slice(0, nr.i + 1).concat([nr.q]), b = [nr.q].concat(d.pts.slice(nr.i + 1)); d.pts = a; DR.add(Object.assign({}, JSON.parse(JSON.stringify(d)), { id: undefined, pts: b, name: (d.name || "") + " 2" })); drSave(); drRender(); }]);
  }
  items.push(["trash", LL("حذف", "Delete"), () => { if (!confirm(t("confirm"))) return; DR.items = DR.items.filter(o => o !== d); DR.sel = null; drSave(); drRender(); }, "er"]);
  items.push(["trash", LL("حذف النقطة المحددة", "Delete selected point"), () => { if (d.pts.length <= 2) return toast(LL("لا يمكن الحذف: نقطتان فقط", "Only two points left")); d.pts.splice(nearestVertex(d.pts, ll), 1); drSave(); drRender(); }, "er"]);
  items.push(["edit", LL("تحرير النقاط", "Edit points"), () => drEdit(id)]); items.push(["table", LL("التفاصيل واللون والنوع", "Details, colour, type"), () => openDraw(id)]);
  menuAt(items, x, y);
}
function drMerge(a, b) {
  const A = a.pts, B = b.pts, d = (p, q) => hav(p, q), c = [[d(A[A.length - 1], B[0]), 0], [d(A[A.length - 1], B[B.length - 1]), 1], [d(A[0], B[0]), 2], [d(A[0], B[B.length - 1]), 3]].sort((x, y) => x[0] - y[0])[0][1];
  a.pts = c === 0 ? A.concat(B) : c === 1 ? A.concat(B.slice().reverse()) : c === 2 ? A.slice().reverse().concat(B) : B.concat(A);
  DR.items = DR.items.filter(o => o !== b); drSave(); drRender(); toast(LL("تم الدمج", "Merged"));
}
const _stopMode6 = stopMode;
stopMode = function (keep) {
  const m = MODE, rn = window.__roadNext;
  if (m && m.dk === "line" && rn && !keep) {
    const raw = m.getPts().slice(); window.__roadNext = null; window.__noDraw = true;
    try { _stopMode6(false); } finally { window.__noDraw = false; }
    if (raw.length >= 2) { const d = DR.add({ kind: "road", pts: raw, name: rtName(rn) }); applyRoad(d, rn); drSave(); drRender(); setTimeout(() => toast(t("dr_made"), [[LL("تحرير النقاط", "Edit points"), () => drEdit(d.id)], [LL("التفاصيل", "Details"), () => openDraw(d.id)]]), 30); }
    return;
  }
  _stopMode6(keep);
};
/* نوع الطريق داخل نافذة الرسم */
const _openDraw6 = openDraw;
openDraw = function (id) {
  _openDraw6(id); const d = drOf(id), b = $("#sh-b"); if (!d || !b || d.kind === "area" || $("#dw_rt", b)) return; const n = $("#dw_n", b); if (!n) return;
  const w = el(`<div><label class="f">${LL("نوع الطريق/الخط", "Road / line type")}</label><select class="in" id="dw_rt"><option value="">—</option>${Object.keys(ROADS).map(k => `<option value="${k}" ${d.rtype === k ? "selected" : ""}>${esc6(rtName(k))}</option>`).join("")}</select></div>`);
  n.parentNode.insertBefore(w, n.nextSibling); $("#dw_rt", w).onchange = e => { if (e.target.value) { applyRoad(d, e.target.value); if (!d.name) d.name = rtName(d.rtype); drSave(); drRender(); openDraw(id); } };
};
/* الخطوط المجلوبة: مشاركة/تحويل إلى رسم/حذف */
const _featClick6 = featClick;
featClick = function (e) {
  const f = e.features && e.features[0]; if (!f || !/LineString/.test(f.geometry.type) || (window.__mode || ADD.mode)) return _featClick6(e);
  e._fc = 1; const p = f.properties, r = map.getCanvas().getBoundingClientRect(), x = r.left + e.point.x, y = r.top + e.point.y;
  const co = f.geometry.type === "LineString" ? f.geometry.coordinates : f.geometry.coordinates.reduce((a, b) => a.concat(b), []);
  menuAt([["pin", p.name || p.type || LL("خط", "Line"), () => _featClick6(e)],
  ["share", LL("مشاركة", "Share"), async () => { try { const g = await api("/api/features/" + encodeURIComponent(p.id) + "/geojson"); saveBlob(new Blob([JSON.stringify(g)], { type: "application/geo+json" }), (p.name || "line") + ".geojson", "share"); } catch (er) { fail(er); } }],
  ["edit", LL("تحويل إلى رسم قابل للتحرير (قص/دمج/فصل)", "Convert to editable drawing"), () => { const d = DR.add({ kind: "road", pts: simp(co.map(c => [c[1], c[0]]), 1.5), name: p.name || p.type || "", color: p.color || "#868e96", width: 4 }); openDraw(d.id); }],
  ["trash", LL("حذف", "Delete"), async () => { if (!confirm(t("confirm"))) return; await post("/api/features/delete", { ids: [p.id] }).catch(fail); await refreshDs(dsIds()); }, "er"]], x, y);
};

/* ---------- رابط جوجل / إحداثية: خيارات ---------- */
async function lnkConvert(c, fmt) {
  const nm = (c.name || "point").replace(/[^\w؀-ۿ]+/g, "_"), la = c.lat, lo = c.lon; let txt, mime = "text/plain", ext = fmt;
  if (fmt === "geojson") { txt = JSON.stringify(fc(ft({ type: "Point", coordinates: [lo, la] }, { name: c.name || "" }))); mime = "application/geo+json"; }
  else if (fmt === "kml") { txt = `<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Placemark><name>${esc6(c.name || "")}</name><Point><coordinates>${lo},${la},0</coordinates></Point></Placemark></kml>`; mime = "application/vnd.google-earth.kml+xml"; }
  else if (fmt === "gpx") { txt = `<?xml version="1.0"?><gpx version="1.1" creator="POI"><wpt lat="${la}" lon="${lo}"><name>${esc6(c.name || "")}</name></wpt></gpx>`; mime = "application/gpx+xml"; }
  else { txt = `name,lat,lon,UTM,MGRS,PlusCode\n"${(c.name || "").replace(/"/g, "'")}",${la},${lo},"${c.UTM || ""}","${c.MGRS || ""}","${c.PLUS || ""}"`; mime = "text/csv"; ext = "csv"; }
  return saveBlob(new Blob([txt], { type: mime }), nm + "." + ext, "share");
}
function linkCard(c) {
  openSheet("lnk", LL("نتيجة الرابط / الإحداثية", "Link / coordinate result"), b => {
    const rows = ["DD", "DMS", "DDM", "UTM", "MGRS", "PLUS", "GMAPS"].filter(k => c[k]);
    b.innerHTML = `<div class="card" style="padding:12px"><b>${esc6(c.name || c.detected || "")}</b><div class="hint" dir="ltr" style="text-align:start">${(+c.lat).toFixed(6)}, ${(+c.lon).toFixed(6)}</div></div>
    <div class="btns"><button class="btn" id="lk_v">${I("pin")}${LL("عرض على الخريطة", "Show on map")}</button><button class="btn sec2" id="lk_a">${I("plus")}${LL("إضافة كمعلم", "Add as landmark")}</button></div>
    <div class="btns"><button class="btn sec2" id="lk_f">${I("fetch")}${LL("تحويل إلى صيغة", "Convert to format")}</button><button class="btn sec2" id="lk_s">${I("share")}${LL("مشاركة", "Share")}</button></div>
    <div class="btns"><button class="btn sec2 er" id="lk_d">${I("trash")}${LL("حذف", "Remove")}</button><button class="btn sec2" id="lk_c">${LL("إلغاء", "Cancel")}</button></div>
    <div class="card" id="lk_r">${rows.map(k => `<div class="row"><div class="t"><b>${k}</b><small dir="ltr" style="text-align:start">${esc6(c[k])}</small></div><button class="ib sm" data-k="${k}">${I("copy")}</button></div>`).join("")}</div>`;
    $("#lk_v", b).onclick = () => { closeSheet(); gotoLL(c.lat, c.lon, 17); marker("sr", c.lon, c.lat); flashAt(c.lon, c.lat); };
    $("#lk_a", b).onclick = () => post("/api/landmarks", { lat: c.lat, lon: c.lon, name: c.name || "", type: "", Gategory: "" }).then(() => { refreshDs(dsIds()); toast(LL("تمت الإضافة", "Added")); }).catch(fail);
    $("#lk_f", b).onclick = () => menuAt(["geojson", "kml", "gpx", "csv"].map(f => ["share", f.toUpperCase(), () => lnkConvert(c, f)]), innerWidth / 2, innerHeight / 2);
    $("#lk_s", b).onclick = () => { const txt = (c.name ? c.name + "\n" : "") + (c.GMAPS || `${c.lat},${c.lon}`) + (c.PLUS ? "\n" + c.PLUS : ""); if (navigator.share) navigator.share({ text: txt }).catch(() => { }); else { navigator.clipboard && navigator.clipboard.writeText(txt); toast(LL("نُسخ", "Copied")); } };
    $("#lk_d", b).onclick = () => { if (MK.sr) { MK.sr.remove(); delete MK.sr; } if (POP) POP.remove(); closeSheet(); };
    $("#lk_c", b).onclick = () => closeSheet();
    $$("#lk_r [data-k]", b).forEach(x => x.onclick = () => { navigator.clipboard && navigator.clipboard.writeText(c[x.dataset.k]); toast(LL("نُسخ", "Copied")); });
  });
}
goText = async function (q, quiet) {
  try { const c = await api("/api/coords?text=" + encodeURIComponent(q) + refQ()); gotoLL(c.lat, c.lon, 17); marker("sr", c.lon, c.lat);
    if (!quiet) { linkCard(c); if (c.points && c.points.length > 1) setTimeout(() => toast(t("route"), [[t("route"), () => { RT.from = { lat: c.points[0][0], lon: c.points[0][1], label: "A" }; const z = c.points[c.points.length - 1]; RT.to = { lat: z[0], lon: z[1], label: "B" }; RT.line = null; RT.info = null; openRoute(); }]]), 400); }
    return true; } catch (e) { if (!quiet) toast("⚠ " + (e.message || t("notfound"))); return false; }
};

/* ================= أداة Layout (تخطيط الخريطة للطباعة والتصدير) ================= */
const PAPERS = { A5: [148, 210], A4: [210, 297], A3: [297, 420], A2: [420, 594], Letter: [216, 279] }, PT = 0.3528, PM = 14, PXM = 5;
const FONTS = ["sans-serif", "serif", "monospace", "Arial", "Tahoma", "Times New Roman", "Courier New", "Georgia", "Verdana"];
const LY = { open: false, paper: "A4", ori: "p", bg: "#ffffff", els: [], sel: null, zoom: 1, cap: null, guides: [], imgs: {}, n: 0 };
try { const s = JSON.parse(localStorage.getItem("layout") || "null"); if (s) Object.assign(LY, { paper: s.paper, ori: s.ori, bg: s.bg, els: s.els || [] }); } catch (e) { }
const lySave = () => { try { localStorage.setItem("layout", JSON.stringify({ paper: LY.paper, ori: LY.ori, bg: LY.bg, els: LY.els })); } catch (e) { } };
const lyPaper = () => { const [w, h] = PAPERS[LY.paper]; return LY.ori === "p" ? [w, h] : [h, w]; };
const lyEl = id => LY.els.find(e => e.id === id);
const lyDef = { map: [100, 100, "خريطة", "Map"], title: [120, 14, "عنوان", "Title"], legend: [50, 50, "مفتاح الخريطة", "Legend"], north: [18, 22, "سهم الشمال", "North arrow"], scale: [70, 14, "مقياس الرسم", "Scale bar"], text: [60, 25, "مربع نص", "Text box"], image: [30, 30, "شعار/صورة", "Logo/image"], rect: [50, 30, "مربع", "Rectangle"], line: [60, 1, "خط", "Line"], table: [180, 70, "جدول", "Table"] };
function lyAdd(type, o) {
  const [w, h] = lyDef[type], [pw, ph] = lyPaper(); const z = Math.max(0, ...LY.els.map(e => e.z)) + 1;
  const e = Object.assign({ id: "e" + Date.now().toString(36) + (LY.n++), type, x: Math.max(5, (pw - w) / 2), y: Math.max(5, (ph - h) / 2), w: Math.min(w, pw - 10), h: Math.min(h, ph - 10), z, font: "sans-serif", size: 12, color: "#16202b", bg: "#ffffff", bgOn: false, bc: "#16202b", bw: 0, op: 1, al: "center", bold: false, italic: false, text: "" }, o || {});
  if (type === "title") Object.assign(e, { text: LL("عنوان الخريطة", "Map title"), size: 26, bold: true, bw: 0 });
  if (type === "text") Object.assign(e, { text: LL("اكتب هنا…", "Type here…"), size: 11, al: "start", bgOn: true, bw: .3 });
  if (type === "map") Object.assign(e, { bw: .5, iz: 1, ox: 0, oy: 0, bgOn: true, bg: "#e5e9ee" });
  if (type === "legend") Object.assign(e, { text: LL("مفتاح الخريطة", "Legend"), size: 9, al: "start", bgOn: true, bw: .3, cols: 1, items: lyLegendItems() });
  if (type === "north") Object.assign(e, { style: "n1", rot: true, color: "#16202b" });
  if (type === "scale") Object.assign(e, { style: "alt", size: 8, ratio: true, color: "#16202b" });
  if (type === "rect") Object.assign(e, { bgOn: true, bg: "#ffffff", bw: .4 });
  if (type === "line") Object.assign(e, { bw: .5, h: 1 });
  if (type === "table") Object.assign(e, { size: 8, ds: (S.ds[0] || {}).id || "", cols: ["name", "type", "Gategory", "Nahia"], rows: 15, bw: .2, hdr: "#1e5aa8", al: "start" });
  LY.els.push(e); LY.sel = e.id; return e;
}
function lyLegendItems() {
  const it = []; S.ds.filter(d => d.visible && d.kind !== "reference").forEach(d => { const g = GJ[d.id], f = g && g.features[0], r = f && f.geometry.type === "Point" ? iconRes(f.properties, d.id) : null, gt = f ? f.geometry.type : "Point"; it.push({ label: d.label, color: d.color, shape: r ? "icon" : /Polygon/.test(gt) ? "area" : /Line/.test(gt) ? "line" : "point", g: r ? r.g : "", on: true }); });
  DR.items.filter(d => d.vis).forEach(d => it.push({ label: d.name || drKindName(d), color: d.color, shape: d.kind === "area" ? "area" : "line", g: "", on: true, dash: d.dash, w: d.width })); return it;
}
function lyScaleInfo() { const m = LY.els.filter(e => e.type === "map" && LY.cap).sort((a, b) => a.z - b.z)[0]; if (!m) return null; const s = Math.max(m.w / LY.cap.w, m.h / LY.cap.h) * (m.iz || 1); return { mmpp: LY.cap.mpp / s, el: m }; }
const niceLen = mx => { const p = Math.pow(10, Math.floor(Math.log10(mx))); for (const k of [5, 2, 1]) if (k * p <= mx) return k * p; return p; };
const fmLen = m => m >= 1000 ? (m / 1000).toString().replace(/\.0+$/, "") + " km" : Math.round(m) + " m";
function lyText(c, txt, x, y, w, h, e, px, vpos) {
  c.save(); c.beginPath(); c.rect(x, y, w, h); c.clip(); const fs = e.size * PT * px; c.font = `${e.italic ? "italic " : ""}${e.bold ? "700 " : "400 "}${fs}px ${e.font}`; c.fillStyle = e.color; c.textBaseline = "top";
  const pad = 1.5 * px, lines = []; String(txt).split("\n").forEach(par => { let cur = ""; par.split(" ").forEach(wd => { const t2 = cur ? cur + " " + wd : wd; if (c.measureText(t2).width > w - 2 * pad && cur) { lines.push(cur); cur = wd; } else cur = t2; }); lines.push(cur); });
  const lh = fs * 1.35, th = lines.length * lh; let yy = vpos === "mid" ? y + (h - th) / 2 : y + pad;
  lines.forEach(l => { const tw = c.measureText(l).width; const al = e.al === "start" ? (/[؀-ۿ]/.test(l) ? "right" : "left") : e.al === "end" ? (/[؀-ۿ]/.test(l) ? "left" : "right") : e.al; const xx = al === "center" ? x + (w - tw) / 2 : al === "right" ? x + w - pad - tw : x + pad; c.fillText(l, xx, yy); yy += lh; }); c.restore();
}
function lyBox(c, e, px) {
  const x = e.x * px, y = e.y * px, w = e.w * px, h = e.h * px; if (e.bgOn) { c.fillStyle = e.bg; c.fillRect(x, y, w, h); } if (e.bw > 0) { c.strokeStyle = e.bc; c.lineWidth = e.bw * px; c.strokeRect(x, y, w, h); }
}
function lyNorth(c, e, x, y, w, h, bearing) {
  const s = Math.min(w, h * 0.82), cx = x + w / 2, cy = y + h * 0.58, R = s / 2; c.save(); c.translate(cx, cy); if (e.rot) c.rotate(-bearing * Math.PI / 180); c.fillStyle = c.strokeStyle = e.color; c.lineWidth = Math.max(1, R * .08); c.lineJoin = "round";
  const poly = (pts, f) => { c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0] * R, p[1] * R) : c.moveTo(p[0] * R, p[1] * R)); c.closePath(); f ? c.fill() : c.stroke(); };
  const st = e.style || "n1";
  if (st === "n1") { poly([[0, -1], [.55, .8], [0, .4], [-.55, .8]], true); }
  else if (st === "n2") { poly([[0, -1], [.22, -.22], [0, 0], [-.22, -.22]], true); poly([[0, 1], [.22, .22], [0, 0], [-.22, .22]], false); poly([[1, 0], [.22, -.22], [0, 0], [.22, .22]], false); poly([[-1, 0], [-.22, -.22], [0, 0], [-.22, .22]], false); poly([[.7, -.7], [.12, -.12], [.3, 0]], false); }
  else if (st === "n3") { c.beginPath(); c.arc(0, 0, R * .95, 0, 7); c.stroke(); poly([[0, -.8], [.3, .5], [0, .25], [-.3, .5]], true); }
  else if (st === "n4") { poly([[0, -1], [.5, .8], [0, .45]], true); poly([[0, -1], [-.5, .8], [0, .45]], false); }
  else if (st === "n5") { c.beginPath(); c.moveTo(0, .9); c.lineTo(0, -.7); c.stroke(); poly([[0, -1], [.3, -.55], [-.3, -.55]], true); }
  else { c.beginPath(); c.arc(0, 0, R * .7, 0, 7); c.stroke(); c.beginPath(); c.moveTo(0, -R); c.lineTo(0, R); c.moveTo(-R, 0); c.lineTo(R, 0); c.stroke(); poly([[0, -.7], [.18, 0], [-.18, 0]], true); }
  c.restore(); c.fillStyle = e.color; c.font = `700 ${Math.max(8, s * .38)}px sans-serif`; c.textAlign = "center"; c.textBaseline = "alphabetic"; c.fillText("N", cx, y + h * 0.17); c.textAlign = "start";
}
function lyScale(c, e, px) {
  const x = e.x * px, y = e.y * px, w = e.w * px, h = e.h * px, inf = lyScaleInfo(); c.save(); c.fillStyle = c.strokeStyle = e.color; const fs = e.size * PT * px; c.font = `${e.bold ? "700 " : "400 "}${fs}px ${e.font}`; c.textBaseline = "alphabetic"; c.lineWidth = Math.max(1, .3 * px);
  if (!inf) { c.fillText(LL("أضف إطار خريطة", "Add a map frame"), x, y + h / 2); c.restore(); return; }
  const mmpp = inf.mmpp, maxM = (e.w - 6) * mmpp * (e.style === "double" ? 1 : 1), L = niceLen(maxM), Lmm = L / mmpp, bw = Lmm * px, bx = x + 2 * px, by = y + h * (e.ratio ? .62 : .5), bh = Math.max(2 * px, h * .2);
  if (e.ratio) { c.textAlign = "left"; c.fillText("1 : " + Math.round(mmpp * 1000).toLocaleString("en"), bx, y + fs * 1.05); }
  if (e.style === "text") { c.restore(); return; }
  const n = 4; c.textAlign = "center";
  if (e.style === "alt" || e.style === "hollow") { for (let i = 0; i < n; i++) { c.fillStyle = e.style === "alt" && i % 2 === 0 ? e.color : "#ffffff"; c.fillRect(bx + bw / n * i, by, bw / n, bh); c.strokeRect(bx + bw / n * i, by, bw / n, bh); } }
  else if (e.style === "line") { c.beginPath(); c.moveTo(bx, by + bh); c.lineTo(bx + bw, by + bh); for (let i = 0; i <= n; i++) { c.moveTo(bx + bw / n * i, by + bh); c.lineTo(bx + bw / n * i, by + (i % 2 ? bh * .5 : 0)); } c.stroke(); }
  else if (e.style === "double") { for (let i = 0; i < n; i++) { c.fillStyle = i % 2 === 0 ? e.color : "#fff"; c.fillRect(bx + bw / n * i, by, bw / n, bh / 2); c.strokeRect(bx + bw / n * i, by, bw / n, bh / 2); } const L2 = L * 3.28084, nl = niceLen(L2), w2 = nl / 3.28084 / mmpp * px; for (let i = 0; i < n; i++) { c.fillStyle = i % 2 ? e.color : "#fff"; c.fillRect(bx + w2 / n * i, by + bh / 2, w2 / n, bh / 2); c.strokeRect(bx + w2 / n * i, by + bh / 2, w2 / n, bh / 2); } c.fillStyle = e.color; c.textAlign = "left"; c.fillText(nl >= 5280 ? (nl / 5280).toFixed(1) + " mi" : Math.round(nl) + " ft", bx + w2 + 2 * px, by + bh); c.textAlign = "center"; }
  c.fillStyle = e.color; c.font = `${e.bold ? "700 " : "400 "}${fs * .85}px ${e.font}`; const ly = by + bh + fs * 1.0; [0, 1].forEach(i => c.fillText(i ? fmLen(L) : "0", bx + bw * i, ly)); if (L >= 2) c.fillText(fmLen(L / 2), bx + bw / 2, ly); c.restore();
}
function lyLegend(c, e, px) {
  const x = e.x * px, y = e.y * px, w = e.w * px, h = e.h * px; c.save(); c.beginPath(); c.rect(x, y, w, h); c.clip(); const fs = e.size * PT * px, pad = 2.2 * px; c.font = `700 ${fs * 1.15}px ${e.font}`; c.fillStyle = e.color; c.textBaseline = "middle";
  const rtl = /[؀-ۿ]/.test(e.text), hy = y + pad + fs * .7; c.textAlign = rtl ? "right" : "left"; c.fillText(e.text, rtl ? x + w - pad : x + pad, hy);
  const items = (e.items || []).filter(i => i.on), cols = e.cols || 1, cw = (w - 2 * pad) / cols, rh = fs * 1.9, sw = fs * 1.5; c.font = `${e.bold ? "700 " : "400 "}${fs}px ${e.font}`;
  items.forEach((it, i) => { const col = i % cols, row = Math.floor(i / cols), cy = hy + fs * 1.3 + row * rh + rh / 2, rr = /[؀-ۿ]/.test(it.label), x0 = rr ? x + pad + (col + 1) * cw : x + pad + col * cw; const sx = rr ? x0 - sw : x0, tx = rr ? x0 - sw - fs * .5 : x0 + sw + fs * .5;
    c.fillStyle = c.strokeStyle = it.color; if (it.shape === "icon") { const g = GL[it.g] || GL.pin; c.save(); c.translate(sx, cy - sw / 2); c.scale(sw / 64, sw / 64); c.beginPath(); c.arc(32, 32, 29, 0, 7); c.fillStyle = it.color; c.fill(); c.lineWidth = 4; c.strokeStyle = "#fff"; c.stroke(); c.translate(14, 14); c.scale(1.5, 1.5); c.lineWidth = 2; c.lineCap = c.lineJoin = "round"; c.fillStyle = "#fff"; const p = new Path2D(g[1]); FILLED.has(it.g) ? c.fill(p) : c.stroke(p); c.restore(); }
    else if (it.shape === "point") { c.beginPath(); c.arc(sx + sw / 2, cy, sw * .32, 0, 7); c.fill(); c.strokeStyle = "#fff"; c.lineWidth = px * .3; c.stroke(); }
    else if (it.shape === "line") { c.lineWidth = Math.max(px * .4, (it.w || 3) * px * .12); c.setLineDash(it.dash === "dashed" ? [px * 1.5, px] : it.dash === "dotted" ? [px * .3, px] : []); c.beginPath(); c.moveTo(sx, cy); c.lineTo(sx + sw, cy); c.stroke(); c.setLineDash([]); }
    else { c.globalAlpha = .45; c.fillRect(sx, cy - sw * .35, sw, sw * .7); c.globalAlpha = 1; c.lineWidth = px * .3; c.strokeRect(sx, cy - sw * .35, sw, sw * .7); }
    c.fillStyle = e.color; c.textAlign = rr ? "right" : "left"; c.fillText(it.label, tx, cy, cw - sw - fs); });
  c.restore();
}
function lyTable(c, e, px) {
  const x = e.x * px, y = e.y * px, w = e.w * px, g = GJ[e.ds], rows = g ? g.features.slice(0, e.rows).map(f => f.properties) : [], cols = e.cols && e.cols.length ? e.cols : ["name"], fs = e.size * PT * px, rh = fs * 1.9, cw = w / cols.length;
  c.save(); c.font = `${fs}px ${e.font}`; c.textBaseline = "middle"; c.lineWidth = Math.max(.5, e.bw * px);
  [{ h: 1 }].concat(rows).forEach((r, ri) => { const yy = y + ri * rh; if (ri === 0) { c.fillStyle = e.hdr; c.fillRect(x, yy, w, rh); } else if (ri % 2 === 0) { c.fillStyle = "rgba(0,0,0,.05)"; c.fillRect(x, yy, w, rh); }
    cols.forEach((k, ci) => { const txt = ri === 0 ? t(k) : String(r[k] == null ? "" : r[k]); c.fillStyle = ri === 0 ? "#fff" : e.color; c.font = `${ri === 0 ? "700 " : ""}${fs}px ${e.font}`; c.save(); c.beginPath(); c.rect(x + ci * cw, yy, cw, rh); c.clip(); const rr = /[؀-ۿ]/.test(txt); c.textAlign = rr ? "right" : "left"; c.fillText(txt, rr ? x + (ci + 1) * cw - fs * .4 : x + ci * cw + fs * .4, yy + rh / 2); c.restore(); }); c.strokeStyle = e.bc; c.strokeRect(x, yy, w, rh); });
  c.restore(); e.h = (rows.length + 1) * rh / px;
}
function drawEl(c, e, px, pv) {
  c.save(); c.globalAlpha = e.op == null ? 1 : e.op; const x = e.x * px, y = e.y * px, w = e.w * px, h = e.h * px;
  if (e.type === "map") { c.save(); c.beginPath(); c.rect(x, y, w, h); c.clip(); if (e.bgOn) { c.fillStyle = e.bg; c.fillRect(x, y, w, h); }
    if (LY.cap && LY.cap.img) { const s = Math.max(w / LY.cap.w, h / LY.cap.h) * (e.iz || 1), dw = LY.cap.w * s, dh = LY.cap.h * s; c.drawImage(LY.cap.img, x + (w - dw) / 2 + (e.ox || 0) / 100 * w, y + (h - dh) / 2 + (e.oy || 0) / 100 * h, dw, dh); }
    else { c.fillStyle = "#6b7785"; c.font = `${3.5 * px}px sans-serif`; c.textAlign = "center"; c.fillText(LL("اضغط «التقاط الخريطة»", "Tap “Capture map”"), x + w / 2, y + h / 2); } c.restore(); if (e.bw > 0) { c.strokeStyle = e.bc; c.lineWidth = e.bw * px; c.strokeRect(x, y, w, h); } }
  else if (e.type === "title" || e.type === "text") { lyBox(c, e, px); lyText(c, e.text, x, y, w, h, e, px, e.type === "title" ? "mid" : "top"); }
  else if (e.type === "legend") { lyBox(c, e, px); lyLegend(c, e, px); }
  else if (e.type === "north") { lyBox(c, e, px); lyNorth(c, e, x, y, w, h, LY.cap ? LY.cap.bearing : 0); }
  else if (e.type === "scale") { lyBox(c, e, px); lyScale(c, e, px); }
  else if (e.type === "image") { lyBox(c, e, px); const im = LY.imgs[e.id]; if (im && im.complete) { const s = Math.min(w / im.naturalWidth, h / im.naturalHeight); c.drawImage(im, x + (w - im.naturalWidth * s) / 2, y + (h - im.naturalHeight * s) / 2, im.naturalWidth * s, im.naturalHeight * s); } else { c.fillStyle = "#98a2ad"; c.font = `${3 * px}px sans-serif`; c.textAlign = "center"; c.fillText(LL("شعار", "Logo"), x + w / 2, y + h / 2); } }
  else if (e.type === "rect") lyBox(c, e, px);
  else if (e.type === "line") { c.strokeStyle = e.bc; c.lineWidth = Math.max(.5, (e.bw || .5) * px); c.beginPath(); c.moveTo(x, y + h / 2); c.lineTo(x + w, y + h / 2); c.stroke(); }
  else if (e.type === "table") lyTable(c, e, px);
  c.restore();
}
function lyPaint(c, px, pv) {
  const [pw, ph] = lyPaper(), off = pv ? PM * px : 0; c.save(); if (pv) { c.fillStyle = "#7d8791"; c.fillRect(0, 0, c.canvas.width, c.canvas.height); c.shadowColor = "rgba(0,0,0,.45)"; c.shadowBlur = 14; } c.translate(off, off);
  c.fillStyle = LY.bg; c.fillRect(0, 0, pw * px, ph * px); c.shadowBlur = 0; c.save(); if (!pv) { c.beginPath(); c.rect(0, 0, pw * px, ph * px); c.clip(); }
  LY.els.slice().sort((a, b) => a.z - b.z).forEach(e => drawEl(c, e, px, pv)); c.restore();
  if (pv && LY.sel && !LY.previewOnly) { const e = lyEl(LY.sel); if (e) { c.strokeStyle = "#1e88ff"; c.lineWidth = 2; c.setLineDash([6, 4]); c.strokeRect(e.x * px, e.y * px, e.w * px, e.h * px); c.setLineDash([]); c.fillStyle = "#1e88ff"; c.fillRect(e.x * px + e.w * px - 9, e.y * px + e.h * px - 9, 18, 18); } }
  if (pv) { c.strokeStyle = "#ff3b8d"; c.lineWidth = 1; LY.guides.forEach(g => { c.beginPath(); if (g.v) { c.moveTo(g.v * px, 0); c.lineTo(g.v * px, ph * px); } else { c.moveTo(0, g.h * px); c.lineTo(pw * px, g.h * px); } c.stroke(); }); }
  c.restore();
}
function lyDraw() { const cv = $("#lyc"); if (!cv) return; const [pw, ph] = lyPaper(); cv.width = (pw + PM * 2) * PXM; cv.height = (ph + PM * 2) * PXM; lyPaint(cv.getContext("2d"), PXM, true); lySizeCanvas(); }
function lySizeCanvas() { const cv = $("#lyc"), w = $(".lyw"); if (!cv || !w) return; const [pw] = lyPaper(), fit = (w.clientWidth - 8) / ((pw + PM * 2)); cv.style.width = Math.round((pw + PM * 2) * fit * LY.zoom) + "px"; cv.style.height = "auto"; }
async function lyCapture() {
  const c = map.getCanvas(); await new Promise(r => { map.once("render", () => { try { const u = c.toDataURL("image/png"), im = new Image(); im.onload = () => { LY.cap = { img: im, w: c.width, h: c.height, mpp: 40075016.686 * Math.cos(map.getCenter().lat * Math.PI / 180) / (512 * Math.pow(2, map.getZoom())) * (c.clientWidth / c.width), bearing: map.getBearing() }; r(); }; im.src = u; } catch (er) { r(); } }); map.triggerRepaint(); });
  lyDraw(); lyProps(); toast(LL("تم التقاط الخريطة الحالية", "Current map captured"));
}
function lyAutoArrange() {
  const [pw, ph] = lyPaper(), m = 8, g = (t2) => LY.els.find(e => e.type === t2), tb = g("table"), z = (e, x, y, w, h) => { if (e) Object.assign(e, { x, y, w, h }); };
  const bottom = 30, th = g("title") ? 16 : 0, mapY = m + (th ? th + 4 : 0), tblH = tb ? Math.min(ph * .3, 70) : 0, mapH = ph - mapY - m - bottom - (tb ? tblH + 4 : 0);
  z(g("title"), m, m, pw - 2 * m, 16); z(g("map"), m, mapY, pw - 2 * m, mapH); const by = mapY + mapH + 4;
  z(g("legend"), m, by, Math.min(80, pw * .42), bottom - 4); z(g("north"), pw - m - 20 - 2, mapY + 3, 20, 24); z(g("scale"), pw - m - Math.min(75, pw * .42), by + 2, Math.min(75, pw * .42), bottom - 6);
  if (tb) z(tb, m, by + bottom, pw - 2 * m, tblH); const lg = g("legend"); if (lg) { const rows = (lg.items || []).filter(i => i.on).length, need = (lg.size * PT * 1.9 * Math.ceil(rows / (lg.cols || 1)) + lg.size * PT * 3.5 + 4); lg.h = Math.max(bottom - 4, need); }
  LY.els.forEach(e => { if (!["map", "title", "legend", "north", "scale", "table"].includes(e.type)) e.z = e.z; }); const mp = g("map"); if (mp) mp.z = 0; ["north", "scale", "legend"].forEach(k => { const e = g(k); if (e) e.z = 5; }); lySave(); lyDraw(); lyProps();
}
function lySnap(e, nx, ny) {
  const [pw, ph] = lyPaper(), th = 2.2; LY.guides = []; const xs = [0, pw / 2, pw, 8, pw - 8], ys = [0, ph / 2, ph, 8, ph - 8];
  LY.els.filter(o => o !== e).forEach(o => { xs.push(o.x, o.x + o.w / 2, o.x + o.w); ys.push(o.y, o.y + o.h / 2, o.y + o.h); });
  let dx = th, dy = th, rx = nx, ry = ny, gx = null, gy = null;
  [0, e.w / 2, e.w].forEach(o => xs.forEach(v => { const d = Math.abs(nx + o - v); if (d < dx) { dx = d; rx = v - o; gx = v; } }));
  [0, e.h / 2, e.h].forEach(o => ys.forEach(v => { const d = Math.abs(ny + o - v); if (d < dy) { dy = d; ry = v - o; gy = v; } }));
  if (gx != null) LY.guides.push({ v: gx }); if (gy != null) LY.guides.push({ h: gy }); return [rx, ry];
}
function lyPointer() {
  const cv = $("#lyc"), W = $(".lyw"); let mode = null, st = null;
  const pos = ev => { const r = cv.getBoundingClientRect(), k = cv.width / r.width; return [(ev.clientX - r.left) * k / PXM - PM, (ev.clientY - r.top) * k / PXM - PM]; };
  cv.addEventListener("pointerdown", ev => { if (LY.previewOnly) return; cv.setPointerCapture(ev.pointerId); const [x, y] = pos(ev), s = lyEl(LY.sel);
    if (s && x > s.x + s.w - 4 && x < s.x + s.w + 3 && y > s.y + s.h - 4 && y < s.y + s.h + 3) { mode = "rs"; st = { x, y, w: s.w, h: s.h }; return; }
    const hit = LY.els.slice().sort((a, b) => b.z - a.z).find(e => x >= e.x && x <= e.x + e.w && y >= e.y && y <= e.y + e.h);
    if (hit) { LY.sel = hit.id; mode = "mv"; st = { x, y, ex: hit.x, ey: hit.y, t: Date.now() }; lyDraw(); lyProps(); } else { LY.sel = null; mode = "pan"; st = { sx: ev.clientX, sy: ev.clientY, l: W.scrollLeft, tp: W.scrollTop }; lyDraw(); lyProps(); } });
  cv.addEventListener("pointermove", ev => { if (!mode) return; const e = lyEl(LY.sel);
    if (mode === "pan") { W.scrollLeft = st.l - (ev.clientX - st.sx); W.scrollTop = st.tp - (ev.clientY - st.sy); return; } if (!e) return; const [x, y] = pos(ev);
    if (mode === "mv") { const [nx, ny] = lySnap(e, st.ex + x - st.x, st.ey + y - st.y); e.x = nx; e.y = ny; } else { e.w = Math.max(4, st.w + x - st.x); e.h = Math.max(1, st.h + y - st.y); LY.guides = []; } lyDraw(); });
  const end = ev => { if (!mode) return; const e = lyEl(LY.sel); if (mode === "mv" && e && Date.now() - st.t < 250 && Math.abs(e.x - st.ex) < .5 && Math.abs(e.y - st.ey) < .5 && lyEl(LY.sel)) { if (LY.lastTap && Date.now() - LY.lastTap < 450) lyEditText(e); LY.lastTap = Date.now(); } mode = null; LY.guides = []; lySave(); lyDraw(); lyProps(); };
  cv.addEventListener("pointerup", end); cv.addEventListener("pointercancel", end);
}
function lyEditText(e) { if (!["title", "text", "legend"].includes(e.type)) return; const b = el(`<div><textarea class="in ta" id="lt_v">${esc6(e.text)}</textarea></div>`); modal(LL("تحرير النص", "Edit text"), b, () => { e.text = $("#lt_v", b).value; lySave(); lyDraw(); lyProps(); }); }
const LYCOL = ["#16202b", "#ffffff", "#1e88ff", "#e8590c", "#0ca678", "#862e9c", "#f59f00", "#e03131", "#868e96", "#1e5aa8"];
function lyProps() {
  const P = $(".lyp"); if (!P) return; const e = lyEl(LY.sel);
  if (!e) { const [pw, ph] = lyPaper(); P.innerHTML = `<div class="lyh">${LL("الورقة", "Paper")}: ${LY.paper} ${pw}×${ph} mm — ${LL("اضغط عنصراً لتحريره، اسحب لتحريكه، اسحب المربع الأزرق لتغيير الحجم، اضغط مرتين لتحرير النص", "Tap an element to edit, drag to move, drag the blue square to resize, double-tap to edit text")}</div>`; return; }
  const num = (k, lab, st) => `<label class="lyf">${lab}<input type="number" data-k="${k}" step="${st || 1}" value="${+(+e[k]).toFixed(1)}"></label>`, col = (k, lab) => `<label class="lyf">${lab}<input type="color" data-k="${k}" value="${/^#[0-9a-f]{6}$/i.test(e[k]) ? e[k] : "#000000"}"></label>`;
  const chk = (k, lab) => `<label class="lyf"><input type="checkbox" data-k="${k}" ${e[k] ? "checked" : ""}> ${lab}</label>`, sel = (k, lab, o) => `<label class="lyf">${lab}<select data-k="${k}">${o.map(([v, l]) => `<option value="${v}" ${String(e[k]) === String(v) ? "selected" : ""}>${l}</option>`).join("")}</select></label>`;
  const txt = ["title", "text", "legend", "scale", "table"].includes(e.type);
  let h = `<div class="lyh"><b>${LL(lyDef[e.type][2], lyDef[e.type][3])}</b><span class="lyb2"><button data-a="up">⬆</button><button data-a="dn">⬇</button><button data-a="dup">${LL("نسخ", "Dup")}</button><button data-a="del" class="er">${LL("حذف", "Del")}</button><button data-a="x">✕</button></span></div><div class="lyg">`;
  h += num("x", "X mm", .5) + num("y", "Y mm", .5) + num("w", LL("العرض", "W"), .5) + num("h", LL("الارتفاع", "H"), .5);
  if (e.type === "map") h += `<button class="btn sec2 lyfb" data-a="cap">${LL("التقاط الخريطة الحالية", "Capture current map")}</button><label class="lyf">${LL("تكبير داخل الإطار", "Zoom in frame")}<input type="range" data-k="iz" min="0.5" max="4" step="0.05" value="${e.iz}"></label><label class="lyf">${LL("إزاحة X", "Shift X")}<input type="range" data-k="ox" min="-100" max="100" value="${e.ox}"></label><label class="lyf">${LL("إزاحة Y", "Shift Y")}<input type="range" data-k="oy" min="-100" max="100" value="${e.oy}"></label>`;
  if (txt) h += sel("font", LL("الخط", "Font"), FONTS.map(f => [f, f])) + num("size", LL("الحجم pt", "Size pt")) + chk("bold", LL("عريض", "Bold")) + chk("italic", LL("مائل", "Italic")) + sel("al", LL("المحاذاة", "Align"), [["start", LL("بداية", "Start")], ["center", LL("وسط", "Center")], ["end", LL("نهاية", "End")]]) + col("color", LL("لون الخط", "Text colour"));
  if (e.type === "north") h += sel("style", LL("النمط", "Style"), [["n1", "1"], ["n2", "2"], ["n3", "3"], ["n4", "4"], ["n5", "5"], ["n6", "6"]]) + col("color", LL("اللون", "Colour")) + chk("rot", LL("يتبع دوران الخريطة", "Follow map rotation"));
  if (e.type === "scale") h += sel("style", LL("النمط", "Style"), [["alt", LL("متناوب", "Alternating")], ["line", LL("خط", "Line")], ["hollow", LL("مفرغ", "Hollow")], ["double", LL("مزدوج م/قدم", "Double m/ft")], ["text", LL("نسبة فقط", "Ratio only")]]) + chk("ratio", LL("إظهار 1:x", "Show 1:x"));
  if (e.type === "legend") h += sel("cols", LL("أعمدة", "Columns"), [[1, 1], [2, 2], [3, 3]]) + `<button class="btn sec2 lyfb" data-a="lgr">${LL("تحديث من الخريطة", "Refresh from map")}</button><button class="btn sec2 lyfb" data-a="lgf">${LL("ملاءمة الارتفاع", "Fit height")}</button><div class="lyfb" id="lg_it">${(e.items || []).map((it, i) => `<div class="lgr"><input type="checkbox" data-li="${i}" ${it.on ? "checked" : ""}><input class="in" data-lt="${i}" value="${esc6(it.label)}"><input type="color" data-lc="${i}" value="${it.color}"></div>`).join("")}</div>`;
  if (e.type === "table") h += sel("ds", LL("الطبقة", "Layer"), S.ds.filter(d => d.kind !== "reference").map(d => [d.id, d.label])) + num("rows", LL("عدد الصفوف", "Rows")) + `<div class="lyfb">${FIELDS.map(k => `<label class="lyf"><input type="checkbox" data-tc="${k}" ${(e.cols || []).includes(k) ? "checked" : ""}> ${t(k)}</label>`).join("")}</div>` + col("hdr", LL("لون الرأس", "Header colour"));
  if (e.type === "image") h += `<button class="btn sec2 lyfb" data-a="img">${LL("اختيار صورة/شعار", "Choose image/logo")}</button>`;
  if (e.type !== "line") h += chk("bgOn", LL("خلفية", "Background")) + col("bg", LL("لون الخلفية", "Fill"));
  h += num("bw", LL("سماكة الإطار mm", "Border mm"), .1) + col("bc", LL("لون الإطار", "Border colour")) + `<label class="lyf">${LL("الشفافية", "Opacity")}<input type="range" data-k="op" min="0.1" max="1" step="0.05" value="${e.op}"></label></div>`;
  P.innerHTML = h;
  $$("[data-k]", P).forEach(i => { const k = i.dataset.k, f = () => { let v = i.type === "checkbox" ? i.checked : i.type === "number" || i.type === "range" ? +i.value : i.value; if (k === "cols" && e.type === "legend") v = +v; if (k === "ds") { v = i.value; ensureDs(S.ds.find(d => d.id === v)).then(lyDraw); } e[k] = v; lySave(); lyDraw(); }; i.oninput = f; i.onchange = f; });
  $$("[data-li]", P).forEach(i => i.onchange = () => { e.items[+i.dataset.li].on = i.checked; lySave(); lyDraw(); }); $$("[data-lt]", P).forEach(i => i.oninput = () => { e.items[+i.dataset.lt].label = i.value; lySave(); lyDraw(); }); $$("[data-lc]", P).forEach(i => i.oninput = () => { e.items[+i.dataset.lc].color = i.value; lySave(); lyDraw(); });
  $$("[data-tc]", P).forEach(i => i.onchange = () => { const s = new Set(e.cols); i.checked ? s.add(i.dataset.tc) : s.delete(i.dataset.tc); e.cols = FIELDS.filter(k => s.has(k)); lySave(); lyDraw(); });
  $$("[data-a]", P).forEach(b => b.onclick = () => { const a = b.dataset.a;
    if (a === "x") { LY.sel = null; lyDraw(); lyProps(); } else if (a === "del") { LY.els = LY.els.filter(o => o !== e); LY.sel = null; lySave(); lyDraw(); lyProps(); } else if (a === "dup") { const n = lyAdd(e.type, JSON.parse(JSON.stringify(e))); n.x += 5; n.y += 5; n.id = "e" + Date.now().toString(36) + LY.n++; lySave(); lyDraw(); lyProps(); }
    else if (a === "up") { e.z = Math.max(...LY.els.map(o => o.z)) + 1; lySave(); lyDraw(); } else if (a === "dn") { e.z = Math.min(...LY.els.map(o => o.z)) - 1; lySave(); lyDraw(); } else if (a === "cap") lyCapture();
    else if (a === "lgr") { e.items = lyLegendItems(); lySave(); lyDraw(); lyProps(); } else if (a === "lgf") { const rows = e.items.filter(i => i.on).length; e.h = e.size * PT * 1.9 * Math.ceil(rows / (e.cols || 1)) + e.size * PT * 3.5 + 4; lySave(); lyDraw(); lyProps(); }
    else if (a === "img") { const f = document.createElement("input"); f.type = "file"; f.accept = "image/*"; f.onchange = () => { const r = new FileReader(); r.onload = () => { const im = new Image(); im.onload = () => { LY.imgs[e.id] = im; e.src = r.result; lySave(); lyDraw(); }; im.src = r.result; }; r.readAsDataURL(f.files[0]); }; f.click(); } });
}
async function lyRender(dpi, fmt) {
  const [pw, ph] = lyPaper(); let d = dpi; while (pw * d / 25.4 * ph * d / 25.4 > 60e6 && d > 72) d = Math.floor(d / 1.25);
  const px = d / 25.4, cv = document.createElement("canvas"); cv.width = Math.round(pw * px); cv.height = Math.round(ph * px); const c = cv.getContext("2d"); const sv = LY.sel; LY.sel = null; lyPaint(c, px, false); LY.sel = sv;
  const bl = await new Promise(r => cv.toBlob(r, fmt === "png" ? "image/png" : "image/jpeg", .93)); if (fmt === "pdf") return makePdf(new Uint8Array(await bl.arrayBuffer()), cv.width, cv.height, pw, ph); return bl;
}
function makePdf(jpg, wp, hp, wm, hm) {
  const W = wm * 72 / 25.4, H = hm * 72 / 25.4, enc = s => new TextEncoder().encode(s), parts = [], off = []; let len = 0; const add = u => { parts.push(u); len += u.length; }, obj = (n, body) => { off[n] = len; add(enc(`${n} 0 obj\n${body}\nendobj\n`)); };
  add(enc("%PDF-1.4\n")); obj(1, "<< /Type /Catalog /Pages 2 0 R >>"); obj(2, "<< /Type /Pages /Kids [3 0 R] /Count 1 >>"); obj(3, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W.toFixed(2)} ${H.toFixed(2)}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`);
  off[4] = len; add(enc(`4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${wp} /Height ${hp} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`)); add(jpg); add(enc("\nendstream\nendobj\n"));
  const cs = `q ${W.toFixed(2)} 0 0 ${H.toFixed(2)} 0 0 cm /Im0 Do Q`; obj(5, `<< /Length ${cs.length} >>\nstream\n${cs}\nendstream`); const xr = len; let x = "xref\n0 6\n0000000000 65535 f \n"; for (let i = 1; i <= 5; i++) x += String(off[i]).padStart(10, "0") + " 00000 n \n"; x += `trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xr}\n%%EOF`; add(enc(x)); return new Blob(parts, { type: "application/pdf" });
}
function lyExport() {
  const b = el(`<div><label class="f">${LL("الصيغة", "Format")}</label><select class="in" id="lx_f"><option value="pdf">PDF</option><option value="png">PNG</option><option value="jpg">JPG</option></select><label class="f">${LL("الدقة (DPI)", "Resolution (DPI)")}</label><select class="in" id="lx_d"><option>96</option><option>150</option><option selected>300</option><option>600</option></select>${fieldRow(LL("اسم الملف", "File name"), "lx_n", "layout")}
    <div class="btns"><button class="btn" id="lx_s">${I("save")}${LL("حفظ", "Save")}</button><button class="btn sec2" id="lx_o">${I("open")}${LL("فتح", "Open")}</button></div><div class="btns"><button class="btn sec2" id="lx_h">${I("share")}${LL("مشاركة", "Share")}</button><button class="btn sec2" id="lx_p">${LL("طباعة", "Print")}</button></div></div>`);
  const m = modal(LL("تصدير / طباعة", "Export / Print"), b, () => true, LL("إغلاق", "Close")), go = async mode => { const f = $("#lx_f", b).value, bl = await lyRender(+$("#lx_d", b).value, f), nm = ($("#lx_n", b).value || "layout") + "." + f;
    if (mode === "print") { if (window.Android) return saveBlob(bl, nm, "open"); const u = URL.createObjectURL(bl), w = window.open(u); w && w.addEventListener("load", () => w.print()); return; } toast(LL("جارٍ التصدير…", "Exporting…")); await saveBlob(bl, nm, mode); };
  $("#lx_s", b).onclick = () => go("save"); $("#lx_o", b).onclick = () => go("open"); $("#lx_h", b).onclick = () => go("share"); $("#lx_p", b).onclick = () => go("print");
}
function lyPaperUI() {
  const b = el(`<div><label class="f">${LL("حجم الورقة", "Paper size")}</label><select class="in" id="lp_s">${Object.keys(PAPERS).map(k => `<option ${k === LY.paper ? "selected" : ""}>${k}</option>`).join("")}</select>
    <label class="f">${LL("الاتجاه", "Orientation")}</label><select class="in" id="lp_o"><option value="p" ${LY.ori === "p" ? "selected" : ""}>${LL("عمودي", "Portrait")}</option><option value="l" ${LY.ori === "l" ? "selected" : ""}>${LL("أفقي", "Landscape")}</option></select>
    <label class="f">${LL("لون الورقة", "Paper colour")}</label><input type="color" id="lp_c" value="${LY.bg}"></div>`);
  modal(LL("إعدادات الورقة", "Paper settings"), b, () => { LY.paper = $("#lp_s", b).value; LY.ori = $("#lp_o", b).value; LY.bg = $("#lp_c", b).value; lySave(); lyDraw(); lyProps(); });
}
function openLayout() {
  closeSheet(); document.body.classList.remove("dr"); if ($("#lay")) $("#lay").remove(); LY.open = true; LY.previewOnly = false;
  LY.els.forEach(e => { if (e.type === "image" && e.src && !LY.imgs[e.id]) { const im = new Image(); im.onload = lyDraw; im.src = e.src; LY.imgs[e.id] = im; } });
  const root = el(`<div id="lay"><div class="lyt"><button class="ib" id="ly_x">${I("x")}</button><b>Layout</b><span class="lysp"></span><button class="btn sec2" id="ly_pv">${LL("معاينة", "Preview")}</button><button class="btn" id="ly_ex">${LL("تصدير / طباعة", "Export / Print")}</button></div>
    <div class="lyw"><canvas id="lyc"></canvas></div><div class="lyz"><button id="lz_i">+</button><button id="lz_o">−</button><button id="lz_f">⤢</button></div>
    <div class="lyp"></div><div class="lya">${["map", "title", "legend", "north", "scale", "text", "image", "table", "rect", "line"].map(k => `<button data-t="${k}">+ ${LL(lyDef[k][2], lyDef[k][3])}</button>`).join("")}<button data-t="_cap">${LL("التقاط الخريطة", "Capture map")}</button><button data-t="_auto">${LL("ترتيب تلقائي", "Auto arrange")}</button><button data-t="_paper">${LL("الورقة", "Paper")}</button><button data-t="_new">${LL("مسح الكل", "Clear all")}</button></div></div>`, document.body);
  $("#ly_x", root).onclick = () => { lySave(); root.remove(); LY.open = false; };
  $("#ly_ex", root).onclick = lyExport; $("#ly_pv", root).onclick = () => { LY.previewOnly = !LY.previewOnly; root.classList.toggle("pv", LY.previewOnly); $("#ly_pv", root).textContent = LY.previewOnly ? LL("تحرير", "Edit") : LL("معاينة", "Preview"); lyDraw(); };
  $("#lz_i", root).onclick = () => { LY.zoom = Math.min(4, LY.zoom * 1.3); lySizeCanvas(); }; $("#lz_o", root).onclick = () => { LY.zoom = Math.max(.4, LY.zoom / 1.3); lySizeCanvas(); }; $("#lz_f", root).onclick = () => { LY.zoom = 1; lySizeCanvas(); };
  $$(".lya button", root).forEach(b => b.onclick = async () => { const k = b.dataset.t;
    if (k === "_cap") return lyCapture(); if (k === "_auto") return lyAutoArrange(); if (k === "_paper") return lyPaperUI(); if (k === "_new") { if (confirm(t("confirm"))) { LY.els = []; LY.sel = null; lySave(); lyDraw(); lyProps(); } return; }
    if (k === "map" && !LY.cap) await lyCapture(); if (k === "table" && !S.ds.length) return toast(t("nol")); const e = lyAdd(k); if (e.type === "table") await ensureDs(S.ds.find(d => d.id === e.ds)); lySave(); lyDraw(); lyProps(); });
  lyPointer(); lyDraw(); lyProps(); if (!LY.els.length) { lyCapture().then(() => { lyAdd("map"); lyAdd("title"); lyAdd("north"); lyAdd("scale"); lyAdd("legend"); lyAutoArrange(); LY.sel = null; lyDraw(); lyProps(); }); }
}
const _back6 = window.__back; window.__back = () => { const l = $("#lay"); if (l) { l.remove(); LY.open = false; return true; } return _back6 ? _back6() : false; };
const _openTools6 = openTools;
openTools = async function () {
  await _openTools6(); const b = $("#sh-b"); if (SHEET !== "tools" || !b) return; const g = $(".grid", b); if (!g || $("#tl_lay", b)) return;
  const add = (id, ic, lab, fn) => { const x = el(`<button class="tile" id="${id}">${I(ic)}<span>${lab}</span></button>`, g); x.onclick = fn; };
  add("tl_lay", "report", "Layout", openLayout); add("tl_road", "route", LL("رسم طريق", "Draw road"), startRoad);
  const s = el(`<input class="in" id="tl_q" placeholder="${LL("ابحث عن أداة…", "Search tools…")}" style="margin-bottom:10px">`); g.parentNode.insertBefore(s, g);
  s.oninput = () => { const q = s.value.trim().toLowerCase(); $$(".tile", g).forEach(x => x.style.display = !q || x.textContent.toLowerCase().includes(q) ? "" : "none"); };
};
