"use strict";
/* ===== app6: Layout، تحرير الطرق، روابط جوجل، الفلاش، تحسينات ===== */
Object.assign(TX.ar, { dr_kind_road: "طريق" }); Object.assign(TX.en, { dr_kind_road: "Road" });
const LL = (ar, en) => (S.set.lang === "en" ? en : ar);
const esc6 = s => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/* ---------- لمس مركز الخريطة يفتح إضافة معلم ---------- */
window.addEventListener("DOMContentLoaded", () => {
  map.on("click", e => {
    if (window.__mode || ADD.mode || window.__lpT && Date.now() - window.__lpT < 900) return;
    const r = map.getCanvas().getBoundingClientRect(), cx = r.width / 2, cy = r.height / 2, rad = Math.max(24, (+S.set.cross_size || 34) / 2 + 6);
    if (Math.hypot(e.point.x - cx, e.point.y - cy) > rad) return;
    setTimeout(() => { if (!e._fc && !(window.__drT && Date.now() - window.__drT < 400)) { ADD.at = null; openAdd(); } }, 40);
  });
});

/* ---------- نافذة الإضافة: الاسم أولاً ثم النوع ---------- */
const _openAdd6 = openAdd;
openAdd = function () {
  _openAdd6(); const b = $("#sh-b"), a = b && $("#a_name", b), ty = b && $("#a_type", b); if (!a || !ty) return;
  const first = b.firstElementChild; [a, ty].forEach(i => { const l = i.previousElementSibling; b.insertBefore(l, first); b.insertBefore(i, first); });
};

/* ---------- الفلاش: الانتقال من الجدول إلى المعلم مع توجيه ---------- */
function flashAt(lon, lat) {
  const e = document.createElement("div"); e.className = "flash"; e.innerHTML = "<i></i><i></i><i></i>";
  const m = new maplibregl.Marker({ element: e }).setLngLat([lon, lat]).addTo(map); setTimeout(() => m.remove(), 6500);
}
function goFlash(r) {
  closeSheet(); map.flyTo({ center: [r.lon, r.lat], zoom: Math.max(map.getZoom(), 17), speed: 1.6 }); marker("z", r.lon, r.lat); flashAt(r.lon, r.lat);
  toast((r.name || r.type || "") + " — " + (+r.lat).toFixed(5) + ", " + (+r.lon).toFixed(5), [[LL("توجيه", "Navigate"), () => navStart({ lat: +r.lat, lon: +r.lon, name: r.name || "" })]]);
}
const _loadRows6 = loadRows;
loadRows = async function (b, reset, norefetch) {
  await _loadRows6(b, reset, norefetch);
  $$("tbody tr", b).forEach((tr, i) => { const r = TB.rows[i], z = $("[data-a=z]", tr); if (r && z) z.onclick = ev => { ev.stopPropagation(); goFlash(r); }; });
};

/* ---------- خيارات الجلب: تحديد الكل / إلغاء التحديد ---------- */
const _openFetch6 = openFetch;
openFetch = function () {
  _openFetch6(); const b = $("#sh-b"), box = b && $("#f_l", b); if (!box) return;
  $$("details", box).forEach(d => {
    const old = $("summary button", d); if (!old) return; const chips = () => $$(".chip", d);
    const mk = (txt, want) => { const x = old.cloneNode(false); x.textContent = txt; x.onclick = e => { e.preventDefault(); e.stopPropagation(); chips().forEach(c => { if (c.classList.contains("on") !== want) c.click(); }); }; return x; };
    const wrap = document.createElement("span"); wrap.style.cssText = "display:flex;gap:6px"; wrap.append(mk(LL("تحديد الكل", "Select all"), true), mk(LL("إلغاء", "None"), false)); old.replaceWith(wrap);
  });
  const all = el(`<div class="btns" style="margin:0 0 8px"><button class="btn sec2" id="fl_a">${LL("تحديد كل العوارض", "Select all features")}</button><button class="btn sec2" id="fl_n">${LL("إلغاء تحديد الكل", "Clear all")}</button></div>`);
  box.parentNode.insertBefore(all, box); const each = w => $$(".chip", box).forEach(c => { if (c.classList.contains("on") !== w) c.click(); });
  $("#fl_a", all).onclick = () => each(true); $("#fl_n", all).onclick = () => each(false);
};

/* ---------- رسم الطرق: أنواع وقص/دمج/فصل/حذف ---------- */
const ROADS = {
  motorway: ["طريق سريع", "Motorway", "#e8590c", 7, "solid"], primary: ["طريق رئيسي", "Primary road", "#f59f00", 6, "solid"], secondary: ["طريق ثانوي", "Secondary road", "#fab005", 5, "solid"],
  local: ["طريق فرعي", "Local road", "#868e96", 4, "solid"], track: ["طريق ترابي", "Dirt track", "#a0764a", 3, "dashed"], foot: ["ممر مشاة", "Footpath", "#d6336c", 3, "dotted"],
  bridge: ["جسر", "Bridge", "#495057", 6, "solid"], rail: ["سكة قطار", "Railway", "#343a40", 4, "dashed"], river: ["نهر/قناة", "River/canal", "#1c7ed6", 5, "solid"], pipe: ["أنبوب", "Pipeline", "#7048e8", 3, "dashed"]
};
const rtName = k => (S.set.lang === "en" ? ROADS[k][1] : ROADS[k][0]);
function applyRoad(d, k) { const r = ROADS[k]; d.rtype = k; d.color = r[2]; d.width = r[3]; d.dash = r[4]; if (d.kind !== "area") d.kind = d.kind === "route" || d.kind === "track" ? d.kind : "road"; }
function startRoad() {
  const b = el(`<div><div class="hint">${LL("اختر نوع الطريق ثم ارسمه على الخريطة (اضغط النقاط ثم إنهاء)", "Pick a road type, then tap the points and finish")}</div><div class="icg" id="rd_g"></div></div>`);
  Object.keys(ROADS).forEach(k => { const x = el(`<button class="ig" style="flex-direction:column;gap:2px;min-height:58px"><svg width="46" height="14"><line x1="3" y1="7" x2="43" y2="7" stroke="${ROADS[k][2]}" stroke-width="${ROADS[k][3]}" stroke-linecap="round" ${ROADS[k][4] === "dashed" ? 'stroke-dasharray="8 5"' : ROADS[k][4] === "dotted" ? 'stroke-dasharray="1 6"' : ""}/></svg><span class="igt">${esc6(rtName(k))}</span></button>`, $("#rd_g", b)); x.onclick = () => { document.querySelector(".modal") && document.querySelector(".modal").remove(); window.__roadNext = k; measureMode("line"); }; });
  modal(LL("رسم طريق", "Draw road"), b, () => true, LL("إغلاق", "Close"));
}
function nearestOn(pts, ll) {
  const k = 111320, cl = Math.cos(ll.lat * Math.PI / 180); let best = { d: 1e18, i: 0, t: 0, q: pts[0] };
  for (let i = 0; i < pts.length - 1; i++) { const a = pts[i], b = pts[i + 1], ax = a[1] * k * cl, ay = a[0] * k, bx = b[1] * k * cl, by = b[0] * k, px = ll.lng * k * cl, py = ll.lat * k, dx = bx - ax, dy = by - ay, L = dx * dx + dy * dy;
    let tt = L ? ((px - ax) * dx + (py - ay) * dy) / L : 0; tt = Math.max(0, Math.min(1, tt)); const d = Math.hypot(px - ax - tt * dx, py - ay - tt * dy); if (d < best.d) best = { d, i, t: tt, q: [a[0] + (b[0] - a[0]) * tt, a[1] + (b[1] - a[1]) * tt] }; }
  return best;
}
const nearestVertex = (pts, ll) => { let bi = 0, bd = 1e18; pts.forEach((p, i) => { const d = hav(p, [ll.lat, ll.lng]); if (d < bd) { bd = d; bi = i; } }); return bi; };
function drShare(d) { const co = d.pts.map(p => [p[1], p[0]]), g = d.kind === "area" ? { type: "Polygon", coordinates: [co.concat([co[0]])] } : { type: "LineString", coordinates: co }; return saveBlob(new Blob([JSON.stringify(fc(ft(g, { name: d.name || "", type: d.rtype ? rtName(d.rtype) : "" })))], { type: "application/geo+json" }), (d.name || "road").replace(/[^\w؀-ۿ]+/g, "_") + ".geojson", "share"); }
function drTap(id, ll) {
  const d = drOf(id); if (!d) return; DR.sel = id; drRender();
  const pt = map.project(ll), r = map.getCanvas().getBoundingClientRect(), x = r.left + pt.x, y = r.top + pt.y, line = d.kind !== "area";
  const nr = line ? nearestOn(d.pts, ll) : null, items = [];
  items.push(["share", LL("مشاركة", "Share"), () => drShare(d)]);
  if (line && d.pts.length >= 2) {
    items.push(["edit", LL("قص (إبقاء ما قبل/بعد النقطة)", "Cut (keep before/after)"), () => menuAt([["pin", LL("إبقاء ما قبل الموضع", "Keep before point"), () => { d.pts = d.pts.slice(0, nr.i + 1).concat([nr.q]); drSave(); drRender(); }], ["pin", LL("إبقاء ما بعد الموضع", "Keep after point"), () => { d.pts = [nr.q].concat(d.pts.slice(nr.i + 1)); drSave(); drRender(); }]], x, y)]);
    items.push(["plus", LL("دمج مع خط آخر", "Merge with another"), () => { const others = DR.items.filter(o => o !== d && o.kind !== "area" && o.pts.length > 1); if (!others.length) return toast(LL("لا يوجد خط آخر للدمج", "No other line to merge")); menuAt(others.map(o => ["pin", o.name || drKindName(o), () => { drMerge(d, o); }]), x, y); }]);
    items.push(["x", LL("انفصال عند هذه النقطة", "Split here"), () => { const a = d.pts.slice(0, nr.i + 1).concat([nr.q]), b = [nr.q].concat(d.pts.slice(nr.i + 1)); d.pts = a; DR.add(Object.assign({}, JSON.parse(JSON.stringify(d)), { id: undefined, pts: b, name: (d.name || "") + " 2" })); drSave(); drRender(); }]);
  }
  items.push(["trash", LL("حذف", "Delete"), async () => { if (!(await ask(t("confirm")))) return; DR.items = DR.items.filter(o => o !== d); DR.sel = null; drSave(); drRender(); }, "er"]);
  items.push(["trash", LL("حذف النقطة المحددة", "Delete selected point"), () => { if (d.pts.length <= 2) return toast(LL("لا يمكن الحذف: نقطتان فقط", "Only two points left")); d.pts.splice(nearestVertex(d.pts, ll), 1); drSave(); drRender(); }, "er"]);
  items.push(["edit", LL("تحرير النقاط", "Edit points"), () => drEdit(id)]); items.push(["table", LL("التفاصيل واللون والنوع", "Details, colour, type"), () => openDraw(id)]);
  menuAt(items, x, y);
}
function drMerge(a, b) {
  const A = a.pts, B = b.pts, d = (p, q) => hav(p, q), c = [[d(A[A.length - 1], B[0]), 0], [d(A[A.length - 1], B[B.length - 1]), 1], [d(A[0], B[0]), 2], [d(A[0], B[B.length - 1]), 3]].sort((x, y) => x[0] - y[0])[0][1];
  a.pts = c === 0 ? A.concat(B) : c === 1 ? A.concat(B.slice().reverse()) : c === 2 ? A.slice().reverse().concat(B) : B.concat(A);
  DR.items = DR.items.filter(o => o !== b); drSave(); drRender(); toast(LL("تم الدمج", "Merged"));
}
const _stopMode6 = stopMode;
stopMode = function (keep) {
  const m = MODE, rn = window.__roadNext;
  if (m && m.dk === "line" && rn && !keep) {
    const raw = m.getPts().slice(); window.__roadNext = null; window.__noDraw = true;
    try { _stopMode6(false); } finally { window.__noDraw = false; }
    if (raw.length >= 2) { const d = DR.add({ kind: "road", pts: raw, name: rtName(rn) }); applyRoad(d, rn); drSave(); drRender(); setTimeout(() => toast(t("dr_made"), [[LL("تحرير النقاط", "Edit points"), () => drEdit(d.id)], [LL("التفاصيل", "Details"), () => openDraw(d.id)]]), 30); }
    return;
  }
  _stopMode6(keep);
};
/* نوع الطريق داخل نافذة الرسم */
const _openDraw6 = openDraw;
openDraw = function (id) {
  _openDraw6(id); const d = drOf(id), b = $("#sh-b"); if (!d || !b || d.kind === "area" || $("#dw_rt", b)) return; const n = $("#dw_n", b); if (!n) return;
  const w = el(`<div><label class="f">${LL("نوع الطريق/الخط", "Road / line type")}</label><select class="in" id="dw_rt"><option value="">—</option>${Object.keys(ROADS).map(k => `<option value="${k}" ${d.rtype === k ? "selected" : ""}>${esc6(rtName(k))}</option>`).join("")}</select></div>`);
  n.parentNode.insertBefore(w, n.nextSibling); $("#dw_rt", w).onchange = e => { if (e.target.value) { applyRoad(d, e.target.value); if (!d.name) d.name = rtName(d.rtype); drSave(); drRender(); openDraw(id); } };
};
/* الخطوط المجلوبة: مشاركة/تحويل إلى رسم/حذف */
const _featClick6 = featClick;
featClick = function (e) {
  const f = e.features && e.features[0]; if (!f || !/LineString/.test(f.geometry.type) || (window.__mode || ADD.mode)) return _featClick6(e);
  e._fc = 1; const p = f.properties, r = map.getCanvas().getBoundingClientRect(), x = r.left + e.point.x, y = r.top + e.point.y;
  const co = f.geometry.type === "LineString" ? f.geometry.coordinates : f.geometry.coordinates.reduce((a, b) => a.concat(b), []);
  menuAt([["pin", p.name || p.type || LL("خط", "Line"), () => _featClick6(e)],
  ["share", LL("مشاركة", "Share"), async () => { try { const g = await api("/api/features/" + encodeURIComponent(p.id) + "/geojson"); saveBlob(new Blob([JSON.stringify(g)], { type: "application/geo+json" }), (p.name || "line") + ".geojson", "share"); } catch (er) { fail(er); } }],
  ["edit", LL("تحويل إلى رسم قابل للتحرير (قص/دمج/فصل)", "Convert to editable drawing"), () => { const d = DR.add({ kind: "road", pts: simp(co.map(c => [c[1], c[0]]), 1.5), name: p.name || p.type || "", color: p.color || "#868e96", width: 4 }); openDraw(d.id); }],
  ["trash", LL("حذف", "Delete"), async () => { if (!(await ask(t("confirm")))) return; await post("/api/features/delete", { ids: [p.id] }).catch(fail); await refreshDs(dsIds()); }, "er"]], x, y);
};

/* ---------- رابط جوجل / إحداثية: خيارات ---------- */
async function lnkConvert(c, fmt) {
  const nm = (c.name || "point").replace(/[^\w؀-ۿ]+/g, "_"), la = c.lat, lo = c.lon; let txt, mime = "text/plain", ext = fmt;
  if (fmt === "geojson") { txt = JSON.stringify(fc(ft({ type: "Point", coordinates: [lo, la] }, { name: c.name || "" }))); mime = "application/geo+json"; }
  else if (fmt === "kml") { txt = `<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Placemark><name>${esc6(c.name || "")}</name><Point><coordinates>${lo},${la},0</coordinates></Point></Placemark></kml>`; mime = "application/vnd.google-earth.kml+xml"; }
  else if (fmt === "gpx") { txt = `<?xml version="1.0"?><gpx version="1.1" creator="POI"><wpt lat="${la}" lon="${lo}"><name>${esc6(c.name || "")}</name></wpt></gpx>`; mime = "application/gpx+xml"; }
  else { txt = `name,lat,lon,UTM,MGRS,PlusCode\n"${(c.name || "").replace(/"/g, "'")}",${la},${lo},"${c.UTM || ""}","${c.MGRS || ""}","${c.PLUS || ""}"`; mime = "text/csv"; ext = "csv"; }
  return saveBlob(new Blob([txt], { type: mime }), nm + "." + ext, "share");
}
function linkCard(c) {
  openSheet("lnk", LL("نتيجة الرابط / الإحداثية", "Link / coordinate result"), b => {
    const rows = ["DD", "DMS", "DDM", "UTM", "MGRS", "PLUS", "GMAPS"].filter(k => c[k]);
    b.innerHTML = `<div class="card" style="padding:12px"><b>${esc6(c.name || c.detected || "")}</b><div class="hint" dir="ltr" style="text-align:start">${(+c.lat).toFixed(6)}, ${(+c.lon).toFixed(6)}</div></div>
    <div class="btns"><button class="btn" id="lk_v">${I("pin")}${LL("عرض على الخريطة", "Show on map")}</button><button class="btn sec2" id="lk_a">${I("plus")}${LL("إضافة كمعلم", "Add as landmark")}</button></div>
    <div class="btns"><button class="btn sec2" id="lk_f">${I("fetch")}${LL("تحويل إلى صيغة", "Convert to format")}</button><button class="btn sec2" id="lk_s">${I("share")}${LL("مشاركة", "Share")}</button></div>
    <div class="btns"><button class="btn sec2 er" id="lk_d">${I("trash")}${LL("حذف", "Remove")}</button><button class="btn sec2" id="lk_c">${LL("إلغاء", "Cancel")}</button></div>
    <div class="card" id="lk_r">${rows.map(k => `<div class="row"><div class="t"><b>${k}</b><small dir="ltr" style="text-align:start">${esc6(c[k])}</small></div><button class="ib sm" data-k="${k}">${I("copy")}</button></div>`).join("")}</div>`;
    $("#lk_v", b).onclick = () => { closeSheet(); gotoLL(c.lat, c.lon, 17); marker("sr", c.lon, c.lat); flashAt(c.lon, c.lat); };
    $("#lk_a", b).onclick = () => post("/api/landmarks", { lat: c.lat, lon: c.lon, name: c.name || "", type: "", Gategory: "" }).then(() => { refreshDs(dsIds()); toast(LL("تمت الإضافة", "Added")); }).catch(fail);
    $("#lk_f", b).onclick = () => menuAt(["geojson", "kml", "gpx", "csv"].map(f => ["share", f.toUpperCase(), () => lnkConvert(c, f)]), innerWidth / 2, innerHeight / 2);
    $("#lk_s", b).onclick = () => { const txt = (c.name ? c.name + "\n" : "") + (c.GMAPS || `${c.lat},${c.lon}`) + (c.PLUS ? "\n" + c.PLUS : ""); if (navigator.share) navigator.share({ text: txt }).catch(() => { }); else { navigator.clipboard && navigator.clipboard.writeText(txt); toast(LL("نُسخ", "Copied")); } };
    $("#lk_d", b).onclick = () => { if (MK.sr) { MK.sr.remove(); delete MK.sr; } if (POP) POP.remove(); closeSheet(); };
    $("#lk_c", b).onclick = () => closeSheet();
    $$("#lk_r [data-k]", b).forEach(x => x.onclick = () => { navigator.clipboard && navigator.clipboard.writeText(c[x.dataset.k]); toast(LL("نُسخ", "Copied")); });
  });
}
goText = async function (q, quiet) {
  try { const c = await api("/api/coords?text=" + encodeURIComponent(q) + refQ()); gotoLL(c.lat, c.lon, 17); marker("sr", c.lon, c.lat);
    if (!quiet) { linkCard(c); if (c.points && c.points.length > 1) setTimeout(() => toast(t("route"), [[t("route"), () => { RT.from = { lat: c.points[0][0], lon: c.points[0][1], label: "A" }; const z = c.points[c.points.length - 1]; RT.to = { lat: z[0], lon: z[1], label: "B" }; RT.line = null; RT.info = null; openRoute(); }]]), 400); }
    return true; } catch (e) { if (!quiet) toast("⚠ " + (e.message || t("notfound"))); return false; }
};

const _back6 = window.__back; window.__back = () => { if (document.getElementById("lyroot")) return lyBack(); return _back6 ? _back6() : false; };
const _openTools6 = openTools;
openTools = async function () {
  await _openTools6(); const b = $("#sh-b"); if (SHEET !== "tools" || !b) return; const g = $(".grid", b); if (!g || $("#tl_lay", b)) return;
  const add = (id, ic, lab, fn) => { const x = el(`<button class="tile" id="${id}">${I(ic)}<span>${lab}</span></button>`, g); x.onclick = fn; };
  add("tl_lay", "report", "Layout", openLayout); add("tl_road", "route", LL("رسم طريق", "Draw road"), startRoad);
  const s = el(`<input class="in" id="tl_q" placeholder="${LL("ابحث عن أداة…", "Search tools…")}" style="margin-bottom:10px">`); g.parentNode.insertBefore(s, g);
  s.oninput = () => { const q = s.value.trim().toLowerCase(); $$(".tile", g).forEach(x => x.style.display = !q || x.textContent.toLowerCase().includes(q) ? "" : "none"); };
};
