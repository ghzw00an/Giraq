"use strict";
/* ===== نصوص ===== */
Object.assign(TX.ar, {
  offline: "خرائط بلا إنترنت", clearov: "مسح الرسومات", b_copy: "نسخ", names: "إظهار أسماء المعالم", photos: "الصور", addph: "إضافة صور", takeph: "التقاط", noph: "لا توجد صور", goto: "ملاحة إلى هنا", copyc: "نسخ الإحداثيات", more: "المزيد",
  pastel: "لصق رابط أو Plus Code", pastet: "ألصق رابط خرائط Google أو Plus Code أو إحداثيات", spatial: "تحليل مكاني", backup: "نسخة احتياطية", restore: "استعادة نسخة", undo2: "تراجع", redo2: "إعادة", hist: "سجل التغييرات", nohist: "لا يوجد سجل",
  bigarea: "المنطقة كبيرة (~{n} كم²). سيُقسَّم الجلب تلقائياً إلى أجزاء وقد يستغرق وقتاً طويلاً. متابعة؟", fcancel: "إيقاف الجلب", allscreen: "كل الشاشة", lastplace: "حدود آخر مكان بحثت عنه",
  qr_shape: "شكل", qr_area: "المنطقة", qr_route: "المسار", qr_pick: "اختر", qr_cardsub: "امسح الباركود لعرضه في التطبيق", qr_cut: "تم تبسيط الشكل ليناسب الباركود", qr_added: "أُضيف من الباركود",
  sp_stats: "إحصائيات", sp_near: "الأقرب لمركز الخريطة", sp_rad: "ضمن نصف قطر", sp_buf: "حرم (Buffer)", sp_dup: "كشف المكرر", sp_in: "اختيار بالموقع (داخل مضلعات)", sp_fill: "تعبئة القضاء والمحافظة", sp_calc: "حاسبة الحقول",
  sp_by: "حسب", sp_k: "العدد", sp_r: "نصف القطر (م)", sp_d: "المسافة (م)", sp_poly: "طبقة المضلعات", sp_tpl: "القالب، مثل: {name} - {n}", sp_field: "الحقل الهدف", sp_rm: "حذف المكرر", sp_run: "تنفيذ", sp_res: "النتيجة", sp_ow: "استبدال الموجود",
  off_h: "نزّل جزءاً من الخريطة لتعمل بلا إنترنت (يُستعمل حدّ المنطقة الحالية أو الشاشة)", off_src: "الخريطة", off_z: "التكبير من/إلى", off_area: "المنطقة", off_screen: "الشاشة", off_box: "مربع المنطقة", off_est: "تقدير", off_go: "تنزيل", off_stop: "إيقاف", off_done: "اكتمل التنزيل", tiles_: "بلاطة", off_clear: "مسح الخرائط المخزّنة", off_size: "المخزّن",
  trk_pause: "إيقاف مؤقت", trk_resume: "متابعة", trk_wp: "علامة", trk_gpx: "تصدير GPX", trk_save: "حفظ كطبقة", trk_drop: "تجاهل", trk_dur: "المدة", trk_spd: "السرعة", trk_acc: "الدقة", trk_end: "انتهى التتبع",
  nav_to: "ملاحة", nav_arr: "وصلت!", nav_alert: "تنبيه عند الاقتراب (م)", nav_stop: "إنهاء", nav_dist: "المسافة", route_here: "مسار إلى هنا", route_from: "مسار من هنا", measure_here: "مسطرة من هنا", add_here: "إضافة معلم هنا", plus_c: "Plus Code", gmaps_c: "رابط Google Maps", copied: "تم النسخ",
  gpsbad: "تعذّر تحديد الموقع", resolved: "تم التعرّف", notfound: "لم يُتعرَّف على المدخل"
});
Object.assign(TX.en, {
  offline: "Offline maps", clearov: "Clear drawings", b_copy: "Copy", names: "Show landmark names", photos: "Photos", addph: "Add photos", takeph: "Capture", noph: "No photos", goto: "Navigate here", copyc: "Copy coordinates", more: "More",
  pastel: "Paste link or Plus Code", pastet: "Paste a Google Maps link, Plus Code or coordinates", spatial: "Spatial analysis", backup: "Backup", restore: "Restore backup", undo2: "Undo", redo2: "Redo", hist: "History", nohist: "No history",
  bigarea: "The area is large (~{n} km²). The fetch will be split automatically and may take a long time. Continue?", fcancel: "Stop fetch", allscreen: "Whole screen", lastplace: "Bounds of last searched place",
  qr_shape: "Shape", qr_area: "Area", qr_route: "Route", qr_pick: "Pick", qr_cardsub: "Scan the barcode to view it in the app", qr_cut: "Shape was simplified to fit the barcode", qr_added: "Added from barcode",
  sp_stats: "Statistics", sp_near: "Nearest to map centre", sp_rad: "Within radius", sp_buf: "Buffer", sp_dup: "Find duplicates", sp_in: "Select by location (inside polygons)", sp_fill: "Fill district & governorate", sp_calc: "Field calculator",
  sp_by: "By", sp_k: "Count", sp_r: "Radius (m)", sp_d: "Distance (m)", sp_poly: "Polygon layer", sp_tpl: "Template, e.g. {name} - {n}", sp_field: "Target field", sp_rm: "Delete duplicates", sp_run: "Run", sp_res: "Result", sp_ow: "Overwrite existing",
  off_h: "Download part of the map to use without internet (uses the current area box or screen)", off_src: "Map", off_z: "Zoom from/to", off_area: "Area", off_screen: "Screen", off_box: "Area box", off_est: "Estimate", off_go: "Download", off_stop: "Stop", off_done: "Download complete", tiles_: "tiles", off_clear: "Clear cached maps", off_size: "Stored",
  trk_pause: "Pause", trk_resume: "Resume", trk_wp: "Waypoint", trk_gpx: "Export GPX", trk_save: "Save as layer", trk_drop: "Discard", trk_dur: "Duration", trk_spd: "Speed", trk_acc: "Accuracy", trk_end: "Tracking finished",
  nav_to: "Navigate", nav_arr: "Arrived!", nav_alert: "Alert when closer than (m)", nav_stop: "End", nav_dist: "Distance", route_here: "Route to here", route_from: "Route from here", measure_here: "Ruler from here", add_here: "Add landmark here", plus_c: "Plus Code", gmaps_c: "Google Maps link", copied: "Copied",
  gpsbad: "Could not get location", resolved: "Recognised", notfound: "Input not recognised"
});
Object.assign(ICONS, {
  names: "M4 7V4h16v3M9 20h6M12 4v16", undo: "M9 14L4 9l5-5M4 9h10a6 6 0 010 12h-3", redo: "M15 14l5-5-5-5M20 9H10a6 6 0 000 12h3", anal: "M3 3v18h18M7 15l4-4 3 3 5-6",
  cloud: "M7 18a4 4 0 010-8 5 5 0 019.6-1A4.5 4.5 0 0117 18zM12 11v6m0 0l-2-2m2 2l2-2", copy: "M9 9h11v11H9zM5 15V4h11", nav: "M12 2l7 19-7-4-7 4z", pause: "M8 5v14M16 5v14", play: "M6 4l14 8-14 8z",
  hist: "M3 12a9 9 0 109-9v4M12 7v5l3 2", flag2: "M5 21V4h12l-2 4 2 4H5", link: "M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1", db: "M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6"
});
const copyText = async s => { try { await navigator.clipboard.writeText(s); } catch (e) { const a = document.createElement("textarea"); a.value = s; document.body.appendChild(a); a.select(); try { document.execCommand("copy"); } catch (e2) { } a.remove(); } toast(t("copied") + ": " + s); };
const gotoLL = (lat, lon, z) => { map.flyTo({ center: [lon, lat], zoom: z || Math.max(map.getZoom(), 16) }); marker("sr", lon, lat); };

/* ===== أسماء المعالم (تظهر/تختفي من الأدوات) ===== */
S.names = (() => { try { return localStorage.getItem("names") === "1"; } catch (e) { return false; } })();
function ensureGlyphs() {
  try { if (!map.getStyle().glyphs) map.setGlyphs("https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf"); } catch (e) { }
  try { const st = maplibregl.getRTLTextPluginStatus && maplibregl.getRTLTextPluginStatus(); if (st === "unavailable") fetch("/assets/vendor/rtl-text.js", { method: "HEAD" }).then(r => maplibregl.setRTLTextPlugin(r.ok ? ORIGIN + "/assets/vendor/rtl-text.js" : "https://unpkg.com/@mapbox/mapbox-gl-rtl-text@0.3.0/mapbox-gl-rtl-text.js", true)).catch(() => { }); } catch (e) { }
}
function addNameLayer(d) {
  const sid = "d-" + d.id, id = sid + "-t"; if (!map.getSource(sid)) return;
  if (!map.getLayer(id)) { ensureGlyphs(); map.addLayer({ id, type: "symbol", source: sid, layout: { "text-field": ["coalesce", ["get", "name"], ""], "text-font": ["Noto Sans Regular"], "text-size": 12.5, "text-offset": [0, 1.1], "text-anchor": "top", "text-optional": true, "text-max-width": 9, visibility: "none" }, paint: { "text-color": "#16202b", "text-halo-color": "#ffffff", "text-halo-width": 1.8 } }); }
  map.setLayoutProperty(id, "visibility", S.names && d.visible ? "visible" : "none");
}
const _ensureDs = ensureDs; ensureDs = async function (d, f) { await _ensureDs(d, f); try { addNameLayer(d); } catch (e) { } };
function setNames(v) { S.names = v; try { localStorage.setItem("names", v ? "1" : "0"); } catch (e) { } if (v) ensureGlyphs(); S.ds.forEach(d => { try { addNameLayer(d); } catch (e) { } }); }

/* ===== بطاقة المعلم عند الضغط عليه ===== */
const _featClick3 = featClick;
featClick = function (e) {
  if (window.__mode || ADD.mode) return; const f = e.features && e.features[0]; if (!f) return; const p = f.properties; e._fc = 1;
  const gt = (f.geometry && f.geometry.type) || "Point", kind = gt.includes("Polygon") ? "polygon" : gt.includes("Line") ? "line" : "point";
  const rows = ["type", "Gategory", "gathaa", "Nahia", "mohafadha"].filter(k => p[k]).map(k => `<div class="ps"><b>${t(k)}:</b> ${esc(p[k])}</div>`).join("");
  const B = (id, ic_, l, cls) => `<button class="pgb ${cls || ""}" id="${id}">${I(ic_)}<span>${l}</span></button>`;
  popupAt(e.lngLat, `<div class="pc"><b class="pt">${esc(p.name || "—")}</b>${rows}<div class="ps" id="pm" dir="ltr" style="text-align:center;unicode-bidi:isolate">${(+p.lat).toFixed(5)}, ${(+p.lon).toFixed(5)}</div>
    <div class="pg">${B("pe", "edit", t("d_edit"))}${B("pp", "cam", t("photos"))}${B("pq", "qr", t("qr"))}${B("pn", "nav", t("nav_to"))}${B("pr", "route", t("route"))}${B("pc", "copy", t("b_copy"))}${B("ps", "share", t("share"))}${B("pd", "trash", t("d_del"), "er")}</div></div>`, d => {
    $("#pe", d).onclick = () => editRow(p, () => refreshDs(dsIds()));
    $("#pd", d).onclick = async () => { if (confirm(t("confirm"))) { await post("/api/features/delete", { ids: [p.id] }).catch(fail); POP.remove(); refreshDs(dsIds()); } };
    $("#pp", d).onclick = () => openPhotos(p.id, p.name || "");
    $("#pq", d).onclick = () => { POP.remove(); openQR({ kind: "shape", fid: p.id, title: p.name || "" }); };
    $("#pn", d).onclick = () => { POP.remove(); navStart({ lat: +p.lat, lon: +p.lon, name: p.name || "" }); };
    $("#pr", d).onclick = () => { POP.remove(); RT.to = { lat: +p.lat, lon: +p.lon, label: p.name || "" }; RT.line = null; RT.info = null; openRoute(); };
    $("#pc", d).onclick = () => copyMenu(+p.lat, +p.lon, e.originalEvent ? e.originalEvent.clientX : innerWidth / 2, e.originalEvent ? e.originalEvent.clientY : innerHeight / 2);
    $("#ps", d).onclick = () => { const s = `${p.name || ""}\n${p.lat},${p.lon}\nhttps://www.google.com/maps?q=${p.lat},${p.lon}`; navigator.share ? navigator.share({ text: s }).catch(() => { }) : copyText(s); };
    if (kind !== "point") api("/api/features/" + encodeURIComponent(p.id).replace(/%2F/g, "/") + "/geojson").then(g => { const pts = g.geometry.coordinates.flat(g.geometry.type === "MultiPolygon" ? 2 : 1).map(c => [c[1], c[0]]);
      const x = kind === "line" ? `${t("total")}: ${fm(g.geometry.coordinates.reduce((s, l) => s + plen(l.map(c => [c[1], c[0]])), 0))}` : `${t("area_")}: ${fa(g.geometry.coordinates.reduce((s, pl) => s + parea(pl[0].map(c => [c[1], c[0]])), 0))}`; $("#pm", d).insertAdjacentHTML("beforebegin", `<div class="ps"><b>${x}</b></div>`); }).catch(() => { });
  });
};
async function copyMenu(lat, lon, x, y) {
  try { const c = await api(`/api/coords?text=${lat},${lon}`); const it = [["DD", c.DD], ["DMS", c.DMS], ["UTM", c.UTM], ["MGRS", c.MGRS], ["Plus Code", c.PLUS], ["Google Maps", c.GMAPS]];
    menuAt(it.map(([k, v]) => ["copy", `${k}: ${String(v).slice(0, 34)}`, () => copyText(v)]), x, y); } catch (e) { fail(e); }
}
/* ===== صور المعالم: بلا حدّ للحجم ===== */
function uploadPhotos(fid, files, bar) {
  return new Promise((ok, no) => { const fd = new FormData(); [...files].forEach(f => fd.append("file", f)); const x = new XMLHttpRequest(); x.open("POST", "/api/photos/" + fid);
    x.upload.onprogress = e => { if (e.lengthComputable && bar) bar.style.width = Math.round(e.loaded / e.total * 100) + "%"; };
    x.onload = () => x.status < 300 ? ok(JSON.parse(x.responseText)) : no(new Error(x.status)); x.onerror = () => no(new Error("net")); x.send(fd); });
}
function openPhotos(fid, name) {
  POP && POP.remove();
  openSheet("photos", t("photos") + (name ? " — " + name : ""), b => {
    b.innerHTML = `<div class="btns"><label class="btn">${I("plus")}${t("addph")}<input type="file" accept="image/*,video/*" multiple hidden id="ph_f"></label><label class="btn sec2">${I("cam")}${t("takeph")}<input type="file" accept="image/*" capture="environment" hidden id="ph_c"></label></div>
      <div class="pbar" id="ph_b" style="display:none"><i></i></div><div class="phg" id="ph_g"></div>`;
    const load = async () => { const g = $("#ph_g", b); const L = await api("/api/photos/" + fid).catch(() => []); g.innerHTML = L.length ? "" : `<div class="hint">${t("noph")}</div>`;
      L.forEach(x => { const im = el(`<button class="ph"><img loading="lazy" src="${x.url}"></button>`, g); im.onclick = () => lightbox(x, fid, load); }); };
    const up = async fs => { if (!fs.length) return; const bar = $("#ph_b", b); bar.style.display = ""; try { await uploadPhotos(fid, fs, $("i", bar)); toast(t("done")); await load(); } catch (e) { fail(e); } bar.style.display = "none"; };
    $("#ph_f", b).onchange = e => up(e.target.files); $("#ph_c", b).onchange = e => up(e.target.files); load();
  }, { full: true });
}
function lightbox(x, fid, done) {
  const m = el(`<div class="lbx"><img src="${x.url}"><div class="lbb"><button class="ib" id="lb_s">${I("share")}</button><button class="ib er" id="lb_d">${I("trash")}</button><button class="ib" id="lb_x">${I("x")}</button></div></div>`, document.body);
  $("#lb_x", m).onclick = () => m.remove(); m.onclick = e => { if (e.target === m) m.remove(); };
  $("#lb_s", m).onclick = async () => saveBlob(await fileBlob(x.url), x.ref.split("/").pop(), "share");
  $("#lb_d", m).onclick = async () => { if (!confirm(t("confirm"))) return; await del("/api/photos/" + fid + "?ref=" + encodeURIComponent(x.ref)).catch(fail); m.remove(); done(); };
}

/* ===== الباركود الهندسي (نقطة/خط/مساحة/مسار/منطقة) + بطاقة متناسقة ===== */
const encV = v => { v = v < 0 ? ~(v << 1) : (v << 1); let o = ""; while (v >= 0x20) { o += String.fromCharCode((0x20 | (v & 0x1f)) + 63); v >>= 5; } return o + String.fromCharCode(v + 63); };
const polyEnc = pts => { let a0 = 0, o0 = 0, s = ""; for (const [la, lo] of pts) { const a = Math.round(la * 1e5), o = Math.round(lo * 1e5); s += encV(a - a0) + encV(o - o0); a0 = a; o0 = o; } return s; };
function polyDec(s) { const out = []; let i = 0, a = 0, o = 0; const rd = () => { let r = 0, sh = 0, c; do { c = s.charCodeAt(i++) - 63; r |= (c & 0x1f) << sh; sh += 5; } while (c >= 0x20 && i <= s.length); return (r & 1) ? ~(r >> 1) : (r >> 1); }; while (i < s.length) { a += rd(); o += rd(); out.push([a / 1e5, o / 1e5]); } return out; }
function rdp(p, eps) { if (p.length < 3) return p; const keep = new Uint8Array(p.length); keep[0] = keep[p.length - 1] = 1; const st = [[0, p.length - 1]];
  while (st.length) { const [a, b] = st.pop(); let md = 0, mi = -1; for (let i = a + 1; i < b; i++) { const d = pd(p[i], p[a], p[b]); if (d > md) { md = d; mi = i; } } if (md > eps && mi > 0) { keep[mi] = 1; st.push([a, mi], [mi, b]); } } return p.filter((_, i) => keep[i]); }
function pd(p, a, b) { const dx = b[1] - a[1], dy = b[0] - a[0], l = dx * dx + dy * dy; if (!l) return Math.hypot(p[0] - a[0], p[1] - a[1]); let t_ = ((p[1] - a[1]) * dx + (p[0] - a[0]) * dy) / l; t_ = Math.max(0, Math.min(1, t_)); return Math.hypot(p[1] - (a[1] + t_ * dx), p[0] - (a[0] + t_ * dy)); }
const QR_MAX = 2250;
/** سجلات الشكل → نص GEO1 يناسب سعة الباركود (يبسّط تلقائياً). */
function geoPack(recs) {
  const clean = s => String(s || "").replace(/[\t\n\r]+/g, " ");
  let cut = false;
  for (const eps of [0, 2e-6, 5e-6, 1e-5, 3e-5, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2]) {
    const text = "GEO1\n" + recs.map(r => { let pts = r.pts; if (eps && r.k !== "P") pts = rdp(pts, eps); if (r.k === "G" && pts.length < 3) pts = r.pts.slice(0, 3); return [r.k, clean(r.name), clean(r.type), clean(r.sector), polyEnc(pts)].join("\t"); }).join("\n");
    if (text.length <= QR_MAX) return { text, cut: eps > 0 || cut };
    cut = true;
  }
  throw new Error(t("qr_big"));
}
const ringOf = g => { const c = g.coordinates; if (g.type === "Polygon") return c[0]; if (g.type === "MultiPolygon") return c.map(p => p[0]).sort((a, b) => b.length - a.length)[0]; if (g.type === "MultiLineString") return c.slice().sort((a, b) => b.length - a.length)[0]; return c; };
function recFromGeojson(g) {
  const p = g.properties || {}, geo = g.geometry; const k = geo.type === "Point" ? "P" : geo.type.includes("Polygon") ? "G" : "L";
  const pts = (k === "P" ? [geo.coordinates] : ringOf(geo)).map(c => [c[1], c[0]]); return { k, name: p.name, type: p.type, sector: p.Gategory, pts };
}
function qrCard(text, title, sub) {
  const q = qrcode(0, "L"); q.addData(text); try { q.make(); } catch (e) { throw new Error(t("qr_big")); }
  const n = q.getModuleCount(), quiet = 4, sc = Math.max(2, Math.floor(480 / (n + quiet * 2))), side = sc * (n + quiet * 2);
  const W = 600, H = side + 100, c = document.createElement("canvas"); c.width = W; c.height = H; const x = c.getContext("2d");
  x.fillStyle = "#fff"; x.fillRect(0, 0, W, H); x.fillStyle = "#0b1d2e"; x.fillRect(0, 0, W, 10);
  const ox = Math.round((W - side) / 2), oy = 40; x.fillStyle = "#fff"; x.fillRect(ox, oy, side, side); x.fillStyle = "#000";
  for (let r = 0; r < n; r++) for (let k = 0; k < n; k++) if (q.isDark(r, k)) x.fillRect(ox + (k + quiet) * sc, oy + (r + quiet) * sc, sc, sc);
  x.textAlign = "center"; x.textBaseline = "alphabetic"; x.fillStyle = "#16202b";
  const fit = (s, px, wt, mw) => { let f = px; do { x.font = `${wt} ${f}px sans-serif`; f -= 1; } while (x.measureText(s).width > mw && f > 12); };
  x.fillStyle = "#9aa7b4"; x.font = "400 16px sans-serif"; x.fillText(t("qr_cardsub"), W / 2, H - 28);
  return c.toDataURL("image/png");
}
/** يبني النص من نوع المصدر المختار. */
async function qrBuild(k, b) {
  const g = id => $("#" + id, b);
  if (k === "text" || k === "url") return { text: g("q_v").value, title: k === "url" ? g("q_v").value.replace(/^https?:\/\//, "") : g("q_v").value.slice(0, 40), sub: "" };
  if (k === "loc" || k === "map") { const la = (+g("q_la").value).toFixed(6), lo = (+g("q_lo").value).toFixed(6); const nm = g("q_nm").value.trim();
    return { text: k === "loc" ? `geo:${la},${lo}` + (nm ? `?q=${la},${lo}(${encodeURIComponent(nm)})` : "") : `https://www.google.com/maps?q=${la},${lo}`, title: nm || (k === "loc" ? "Location" : "Google Maps"), sub: `${la}, ${lo}` }; }
  if (k === "lm") { const id = g("q_d").value; let rows; if (g("q_sl") && g("q_sl").classList.contains("on") && id === TB.id) rows = TB.rows.filter(r => TB.sel.has(r.id)); else rows = (await api(`/api/datasets/${id}/rows?limit=80`)).rows;
    const pack = rs => "POI1:" + JSON.stringify(rs.map(r => [r.name || "", r.type || "", r.Gategory || "", +(+r.lat).toFixed(6), +(+r.lon).toFixed(6)])); const tot = rows.length; while (rows.length && pack(rows).length > QR_MAX) rows = rows.slice(0, -1); if (!rows.length) throw new Error(t("qr_big"));
    const d = S.ds.find(z => z.id === id); return { text: pack(rows), title: d ? d.label : "POI", sub: rows.length + (rows.length < tot ? " / " + tot : "") + " " + t("rows") }; }
  if (k === "shape") { const fid = g("q_f").value; if (!fid) throw new Error(t("qr_pick")); const gj = await api("/api/features/" + fid.replace(/%2F/g, "/") + "/geojson"); const rec = recFromGeojson(gj); const pk = geoPack([rec]); return { text: pk.text, title: rec.name || "—", sub: (rec.k === "P" ? "Point" : rec.k === "L" ? "Line" : "Polygon") + (pk.cut ? " · " + t("qr_cut") : "") }; }
  if (k === "area") { const pk = geoPack([{ k: "G", name: t("qr_area"), type: "", sector: "", pts: areaPoly().map(c => [c[1], c[0]]) }]); return { text: pk.text, title: t("qr_area"), sub: fa(A.shape === "circle" ? Math.PI * A.r * A.r : A.w * A.h) }; }
  if (k === "route") { if (!RT.line) throw new Error(t("qr_pick")); const pk = geoPack([{ k: "L", name: t("qr_route"), type: "", sector: "", pts: RT.line.map(c => [c[1], c[0]]) }]); return { text: pk.text, title: t("qr_route"), sub: RT.info ? fm(RT.info.d) + (pk.cut ? " · " + t("qr_cut") : "") : "" }; }
  const fl = g("q_fl").files[0]; if (!fl) throw new Error(t("pick")); if (fl.type.startsWith("image/")) return { text: await downscale(fl), title: fl.name, sub: "" };
  const tx = "data:" + (fl.type || "application/octet-stream") + ";name=" + encodeURIComponent(fl.name) + ";base64," + await blobB64(fl); if (tx.length > QR_MAX) throw new Error(t("qr_big")); return { text: tx, title: fl.name, sub: Math.round(fl.size) + " B" };
}
const QRK2 = [["text", "qr_text"], ["url", "qr_url"], ["loc", "qr_loc"], ["map", "qr_map"], ["lm", "qr_lm"], ["shape", "qr_shape"], ["area", "qr_area"], ["route", "qr_route"], ["file", "qr_file"]];
qrMakeUI = function (b) {
  const k = QR.kind, c = map.getCenter(); const real = S.ds.filter(d => d.kind !== "reference"), def = QR.ds || (real.find(d => d.count > 0) || {}).id;
  b.innerHTML = `<div class="chips qk" id="q_k"></div><div class="qform" id="q_form"></div><button class="btn blk" id="q_go">${I("qr")}${t("qr_gen")}</button><div id="q_o" class="qout"></div>`;
  QRK2.forEach(([v, l]) => { const x = el(`<span class="chip ${k === v ? "on" : ""}">${t(l)}</span>`, $("#q_k", b)); x.onclick = () => { QR.kind = v; qrMakeUI(b); }; });
  const f = $("#q_form", b), dsOpts = real.map(d => `<option value="${d.id}" ${d.id === def ? "selected" : ""}>${esc(d.label)} (${d.count})</option>`).join("");
  if (k === "text") f.innerHTML = `<textarea class="in ta" id="q_v" placeholder="${t("qr_text")}"></textarea>`;
  else if (k === "url") f.innerHTML = fieldRow(t("qr_url"), "q_v", "https://");
  else if (k === "loc" || k === "map") { f.innerHTML = fieldRow(t("gname"), "q_nm", QR.title || "") + `<div class="two">${fieldRow("lat", "q_la", (QR.lat != null ? QR.lat : c.lat).toFixed(6))}${fieldRow("lon", "q_lo", (QR.lon != null ? QR.lon : c.lng).toFixed(6))}</div><button class="btn sec2 blk" id="q_c">${I("zoom")}${t("qr_cur")}</button>`; $("#q_c", b).onclick = () => { const m = map.getCenter(); $("#q_la", b).value = m.lat.toFixed(6); $("#q_lo", b).value = m.lng.toFixed(6); }; }
  else if (k === "lm") f.innerHTML = `<label class="f">${t("gname")}</label><select class="in" id="q_d">${dsOpts}</select>${TB.sel.size ? `<div class="chips" style="margin-top:8px"><span class="chip on" id="q_sl">${t("qr_pickrows")} (${TB.sel.size})</span></div>` : ""}`;
  else if (k === "shape") {
    f.innerHTML = `<label class="f">${t("gname")}</label><select class="in" id="q_d">${dsOpts}</select><label class="f">${t("qr_pick")}</label><select class="in" id="q_f"></select>`;
    const fill = async () => { const id = $("#q_d", b).value, sel = $("#q_f", b); sel.innerHTML = ""; if (!id) return; const r = (await api(`/api/datasets/${id}/rows?limit=300`)).rows; r.forEach(x => sel.appendChild(el(`<option value="${esc(x.id)}">${esc(x.name || "—")}${x.type ? " · " + esc(x.type) : ""}</option>`))); if (QR.fid && r.find(x => x.id === QR.fid)) sel.value = QR.fid; };
    $("#q_d", b).onchange = fill;
    if (QR.fid) { const o = QR.fid; QR.fid = null; fillFor(b, o); } else fill();
  }
  else if (k === "area" || k === "route") f.innerHTML = `<div class="hint">${k === "area" ? t("qr_area") : t("qr_route")}${k === "route" && !RT.line ? " — " + t("qr_pick") : ""}</div>`;
  else f.innerHTML = `<input class="in" type="file" id="q_fl"><div class="hint">≤ 2.5 KB</div>`;
  $("#q_go", b).onclick = async () => { const o = $("#q_o", b); o.innerHTML = ""; try { const r = await qrBuild(k, b); await qrLib(); const url = qrCard(r.text, r.title, r.sub); QR.out = url;
    o.innerHTML = `<img id="qrimg" src="${url}"><div class="qbtns"><button class="btn" id="q_sv">${I("fetch")}${t("save2")}</button><button class="btn sec2" id="q_op">${I("open")}${t("open")}</button><button class="btn sec2" id="q_sh">${I("share")}${t("share")}</button></div>`;
    const sv = async m => saveBlob(await fileBlob(url), "qr-" + Date.now() + ".png", m); $("#q_sv", o).onclick = () => sv(); $("#q_op", o).onclick = () => sv("open"); $("#q_sh", o).onclick = () => sv("share");
  } catch (e) { o.innerHTML = `<div class="hint" style="color:var(--er)">⚠ ${esc(e.message)}</div>`; } };
};
async function fillFor(b, fid) {                      // يحدّد المجموعة التي فيها المعلم ثم يختاره
  for (const d of S.ds.filter(z => z.kind !== "reference")) { const r = (await api(`/api/datasets/${d.id}/rows?limit=300`)).rows; if (r.find(x => x.id === fid)) { $("#q_d", b).value = d.id; const sel = $("#q_f", b); sel.innerHTML = ""; r.forEach(x => sel.appendChild(el(`<option value="${esc(x.id)}">${esc(x.name || "—")}</option>`))); sel.value = fid; return; } }
}
const _qrResult = qrResult;
qrResult = function (text, box) {
  if (!text.startsWith("GEO1\n")) return _qrResult(text, box);
  if (!box) { openQR({ kind: "text" }); box = $("#q_body"); $$("#q_tab button").forEach(x => x.classList.toggle("on", x.dataset.v === "scan")); qrScanUI(box); box = $("#s_r"); }
  const recs = text.split("\n").slice(1).map(l => l.split("\t")).map(a => ({ k: a[0], name: a[1], type: a[2], sector: a[3], pts: polyDec(a[4] || "") })).filter(r => r.pts.length);
  const gj = { type: "FeatureCollection", features: recs.map(r => ft(r.k === "P" ? { type: "Point", coordinates: [r.pts[0][1], r.pts[0][0]] } : r.k === "L" ? { type: "LineString", coordinates: r.pts.map(c => [c[1], c[0]]) } : { type: "Polygon", coordinates: [r.pts.map(c => [c[1], c[0]]).concat([[r.pts[0][1], r.pts[0][0]]])] }, { name: r.name })) };
  box.innerHTML = `<div class="card" style="padding:12px;margin-top:10px"><div class="hint" style="margin:0 0 6px">${t("qr_res")}</div>${recs.map(r => `<div class="row"><div class="t"><b>${esc(r.name || "—")}</b><small>${r.k === "P" ? "Point" : r.k === "L" ? "Line · " + fm(plen(r.pts)) : "Polygon · " + fa(parea(r.pts))} · ${r.pts.length} ${t("pts_")}</small></div></div>`).join("")}<div class="qbtns"><button class="btn" id="g_m">${I("eye")}${t("qr_show")}</button><button class="btn sec2" id="g_a">${I("plus")}${t("qr_addpts")}</button></div></div>`;
  $("#g_m", box).onclick = () => { closeSheet(); cvMap(gj); };
  $("#g_a", box).onclick = async () => { try { for (const r of recs) await post("/api/digitize", { kind: r.k === "P" ? "point" : r.k === "L" ? "line" : "polygon", points: r.pts, name: r.name, type: r.type, Gategory: r.sector, layer: t("qr_added") }); await refreshDs(dsIds()); toast(t("done")); } catch (e) { fail(e); } };
};
/* زر «باركود المسار» في نافذة المسار */
const _showRouteInfo = showRouteInfo;
showRouteInfo = function (b) { _showRouteInfo(b); const r = $("#rt_cl", b); if (r) { const x = el(`<button class="btn sec2" id="rt_qr">${I("qr")}${t("qr")}</button>`); r.parentNode.insertBefore(x, r); x.onclick = () => openQR({ kind: "route" }); } };

/* ===== التحليل المكاني ===== */
const SP = { op: "stats", layer: "" };
function openSpatial() {
  const real = S.ds.filter(d => d.kind !== "reference"); if (!real.length) return toast(t("nol")); if (!real.find(d => d.id === SP.layer)) SP.layer = real[0].id;
  openSheet("spatial", t("spatial"), b => {
    const ops = [["stats", "sp_stats"], ["near", "sp_near"], ["rad", "sp_rad"], ["buf", "sp_buf"], ["dup", "sp_dup"], ["in", "sp_in"], ["fill", "sp_fill"], ["calc", "sp_calc"]];
    b.innerHTML = `<label class="f">${t("gname")}</label><select class="in" id="sp_l">${real.map(d => `<option value="${d.id}" ${d.id === SP.layer ? "selected" : ""}>${esc(d.label)} (${d.count})</option>`).join("")}</select><div class="chips" id="sp_o" style="margin:10px 0"></div><div id="sp_p"></div><button class="btn blk" id="sp_go">${I("tool")}${t("sp_run")}</button><div id="sp_r"></div>`;
    $("#sp_l", b).onchange = e => SP.layer = e.target.value;
    ops.forEach(([k, l]) => { const c = el(`<span class="chip ${SP.op === k ? "on" : ""}">${t(l)}</span>`, $("#sp_o", b)); c.onclick = () => { SP.op = k; openSpatial(); }; });
    const P = $("#sp_p", b), sel = (id, o) => `<select class="in" id="${id}">${o}</select>`;
    P.innerHTML = { stats: `<label class="f">${t("sp_by")}</label>` + sel("sp_by", ["qadaa", "sector", "type", "mohafadha", "nahia"].map(x => `<option>${x}</option>`).join("")),
      near: fieldRow(t("sp_k"), "sp_k", 5, 'type="number"'), rad: fieldRow(t("sp_r"), "sp_r", 500, 'type="number"'), buf: fieldRow(t("sp_r"), "sp_r", 200, 'type="number"'),
      dup: fieldRow(t("sp_d"), "sp_d", 30, 'type="number"') + `<div class="chips" style="margin-top:8px"><span class="chip" id="sp_rm">${t("sp_rm")}</span></div>`,
      in: `<label class="f">${t("sp_poly")}</label>` + sel("sp_pl", real.filter(d => d.geom === 5).map(d => `<option value="${d.id}">${esc(d.label)}</option>`).join("")),
      fill: `<div class="chips"><span class="chip" id="sp_ow">${t("sp_ow")}</span></div>`,
      calc: `<label class="f">${t("sp_field")}</label>` + sel("sp_fd", ["name", "type", "Gategory", "gathaa", "Nahia", "mohafadha"].map(x => `<option>${x}</option>`).join("")) + fieldRow(t("sp_tpl"), "sp_t", "{name} - {n}") + (TB.sel.size ? `<div class="hint">${TB.sel.size} ${t("d_sel")}</div>` : "") }[SP.op];
    const tg = id => { const e = $("#" + id, b); if (e) e.onclick = () => e.classList.toggle("on"); }; tg("sp_rm"); tg("sp_ow");
    const out = $("#sp_r", b), list = r => { out.innerHTML = `<div class="sec">${t("sp_res")}: ${r.length}</div><div class="card">${r.map((x, i) => `<button class="row" data-i="${i}" style="width:100%;border:0;background:none;text-align:start;cursor:pointer"><div class="t"><b>${esc(x.name || "—")}</b><small>${esc(x.type || "")}${x.dist != null ? " · " + fm(x.dist) : ""}</small></div></button>`).join("")}</div>`; $$("[data-i]", out).forEach(z => z.onclick = () => { const x = r[+z.dataset.i]; closeSheet(); gotoLL(x.lat, x.lon); }); };
    $("#sp_go", b).onclick = async () => {
      const c = map.getCenter(), L = SP.layer; out.innerHTML = `<div class="hint">${t("wait")}</div>`;
      try {
        if (SP.op === "stats") { const r = await post("/api/analysis", { op: "stats", layer: L, by: $("#sp_by", b).value }); const mx = Math.max(1, ...r.rows.map(x => x[1]));
          out.innerHTML = `<div class="sec">${t("sp_res")}: ${r.total}</div><div class="card">${r.rows.map(([k, v]) => `<div class="row"><div class="t"><b>${esc(k)}</b><div class="pbar" style="display:block"><i style="width:${Math.round(v / mx * 100)}%"></i></div></div><b>${v}</b></div>`).join("")}</div>`; }
        else if (SP.op === "near") list(await post("/api/analysis", { op: "nearest", lat: c.lat, lon: c.lng, k: +$("#sp_k", b).value, layers: [L] }));
        else if (SP.op === "rad") list(await post("/api/analysis", { op: "radius", lat: c.lat, lon: c.lng, r: +$("#sp_r", b).value, layers: [L] }));
        else if (SP.op === "buf") { const r = await post("/api/analysis", { op: "buffer", layer: L, r: +$("#sp_r", b).value }); await refreshDs(dsIds()); out.innerHTML = `<div class="hint">${t("done")}: ${r.n}</div>`; }
        else if (SP.op === "dup") { const rm = $("#sp_rm", b).classList.contains("on"); const r = await post("/api/analysis", { op: "duplicates", layer: L, dist: +$("#sp_d", b).value, remove: rm }); if (rm) { await refreshDs(dsIds()); out.innerHTML = `<div class="hint">${t("done")}: ${r.removed}</div>`; } else out.innerHTML = `<div class="sec">${t("sp_res")}: ${r.n}</div>` + r.groups.map(g => `<div class="card" style="margin-bottom:8px">${g.map(x => `<div class="row"><div class="t"><b>${esc(x.name || "—")}</b><small>${x.lat.toFixed(5)}, ${x.lon.toFixed(5)}</small></div></div>`).join("")}</div>`).join(""); }
        else if (SP.op === "in") { const pl = $("#sp_pl", b).value; if (!pl) throw new Error(t("sp_poly")); const r = await post("/api/analysis", { op: "inside", layer: L, polygons: pl, save: true, name: t("sp_in") }); await refreshDs(dsIds()); out.innerHTML = `<div class="hint">${t("done")}: ${r.n}</div>`; }
        else if (SP.op === "fill") { const r = await post("/api/analysis", { op: "fill_admin", layer: L, overwrite: $("#sp_ow", b).classList.contains("on") }); await refreshDs([L]); out.innerHTML = `<div class="hint">${t("done")}: ${r.n}</div>`; }
        else if (SP.op === "calc") { const r = await post("/api/analysis", { op: "calc", layer: L, field: $("#sp_fd", b).value, template: $("#sp_t", b).value, ids: TB.id === L ? [...TB.sel] : [] }); await refreshDs([L]); out.innerHTML = `<div class="hint">${t("done")}: ${r.n}</div>`; }
      } catch (e) { out.innerHTML = `<div class="hint" style="color:var(--er)">⚠ ${esc(e.message)}</div>`; }
    };
  }, { full: true });
}

/* ===== خرائط بلا إنترنت ===== */
const OFF = { src: "osm", z0: 10, z1: 15, area: "box", id: null };
function openOffline() {
  openSheet("offline", t("offline"), b => {
    const srcs = [["osm", "OpenStreetMap"], ["roads", "Carto Voyager"], ["sat", "Esri Satellite"], ["gm", "Google Maps"], ["gs", "Google Satellite"], ["gh", "Google Hybrid"]];
    b.innerHTML = `<div class="hint">${t("off_h")}</div><label class="f">${t("off_src")}</label><select class="in" id="of_s">${srcs.map(([k, l]) => `<option value="${k}" ${k === OFF.src ? "selected" : ""}>${l}</option>`).join("")}</select>
    <label class="f">${t("off_area")}</label><div class="seg" id="of_a"><button data-k="box" class="${OFF.area === "box" ? "on" : ""}">${t("off_box")}</button><button data-k="view" class="${OFF.area === "view" ? "on" : ""}">${t("off_screen")}</button></div>
    <label class="f">${t("off_z")}: <b id="of_zl"></b></label><div class="two"><input type="range" id="of_z0" min="4" max="19" value="${OFF.z0}"><input type="range" id="of_z1" min="4" max="19" value="${OFF.z1}"></div>
    <div class="hint" id="of_e"></div><div class="pbar" id="of_b" style="display:none"><i></i></div><div class="btns"><button class="btn" id="of_go">${I("cloud")}${t("off_go")}</button><button class="btn sec2" id="of_x" style="display:none">${I("x")}${t("off_stop")}</button></div>
    <div class="sec">${t("off_size")}: <span id="of_sz">…</span></div><div class="btns"><button class="btn sec2 er" id="of_c">${I("trash")}${t("off_clear")}</button></div>`;
    const bbox = () => { if (OFF.area === "view") { const m = map.getBounds(); return [m.getSouth(), m.getWest(), m.getNorth(), m.getEast()]; } return areaBBox(); };
    const est = async () => { OFF.src = $("#of_s", b).value; OFF.z0 = Math.min(+$("#of_z0", b).value, +$("#of_z1", b).value); OFF.z1 = Math.max(+$("#of_z0", b).value, +$("#of_z1", b).value); $("#of_zl", b).textContent = OFF.z0 + " → " + OFF.z1;
      try { const r = await post("/api/offline/start", { src: OFF.src, bbox: bbox(), zmin: OFF.z0, zmax: OFF.z1, dry: true }); $("#of_e", b).style.color = ""; $("#of_e", b).textContent = `${t("off_est")}: ${r.tiles.toLocaleString("en")} ${t("tiles_")} ≈ ${r.mb} MB`; } catch (e) { $("#of_e", b).style.color = "var(--er)"; $("#of_e", b).textContent = "⚠ " + e.message; } };
    ["of_s", "of_z0", "of_z1"].forEach(i => $("#" + i, b).oninput = est); $$("#of_a button", b).forEach(x => x.onclick = () => { OFF.area = x.dataset.k; $$("#of_a button", b).forEach(y => y.classList.toggle("on", y === x)); est(); }); est();
    const sz = async () => { try { const r = await api("/api/tiles/size"); $("#of_sz", b).textContent = `${r.files.toLocaleString("en")} ${t("tiles_")} · ${r.mb} MB`; } catch (e) { } }; sz();
    $("#of_go", b).onclick = async () => { try { const r = await post("/api/offline/start", { src: OFF.src, bbox: bbox(), zmin: OFF.z0, zmax: OFF.z1 }); OFF.id = r.id; $("#of_b", b).style.display = ""; $("#of_x", b).style.display = ""; $("#of_go", b).disabled = true;
      for (; ;) { await new Promise(z => setTimeout(z, 700)); if (SHEET !== "offline") break; const s = await api("/api/offline/status/" + r.id); $("#of_b i", b).style.width = Math.round(s.done / s.total * 100) + "%"; $("#of_e", b).textContent = `${s.done.toLocaleString("en")} / ${s.total.toLocaleString("en")}` + (s.fail ? ` ⚠ ${s.fail}` : ""); if (s.state !== "running") { toast(t("off_done")); break; } }
      $("#of_go", b).disabled = false; $("#of_x", b).style.display = "none"; sz(); } catch (e) { fail(e); $("#of_go", b).disabled = false; } };
    $("#of_x", b).onclick = () => OFF.id && post("/api/offline/cancel/" + OFF.id, {}).catch(() => { });
    $("#of_c", b).onclick = async () => { if (confirm(t("confirm"))) { await del("/api/tiles").catch(fail); sz(); } };
  }, { full: true });
}

/* ===== التتبع المحسّن: إيقاف مؤقت، علامات، إحصائيات، GPX، شاشة مضاءة ===== */
let WL = null;
const gpxOf = (pts, times, wps, name) => `<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="POI Exporter" xmlns="http://www.topografix.com/GPX/1/1"><metadata><name>${esc(name)}</name></metadata>` +
  wps.map(w => `<wpt lat="${w.lat}" lon="${w.lon}"><name>${esc(w.name)}</name></wpt>`).join("") + `<trk><name>${esc(name)}</name><trkseg>` + pts.map((p, i) => `<trkpt lat="${p[0]}" lon="${p[1]}">${p[2] != null ? `<ele>${p[2]}</ele>` : ""}<time>${new Date(times[i]).toISOString()}</time></trkpt>`).join("") + `</trkseg></trk></gpx>`;
Object.assign(TRK, { t: [], wps: [], pause: false, max: 0, acc: 0, t0: 0 });
trkStart = function () {
  if (!navigator.geolocation) return toast("GPS ✕"); if (TRK.id != null) return; Object.assign(TRK, { pts: [], t: [], wps: [], pause: false, max: 0, t0: Date.now() }); setSrc("track");
  try { navigator.wakeLock && navigator.wakeLock.request("screen").then(w => WL = w).catch(() => { }); } catch (e) { }
  const bar = el(`<div id="trkbar" class="mbar" style="bottom:calc(env(safe-area-inset-bottom) + 82px)"></div>`, document.body);
  const upd = () => { const L = plen(TRK.pts), dur = (Date.now() - TRK.t0) / 1000, avg = dur > 0 ? L / dur * 3.6 : 0;
    bar.innerHTML = barHtml(t("lp_track"), `${t("trk_len")}: <b>${fm(L)}</b> · ${fdur(dur)}<br>${t("trk_spd")}: ${avg.toFixed(1)} / ${(TRK.max * 3.6).toFixed(1)} km/h · ${t("trk_acc")}: ±${Math.round(TRK.acc)} m`, [["tk_p", TRK.pause ? "play" : "pause", t(TRK.pause ? "trk_resume" : "trk_pause")], ["tk_w", "flag2", t("trk_wp")], ["tk_s", "check", t("lp_stop"), "btn"]]);
    $("#tk_p", bar).onclick = () => { TRK.pause = !TRK.pause; upd(); }; $("#tk_w", bar).onclick = () => { const l = TRK.last; if (l) { TRK.wps.push({ lat: l[0], lon: l[1], name: "WP" + (TRK.wps.length + 1) }); toast(t("trk_wp") + " " + TRK.wps.length); } }; $("#tk_s", bar).onclick = () => trkStop(true); };
  upd(); TRK.tm = setInterval(upd, 1500);
  TRK.id = navigator.geolocation.watchPosition(p => { const ll = [p.coords.latitude, p.coords.longitude, p.coords.altitude]; TRK.acc = p.coords.accuracy || 0; TRK.last = ll; marker("me", ll[1], ll[0]); if (TRK.pause) return;
    if (p.coords.speed != null && p.coords.speed > TRK.max) TRK.max = p.coords.speed; const last = TRK.pts[TRK.pts.length - 1];
    if (TRK.acc <= 60 && (!last || hav(last, ll) > Math.max(3, TRK.acc / 3))) { TRK.pts.push(ll); TRK.t.push(Date.now()); setSrc("track", fc(ft({ type: "LineString", coordinates: TRK.pts.map(q => [q[1], q[0]]) }))); upd(); } map.easeTo({ center: [ll[1], ll[0]], duration: 500 }); },
    e => toast("GPS: " + e.message), { enableHighAccuracy: true, maximumAge: 1000 });
};
trkStop = function (save) {
  if (TRK.id != null) navigator.geolocation.clearWatch(TRK.id); TRK.id = null; clearInterval(TRK.tm); try { WL && WL.release(); } catch (e) { } WL = null; const b = $("#trkbar"); b && b.remove();
  const pts = TRK.pts.slice(), times = TRK.t.slice(), wps = TRK.wps.slice(); TRK.pts = []; TRK.t = [];
  if (!save || pts.length < 2) { setSrc("track"); return; }
  const nm = "Track " + new Date().toISOString().slice(0, 16).replace("T", " "), dur = (times[times.length - 1] - times[0]) / 1000;
  const m = el(`<div class="modal"><div class="p"><h3>${t("trk_end")}</h3><div class="hint">${t("trk_len")}: <b>${fm(plen(pts))}</b> · ${t("trk_dur")}: ${fdur(dur)} · ${pts.length} ${t("pts_")}</div><div class="qbtns" style="grid-template-columns:1fr"><button class="btn" id="tk1">${I("save")}${t("trk_save")}</button><button class="btn sec2" id="tk2">${I("fetch")}${t("trk_gpx")}</button><button class="btn sec2 er" id="tk3">${I("trash")}${t("trk_drop")}</button></div></div></div>`, document.body);
  $("#tk1", m).onclick = () => { m.remove(); saveDraw("line", pts.map(p => [p[0], p[1]]), () => setSrc("track")); };
  $("#tk2", m).onclick = () => saveBlob(new Blob([gpxOf(pts, times, wps, nm)], { type: "application/gpx+xml" }), nm.replace(/[ :]/g, "_") + ".gpx", "share");
  $("#tk3", m).onclick = () => { m.remove(); setSrc("track"); };
};
/* ===== الملاحة إلى معلم (Stakeout) مع تنبيه الاقتراب ===== */
const NAV = { id: null, o: null };
function navStop() { if (NAV.id != null) navigator.geolocation.clearWatch(NAV.id); NAV.id = null; window.removeEventListener("deviceorientationabsolute", NAV.h); const b = $("#navbar"); b && b.remove(); setSrc("ruler"); }
function navStart(tg) {
  if (!navigator.geolocation) return toast("GPS ✕"); navStop(); let alerted = false, rad = 30, hd = null;
  const bar = el(`<div id="navbar" class="mbar" style="bottom:calc(env(safe-area-inset-bottom) + 82px)"></div>`, document.body);
  bar.innerHTML = barHtml(`${t("nav_to")}: ${esc(tg.name || "")}`, `<div class="navarr"><svg viewBox="0 0 24 24" id="na"><path d="M12 2l7 19-7-4-7 4z" fill="currentColor"/></svg><div id="nv">…</div></div>`, [["nv_s", "x", t("nav_stop"), "btn"]]);
  $("#nv_s", bar).onclick = navStop;
  NAV.h = e => { const h = e.webkitCompassHeading != null ? e.webkitCompassHeading : (e.alpha != null ? 360 - e.alpha : null); if (h != null) hd = h; }; window.addEventListener("deviceorientationabsolute", NAV.h);
  el(`<div><label class="f" style="margin:6px 0 0">${t("nav_alert")}</label><input class="in" type="number" value="30" id="nv_r" style="padding:6px 10px"></div>`, $(".mv", bar)); $("#nv_r", bar).oninput = e => { rad = +e.target.value || 30; alerted = false; };
  NAV.id = navigator.geolocation.watchPosition(p => { const me = [p.coords.latitude, p.coords.longitude], to = [tg.lat, tg.lon], d = hav(me, to), b = brg(me, to); marker("me", me[1], me[0]);
    $("#nv", bar).innerHTML = `${t("nav_dist")}: <b>${fm(d)}</b><br>${t("bearing")}: ${Math.round(b)}° · ±${Math.round(p.coords.accuracy)} m`; $("#na", bar).style.transform = `rotate(${Math.round(b - (hd != null ? hd : 0))}deg)`;
    setSrc("ruler", fc(ft({ type: "Point", coordinates: [to[1], to[0]] }), ft({ type: "LineString", coordinates: [[me[1], me[0]], [to[1], to[0]]] })));
    if (d <= rad && !alerted) { alerted = true; navigator.vibrate && navigator.vibrate([200, 100, 200]); toast(t("nav_arr")); } if (d > rad * 1.5) alerted = false; }, e => toast(t("gpsbad") + ": " + e.message), { enableHighAccuracy: true, maximumAge: 1000 });
}
/* ===== لصق رابط/Plus Code/إحداثيات + البحث ===== */
async function goText(q, quiet) {
  try { const c = await api("/api/coords?text=" + encodeURIComponent(q) + refQ());
    gotoLL(c.lat, c.lon, 17); if (!quiet) toast(`${t("resolved")}: ${c.detected} — ${c.PLUS || ""}`, [[t("add_here"), () => post("/api/landmarks", { lat: c.lat, lon: c.lon, name: c.name || "", type: "", Gategory: "" }).then(() => refreshDs(dsIds())).catch(fail)]]);
    if (c.points && c.points.length > 1) toast(t("route"), [[t("route"), () => { RT.from = { lat: c.points[0][0], lon: c.points[0][1], label: "A" }; const z = c.points[c.points.length - 1]; RT.to = { lat: z[0], lon: z[1], label: "B" }; RT.line = null; RT.info = null; openRoute(); }]]);
    return true; } catch (e) { if (!quiet) toast("⚠ " + (e.message || t("notfound"))); return false; }
}
function pasteTool() {
  const b = el(`<div><div class="hint">${t("pastet")}</div><textarea class="in ta" id="pt_v"></textarea></div>`);
  modal(t("pastel"), b, async () => { const v = $("#pt_v", b).value.trim(); if (!v) return false; return (await goText(v)) ? true : false; }, t("go"));
  navigator.clipboard && navigator.clipboard.readText && navigator.clipboard.readText().then(s => { if (s && SPECIAL_RE.test(s)) $("#pt_v", b).value = s; }).catch(() => { });
}
const _onType = onType; onType = function () { const q = $("#q").value.trim(); if (SPECIAL_RE.test(q)) { showSug([]); return; } _onType(); };
const _enterSearch = enterSearch; enterSearch = async function () { const q = $("#q").value.trim(); if (q && SPECIAL_RE.test(q)) { $("#sug").style.display = "none"; $("#q").blur(); return goText(q); } return _enterSearch(); };
let LASTBB = null; const _pickSug = pickSug; pickSug = function (x) { if (x.bbox) LASTBB = x.bbox; _pickSug(x); };
/* ===== المنطقة: بلا حدّ ===== */
const _openArea = openArea;
openArea = function () {
  _openArea(); const b = $("#sh-b"); if (!b || SHEET !== "area") return;
  ["w", "h"].forEach(k => { const s = $("#ar_" + k, b); if (s) { s.max = 400000; s.step = 50; } }); const r = $("#ar_r", b); if (r) { r.max = 200000; r.step = 50; }
  const row = $(".btns", b), mk = (ic_, l, f) => { const x = el(`<button class="btn sec2">${I(ic_)}${l}</button>`, row); x.onclick = f; };
  mk("area", t("allscreen"), () => { const m = map.getBounds(), c = map.getCenter(); A.lat = c.lat; A.lon = c.lng; A.deg = 0; A.shape = "rect"; A.follow = false; A.w = Math.round((m.getEast() - m.getWest()) * MX * Math.cos(c.lat * Math.PI / 180)); A.h = Math.round((m.getNorth() - m.getSouth()) * 110574); drawArea(); openArea(); });
  mk("pin", t("lastplace"), () => { if (!LASTBB) return toast(t("sugn")); const [w0, s0, e0, n0] = [LASTBB[0], LASTBB[1], LASTBB[2], LASTBB[3]]; /* bbox: [lon,lat,lon,lat] أو [lat,lon,lat,lon] */ const bb = Math.abs(w0) > 90 || Math.abs(e0) > 90 ? [s0, w0, n0, e0] : [w0, s0, e0, n0]; const cl = (bb[0] + bb[2]) / 2, co = (bb[1] + bb[3]) / 2; A.lat = cl; A.lon = co; A.deg = 0; A.shape = "rect"; A.follow = false; A.w = Math.round((bb[3] - bb[1]) * MX * Math.cos(cl * Math.PI / 180)); A.h = Math.round((bb[2] - bb[0]) * 110574); drawArea(); openArea(); });
};
/* زر إيقاف الجلب */
const _openFetch4 = openFetch;
openFetch = function () { _openFetch4(); const b = $("#sh-b"), go = b && $("#f_go", b); if (!go) return; const x = el(`<button class="btn sec2 er" id="f_cancel" style="display:none">${I("x")}${t("fcancel")}</button>`); go.parentNode.appendChild(x); x.onclick = () => window.__fjob && post("/api/download/cancel/" + window.__fjob, {}).catch(() => { });
  new MutationObserver(() => { x.style.display = go.disabled ? "" : "none"; }).observe(go, { attributes: true, attributeFilter: ["disabled"] }); };
/* ===== أدوات إضافية في نافذة الأدوات ===== */
const _openTools4 = openTools;
openTools = async function () {
  await _openTools4(); const b = $("#sh-b"); if (SHEET !== "tools" || !b) return; const g = $(".grid", b); if (!g) return;
  [["names", "names", () => { setNames(!S.names); openTools(); }, S.names], ["link", "pastel", pasteTool], ["anal", "spatial", openSpatial], ["cloud", "offline", () => openOffline()], ["undo", "undo2", doUndo], ["redo", "redo2", doRedo], ["hist", "hist", openHist], ["db", "backup", doBackup], ["imp", "restore", doRestore], ["x", "clearov", clearOverlays]]
    .forEach(([i, k, f, on]) => { const x = el(`<button class="tile ${on ? "on" : ""}">${I(i)}<span>${t(k)}${on ? " ✓" : ""}</span></button>`, g); x.onclick = f; });
};
function clearOverlays() { stopMode(); ["meas", "route", "track", "ruler"].forEach(i => setSrc(i)); RT.line = null; RT.info = null; RT.from = RT.to = null; cvClear(); Object.keys(MK).forEach(k => { if (k !== "me") { MK[k].remove(); delete MK[k]; } }); toast(t("done")); }
async function doUndo() { const r = await post("/api/undo", {}).catch(fail); if (r) { toast(r.label ? t("undo2") + ": " + r.label : t("nohist")); await refreshDs(dsIds()); } }
async function doRedo() { const r = await post("/api/redo", {}).catch(fail); if (r) { toast(r.label ? t("redo2") + ": " + r.label : t("nohist")); await refreshDs(dsIds()); } }
async function openHist() { const h = await api("/api/history").catch(fail); if (!h) return;
  openSheet("hist", t("hist"), b => { b.innerHTML = `<div class="btns"><button class="btn sec2" id="h_u" ${h.can_undo ? "" : "disabled"}>${I("undo")}${t("undo2")}</button><button class="btn sec2" id="h_r" ${h.can_redo ? "" : "disabled"}>${I("redo")}${t("redo2")}</button></div>` + (h.items.length ? `<div class="card">${h.items.map(x => `<div class="row" style="opacity:${x.undone ? .45 : 1}"><div class="t"><b>${esc(x.label)}</b><small>${esc(x.ts || "")}${x.undone ? " · ↩" : ""}</small></div></div>`).join("")}</div>` : `<div class="hint">${t("nohist")}</div>`);
    $("#h_u", b).onclick = async () => { await doUndo(); openHist(); }; $("#h_r", b).onclick = async () => { await doRedo(); openHist(); }; }); }
const doBackup = async () => { try { await csPush(); } catch (e) { } return getFile("/api/backup", {}, "POI-backup.poibak").catch(fail); };
function doRestore() { const i = document.createElement("input"); i.type = "file"; i.onchange = async () => { const f = i.files[0]; if (!f) return; const fd = new FormData(); fd.append("file", f); try { const r = await api("/api/restore", { method: "POST", body: fd }); toast(t("done") + ": " + r.restored); csApply(r.client, true); await refreshDs(dsIds()); } catch (e) { fail(e); } }; i.click(); }
/* ===== ضغط مطوّل على الخريطة ===== */
window.addEventListener("DOMContentLoaded", () => {
  const cv = map.getCanvas(); let tm, sx, sy, sl;
  const fire = (x, y, ll) => { if (window.__mode || ADD.mode) return; navigator.vibrate && navigator.vibrate(15);
    menuAt([["plus", t("add_here"), () => post("/api/landmarks", { lat: ll.lat, lon: ll.lng, name: "", type: "", Gategory: "" }).then(() => { refreshDs(dsIds()); toast(t("added")); }).catch(fail)], ["copy", t("copyc"), () => copyMenu(ll.lat, ll.lng, x, y)], ["route", t("route_from"), () => { RT.from = { lat: ll.lat, lon: ll.lng, label: ll.lat.toFixed(5) + ", " + ll.lng.toFixed(5) }; openRoute(); }],
      ["route", t("route_here"), () => { RT.to = { lat: ll.lat, lon: ll.lng, label: ll.lat.toFixed(5) + ", " + ll.lng.toFixed(5) }; openRoute(); }], ["nav", t("goto"), () => navStart({ lat: ll.lat, lon: ll.lng, name: ll.lat.toFixed(5) + ", " + ll.lng.toFixed(5) })], ["ruler", t("measure_here"), () => { rulerMode(); setTimeout(() => { const c = map.getCenter(); map.easeTo({ center: [ll.lng, ll.lat], duration: 0 }); $("#r_c") && $("#r_c").click(); }, 50); }]], x, y); };
  cv.addEventListener("pointerdown", e => { if (e.pointerType === "mouse" && e.button !== 0) return; sx = e.clientX; sy = e.clientY; const r = cv.getBoundingClientRect(); sl = map.unproject([e.clientX - r.left, e.clientY - r.top]); clearTimeout(tm); tm = setTimeout(() => fire(sx, sy, sl), 650); });
  ["pointerup", "pointercancel"].forEach(ev => cv.addEventListener(ev, () => clearTimeout(tm))); cv.addEventListener("pointermove", e => { if (Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) > 8) clearTimeout(tm); });
  map.on("movestart", () => clearTimeout(tm)); map.on("zoomstart", () => clearTimeout(tm));
  if (map.getContainer && !S._sc2) { try { applyScale && !S.set.scale && (S.set.scale = true, applyScale()); } catch (e) { } }
});
