"use strict";
/* ===== نصوص الإضافات ===== */
Object.assign(TX.ar, {
  route: "مسار", measure: "قياس المسافة", marea: "قياس المساحة", ruler: "مسطرة من نقطة", digi: "تنقيط", merge: "دمج", fconvert: "محوّل الملفات", qr: "باركود",
  undo: "تراجع", finish: "إنهاء", save3: "حفظ", dist_: "المسافة", total: "المجموع", perim: "المحيط", area_: "المساحة", donum: "دونم", ha: "هكتار", pts_: "نقاط", tapadd: "اضغط على الخريطة لإضافة نقطة",
  rul1: "اضغط لتحديد نقطة البداية، ثم حرّك الخريطة وسترى المسافة إلى المركز (+)", rul2: "المسافة من النقطة", fromgps: "حسب موقعي (GPS)", setcenter: "من المركز (+)", bearing: "الاتجاه",
  from: "من", to: "إلى", byland: "معلم", bycoord: "إحداثية", bymap: "من الخريطة", myloc: "موقعي", calc: "احسب المسار", driving: "سيارة", walking: "مشي", cycling: "دراجة", savero: "حفظ المسار", routefail: "تعذّر حساب المسار (يحتاج إنترنت)؛ رُسم خط مستقيم", dur: "المدة", searchlm: "ابحث عن معلم أو مكان", picked: "تم التحديد", pickmap: "اضغط على الخريطة للاختيار",
  gname: "الاسم", lname: "اسم الطبقة", dig_pt: "نقاط", dig_ln: "خط", dig_pg: "مساحة", digtip: "نقّط على الخريطة المعروضة مباشرة (أنهار، مبانٍ، طرق، أسماء…) وأعطها اسماً وقطاعاً",
  mergeh: "اختر مجموعتين أو أكثر لدمجها في مجموعة واحدة", mname: "اسم المجموعة الجديدة", mdel: "حذف المجموعات المصدر بعد الدمج", mcopy: "نسخ (إبقاء الأصل)", mdone: "تم الدمج", mmove: "دمج / نقل المحدد", target: "المجموعة الهدف", newgrp: "مجموعة جديدة",
  cv_h: "حوّل أي ملف (KML، KMZ، SHP، CSV، GPX، GeoJSON، Excel، GPKG) بإحداثيات WGS84 أو UTM أو MGRS", cv_open: "فتح الملف", cv_map: "عرض على الخريطة", cv_tbl: "فتح في جدول", cv_add: "إضافة للمعالم", cv_cancel: "إلغاء", cv_out: "صيغة الإخراج", cv_coord: "إحداثيات الجداول", cv_utm: "UTM (افتراضي)", cv_wgs: "خط عرض/طول", cv_mgrs: "+ عمود MGRS", cv_found: "عناصر", cv_exp: "تصدير",
  qr_make: "إنشاء", qr_scan: "مسح", qr_text: "نص", qr_url: "رابط", qr_loc: "موقع", qr_lm: "معالم", qr_file: "ملف/صورة", qr_map: "خريطة", qr_gen: "إنشاء الباركود", qr_big: "المحتوى أكبر من سعة الباركود", qr_cam: "فتح الكاميرا", qr_img: "مسح من صورة", qr_res: "المحتوى", qr_open: "فتح الرابط", qr_show: "عرض على الخريطة", qr_addpts: "إضافة للمعالم", qr_copy: "نسخ", qr_nocam: "تعذّر فتح الكاميرا", qr_nocode: "لم يُعثر على باركود في الصورة", qr_pickrows: "اختر من الجدول", qr_cur: "المركز الحالي", qr_savefile: "حفظ الملف",
  lp_off: "إيقاف الموقع", lp_track: "تتبع المسار", lp_stop: "إيقاف التتبع", cp_mode: "بوصلة الجهاز", cp_north: "إعادة الشمال", cp_tilt: "إمالة", trk_done: "حفظ مسار التتبع؟", trk_len: "طول المسار",
  d_open: "فتح", d_edit: "تعديل", d_merge: "دمج مع…", d_share: "مشاركة", d_del: "حذف", d_exp: "تصدير", d_info: "تفاصيل", d_all: "تحديد الكل", d_sel: "محدد", d_none: "إلغاء التحديد", d_rename: "إعادة تسمية", d_color: "اللون", d_zoom: "تقريب", d_qr: "باركود",
  reset: "إعادة ضبط البرنامج", reset_s: "يمسح كل شيء: المعالم والطبقات والإعدادات والقوالب والخرائط المخزّنة", reset_c: "اكتب كلمة «مسح» للتأكيد", reset_w: "مسح", reset_ok: "تمت إعادة الضبط",
  inc_t: "ملف وارد", inc_imp: "استيراد كمعالم", inc_cv: "فتح في المحوّل", inc_map: "عرض على الخريطة", inc_txt: "نص وارد", mm_grp: "العوارض الاصطناعية", nat_grp: "العوارض الطبيعية", infra_grp: "البنية التحتية والطرق", all_: "الكل"
});
Object.assign(TX.en, {
  route: "Route", measure: "Measure distance", marea: "Measure area", ruler: "Ruler from point", digi: "Digitize", merge: "Merge", fconvert: "File converter", qr: "Barcode",
  undo: "Undo", finish: "Finish", save3: "Save", dist_: "Distance", total: "Total", perim: "Perimeter", area_: "Area", donum: "donum", ha: "ha", pts_: "points", tapadd: "Tap the map to add a point",
  rul1: "Tap to set the start point, then move the map: distance to the centre (+) is shown", rul2: "Distance from point", fromgps: "From my location (GPS)", setcenter: "From centre (+)", bearing: "Bearing",
  from: "From", to: "To", byland: "Landmark", bycoord: "Coordinate", bymap: "From map", myloc: "My location", calc: "Calculate route", driving: "Car", walking: "Walk", cycling: "Bike", savero: "Save route", routefail: "Routing failed (needs internet); a straight line was drawn", dur: "Duration", searchlm: "Search landmark or place", picked: "Picked", pickmap: "Tap the map to pick",
  gname: "Name", lname: "Layer name", dig_pt: "Points", dig_ln: "Line", dig_pg: "Area", digtip: "Digitize on the displayed map (rivers, buildings, roads, names…) with a name and sector",
  mergeh: "Pick two or more groups to merge into one", mname: "New group name", mdel: "Delete source groups after merging", mcopy: "Copy (keep originals)", mdone: "Merged", mmove: "Merge / move selected", target: "Target group", newgrp: "New group",
  cv_h: "Convert any file (KML, KMZ, SHP, CSV, GPX, GeoJSON, Excel, GPKG) in WGS84, UTM or MGRS", cv_open: "Open file", cv_map: "Show on map", cv_tbl: "Open in table", cv_add: "Add to landmarks", cv_cancel: "Cancel", cv_out: "Output format", cv_coord: "Table coordinates", cv_utm: "UTM (default)", cv_wgs: "Lat/Lon", cv_mgrs: "+ MGRS column", cv_found: "items", cv_exp: "Export",
  qr_make: "Create", qr_scan: "Scan", qr_text: "Text", qr_url: "Link", qr_loc: "Location", qr_lm: "Landmarks", qr_file: "File/Image", qr_map: "Map", qr_gen: "Generate barcode", qr_big: "Content is too large for a barcode", qr_cam: "Open camera", qr_img: "Scan from image", qr_res: "Content", qr_open: "Open link", qr_show: "Show on map", qr_addpts: "Add to landmarks", qr_copy: "Copy", qr_nocam: "Camera unavailable", qr_nocode: "No barcode found in image", qr_pickrows: "Pick from table", qr_cur: "Current centre", qr_savefile: "Save file",
  lp_off: "Turn off location", lp_track: "Track route", lp_stop: "Stop tracking", cp_mode: "Device compass", cp_north: "Reset north", cp_tilt: "Tilt", trk_done: "Save the tracked route?", trk_len: "Route length",
  d_open: "Open", d_edit: "Edit", d_merge: "Merge with…", d_share: "Share", d_del: "Delete", d_exp: "Export", d_info: "Details", d_all: "Select all", d_sel: "selected", d_none: "Clear selection", d_rename: "Rename", d_color: "Colour", d_zoom: "Zoom to", d_qr: "Barcode",
  reset: "Reset the app", reset_s: "Erases everything: landmarks, layers, settings, templates and cached maps", reset_c: "Type “DELETE” to confirm", reset_w: "DELETE", reset_ok: "Reset done",
  inc_t: "Incoming file", inc_imp: "Import as landmarks", inc_cv: "Open in converter", inc_map: "Show on map", inc_txt: "Incoming text", mm_grp: "Man-made features", nat_grp: "Natural features", infra_grp: "Infrastructure and roads", all_: "All"
});
Object.assign(ICONS, {
  ruler: "M3 17L17 3l4 4L7 21zM8 12l2 2M11 9l2 2M14 6l2 2", route: "M6 19a2 2 0 100-4 2 2 0 000 4zM18 9a2 2 0 100-4 2 2 0 000 4zM8 17h6a3 3 0 000-6h-4a3 3 0 010-6h6", qr: "M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h3v3h-3zM20 14v1M14 20h1M18 18h3v3h-3z",
  merge: "M6 3v6a6 6 0 006 6h0a6 6 0 006-6V3M12 15v6", conv: ICONS.conv, trash: ICONS.trash, pen: "M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z", info: "M12 22a10 10 0 100-20 10 10 0 000 20zM12 16v-4M12 8h.01",
  poly: "M4 8l8-5 8 5-3 11H7z", track: "M3 17c4-8 8 4 12-4s4-6 6-7M3 21h.01", cam: "M4 7h3l2-3h6l2 3h3v13H4zM12 17a4 4 0 100-8 4 4 0 000 8z", off: "M2 2l20 20M12 8a4 4 0 014 4M8.5 8.5A4 4 0 0012 16", reset: "M3 12a9 9 0 109-9M3 4v5h5"
});

/* ===== مساعدات هندسية ===== */
const R_E = 6371008.8, rad = d => d * Math.PI / 180;
function hav(a, b) { const dl = rad(b[0] - a[0]), dn = rad(b[1] - a[1]), x = Math.sin(dl / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dn / 2) ** 2; return 2 * R_E * Math.asin(Math.sqrt(x)); }   // نقاط [lat,lon]
function brg(a, b) { const y = Math.sin(rad(b[1] - a[1])) * Math.cos(rad(b[0])), x = Math.cos(rad(a[0])) * Math.sin(rad(b[0])) - Math.sin(rad(a[0])) * Math.cos(rad(b[0])) * Math.cos(rad(b[1] - a[1])); return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360; }
function plen(p) { let s = 0; for (let i = 1; i < p.length; i++) s += hav(p[i - 1], p[i]); return s; }
function parea(p) { if (p.length < 3) return 0; let s = 0; for (let i = 0; i < p.length; i++) { const a = p[i], b = p[(i + 1) % p.length]; s += rad(b[1] - a[1]) * (2 + Math.sin(rad(a[0])) + Math.sin(rad(b[0]))); } return Math.abs(s * R_E * R_E / 2); }
const fm = m => m >= 1000 ? (m / 1000).toFixed(m >= 100000 ? 1 : 3) + " km" : Math.round(m * 10) / 10 + " m";
const fa = a => `${a >= 1e6 ? (a / 1e6).toFixed(3) + " km²" : Math.round(a).toLocaleString("en") + " m²"} · ${(a / 2500).toFixed(2)} ${t("donum")} · ${(a / 1e4).toFixed(2)} ${t("ha")}`;
const fdur = s => { s = Math.round(s / 60); return s >= 60 ? Math.floor(s / 60) + "h " + s % 60 + "m" : s + " min"; };

/* ===== أنماط الخريطة: نظام «الوضع» الذي يلتقط النقر ===== */
let MODE = null;
function g3() { return map.getSource("m3") ? true : false; }
function initLayers3() {
  ["meas", "route", "track", "ruler"].forEach(id => map.addSource("m3-" + id, { type: "geojson", data: { type: "FeatureCollection", features: [] } }));
  map.addLayer({ id: "m3-meas-f", type: "fill", source: "m3-meas", filter: ["==", "$type", "Polygon"], paint: { "fill-color": "#f59f00", "fill-opacity": .25 } });
  map.addLayer({ id: "m3-meas-l", type: "line", source: "m3-meas", filter: ["!=", "$type", "Point"], paint: { "line-color": "#f08c00", "line-width": 3, "line-dasharray": [2, 1] } });
  map.addLayer({ id: "m3-meas-c", type: "circle", source: "m3-meas", filter: ["==", "$type", "Point"], paint: { "circle-radius": 5, "circle-color": "#fff", "circle-stroke-color": "#f08c00", "circle-stroke-width": 3 } });
  map.addLayer({ id: "m3-ruler-l", type: "line", source: "m3-ruler", filter: ["!=", "$type", "Point"], paint: { "line-color": "#e03131", "line-width": 3, "line-dasharray": [3, 2] } });
  map.addLayer({ id: "m3-ruler-c", type: "circle", source: "m3-ruler", filter: ["==", "$type", "Point"], paint: { "circle-radius": 7, "circle-color": "#e03131", "circle-stroke-color": "#fff", "circle-stroke-width": 3 } });
  map.addLayer({ id: "m3-route-b", type: "line", source: "m3-route", filter: ["!=", "$type", "Point"], layout: { "line-cap": "round", "line-join": "round" }, paint: { "line-color": "#fff", "line-width": 9 } });
  map.addLayer({ id: "m3-route-l", type: "line", source: "m3-route", filter: ["!=", "$type", "Point"], layout: { "line-cap": "round", "line-join": "round" }, paint: { "line-color": "#1e7bff", "line-width": 5 } });
  map.addLayer({ id: "m3-route-c", type: "circle", source: "m3-route", filter: ["==", "$type", "Point"], paint: { "circle-radius": 8, "circle-color": ["get", "c"], "circle-stroke-color": "#fff", "circle-stroke-width": 3 } });
  map.addLayer({ id: "m3-track-l", type: "line", source: "m3-track", layout: { "line-cap": "round", "line-join": "round" }, paint: { "line-color": "#12a36b", "line-width": 5 } });
}
const fc = (...f) => ({ type: "FeatureCollection", features: f });
const ft = (g, p) => ({ type: "Feature", properties: p || {}, geometry: g });
const setSrc = (id, d) => map.getSource("m3-" + id) && map.getSource("m3-" + id).setData(d || fc());
function stopMode(keepData) {
  if (!MODE) return; const m = MODE; MODE = null; window.__mode = false; if (m.stop) m.stop(); const b = $("#mbar"); if (b) b.remove(); map.getCanvas().style.cursor = "";
  if (!keepData) { setSrc("meas"); setSrc("ruler"); }
}
function startMode(m) {
  stopMode(); closeSheet(); stopTouch && ADD.mode && stopTouch(); document.body.classList.remove("dr"); MODE = m; window.__mode = true; map.getCanvas().style.cursor = "crosshair";
  const bar = el(`<div id="mbar" class="mbar"></div>`, document.body); m.bar = bar; if (m.start) m.start(bar); return m;
}
map_click_hook: {
  window.addEventListener("DOMContentLoaded", () => {
    map.on("load", initLayers3);
    map.on("click", e => { if (MODE && MODE.click) MODE.click(e); });
    map.on("move", () => { if (MODE && MODE.move) MODE.move(); });
  });
}
const barHtml = (title, body, btns) => `<div class="mt">${title}</div><div class="mv">${body}</div><div class="mb">${btns.map(([id, ic_, l, cls]) => `<button class="btn ${cls || "sec2"}" id="${id}">${ic_ ? I(ic_) : ""}${l}</button>`).join("")}</div>`;
/* ===== قياس المسافة والمساحة ===== */
function measureMode(kind) {
  const pts = []; let name = "";
  const draw = () => { const f = pts.map(p => ft({ type: "Point", coordinates: [p[1], p[0]] })), co = pts.map(p => [p[1], p[0]]);
    if (kind === "area" && pts.length >= 3) f.push(ft({ type: "Polygon", coordinates: [co.concat([co[0]])] })); else if (pts.length >= 2) f.push(ft({ type: "LineString", coordinates: co }));
    setSrc("meas", fc(...f)); };
  const upd = bar => { const L = plen(pts); let v;
    if (kind === "area") { const c = pts.concat(pts.length > 2 ? [pts[0]] : []); v = `${t("area_")}: <b>${pts.length >= 3 ? fa(parea(pts)) : "—"}</b><br>${t("perim")}: ${fm(plen(pts.concat(pts.length > 2 ? [pts[0]] : [])))} · ${pts.length} ${t("pts_")}`; }
    else v = `${t("total")}: <b>${fm(L)}</b>${pts.length > 1 ? "<br>" + t("dist_") + ": " + fm(hav(pts[pts.length - 2], pts[pts.length - 1])) : ""} · ${pts.length} ${t("pts_")}`;
    $(".mv", bar).innerHTML = pts.length ? v : t("tapadd"); };
  startMode({
    start(bar) { bar.innerHTML = barHtml(t(kind === "area" ? "marea" : "measure"), "", [["m_u", "rot", t("undo")], ["m_c", "x", t("clear")], ["m_s", "save", t("save3")], ["m_d", "check", t("finish"), "btn"]]); upd(bar);
      $("#m_u", bar).onclick = () => { pts.pop(); draw(); upd(bar); }; $("#m_c", bar).onclick = () => { pts.length = 0; draw(); upd(bar); }; $("#m_d", bar).onclick = () => stopMode(); $("#m_s", bar).onclick = () => saveDraw(kind === "area" ? "polygon" : "line", pts); },
    click(e) { pts.push([e.lngLat.lat, e.lngLat.lng]); draw(); upd(this.bar); }
  });
}
/* ===== مسطرة من نقطة ===== */
function rulerMode() {
  let o = null, gps = false, wid = null, me = null;
  const upd = () => { const bar = MODE && MODE.bar; if (!bar) return; const tgt = gps && me ? me : (() => { const c = map.getCenter(); return [c.lat, c.lng]; })();
    if (!o) { $(".mv", bar).innerHTML = t("rul1"); setSrc("ruler"); return; }
    const d = hav(o, tgt); $(".mv", bar).innerHTML = `${t("rul2")}: <b>${fm(d)}</b><br>${t("bearing")}: ${Math.round(brg(o, tgt))}°`;
    setSrc("ruler", fc(ft({ type: "Point", coordinates: [o[1], o[0]] }), ft({ type: "LineString", coordinates: [[o[1], o[0]], [tgt[1], tgt[0]]] }))); };
  startMode({
    start(bar) { bar.innerHTML = barHtml(t("ruler"), "", [["r_c", "pin", t("setcenter")], ["r_g", "locate", t("fromgps")], ["r_x", "x", t("clear")], ["r_d", "check", t("finish"), "btn"]]);
      $("#r_c", bar).onclick = () => { const c = map.getCenter(); o = [c.lat, c.lng]; upd(); }; $("#r_x", bar).onclick = () => { o = null; upd(); }; $("#r_d", bar).onclick = () => stopMode();
      $("#r_g", bar).onclick = e => { gps = !gps; e.currentTarget.classList.toggle("on", gps); if (gps && navigator.geolocation) wid = navigator.geolocation.watchPosition(p => { me = [p.coords.latitude, p.coords.longitude]; upd(); }, () => { }, { enableHighAccuracy: true }); else if (wid != null) { navigator.geolocation.clearWatch(wid); wid = null; me = null; upd(); } };
      upd(); },
    click(e) { o = [e.lngLat.lat, e.lngLat.lng]; upd(); }, move: upd, stop() { if (wid != null) navigator.geolocation.clearWatch(wid); }
  });
}
/* ===== حفظ ما رُسم (تنقيط) ===== */
function saveDraw(kind, pts, after) {
  if (!pts.length) return toast(t("tapadd"));
  const b = el(`<div>${fieldRow(t("gname"), "g_n", "")}${fieldRow(t("lname"), "g_l", kind === "point" ? "التنقيط (نقاط)" : kind === "line" ? "التنقيط (خطوط)" : "التنقيط (مساحات)")}${fieldRow(t("type"), "g_t", "")}<label class="f">${t("Gategory")}</label><select class="in" id="g_s"><option value=""></option>${S.sectors.map(s => `<option>${esc(s.name)}</option>`).join("")}</select></div>`);
  modal(t("save3"), b, async () => { try { const attrs = kind === "line" ? { length_m: Math.round(plen(pts)) } : kind === "polygon" ? { area_m2: Math.round(parea(pts)), perimeter_m: Math.round(plen(pts.concat([pts[0]]))) } : undefined;
    await post("/api/digitize", { kind, points: pts, name: $("#g_n", b).value, layer: $("#g_l", b).value, type: $("#g_t", b).value, Gategory: $("#g_s", b).value, attrs }); toast(t("done")); await refreshDs(dsIds()); after && after(); } catch (e) { fail(e); return false; } });
}
/* ===== التنقيط على الخريطة المعروضة ===== */
function digitizeMode(kind) {
  const pts = [];
  const draw = () => { const co = pts.map(p => [p[1], p[0]]), f = pts.map(p => ft({ type: "Point", coordinates: [p[1], p[0]] }));
    if (kind === "polygon" && pts.length >= 3) f.push(ft({ type: "Polygon", coordinates: [co.concat([co[0]])] })); else if (kind !== "point" && pts.length >= 2) f.push(ft({ type: "LineString", coordinates: co })); setSrc("meas", fc(...f)); };
  const upd = bar => { $(".mv", bar).innerHTML = pts.length ? `${pts.length} ${t("pts_")}` + (kind === "line" ? " · " + fm(plen(pts)) : kind === "polygon" && pts.length > 2 ? " · " + fa(parea(pts)) : "") : t("tapadd"); };
  startMode({
    start(bar) { bar.innerHTML = barHtml(t("digi") + " — " + t(kind === "point" ? "dig_pt" : kind === "line" ? "dig_ln" : "dig_pg"), "", [["m_u", "rot", t("undo")], ["m_c", "x", t("clear")], ["m_d", "check", t("save3"), "btn"], ["m_x", "x", t("cancel")]]); upd(bar);
      $("#m_u", bar).onclick = () => { pts.pop(); draw(); upd(bar); }; $("#m_c", bar).onclick = () => { pts.length = 0; draw(); upd(bar); }; $("#m_x", bar).onclick = () => stopMode();
      $("#m_d", bar).onclick = () => saveDraw(kind, pts.slice(), () => stopMode()); },
    click(e) { pts.push([e.lngLat.lat, e.lngLat.lng]); draw(); upd(this.bar); }
  });
}
/* ===== المسارات (OSRM) ===== */
const RT = { from: null, to: null, prof: "driving", pick: null, line: null, info: null };
function openRoute() {
  openSheet("route", t("route"), b => {
    const side = k => `<div class="card" style="padding:10px;margin-bottom:10px"><div class="hint" style="margin:0 0 6px;font-weight:700">${t(k)}: <span id="rt_${k}_l" style="color:var(--pr)">${RT[k] ? esc(RT[k].label) : "—"}</span></div>
      <input class="in" id="rt_${k}_q" placeholder="${t("searchlm")}"><div id="rt_${k}_s" class="card" style="margin-top:6px;display:none"></div>
      <div class="btns" style="margin:8px 0 0"><button class="btn sec2" data-k="${k}" data-a="map">${I("pin")}${t("bymap")}</button><button class="btn sec2" data-k="${k}" data-a="gps">${I("locate")}${t("myloc")}</button><button class="btn sec2" data-k="${k}" data-a="ctr">${I("zoom")}${t("qr_cur")}</button></div></div>`;
    b.innerHTML = side("from") + side("to") + `<div class="seg" id="rt_p">${["driving", "walking", "cycling"].map(k => `<button data-k="${k}" class="${RT.prof === k ? "on" : ""}">${t(k)}</button>`).join("")}</div>
      <div class="btns"><button class="btn" id="rt_go">${I("route")}${t("calc")}</button></div><div id="rt_r"></div>`;
    ["from", "to"].forEach(k => { const q = $("#rt_" + k + "_q", b), box = $("#rt_" + k + "_s", b); let tm;
      q.oninput = () => { clearTimeout(tm); tm = setTimeout(async () => { const v = q.value.trim(); if (!v) { box.style.display = "none"; return; } let r = []; try { if (/\d/.test(v) && /^[\d\s.,°'"NSEWnsew\-+:/]+$/.test(v)) { const c = await api("/api/coords?text=" + encodeURIComponent(v)); r = [{ name: c.DD || v, sub: "", lat: c.lat, lon: c.lon }]; } else r = await api("/api/search?q=" + encodeURIComponent(v)); } catch (e) { }
        box.innerHTML = ""; box.style.display = r.length ? "" : "none"; r.slice(0, 8).forEach(x => { const row = el(`<button class="row" style="width:100%;border:0;background:none;text-align:start;cursor:pointer"><div class="t"><b>${esc(x.name)}</b><small>${esc(x.sub || "")}</small></div></button>`, box); row.onclick = () => { RT[k] = { lat: x.lat, lon: x.lon, label: x.name }; openRoute(); }; }); }, 250); }; });
    $$("[data-a]", b).forEach(x => x.onclick = () => { const k = x.dataset.k, a = x.dataset.a;
      if (a === "ctr") { const c = map.getCenter(); RT[k] = { lat: c.lat, lon: c.lng, label: c.lat.toFixed(5) + ", " + c.lng.toFixed(5) }; openRoute(); }
      else if (a === "gps") { navigator.geolocation.getCurrentPosition(p => { RT[k] = { lat: p.coords.latitude, lon: p.coords.longitude, label: t("myloc") }; openRoute(); }, e => toast("GPS: " + e.message), { enableHighAccuracy: true, timeout: 15000 }); }
      else { startMode({ start(bar) { bar.innerHTML = barHtml(t(k), t("pickmap"), [["m_x", "x", t("cancel")]]); $("#m_x", bar).onclick = () => { stopMode(); openRoute(); }; }, click(e) { RT[k] = { lat: e.lngLat.lat, lon: e.lngLat.lng, label: e.lngLat.lat.toFixed(5) + ", " + e.lngLat.lng.toFixed(5) }; stopMode(); openRoute(); } }); } });
    $$("#rt_p button", b).forEach(x => x.onclick = () => { RT.prof = x.dataset.k; $$("#rt_p button", b).forEach(y => y.classList.toggle("on", y === x)); });
    $("#rt_go", b).onclick = () => calcRoute(b); if (RT.info) showRouteInfo(b);
    drawRouteEnds();
  }, { full: true });
}
function drawRouteEnds() { const f = []; if (RT.from) f.push(ft({ type: "Point", coordinates: [RT.from.lon, RT.from.lat] }, { c: "#12a36b" })); if (RT.to) f.push(ft({ type: "Point", coordinates: [RT.to.lon, RT.to.lat] }, { c: "#e03131" })); if (RT.line) f.push(ft({ type: "LineString", coordinates: RT.line })); setSrc("route", fc(...f)); }
async function calcRoute(b) {
  if (!RT.from || !RT.to) return toast(t("from") + " / " + t("to")); const st = $("#rt_r", b); st.innerHTML = `<div class="hint">${t("wait")}</div>`;
  const prof = { driving: "driving", walking: "foot", cycling: "bike" }[RT.prof] || "driving";
  try {
    const r = await (await fetch(`https://routing.openstreetmap.de/routed-${prof}/route/v1/driving/${RT.from.lon},${RT.from.lat};${RT.to.lon},${RT.to.lat}?overview=full&geometries=geojson`)).json();
    if (!r.routes || !r.routes[0]) throw new Error("no route");
    RT.line = r.routes[0].geometry.coordinates; RT.info = { d: r.routes[0].distance, s: r.routes[0].duration, ok: true };
  } catch (e) { RT.line = [[RT.from.lon, RT.from.lat], [RT.to.lon, RT.to.lat]]; RT.info = { d: hav([RT.from.lat, RT.from.lon], [RT.to.lat, RT.to.lon]), s: 0, ok: false }; toast(t("routefail")); }
  drawRouteEnds(); const bb = new maplibregl.LngLatBounds(); RT.line.forEach(c => bb.extend(c)); map.fitBounds(bb, { padding: { top: 90, bottom: 340, left: 40, right: 40 }, maxZoom: 16, duration: 700 }); showRouteInfo(b);
}
function showRouteInfo(b) {
  const st = $("#rt_r", b), i = RT.info; st.innerHTML = `<div class="card" style="padding:12px;margin-top:10px"><b style="font-size:18px">${fm(i.d)}</b>${i.s ? `<div class="hint">${t("dur")}: ${fdur(i.s)}</div>` : ""}</div><div class="btns"><button class="btn" id="rt_sv">${I("save")}${t("savero")}</button><button class="btn sec2" id="rt_cl">${I("x")}${t("clear")}</button></div>`;
  $("#rt_sv", b).onclick = () => saveDraw("line", RT.line.map(c => [c[1], c[0]])); $("#rt_cl", b).onclick = () => { RT.line = null; RT.info = null; RT.from = RT.to = null; drawRouteEnds(); openRoute(); };
}
/* ===== دمج المجموعات ===== */
const MGPRE = new Set();
function openMerge(pre) {
  MGPRE.clear(); (pre || []).forEach(x => MGPRE.add(x));
  openSheet("merge", t("merge"), b => {
    b.innerHTML = `<div class="hint">${t("mergeh")}</div><div class="card" id="mg_l"></div>${fieldRow(t("mname"), "mg_n", "")}<div class="card" style="margin-top:12px"><div class="row"><div class="t">${t("mcopy")}</div><span id="mg1"></span></div><div class="row"><div class="t">${t("mdel")}</div><span id="mg2"></span></div></div><div class="btns"><button class="btn blk" id="mg_go">${I("merge")}${t("merge")}</button></div>`;
    const sel = new Set(); let cp = false, dl = false;
    S.ds.filter(d => d.kind !== "reference").forEach(d => { const r = el(`<label class="row" style="cursor:pointer"><input type="checkbox" ${MGPRE.has(d.id) ? "checked" : ""}><i class="dot" style="background:${d.color}"></i><div class="t"><b>${esc(d.label)}</b><small>${d.count} ${t("rows")}</small></div></label>`, $("#mg_l", b)); $("input", r).onchange = e => e.target.checked ? sel.add(d.id) : sel.delete(d.id); if (MGPRE.has(d.id)) sel.add(d.id); });
    $("#mg1", b).appendChild(sw(false, v => cp = v)); $("#mg2", b).appendChild(sw(false, v => dl = v));
    $("#mg_go", b).onclick = async () => { if (sel.size < 2) return toast(t("mergeh")); try { await post("/api/merge", { layers: [...sel], name: $("#mg_n", b).value, copy: cp, delete_sources: dl }); toast(t("mdone")); await refreshDs(dsIds()); openSaved(); } catch (e) { fail(e); } };
  }, { full: true });
}
function mergeSelected() {
  if (!TB.sel.size) return toast(t("sel"));
  const b = el(`<div><label class="f">${t("target")}</label><select class="in" id="mt_t"><option value="">${t("newgrp")}</option>${S.ds.filter(d => d.kind !== "reference").map(d => `<option value="${d.id}">${esc(d.label)}</option>`).join("")}</select>${fieldRow(t("mname"), "mt_n", "")}<div class="card" style="margin-top:12px"><div class="row"><div class="t">${t("mcopy")}</div><span id="mt_c"></span></div></div></div>`);
  let cp = false; $("#mt_c", b).appendChild(sw(false, v => cp = v));
  modal(t("mmove"), b, async () => { await post("/api/merge", { ids: [...TB.sel], target: $("#mt_t", b).value, name: $("#mt_n", b).value, copy: cp }); toast(t("mdone")); TB.sel = new Set(); await refreshDs(dsIds()); openTable(); });
}
/* ===== شبكة أدوات إضافية داخل نافذة الأدوات ===== */
const _openTools = openTools;
openTools = async function () {
  await _openTools(); const b = $("#sh-b"); if (SHEET !== "tools" || !b) return;
  const g = el(`<div class="grid" style="margin-bottom:14px"></div>`); b.insertBefore(g, b.firstChild);
  [["ruler", "measure", () => measureMode("line")], ["poly", "marea", () => measureMode("area")], ["ruler", "ruler", rulerMode], ["pen", "digi", openDigi], ["merge", "merge", () => openMerge()], ["route", "route", openRoute], ["conv", "fconvert", () => openFConv()], ["qr", "qr", () => openQR()]]
    .forEach(([i, k, f]) => { const x = el(`<button class="tile">${I(i)}<span>${t(k)}</span></button>`, g); x.onclick = f; });
};
function openDigi() {
  openSheet("digi", t("digi"), b => { b.innerHTML = `<div class="hint">${t("digtip")}</div><div class="grid"></div>`; [["pin", "dig_pt", "point"], ["route", "dig_ln", "line"], ["poly", "dig_pg", "polygon"]].forEach(([i, k, m]) => { const x = el(`<button class="tile">${I(i)}<span>${t(k)}</span></button>`, $(".grid", b)); x.onclick = () => digitizeMode(m); }); });
}
/* ===== جدول: زر الدمج + ترتيب من اليسار ===== */
const _openTable = openTable;
openTable = async function (id) { await _openTable(id); const b = $("#sh-b"); if (SHEET !== "table" || !b) return; const tl = $$(".tools", b)[2]; if (tl && !$("#t_mg", tl)) { const x = el(`<button class="ib" id="t_mg" title="${t("mmove")}">${I("merge")}</button>`); tl.insertBefore(x, $("#t_dl", tl)); x.onclick = mergeSelected; } };

/* ===== أدوات مساعدة ===== */
const loadScript = src => new Promise((ok, no) => { if (document.querySelector(`script[data-s="${src}"]`)) return ok(); const s = document.createElement("script"); s.src = src; s.dataset.s = src; s.onload = ok; s.onerror = () => no(new Error("load " + src)); document.head.appendChild(s); });
const defFmt = () => S.set.export_fmt || "xlsx";
const fileBlob = async u => (await fetch(u)).blob();
function menuAt(items, x, y) {
  $$(".dm").forEach(e => e.remove()); const m = el(`<div class="dm"></div>`, document.body);
  items.forEach(([ic_, l, f, cls]) => { const b = el(`<button class="${cls || ""}">${I(ic_)}<span>${l}</span></button>`, m); b.onclick = () => { m.remove(); f(); }; });
  const w = innerWidth, h = innerHeight; m.style.left = Math.max(8, Math.min(x, w - m.offsetWidth - 8)) + "px"; m.style.top = Math.max(8, Math.min(y, h - m.offsetHeight - 8)) + "px";
  setTimeout(() => document.addEventListener("pointerdown", function f(e) { if (!m.contains(e.target)) { m.remove(); document.removeEventListener("pointerdown", f, true); } }, true), 0);
}
async function dsBounds(id) { const g = await api(`/api/datasets/${id}/geojson`), bb = new maplibregl.LngLatBounds(); const w = c => typeof c[0] === "number" ? bb.extend(c) : c.forEach(w); g.features.forEach(f => f.geometry && w(f.geometry.coordinates)); return bb.isEmpty() ? null : bb; }

/* ===== النقر يتجاهل المعالم أثناء الأوضاع ===== */
const _featClick = featClick; featClick = function (e) { if (window.__mode) return; _featClick(e); };
const _back = window.__back; window.__back = () => { if (MODE) { stopMode(); return true; } if ($(".dm")) { $$(".dm").forEach(e => e.remove()); return true; } return _back(); };

/* ===== المعروضة: ضغط مطوّل ===== */
const DSEL = new Set();
function selBar() {
  let b = $("#dsbar"); if (!DSEL.size) { b && b.remove(); renderShown(); return; }
  if (!b) { b = el(`<div id="dsbar" class="mbar" style="z-index:30"></div>`, document.body); }
  b.innerHTML = barHtml(`${DSEL.size} ${t("d_sel")}`, "", [["ds_m", "merge", t("merge")], ["ds_e", "fetch", t("d_exp")], ["ds_s", "share", t("d_share")], ["ds_d", "trash", t("d_del")], ["ds_x", "x", t("d_none")]]);
  const ids = () => [...DSEL];
  $("#ds_m", b).onclick = () => { const p = ids(); DSEL.clear(); selBar(); document.body.classList.remove("dr"); openMerge(p); };
  $("#ds_e", b).onclick = () => exportDs({ layers: ids(), format: defFmt(), name: "POI" }).catch(fail); $("#ds_s", b).onclick = () => exportDs({ layers: ids(), format: defFmt(), name: "POI" }, "share").catch(fail);
  $("#ds_d", b).onclick = async () => { if (!confirm(t("confirm"))) return; for (const id of ids()) await del("/api/datasets/" + id).catch(fail); DSEL.clear(); selBar(); await refreshDs(); };
  $("#ds_x", b).onclick = () => { DSEL.clear(); selBar(); };
}
function dsMenu(d, x, y) {
  menuAt([
    ["open", t("d_open"), () => { document.body.classList.remove("dr"); openTable(d.id); }], ["zoom", t("d_zoom"), async () => { document.body.classList.remove("dr"); const bb = await dsBounds(d.id); bb && map.fitBounds(bb, { padding: 60, maxZoom: 17 }); }],
    ["edit", t("d_edit"), () => dsEdit(d)], ["merge", t("d_merge"), () => { document.body.classList.remove("dr"); openMerge([d.id]); }],
    ["share", t("d_share"), () => exportDs({ layers: [d.id], format: defFmt(), name: d.label }, "share").catch(fail)], ["fetch", t("d_exp"), () => exportDs({ layers: [d.id], format: defFmt(), name: d.label }).catch(fail)],
    ["qr", t("d_qr"), () => { document.body.classList.remove("dr"); openQR({ kind: "lm", ds: d.id }); }], ["info", t("d_info"), () => dsInfo(d)],
    ["check", t("d_all"), () => { S.ds.forEach(z => DSEL.add(z.id)); selBar(); renderShown(); }],
    ["trash", t("d_del"), async () => { if (!confirm(t("confirm"))) return; await del("/api/datasets/" + d.id).catch(fail); await refreshDs(); }, "er"]], x, y);
}
function dsEdit(d) {
  const b = el(`<div>${fieldRow(t("gname"), "de_n", d.label)}<label class="f">${t("color")}</label><input type="color" class="in" id="de_c" value="${/^#[0-9a-f]{6}$/i.test(d.color) ? d.color : "#1e7bff"}" style="height:44px;padding:4px"></div>`);
  modal(t("d_edit"), b, async () => { await post("/api/datasets/" + d.id, { label: $("#de_n", b).value.trim() || d.label, color: $("#de_c", b).value }); await refreshDs(dsIds()); });
}
function dsInfo(d) {
  const rows = [[t("gname"), d.label], [t("rows"), d.count], ["geom", ({ 1: "Point", 3: "Line", 5: "Polygon" })[d.geom] || d.geom], ["kind", d.kind], [t("color"), d.color], ["source", d.source || ""], ["date", d.source_date || ""]].filter(r => r[1] !== "" && r[1] != null);
  const b = el(`<div>${rows.map(r => `<div class="row"><div class="t"><small>${esc(r[0])}</small><b>${esc(r[1])}</b></div></div>`).join("")}</div>`); modal(t("d_info"), b, () => true, t("ok"));
}
const _renderShown = renderShown;
renderShown = function () {
  _renderShown(); const c = $("#shown"); if (!c) return; const rows = $$(":scope > .row", c);
  S.ds.forEach((d, i) => { const r = rows[4 + i]; if (!r) return; r.classList.toggle("selr", DSEL.has(d.id)); let tm, long = false, sx = 0, sy = 0;
    r.oncontextmenu = e => e.preventDefault();
    r.addEventListener("pointerdown", e => { if (e.target.closest(".sw")) return; long = false; sx = e.clientX; sy = e.clientY; tm = setTimeout(() => { long = true; navigator.vibrate && navigator.vibrate(15); dsMenu(d, sx, sy); }, 480); });
    ["pointerup", "pointerleave", "pointercancel"].forEach(ev => r.addEventListener(ev, () => clearTimeout(tm))); r.addEventListener("pointermove", e => { if (Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) > 10) clearTimeout(tm); });
    r.addEventListener("click", e => { if (long) { e.stopImmediatePropagation(); e.preventDefault(); long = false; return; } if (DSEL.size && !e.target.closest(".sw")) { e.stopImmediatePropagation(); DSEL.has(d.id) ? DSEL.delete(d.id) : DSEL.add(d.id); selBar(); r.classList.toggle("selr", DSEL.has(d.id)); } }, true); });
};

/* ===== جلب: تجميع الطبقات الجديدة ===== */
const _openFetch = openFetch;
openFetch = function () {
  _openFetch(); const b = $("#sh-b"), box = $("#f_l", b); if (!box) return; box.innerHTML = ""; box.className = "";
  [["main", t("infra_grp"), true], ["mm", t("mm_grp"), false], ["nat", t("nat_grp"), false]].forEach(([g, title, open]) => {
    const L = S.boot.layers.filter(x => (x.g || "main") === g); if (!L.length) return;
    const d = el(`<details class="card" style="padding:8px 12px;margin-bottom:8px" ${open ? "open" : ""}><summary style="cursor:pointer;font-weight:700;display:flex;justify-content:space-between;gap:8px;align-items:center"><span>${title} (${L.length})</span><button class="btn sec2" style="flex:none;min-width:0;padding:4px 10px;font-size:12px">${t("all_")}</button></summary><div class="chips" style="margin-top:8px"></div></details>`, box);
    const cs = []; L.forEach(x => { const c = el(`<span class="chip ${F.layers.has(x.id) ? "on" : ""}">${esc(S.set.lang === "ar" ? x.ar : x.en)}</span>`, $(".chips", d)); c.onclick = () => { F.layers.has(x.id) ? F.layers.delete(x.id) : F.layers.add(x.id); c.classList.toggle("on", F.layers.has(x.id)); }; cs.push([x, c]); });
    $("summary button", d).onclick = e => { e.preventDefault(); e.stopPropagation(); const all = cs.every(([x]) => F.layers.has(x.id)); cs.forEach(([x, c]) => { all ? F.layers.delete(x.id) : F.layers.add(x.id); c.classList.toggle("on", !all); }); };
  });
};

/* ===== الإعدادات: إعادة الضبط ===== */
const _openSettings = openSettings;
openSettings = function () {
  _openSettings(); const b = $("#sh-b"); if (!b) return;
  const c = el(`<div class="card" style="margin-top:12px"><div class="row"><div class="t"><b style="color:var(--er)">${t("reset")}</b><small>${t("reset_s")}</small></div><button class="ib er" id="st_rs">${I("reset")}</button></div></div>`, b);
  $("#st_rs", c).onclick = () => { const m = el(`<div>${`<div class="hint">${t("reset_c")}</div>`}<input class="in" id="rs_i" autocomplete="off"></div>`);
    modal(t("reset"), m, async () => { if ($("#rs_i", m).value.trim().toUpperCase() !== t("reset_w").toUpperCase()) { toast(t("reset_c")); return false; } await post("/api/reset", { confirm: "RESET" }); try { localStorage.clear(); sessionStorage.clear(); } catch (e) { } toast(t("reset_ok")); setTimeout(() => location.reload(), 700); }, t("reset_w")); };
};

/* ===== محوّل الملفات ===== */
const CV = { cid: null, file: null, crs: "", res: null };
const CRSL = [["", "WGS84 (4326)"], ["32638", "UTM 38N (32638)"], ["32637", "UTM 37N (32637)"], ["32639", "UTM 39N (32639)"], ["3857", "Web Mercator (3857)"]];
function cvMap(gj) {
  if (!map.getSource("m3-conv")) { map.addSource("m3-conv", { type: "geojson", data: gj }); map.addLayer({ id: "m3-conv-f", type: "fill", source: "m3-conv", filter: ["==", "$type", "Polygon"], paint: { "fill-color": ["coalesce", ["get", "color"], "#7048e8"], "fill-opacity": .25 } }); map.addLayer({ id: "m3-conv-l", type: "line", source: "m3-conv", filter: ["!=", "$type", "Point"], paint: { "line-color": ["coalesce", ["get", "color"], "#7048e8"], "line-width": 2.5 } }); map.addLayer({ id: "m3-conv-c", type: "circle", source: "m3-conv", filter: ["==", "$type", "Point"], paint: { "circle-radius": 6, "circle-color": ["coalesce", ["get", "color"], "#7048e8"], "circle-stroke-color": "#fff", "circle-stroke-width": 2 } }); } else map.getSource("m3-conv").setData(gj);
  const bb = new maplibregl.LngLatBounds(); const w = c => typeof c[0] === "number" ? bb.extend(c) : c.forEach(w); gj.features.forEach(f => f.geometry && w(f.geometry.coordinates)); if (!bb.isEmpty()) map.fitBounds(bb, { padding: 60, maxZoom: 17 });
}
const cvClear = () => { map.getSource("m3-conv") && map.getSource("m3-conv").setData(fc()); };
async function cvParse(b) {
  const fd = new FormData(); fd.append("file", CV.file); if (CV.crs) fd.append("crs", CV.crs); toast(t("wait"));
  if (CV.cid) del("/api/convert2/" + CV.cid).catch(() => { }); CV.cid = null;
  try { const r = await api("/api/convert2", { method: "POST", body: fd }); CV.cid = r.cid; CV.res = r; cvShow(b); } catch (e) { CV.res = null; cvShow(b); fail(e); }
}
function cvShow(b) {
  const box = $("#cv_r", b); if (!CV.res) { box.innerHTML = ""; return; } const r = CV.res;
  box.innerHTML = `<div class="card" style="margin-top:10px">${r.layers.map(l => `<div class="row"><div class="t"><b>${esc(l.label)}</b><small>${l.count} ${t("cv_found")} · ${esc(l.geom)}</small></div></div>`).join("")}</div>
  <div class="btns"><button class="btn" id="cv_m">${I("eye")}${t("cv_map")}</button><button class="btn sec2" id="cv_t">${I("table")}${t("cv_tbl")}</button><button class="btn sec2" id="cv_a">${I("plus")}${t("cv_add")}</button></div>
  <div class="sec">${t("cv_out")}</div><div class="two"><select class="in" id="cv_f">${S.boot.fmts.map(x => `<option ${x === "geojson" ? "selected" : ""}>${x}</option>`).join("")}</select><select class="in" id="cv_o">${CRSL.map(([v, l]) => `<option value="${v}">${l}</option>`).join("")}</select></div>
  <div class="chips" style="margin:8px 0"><span class="chip" id="cv_dd">${t("cv_wgs")}</span><span class="chip" id="cv_mg">${t("cv_mgrs")}</span></div>
  <div class="btns"><button class="btn sec2" id="cv_e">${I("fetch")}${t("cv_exp")}</button><button class="btn sec2" id="cv_op">${I("open")}${t("open")}</button><button class="btn sec2" id="cv_sh">${I("share")}${t("share")}</button><button class="btn sec2 er" id="cv_x">${I("x")}${t("cv_cancel")}</button></div>`;
  let dd = false, mg = false; $("#cv_dd", b).onclick = e => { dd = !dd; e.target.classList.toggle("on", dd); }; $("#cv_mg", b).onclick = e => { mg = !mg; e.target.classList.toggle("on", mg); };
  const base = (CV.file.name || "converted").replace(/\.[^.]+$/, "");
  const ex = m => { const q = new URLSearchParams({ format: $("#cv_f", b).value, name: base }); if ($("#cv_o", b).value) q.set("crs", $("#cv_o", b).value); if (dd) q.set("dd", "1"); if (mg) q.set("mgrs", "1"); return getFile(`/api/convert2/${CV.cid}/export?` + q, {}, base + (EXT[$("#cv_f", b).value] || ""), m).catch(fail); };
  $("#cv_e", b).onclick = () => ex(); $("#cv_op", b).onclick = () => ex("open"); $("#cv_sh", b).onclick = () => ex("share");
  $("#cv_m", b).onclick = () => { closeSheet(); cvMap(r.geojson); };
  const add = async open => { try { const a = await post("/api/convert2/" + CV.cid + "/add", {}); CV.cid = null; CV.res = null; cvClear(); await refreshDs(dsIds()); toast(t("done")); if (open) openTable(a.layers[0]); else cvShow(b); } catch (e) { fail(e); } };
  $("#cv_a", b).onclick = () => add(false); $("#cv_t", b).onclick = () => add(true);
  $("#cv_x", b).onclick = () => { CV.cid && del("/api/convert2/" + CV.cid).catch(() => { }); CV.cid = null; CV.res = null; cvClear(); cvShow(b); $("#cv_file", b).value = ""; };
}
function openFConv(file) {
  openSheet("fconv", t("fconvert"), b => {
    b.innerHTML = `<div class="hint">${t("cv_h")}</div><input class="in" type="file" id="cv_file"><label class="f">${t("crs")}</label><select class="in" id="cv_c">${CRSL.map(([v, l]) => `<option value="${v}" ${v === CV.crs ? "selected" : ""}>${v ? l : "Auto / WGS84 / UTM"}</option>`).join("")}</select><div id="cv_r"></div>`;
    $("#cv_file", b).onchange = e => { CV.file = e.target.files[0]; if (CV.file) cvParse(b); };
    $("#cv_c", b).onchange = e => { CV.crs = e.target.value; if (CV.file) cvParse(b); };
    if (file) { CV.file = file; cvParse(b); } else if (CV.res) cvShow(b);
  }, { full: true });
}

/* ===== الباركود ===== */
const QR = { kind: "text", out: null };
const QRK = [["text", "qr_text"], ["url", "qr_url"], ["loc", "qr_loc"], ["map", "qr_map"], ["lm", "qr_lm"], ["file", "qr_file"]];
async function qrLib() { await loadScript("/assets/vendor/qrcode.js"); try { qrcode.stringToBytes = qrcode.stringToBytesFuncs["UTF-8"]; } catch (e) { } }
function qrMake(text) {
  const q = qrcode(0, "L"); q.addData(text); try { q.make(); } catch (e) { throw new Error(t("qr_big")); }
  return q.createDataURL(8, 2);
}
async function downscale(file) {
  const u = URL.createObjectURL(file), im = new Image(); await new Promise((ok, no) => { im.onload = ok; im.onerror = no; im.src = u; });
  for (const [s, qu] of [[96, .5], [72, .45], [56, .4], [40, .35]]) { const k = Math.min(1, s / Math.max(im.width, im.height)), c = document.createElement("canvas"); c.width = Math.max(1, Math.round(im.width * k)); c.height = Math.max(1, Math.round(im.height * k)); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); const d = c.toDataURL("image/jpeg", qu); if (d.length < 2500) return d; }
  throw new Error(t("qr_big"));
}
function openQR(pre) {
  if (pre) Object.assign(QR, pre);
  openSheet("qr", t("qr"), b => {
    b.innerHTML = `<div class="seg" id="q_tab"><button data-v="make" class="on">${t("qr_make")}</button><button data-v="scan">${t("qr_scan")}</button></div><div id="q_body"></div>`;
    const go = v => { $$("#q_tab button", b).forEach(x => x.classList.toggle("on", x.dataset.v === v)); qrScanStop(); v === "make" ? qrMakeUI($("#q_body", b)) : qrScanUI($("#q_body", b)); };
    $$("#q_tab button", b).forEach(x => x.onclick = () => go(x.dataset.v)); go("make");
  }, { full: true });
}
function qrMakeUI(b) {
  const k = QR.kind, c = map.getCenter();
  b.innerHTML = `<div class="chips" id="q_k" style="margin:10px 0"></div><div id="q_f"></div><div class="btns"><button class="btn blk" id="q_go">${I("qr")}${t("qr_gen")}</button></div><div id="q_o"></div>`;
  QRK.forEach(([v, l]) => { const x = el(`<span class="chip ${k === v ? "on" : ""}">${t(l)}</span>`, $("#q_k", b)); x.onclick = () => { QR.kind = v; qrMakeUI(b); }; });
  const f = $("#q_f", b);
  if (k === "text") f.innerHTML = `<textarea class="in ta" id="q_v" placeholder="${t("qr_text")}"></textarea>`;
  else if (k === "url") f.innerHTML = fieldRow(t("qr_url"), "q_v", "https://");
  else if (k === "loc" || k === "map") { f.innerHTML = `<div class="two">${fieldRow("lat", "q_la", c.lat.toFixed(6))}${fieldRow("lon", "q_lo", c.lng.toFixed(6))}</div><div class="btns"><button class="btn sec2" id="q_c">${I("zoom")}${t("qr_cur")}</button></div>`; $("#q_c", b).onclick = () => { const m = map.getCenter(); $("#q_la", b).value = m.lat.toFixed(6); $("#q_lo", b).value = m.lng.toFixed(6); }; }
  else if (k === "lm") { const def = QR.ds || (S.ds.find(d => d.count > 0 && d.kind !== "reference") || {}).id; f.innerHTML = `<label class="f">${t("gname")}</label><select class="in" id="q_d">${S.ds.filter(d => d.kind !== "reference").map(d => `<option value="${d.id}" ${d.id === def ? "selected" : ""}>${esc(d.label)} (${d.count})</option>`).join("")}</select>${TB.sel.size ? `<div class="chips" style="margin-top:8px"><span class="chip on" id="q_sl">${t("qr_pickrows")} (${TB.sel.size})</span></div>` : ""}`; }
  else f.innerHTML = `<input class="in" type="file" id="q_fl"><div class="hint">≤ 2.5 KB</div>`;
  $("#q_go", b).onclick = async () => {
    const o = $("#q_o", b); try {
      let text; if (k === "text" || k === "url") text = $("#q_v", b).value; else if (k === "loc") text = `geo:${(+$("#q_la", b).value).toFixed(6)},${(+$("#q_lo", b).value).toFixed(6)}`;
      else if (k === "map") { const la = (+$("#q_la", b).value).toFixed(6), lo = (+$("#q_lo", b).value).toFixed(6); text = `https://www.openstreetmap.org/?mlat=${la}&mlon=${lo}#map=17/${la}/${lo}`; }
      else if (k === "lm") { const id = $("#q_d", b).value; let rows; if ($("#q_sl", b) && $("#q_sl", b).classList.contains("on") && id === TB.id) rows = TB.rows.filter(r => TB.sel.has(r.id)); else rows = (await api(`/api/datasets/${id}/rows?limit=60`)).rows;
        const pack = rs => "POI1:" + JSON.stringify(rs.map(r => [r.name || "", r.type || "", r.Gategory || "", +(+r.lat).toFixed(6), +(+r.lon).toFixed(6)])); while (rows.length && pack(rows).length > 2300) rows = rows.slice(0, -1); if (!rows.length) throw new Error(t("qr_big")); text = pack(rows); toast(rows.length + " " + t("rows")); }
      else { const fl = $("#q_fl", b).files[0]; if (!fl) return toast(t("pick")); if (fl.type.startsWith("image/")) text = await downscale(fl); else { text = "data:" + (fl.type || "application/octet-stream") + ";name=" + encodeURIComponent(fl.name) + ";base64," + await blobB64(fl); if (text.length > 2500) throw new Error(t("qr_big")); } }
      if (!text) return toast(t("qr_text")); await qrLib(); const url = qrMake(text); QR.out = url;
      o.innerHTML = `<img id="qrimg" src="${url}"><div class="btns"><button class="btn" id="q_sv">${I("fetch")}${t("save2")}</button><button class="btn sec2" id="q_op">${I("open")}${t("open")}</button><button class="btn sec2" id="q_sh">${I("share")}${t("share")}</button></div>`;
      const sv = async m => { const bl = await fileBlob(url); await saveBlob(bl, "qr-" + Date.now() + ".png", m); }; $("#q_sv", o).onclick = () => sv(); $("#q_op", o).onclick = () => sv("open"); $("#q_sh", o).onclick = () => sv("share");
    } catch (e) { o.innerHTML = `<div class="hint" style="color:var(--er)">⚠ ${esc(e.message)}</div>`; }
  };
}
let QSTREAM = null, QRAF = 0;
function qrScanStop() { cancelAnimationFrame(QRAF); if (QSTREAM) { QSTREAM.getTracks().forEach(x => x.stop()); QSTREAM = null; } }
function qrScanUI(b) {
  b.innerHTML = `<div class="btns"><button class="btn" id="s_c">${I("cam")}${t("qr_cam")}</button><label class="btn sec2" style="cursor:pointer">${I("img")}${t("qr_img")}<input type="file" accept="image/*" id="s_i" style="display:none"></label></div><video id="qrv" playsinline muted style="display:none"></video><div id="s_r"></div>`;
  $("#s_c", b).onclick = async () => {
    try { await loadScript("/assets/vendor/jsQR.js"); QSTREAM = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } }); const v = $("#qrv", b); v.srcObject = QSTREAM; v.style.display = ""; await v.play(); const cv = document.createElement("canvas"), cx = cv.getContext("2d", { willReadFrequently: true });
      const tick = () => { if (!QSTREAM) return; if (v.videoWidth) { cv.width = v.videoWidth; cv.height = v.videoHeight; cx.drawImage(v, 0, 0); const r = jsQR(cx.getImageData(0, 0, cv.width, cv.height).data, cv.width, cv.height); if (r && r.data) { qrScanStop(); v.style.display = "none"; qrResult(r.data, $("#s_r", b)); return; } } QRAF = requestAnimationFrame(tick); }; tick();
    } catch (e) { toast(t("qr_nocam") + ": " + (e.message || e)); }
  };
  $("#s_i", b).onchange = async e => { const f = e.target.files[0]; if (!f) return; try { await loadScript("/assets/vendor/jsQR.js"); const u = URL.createObjectURL(f), im = new Image(); await new Promise((ok, no) => { im.onload = ok; im.onerror = no; im.src = u; });
    for (const s of [1, .5, .25]) { const cv = document.createElement("canvas"); cv.width = Math.round(im.width * s); cv.height = Math.round(im.height * s); const cx = cv.getContext("2d"); cx.drawImage(im, 0, 0, cv.width, cv.height); const r = jsQR(cx.getImageData(0, 0, cv.width, cv.height).data, cv.width, cv.height); if (r && r.data) return qrResult(r.data, $("#s_r", b)); }
    toast(t("qr_nocode")); } catch (e2) { fail(e2); } };
}
function qrResult(text, box) {
  if (!box) { openQR({ kind: "text" }); box = $("#q_body"); $$("#q_tab button").forEach(x => x.classList.toggle("on", x.dataset.v === "scan")); qrScanUI(box); box = $("#s_r"); }
  const m = /^geo:(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/i.exec(text) || /[?&@](?:mlat=|q=|ll=)?(-?\d{1,2}\.\d+)[,&]\s*(?:mlon=)?(-?\d{1,3}\.\d+)/.exec(text);
  let h = `<div class="card" style="padding:12px;margin-top:10px"><div class="hint" style="margin:0 0 6px">${t("qr_res")}</div>`, btns = [];
  if (text.startsWith("POI1:")) { let rows = []; try { rows = JSON.parse(text.slice(5)); } catch (e) { } h += rows.slice(0, 30).map(r => `<div class="row"><div class="t"><b>${esc(r[0] || "—")}</b><small>${esc(r[1])} · ${r[3]}, ${r[4]}</small></div></div>`).join(""); btns.push(["qr_addpts", "plus", async () => { await post("/api/features/add-many", { items: rows.map(r => ({ name: r[0], type: r[1], Gategory: r[2], lat: r[3], lon: r[4] })) }); await refreshDs(dsIds()); toast(t("done")); }], ["qr_show", "eye", () => { closeSheet(); const bb = new maplibregl.LngLatBounds(); rows.forEach(r => bb.extend([r[4], r[3]])); rows.forEach((r, i) => marker("q" + i, r[4], r[3])); map.fitBounds(bb, { padding: 70, maxZoom: 17 }); }]); }
  else if (/^data:image\//.test(text)) { h += `<img src="${text}" style="max-width:100%;image-rendering:pixelated">`; btns.push(["qr_savefile", "fetch", async () => saveBlob(await fileBlob(text), "qr-image-" + Date.now() + ".jpg")]); }
  else if (/^data:/.test(text)) { const nm = (/;name=([^;]+);/.exec(text) || [])[1]; h += `<div>${esc(nm ? decodeURIComponent(nm) : "file")}</div>`; btns.push(["qr_savefile", "fetch", async () => saveBlob(await fileBlob(text), nm ? decodeURIComponent(nm) : "qr-file")]); }
  else { h += `<div style="word-break:break-all;white-space:pre-wrap">${esc(text)}</div>`; if (/^https?:\/\//i.test(text)) btns.push(["qr_open", "open", () => window.open(text, "_blank")]); }
  if (m) btns.push(["qr_show", "pin", () => { closeSheet(); map.flyTo({ center: [+m[2], +m[1]], zoom: 17 }); marker("q", +m[2], +m[1]); }], ["qr_addpts", "plus", async () => { await post("/api/landmarks", { lat: +m[1], lon: +m[2], name: "", type: "", Gategory: "" }); await refreshDs(dsIds()); toast(t("done")); }]);
  btns.push(["qr_copy", "share", () => { navigator.clipboard && navigator.clipboard.writeText(text).then(() => toast(t("done"))).catch(() => { }); }]);
  box.innerHTML = h + `<div class="btns">${btns.map(([k, i, f], j) => `<button class="btn sec2" data-j="${j}">${I(i)}${t(k)}</button>`).join("")}</div></div>`;
  $$("[data-j]", box).forEach(x => x.onclick = () => Promise.resolve(btns[x.dataset.j][2]()).catch(fail));
}

/* ===== قائمة زر الموقع: إيقاف الموقع + التتبع ===== */
const TRK = { id: null, pts: [] };
function trkStop(save) {
  if (TRK.id != null) navigator.geolocation.clearWatch(TRK.id); TRK.id = null; const b = $("#trkbar"); b && b.remove(); const pts = TRK.pts.slice(); TRK.pts = [];
  if (save && pts.length >= 2) saveDraw("line", pts, () => setSrc("track")); else setSrc("track");
}
function trkStart() {
  if (!navigator.geolocation) return toast("GPS ✕"); if (TRK.id != null) return; TRK.pts = []; setSrc("track");
  const bar = el(`<div id="trkbar" class="mbar" style="bottom:calc(env(safe-area-inset-bottom) + 82px)"></div>`, document.body);
  const upd = () => { bar.innerHTML = barHtml(t("lp_track"), `${t("trk_len")}: <b>${fm(plen(TRK.pts))}</b> · ${TRK.pts.length} ${t("pts_")}`, [["tk_s", "check", t("lp_stop"), "btn"]]); $("#tk_s", bar).onclick = () => trkStop(true); }; upd();
  TRK.id = navigator.geolocation.watchPosition(p => { const ll = [p.coords.latitude, p.coords.longitude]; const last = TRK.pts[TRK.pts.length - 1]; if (!last || hav(last, ll) > 3) { TRK.pts.push(ll); setSrc("track", fc(ft({ type: "LineString", coordinates: TRK.pts.map(q => [q[1], q[0]]) }))); upd(); } marker("me", ll[1], ll[0]); map.easeTo({ center: [ll[1], ll[0]], duration: 500 }); }, e => toast("GPS: " + e.message), { enableHighAccuracy: true, maximumAge: 1000 });
}
/* ===== البوصلة ===== */
let DEVC = null;
function devCompass(on) {
  if (!on) { if (DEVC) { window.removeEventListener("deviceorientationabsolute", DEVC); window.removeEventListener("deviceorientation", DEVC); DEVC = null; } return; }
  DEVC = e => { const h = e.webkitCompassHeading != null ? e.webkitCompassHeading : (e.alpha != null ? 360 - e.alpha : null); if (h != null) map.setBearing(h); };
  window.addEventListener("deviceorientationabsolute", DEVC); window.addEventListener("deviceorientation", DEVC);
}
window.addEventListener("DOMContentLoaded", () => {
  const lp = $("#lpm"), mk = (id, ic_, key, fn) => { const b = el(`<button id="${id}">${I(ic_)}<span>${t(key)}</span></button>`, lp); b.onclick = () => { lp.style.display = "none"; fn(); }; return b; };
  mk("lp4", "off", "lp_off", () => { trkStop(false); MK.me && MK.me.remove(); delete MK.me; }); const tr = mk("lp5", "track", "lp_track", () => TRK.id != null ? trkStop(true) : trkStart());
  new MutationObserver(() => { $("span", tr).textContent = t(TRK.id != null ? "lp_stop" : "lp_track"); }).observe(lp, { attributes: true, attributeFilter: ["style"] });
  const cp = $("#compass"), cm = $("#cpm"); let tm, long = false;
  const items = () => [["compass", t("cp_north"), () => map.easeTo({ bearing: 0, pitch: 0 })], ["compass", t("cp_mode") + (DEVC ? " ✓" : ""), () => devCompass(!DEVC)], ["tilt", t("cp_tilt"), () => map.easeTo({ pitch: map.getPitch() > 5 ? 0 : 60 })]];
  cp.addEventListener("pointerdown", () => { long = false; tm = setTimeout(() => { long = true; cm.innerHTML = ""; items().forEach(([i, l, f]) => { const b = el(`<button>${I(i)}<span>${l}</span></button>`, cm); b.onclick = () => { cm.style.display = "none"; f(); }; }); cm.style.display = "block"; const r = cp.getBoundingClientRect(); cm.style.top = (r.bottom + 8) + "px"; cm.style.left = Math.max(8, r.right - cm.offsetWidth) + "px"; }, 450); });
  ["pointerup", "pointerleave"].forEach(e => cp.addEventListener(e, () => clearTimeout(tm))); cp.addEventListener("click", e => { if (long) { e.stopImmediatePropagation(); long = false; } }, true);
  document.addEventListener("pointerdown", e => { if (!cm.contains(e.target) && !cp.contains(e.target)) cm.style.display = "none"; });
});
/* ===== ملفات ونصوص واردة من أندرويد ===== */
window.__incoming = async (name, text) => {
  try {
    if (!name) { if (text) { document.body.classList.remove("dr"); qrResult(text); } return; }
    const bl = await fileBlob("/api/incoming/file/" + encodeURIComponent(name)), f = new File([bl], name);
    openSheet("inc", t("inc_t"), b => {
      b.innerHTML = `<div class="card"><div class="row"><div class="t"><b>${esc(name)}</b><small>${Math.round(bl.size / 1024)} KB</small></div></div></div><div class="btns"><button class="btn" id="in_i">${I("imp")}${t("inc_imp")}</button><button class="btn sec2" id="in_c">${I("conv")}${t("inc_cv")}</button><button class="btn sec2" id="in_m">${I("eye")}${t("inc_map")}</button></div>`;
      const done = () => del("/api/incoming/" + encodeURIComponent(name)).catch(() => { });
      $("#in_i", b).onclick = async () => { const fd = new FormData(); fd.append("file", f); fd.append("skip_dup", "0"); try { const r = await api("/api/landmarks/import", { method: "POST", body: fd }); toast(t("impdone") + " " + r.added); await refreshDs(dsIds()); done(); closeSheet(); } catch (e) { fail(e); } };
      $("#in_c", b).onclick = () => { done(); openFConv(f); };
      $("#in_m", b).onclick = async () => { const fd = new FormData(); fd.append("file", f); try { const r = await api("/api/convert2", { method: "POST", body: fd }); CV.cid = r.cid; CV.res = r; CV.file = f; done(); closeSheet(); cvMap(r.geojson); } catch (e) { fail(e); } };
    });
  } catch (e) { fail(e); }
};
