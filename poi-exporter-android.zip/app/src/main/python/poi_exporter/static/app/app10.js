"use strict";
/* ===== app10: سلسلة الخرائط (Map Series) ومكتبة الشعارات ===== */

/* ---------- مكتبة الشعارات ---------- */
const lyLogosGet = () => { try { return JSON.parse(localStorage.getItem("layout2_logos") || "[]") || []; } catch (e) { return []; } };
const lyLogosPut = a => { try { localStorage.setItem("layout2_logos", JSON.stringify(a)); return true; } catch (e) { toast(LL("تعذّر الحفظ (المساحة ممتلئة)", "Could not save (storage full)")); return false; } };
function lyLogoSave(e) {
  const url = LY.assets[e.asset]; if (!url) return toast(LL("اختر صورة أولاً", "Choose an image first")); const im = new Image();
  im.onload = () => { const s = Math.min(1, 480 / Math.max(im.naturalWidth, im.naturalHeight)), cv = document.createElement("canvas"); cv.width = Math.round(im.naturalWidth * s); cv.height = Math.round(im.naturalHeight * s); cv.getContext("2d").drawImage(im, 0, 0, cv.width, cv.height);
    const a = lyLogosGet(); a.unshift({ id: "l" + Date.now().toString(36), name: e.name, url: cv.toDataURL("image/png") }); if (lyLogosPut(a.slice(0, 16))) { toast(LL("حُفظ في مكتبة الشعارات", "Saved to logo library")); lyProps(); } };
  im.src = url;
}
function lyLogoUse(e, id) { const l = lyLogosGet().find(x => x.id === id); if (!l) return; const aid = "a" + Date.now().toString(36); LY.assets[aid] = l.url; LY.imgs[aid] = null; e.asset = aid; e.name = l.name; lySaveAssets(); lyPush(true); lyDraw(); lyProps(); }
function lyLogosHtml() {
  const a = lyLogosGet(); if (!a.length) return ""; return `<div class="lyfb"><div class="hint">${LL("مكتبة الشعارات (اضغط للاستخدام، اضغط مطولاً للحذف)", "Logo library (tap to use, long-press to delete)")}</div><div class="lylogos">${a.map(l => `<button type="button" data-lg="${l.id}"><img src="${l.url}" alt=""></button>`).join("")}</div></div>`;
}
function lyLogosBind(P, e) {
  $$("[data-lg]", P).forEach(b => { let tm, long = false; b.onpointerdown = () => { long = false; tm = setTimeout(() => { long = true; lyConfirm(LL("حذف الشعار من المكتبة؟", "Delete logo from library?"), () => { lyLogosPut(lyLogosGet().filter(x => x.id !== b.dataset.lg)); lyProps(); }); }, 700); }; b.onpointerup = b.onpointerleave = () => clearTimeout(tm); b.onclick = () => { if (!long) lyLogoUse(e, b.dataset.lg); }; });
  const s = $("[data-a=logosave]", P); if (s) s.onclick = () => lyLogoSave(e);
}

/* ---------- سلسلة الخرائط ---------- */
const lyBBox = g => { let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9; const w = c => { if (typeof c[0] === "number") { x0 = Math.min(x0, c[0]); x1 = Math.max(x1, c[0]); y0 = Math.min(y0, c[1]); y1 = Math.max(y1, c[1]); } else c.forEach(w); }; if (g && g.coordinates) w(g.coordinates); return x1 < x0 ? null : [x0, y0, x1, y1]; };
function lySeriesPages(o) {
  const cv = map.getCanvas(), el = lyRefMap(), fa = el ? el.w / el.h : cv.clientWidth / cv.clientHeight, ca = cv.clientWidth / cv.clientHeight, vw = fa >= ca ? cv.clientWidth : cv.clientHeight * fa, pages = [];
  const zFor = (spanLon, lat) => Math.log2(vw * 360 / (spanLon * 512));
  if (o.src === "grid") {
    const b = map.getBounds(), W = 512, x0 = mXf(b.getWest(), W), x1 = mXf(b.getEast(), W), y0 = mYf(b.getNorth(), W), y1 = mYf(b.getSouth(), W), C = Math.max(1, o.cols), tw = (x1 - x0) / C, th = tw / fa, R = Math.max(1, Math.ceil((y1 - y0) / th - 1e-6));
    for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) { const cx = x0 + tw * (c + .5), cy = y0 + th * (r + .5), lng = uXf(cx, W), lat = uYf(cy, W); pages.push({ name: LL(`صفحة ${pages.length + 1}`, `Page ${pages.length + 1}`), center: [lng, lat], zoom: zFor(tw / W * 360, lat) }); }
  } else {
    const g = GJ[o.ds]; if (!g) return [];
    g.features.forEach((f, i) => { if (!f.geometry || !/Polygon/.test(f.geometry.type)) return; const bb = lyBBox(f.geometry); if (!bb) return; const lat = (bb[1] + bb[3]) / 2, lonSpan = Math.max(bb[2] - bb[0], (bb[3] - bb[1]) / fa * 1) * (1 + o.pad / 100); pages.push({ name: (f.properties && (f.properties.name || f.properties.Nahia || f.properties.qadaa)) || LL(`عنصر ${i + 1}`, `Item ${i + 1}`), center: [(bb[0] + bb[2]) / 2, lat], zoom: zFor(lonSpan, lat) }); });
  }
  return pages;
}
async function lySeriesRun(o, ui) {
  const pages = lySeriesPages(o); if (!pages.length) { ui.msg(LL("لا توجد صفحات (تحقق من المصدر)", "No pages (check the source)")); return; } if (pages.length > 80) { ui.msg(LL("العدد كبير (>80). قلّل الأعمدة أو اختر طبقة أصغر.", "Too many pages (>80).")); return; }
  const v0 = { center: map.getCenter(), zoom: map.getZoom(), bearing: map.getBearing(), pitch: map.getPitch() }, out = [], D = lyDims(o.dpi), [pw, ph] = lyPaper(); LY.sel = null; ui.running = true;
  try {
    for (let i = 0; i < pages.length && !ui.cancel; i++) {
      const pg = pages[i]; ui.msg(LL(`جارٍ إنشاء الصفحة ${i + 1} من ${pages.length}…`, `Building page ${i + 1} of ${pages.length}…`), (i / pages.length) * 100);
      map.jumpTo({ center: pg.center, zoom: lyClamp(pg.zoom, 0, 20), bearing: 0, pitch: 0 }); await lyIdle(7000); LY.series = { i: i + 1, n: pages.length, name: pg.name };
      const m = LY.els.filter(e => e.type === "map" && (e.cid || "main") === "main"); m.forEach(e => { e.iz = 1; e.ox = 0; e.oy = 0; }); await lyCapture("main", true);
      const bl = await lyRender(o.dpi, "jpg"); out.push({ jpg: new Uint8Array(await bl.arrayBuffer()), wp: D.w, hp: D.h });
    }
    if (out.length && !ui.cancel) { const blob = makePdfMulti(out, pw, ph); ui.msg(LL("تم — جارٍ الحفظ…", "Done — saving…"), 100); await saveBlob(blob, (o.name || "map-series") + ".pdf", "save"); ui.msg(LL(`اكتملت ${out.length} صفحة`, `${out.length} pages done`), 100); }
    else ui.msg(LL("أُلغيت العملية", "Cancelled"));
  } catch (e) { ui.msg("⚠ " + (e.message || e)); } finally { LY.series = null; map.jumpTo(v0); ui.running = false; await lyCapture("main", true); lyDraw(); }
}
function lySeriesDlg() {
  if (!lyRefMap()) return toast(LL("أضف إطار خريطة أولاً", "Add a map frame first"));
  const polys = S.ds.filter(d => d.kind !== "reference" && GJ[d.id] && GJ[d.id].features.some(f => f.geometry && /Polygon/.test(f.geometry.type)));
  lyDlg(LL("سلسلة خرائط (Map Series)", "Map Series"), b => {
    b.innerHTML = `<div class="hint">${LL("ينشئ ملف PDF متعدد الصفحات بنفس التخطيط الحالي؛ كل صفحة تلتقط جزءاً مختلفاً. استخدم {page} و{pages} و{name} في النصوص لعرض رقم الصفحة واسمها.", "Creates a multi-page PDF using the current layout; each page captures a different part. Use {page}, {pages} and {name} in text elements.")}</div>
      <div class="lyg"><label class="lyf lyfb"><span>${LL("المصدر", "Source")}</span><select id="sr_s"><option value="grid">${LL("تقسيم المنطقة المعروضة حالياً إلى شبكة", "Split the current view into a grid")}</option>${polys.length ? `<option value="layer">${LL("صفحة لكل مضلع في طبقة", "One page per polygon in a layer")}</option>` : ""}</select></label>
      <label class="lyf" id="sr_g"><span>${LL("عدد الأعمدة", "Columns")}</span><input type="number" id="sr_c" value="2" min="1" max="8"></label>
      <label class="lyf" id="sr_l" style="display:none"><span>${LL("الطبقة", "Layer")}</span><select id="sr_d">${polys.map(d => `<option value="${d.id}">${esc6(d.label)}</option>`).join("")}</select></label>
      <label class="lyf" id="sr_p" style="display:none"><span>${LL("هامش حول المضلع %", "Padding %")}</span><input type="number" id="sr_pd" value="15" min="0" max="100"></label>
      <label class="lyf"><span>${LL("الدقة DPI", "DPI")}</span><select id="sr_dpi">${[96, 150, 200, 300].map(d => `<option${d === 150 ? " selected" : ""}>${d}</option>`).join("")}</select></label>
      <label class="lyf lyfb"><span>${LL("اسم الملف", "File name")}</span><input class="in" id="sr_n" value="map-series"></label>
      <div class="lyfb"><div class="bar" id="sr_b" style="height:8px;background:var(--sf2);border-radius:6px;overflow:hidden"><i style="display:block;height:100%;width:0;background:var(--pr)"></i></div><div class="hint" id="sr_m"></div></div></div>
      <div class="btns"><button class="btn" id="sr_go">${I("open")}${LL("ابدأ", "Start")}</button><button class="btn sec2" id="sr_x">${LL("إلغاء", "Cancel")}</button></div>`;
    const ui = { cancel: false, running: false, msg: (m, p) => { $("#sr_m", b).textContent = m; if (p != null) $("#sr_b i", b).style.width = p + "%"; } };
    $("#sr_s", b).onchange = ev => { const l = ev.target.value === "layer"; $("#sr_g", b).style.display = l ? "none" : ""; $("#sr_l", b).style.display = $("#sr_p", b).style.display = l ? "" : "none"; };
    $("#sr_x", b).onclick = () => { if (ui.running) ui.cancel = true; else $(".lyd").remove(); };
    $("#sr_go", b).onclick = () => { if (ui.running) return; ui.cancel = false; const d = $("#sr_d", b); lySeriesRun({ src: $("#sr_s", b).value, cols: +$("#sr_c", b).value || 1, ds: d ? d.value : "", pad: +$("#sr_pd", b).value || 0, dpi: +$("#sr_dpi", b).value, name: $("#sr_n", b).value }, ui); };
  });
}

/* ---------- فحص الجودة (أداة في قائمة الأدوات) ---------- */
function openQuality() {
  const ds = S.ds.filter(d => d.kind !== "reference"); if (!ds.length) return toast(t("nol"));
  openSheet("qual", LL("فحص جودة البيانات", "Data quality check"), b => {
    b.innerHTML = `<label class="f">${LL("الطبقة", "Layer")}</label><select class="in" id="qc_d">${ds.map(d => `<option value="${d.id}">${esc6(d.label)}</option>`).join("")}</select><div class="btns"><button class="btn" id="qc_go">${I("check")}${LL("افحص", "Check")}</button></div><pre class="hint" id="qc_r" style="white-space:pre-wrap;direction:rtl"></pre><div class="btns" id="qc_b" style="display:none"><button class="btn er" id="qc_dd">${I("trash")}${LL("حذف المكررات", "Remove duplicates")}</button></div>`;
    $("#qc_go", b).onclick = async () => { try { const id = $("#qc_d", b).value, r = await api(`/api/datasets/${id}/quality`); $("#qc_r", b).textContent = r.text + "\n\n" + (r.problems ? LL(`⚠ مشاكل: ${r.problems}`, `⚠ Problems: ${r.problems}`) : LL("✔ لا مشاكل", "✔ No problems")); $("#qc_b", b).style.display = r.dup_ids.length ? "" : "none"; } catch (e) { fail(e); } };
    $("#qc_dd", b).onclick = () => lyConfirm0(LL("سيُحذف كل عنصر مكرر ويُبقى الأول (يمكن التراجع من سجل التغييرات). متابعة؟", "Extra duplicates will be removed (undo is available in History). Continue?"), async () => { try { const r = await post(`/api/datasets/${$("#qc_d", b).value}/dedupe`, {}); toast(LL(`حُذف ${r.removed}`, `Removed ${r.removed}`)); await refreshDs(dsIds()); $("#qc_go", b).click(); } catch (e) { fail(e); } });
  });
}
const lyConfirm0 = (m, ok) => { if (window.confirm(m)) ok(); };
const _openTools10 = openTools;
openTools = async function () {
  await _openTools10(); const b = $("#sh-b"); if (SHEET !== "tools" || !b) return; const g = $(".grid", b); if (!g || $("#tl_qc", b)) return;
  const x = el(`<button class="tile" id="tl_qc">${I("check")}<span>${LL("فحص الجودة", "Quality check")}</span></button>`, g); x.onclick = openQuality;
};
