"use strict";
/* ===== app11: تقرير المشكلة، تجميع الأدوات، شاشة البدء، تنسيق الرموز حسب القيمة ===== */

/* ---------- التقاط أخطاء الواجهة + تقرير المشكلة ---------- */
const _ce = [];
function clientErr(w, m) {
  const line = new Date().toTimeString().slice(0, 8) + " " + w + ": " + m; if (_ce[_ce.length - 1] === line) return; _ce.push(line); if (_ce.length > 100) _ce.shift();
  try { fetch("/api/clienterror", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ m: w + ": " + m }) }).catch(() => { }); } catch (e) { }
}
window.addEventListener("error", e => clientErr("js", (e.message || "") + " @" + String(e.filename || "").split("/").pop() + ":" + e.lineno));
window.addEventListener("unhandledrejection", e => clientErr("promise", String(e.reason && e.reason.message || e.reason)));
async function problemReport() {
  let sv = ""; try { sv = (await api("/api/diag")).text; } catch (e) { sv = "(server) " + e.message; }
  const txt = ["POI Exporter — problem report", new Date().toISOString(), "UA: " + navigator.userAgent, `screen: ${innerWidth}x${innerHeight} dpr ${devicePixelRatio}`, `lang/theme: ${S.set.lang}/${S.set.theme}`, "", "== client errors ==", ..._ce, "", "== server ==", sv].join("\n");
  try { await saveBlob(new Blob([txt], { type: "text/plain" }), "problem-report.txt", "share"); } catch (e) { fail(e); }
}

/* ---------- تنسيق الرموز حسب القيمة (Symbology) ---------- */
const SYMPAL = ["#e03131", "#1c7ed6", "#2f9e44", "#f08c00", "#7048e8", "#0ca678", "#d6336c", "#495057", "#a61e4d", "#1864ab", "#5c940d", "#e8590c", "#364fc7", "#087f5b", "#c2255c", "#868e96"];
let SYM = null;
const symAll = () => { if (!SYM) { try { SYM = JSON.parse(localStorage.getItem("symbology") || "{}") || {}; } catch (e) { SYM = {}; } } return SYM; };
const symPut = () => { try { localStorage.setItem("symbology", JSON.stringify(SYM || {})); } catch (e) { } };
const _dec11 = decorate;
decorate = function (g, d) {
  _dec11(g, d); const sy = symAll()[d.id]; if (!sy || !sy.f) return;
  g.features.forEach(f => { const p = f.properties || {}, v = p[sy.f], c = sy.c[v == null || v === "" ? "—" : v]; if (c) { p.color = c; if (p._ic) { const q = p._ic.split("|"); if (q.length >= 3) { q[2] = c; p._ic = q.join("|"); } } } });
};
function openSym() {
  const ds = S.ds.filter(d => d.kind !== "reference"); if (!ds.length) return toast(t("nodata"));
  const F = ["Gategory", "type", "Nahia", "gathaa", "mohafadha", "name"];
  openSheet("sym", LL("تنسيق الرموز حسب القيمة", "Symbology by value"), b => {
    b.innerHTML = `<label class="f">${LL("الطبقة", "Layer")}</label><select class="in" id="sy_d">${ds.map(d => `<option value="${d.id}">${esc6(d.label)}</option>`).join("")}</select>
      <label class="f">${LL("الحقل", "Field")}</label><select class="in" id="sy_f">${F.map(k => `<option value="${k}">${t(k)}</option>`).join("")}</select>
      <div class="btns"><button class="btn sec2" id="sy_a">${LL("ألوان تلقائية", "Auto colours")}</button><button class="btn sec2" id="sy_r">${LL("إلغاء التنسيق", "Reset")}</button></div><div id="sy_l"></div>
      <div class="btns"><button class="btn" id="sy_go">${I("check")}${LL("تطبيق", "Apply")}</button></div>`;
    let cur = {}, vals = [];
    const load = async () => {
      const id = $("#sy_d", b).value, d = S.ds.find(x => x.id === id); await ensureDs(d); const f = $("#sy_f", b).value, cnt = {};
      GJ[id].features.forEach(x => { const v = x.properties && x.properties[f]; const k = v == null || v === "" ? "—" : v; cnt[k] = (cnt[k] || 0) + 1; });
      vals = Object.keys(cnt).sort((p, q) => cnt[q] - cnt[p]).slice(0, 40); const sy = symAll()[id]; cur = sy && sy.f === f ? Object.assign({}, sy.c) : {};
      vals.forEach((v, i) => { if (!cur[v]) cur[v] = SYMPAL[i % SYMPAL.length]; });
      $("#sy_l", b).innerHTML = vals.map((v, i) => `<div class="lgr"><input type="color" data-v="${i}" value="${lyHex(cur[v])}"><span style="flex:1">${esc6(v)}</span><b>${cnt[v]}</b></div>`).join("") || `<div class="hint">${LL("لا توجد قيم", "No values")}</div>`;
      $$("[data-v]", b).forEach(i => i.oninput = () => { cur[vals[+i.dataset.v]] = i.value; });
    };
    $("#sy_d", b).onchange = load; $("#sy_f", b).onchange = load; load();
    $("#sy_a", b).onclick = () => { vals.forEach((v, i) => cur[v] = SYMPAL[i % SYMPAL.length]); $$("[data-v]", b).forEach(i => i.value = cur[vals[+i.dataset.v]]); };
    $("#sy_go", b).onclick = () => { symAll()[$("#sy_d", b).value] = { f: $("#sy_f", b).value, c: cur }; symPut(); restyleAll(); toast(t("done")); };
    $("#sy_r", b).onclick = () => { delete symAll()[$("#sy_d", b).value]; symPut(); GJ[$("#sy_d", b).value] && (async () => { await refreshDs([$("#sy_d", b).value]); })(); toast(t("done")); load(); };
  });
}

/* ---------- تجميع الأدوات في أقسام ---------- */
const TGROUPS = [
  [["قياس وتحليل", "Measure & analyse"], /تحديد بالشروط|select by|تحديد مكاني|spatial filter|الشبكة|network|نقاط موزعة|construct|إلى مضلعات|إلى خطوط|to polygon|to line|كثافة|heatmap|قياس|مسطرة|measure|ruler|تحليل|analy|spatial|فحص|quality|مسار|track|route|طريق|road/i],
  [["رسم وتحرير", "Draw & edit"], /تنقيط|digit|دمج|merge|رسوم|draw|مسح|clear|تنسيق|symbol/i],
  [["بيانات وملفات", "Data & files"], /محوّل|convert|XY|إلحاق|append|استعلام التعريف|definition|باركود|barcode|qr|لصق|paste|نسخة|backup|restore|استعادة|بلا إنترنت|offline/i],
  [["عرض وإخراج", "Display & output"], /layout|أسماء|names/i],
  [["السجل", "History"], /تراجع|إعادة|سجل|undo|redo|hist/i],
  [["مساعدة", "Help"], /تقرير مشكلة|problem|ما الجديد|what/i]
];
const _openTools11 = openTools;
openTools = async function () {
  await _openTools11(); const b = $("#sh-b"); if (SHEET !== "tools" || !b) return; const g = $(".grid", b); if (!g || g.dataset.grouped) return;
  const add = (id, ic, ar, en, fn) => { if (!$("#" + id, g)) { const x = el(`<button class="tile" id="${id}">${I(ic)}<span>${LL(ar, en)}</span></button>`, g); x.onclick = fn; } };
  add("tl_sym", "tag", "تنسيق حسب القيمة", "Symbology", openSym); add("tl_rep", "report", "تقرير مشكلة", "Problem report", problemReport); add("tl_new", "star", "ما الجديد", "What's new", () => showWelcome(true));
  const tiles = $$(".tile", g), buckets = TGROUPS.map(() => []), other = [];
  tiles.forEach(x => { const i = TGROUPS.findIndex(gr => gr[1].test(x.textContent)); (i < 0 ? other : buckets[i]).push(x); });
  g.dataset.grouped = 1; g.innerHTML = ""; g.style.display = "block";
  const sec = (name, arr) => { if (!arr.length) return; el(`<div class="sec">${name}</div>`, g); const gg = el(`<div class="grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:8px"></div>`, g); arr.forEach(x => gg.appendChild(x)); };
  TGROUPS.forEach((gr, i) => sec(LL(gr[0][0], gr[0][1]), buckets[i])); sec(LL("أخرى", "Other"), other);
};

/* ---------- شاشة البدء / ما الجديد ---------- */
const APP_VER = "3.13";
function showWelcome(force) {
  let seen = ""; try { seen = localStorage.getItem("seen_ver") || ""; } catch (e) { } if (!force && seen === APP_VER) return; if ($("#wel")) return;
  const w = el(`<div id="wel"><div class="wbox"><h2>${LL("مرحباً بك 👋", "Welcome 👋")}</h2><div class="hint">${LL("ابدأ من هنا:", "Start here:")}</div>
    <div class="wgrid"><button data-w="fetch">${I("fetch")}<span>${LL("جلب معالم", "Fetch landmarks")}</span></button><button data-w="add">${I("plus")}<span>${LL("إضافة معلم", "Add landmark")}</span></button><button data-w="conv">${I("conv")}<span>${LL("تحويل إحداثيات", "Convert coordinates")}</span></button><button data-w="lay">${I("report")}<span>Layout</span></button></div>
    <div class="sec">${LL("الجديد في " + APP_VER, "New in " + APP_VER)}</div><ul class="wnew"><li>${LL("Layout بواجهة نظيفة: عناصر عائمة، 13 سهم شمال، 9 مقاييس، شبكة UTM", "Clean Layout: floating elements, 13 north arrows, 9 scale bars, UTM grid")}</li><li>${LL("سلسلة خرائط: PDF متعدد الصفحات", "Map series: multi-page PDF")}</li><li>${LL("فحص الجودة وحذف المكررات", "Quality check & duplicate removal")}</li><li>${LL("تنسيق الرموز حسب القيمة", "Symbology by value")}</li><li>${LL("نسخة احتياطية تشمل الرسومات والتخطيطات", "Backups now include drawings & layouts")}</li><li>${LL("إعدادات بتبويبات، 9 أدوات GIS جديدة (استعلام التعريف، XY، نقاط موزعة، إلحاق، مضلعات/خطوط، تحديد مكاني، طريق عبر الشوارع، تحليل الشبكة)", "Tabbed settings and 9 new GIS tools")}</li><li>${LL("تصدير PostGIS (SQL) وDXF للـ CAD", "PostGIS (SQL) and DXF (CAD) export")}</li><li>${LL("تصدير Layout بصيغة SVG متجهية قابلة للتحرير", "Vector SVG export for Layout")}</li><li>${LL("خريطة الكثافة (Heatmap)", "Heatmap")}</li><li>${LL("تحديد بالشروط وإحصاء الحقول", "Select by attributes & field stats")}</li><li>${LL("رسائل أخطاء مفهومة وتقرير مشكلة", "Clear error messages & problem report")}</li></ul>
    <button class="btn" data-w="ok">${LL("ابدأ الاستخدام", "Get started")}</button></div></div>`, document.body);
  const done = () => { try { localStorage.setItem("seen_ver", APP_VER); } catch (e) { } w.remove(); };
  $$("[data-w]", w).forEach(b => b.onclick = () => { const k = b.dataset.w; done(); if (k === "fetch") openFetch(); else if (k === "add") openAdd(); else if (k === "conv") openConv(); else if (k === "lay") openLayout(); });
}
window.addEventListener("load", () => setTimeout(() => { try { showWelcome(false); } catch (e) { } }, 1800));
