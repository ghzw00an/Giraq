"use strict";
/* ===== app8: Layout — الواجهة (اللوحات، النوافذ، القوالب، اللمس) ===== */
Object.assign(ICONS, { map: "M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2zM9 4v14M15 6v14", back: "M15 5l-7 7 7 7" });

/* ---------------- نوافذ داخلية ---------------- */
function lyDlg(title, build) {
  const root = $("#lyroot"); if (!root) return null; $$(".lyd", root).forEach(x => x.remove());
  const d = el(`<div class="lyd"><div class="lyds"><div class="lydh"><b>${esc6(title)}</b><button class="lyi" data-x>${I("x")}</button></div><div class="lydb"></div></div></div>`, root), close = () => d.remove();
  $("[data-x]", d).onclick = close; d.addEventListener("pointerdown", ev => { if (ev.target === d) close(); }); build($(".lydb", d), close); return { el: d, close };
}
function lyConfirm(msg, ok) {
  lyDlg(LL("تأكيد", "Confirm"), (b, close) => { b.innerHTML = `<div class="hint" style="font-size:15px;margin-bottom:12px">${esc6(msg)}</div><div class="btns"><button class="btn sec2" data-n>${LL("إلغاء", "Cancel")}</button><button class="btn er" data-y>${LL("متابعة", "Continue")}</button></div>`; $("[data-n]", b).onclick = close; $("[data-y]", b).onclick = () => { close(); ok(); }; });
}
function lyUpd() {
  const u = $("#ly_un"), r = $("#ly_re"), i = $("#ly_info"); if (u) u.disabled = LY.hi <= 0; if (r) r.disabled = LY.hi >= LY.hist.length - 1;
  if (i) { const [pw, ph] = lyPaper(); i.textContent = `${LY.paper === "custom" ? LL("مخصص", "Custom") : LY.paper} • ${Math.round(pw)}×${Math.round(ph)} mm • ${LY.ori === "p" ? LL("عمودي", "Portrait") : LL("أفقي", "Landscape")}`; }
}
const lyChanged = () => { lyDraw(); lyPush(); };
function lyMoveZ(e, dir) { const a = lySorted(), i = a.indexOf(e), j = dir === "top" ? a.length - 1 : dir === "bot" ? 0 : lyClamp(i + (dir === "up" ? 1 : -1), 0, a.length - 1); a.splice(i, 1); a.splice(j, 0, e); a.forEach((o, n) => o.z = n + 1); }
function lyDelete(e) { LY.els = LY.els.filter(o => o !== e); LY.sel = null; lyPush(true); lyDraw(); lyProps(); }
function lyDup(e) { const n = JSON.parse(JSON.stringify(e)); n.id = lyId(); n.x += 4; n.y += 4; n.z = Math.max(...LY.els.map(o => o.z)) + 1; n.lock = false; LY.els.push(n); LY.sel = n.id; lyPush(true); lyDraw(); lyProps(); }
function lyAlign(e, a) {
  const [pw, ph] = lyPaper(), m = LY.margin || 0;
  if (a === "l") e.x = m; else if (a === "c") e.x = (pw - e.w) / 2; else if (a === "r") e.x = pw - m - e.w; else if (a === "t") e.y = m; else if (a === "m") e.y = (ph - e.h) / 2; else e.y = ph - m - e.h;
}
function lyChooseImage(e) {
  const f = document.createElement("input"); f.type = "file"; f.accept = "image/*";
  f.onchange = () => {
    const file = f.files && f.files[0]; if (!file) return; const r = new FileReader();
    r.onload = () => { const im = new Image(); im.onerror = () => toast(LL("تعذّر قراءة الصورة", "Could not read the image")); im.onload = () => {
      const s = Math.min(1, 1600 / Math.max(im.naturalWidth, im.naturalHeight)), cv = document.createElement("canvas"); cv.width = Math.round(im.naturalWidth * s); cv.height = Math.round(im.naturalHeight * s); cv.getContext("2d").drawImage(im, 0, 0, cv.width, cv.height);
      const id = "a" + Date.now().toString(36); LY.assets[id] = cv.toDataURL(/png|svg|gif|webp/.test(file.type) ? "image/png" : "image/jpeg", .9); LY.imgs[id] = null; e.asset = id; if (e.name === LL(LYD.image.ar, LYD.image.en)) e.name = file.name.replace(/\.[^.]+$/, "").slice(0, 24); lySaveAssets(); lyPush(true); lyDraw(); lyProps();
    }; im.src = r.result; }; r.readAsDataURL(file);
  }; f.click();
}
function lyMergeItems(old, nw) { const m = {}; (old || []).forEach(o => m[o.label] = o); return nw.map(n => m[n.label] ? Object.assign(n, { on: m[n.label].on }) : n); }

/* ---------------- لوحة الخصائص ---------------- */
function lyF(e) {
  const f = {};
  f.N = (k, lab, st, mn, mx) => `<label class="lyf"><span>${lab}</span><input type="number" inputmode="decimal" data-k="${k}" step="${st || 1}"${mn != null ? ` min="${mn}"` : ""}${mx != null ? ` max="${mx}"` : ""} value="${lyN(e[k])}"></label>`;
  f.R = (k, lab, mn, mx, st) => `<label class="lyf"><span>${lab} <b class="lyv" data-v="${k}">${lyN(e[k])}</b></span><input type="range" data-k="${k}" min="${mn}" max="${mx}" step="${st}" value="${e[k] == null ? mn : e[k]}"></label>`;
  f.C = (k, lab) => `<div class="lyf"><span>${lab}</span><span class="lycw"><input type="color" data-k="${k}" value="${lyHex(e[k])}">${LYCOL.map(c => `<i data-sw="${c}" style="background:${c}"></i>`).join("")}</span></div>`;
  f.B = (k, lab) => `<label class="lyf chk"><input type="checkbox" data-k="${k}" ${e[k] ? "checked" : ""}><span>${lab}</span></label>`;
  f.S = (k, lab, o, n) => `<label class="lyf"><span>${lab}</span><select data-k="${k}"${n ? ' data-n="1"' : ""}>${o.map(([v, l]) => `<option value="${esc6(v)}"${String(e[k]) === String(v) ? " selected" : ""}>${esc6(l)}</option>`).join("")}</select></label>`;
  f.G = (k, lab, o, n, re) => `<div class="lyf"><span>${lab}</span><div class="lysg">${o.map(([v, l]) => `<button type="button" data-sg="${k}" data-v="${esc6(v)}"${n ? ' data-n="1"' : ""}${re ? ' data-re="1"' : ""} class="${String(e[k]) === String(v) ? "on" : ""}">${l}</button>`).join("")}</div></div>`;
  f.T = (k, lab) => `<label class="lyf lyfb"><span>${lab}</span><input class="in" data-k="${k}" value="${esc6(e[k])}"></label>`;
  return f;
}
function lyTabs(e) {
  const L = { cnt: LL("المحتوى", "Content"), txt: LL("الخط", "Font"), pos: LL("الموضع", "Position"), frm: LL("الإطار", "Frame") };
  const K = { map: ["cnt", "pos", "frm"], text: ["cnt", "txt", "pos", "frm"], legend: ["cnt", "txt", "pos", "frm"], north: ["cnt", "pos", "frm"], scale: ["cnt", "txt", "pos", "frm"], image: ["cnt", "pos", "frm"], symbol: ["cnt", "pos", "frm"], qr: ["cnt", "pos", "frm"], table: ["cnt", "txt", "pos", "frm"], shape: e.kind === "line" || e.kind === "arrow" ? ["cnt", "pos"] : ["cnt", "pos", "frm"] }[e.type] || ["pos"];
  return K.map(k => [k, L[k]]);
}
function lyCnt(e, f) {
  switch (e.type) {
    case "map": {
      const inf = lyScaleInfo(e), maps = LY.els.filter(m => m.type === "map" && m !== e), gr = e.gr && e.gr !== "off";
      return `<div class="lyg"><button class="btn lyfb" data-a="cap">${I("camera")}<span>${LL("التقاط الخريطة المعروضة الآن", "Capture the map shown now")}</span></button>
        <label class="lyf"><span>${LL("جودة الالتقاط", "Capture quality")}</span><select data-g="q" data-n="1">${[[1, "×1 " + LL("عادية", "normal")], [2, "×2 " + LL("عالية", "high")], [3, "×3 " + LL("فائقة", "ultra")]].map(o => `<option value="${o[0]}"${+LY.q === o[0] ? " selected" : ""}>${o[1]}</option>`).join("")}</select></label>
        <button type="button" class="chip${LY.mpan ? " on" : ""}" data-a="mpan">${LL("تحريك الخريطة داخل الإطار (سحب / قرص)", "Pan / zoom map inside frame")}</button>
        <button class="btn sec2" data-a="fit">${LL("ملاءمة الخريطة", "Fit map")}</button><button class="btn sec2" data-a="full">${LL("ملء الصفحة", "Fill page")}</button>
        <label class="lyf"><span>${LL("مقياس الرسم 1 :", "Scale 1 :")}</span><input type="number" id="ly_sc" value="${inf ? Math.round(inf.mmpp * 1000) : ""}"></label><button class="btn sec2" data-a="setsc">${LL("تطبيق المقياس", "Apply scale")}</button>
        ${f.R("iz", LL("تكبير داخل الإطار", "Zoom in frame"), .2, 8, .01)}${f.R("ox", LL("إزاحة أفقية %", "Shift X %"), -100, 100, 1)}${f.R("oy", LL("إزاحة رأسية %", "Shift Y %"), -100, 100, 1)}
        ${f.G("gr", LL("شبكة الإحداثيات", "Graticule"), [["off", LL("إيقاف", "Off")], ["lines", LL("خطوط", "Lines")], ["ticks", LL("حواف", "Ticks")], ["crosses", LL("صلبان", "Crosses")]], 0, 1)}
        ${gr ? f.G("gf", LL("الصيغة", "Format"), [["dd", "DD"], ["dms", "DMS"]]) + f.N("gn", LL("عدد الخطوط تقريباً", "Approx. lines"), 1, 2, 12) + f.C("gc", LL("لون الشبكة", "Grid colour")) + f.N("gw", LL("سماكة الخط mm", "Line mm"), .05, .05, 2) + f.N("gz", LL("حجم الإحداثيات pt", "Label pt"), .5, 3, 30) : ""}
        ${maps.length ? f.S("ind", LL("إظهار نطاق خريطة أخرى", "Show extent of another map"), [["", LL("بدون", "None")]].concat(maps.map(m => [m.id, m.name]))) : ""}</div>`;
    }
    case "north": return `<div class="lynth">${NORTHS.map(s => `<button type="button" data-ns="${s}" class="${e.style === s ? "on" : ""}"><canvas width="96" height="96" data-nc="${s}"></canvas></button>`).join("")}</div><div class="lyg">${f.G("lt", LL("الحرف", "Letter"), [["N", "N"], ["ش", "ش"], ["", LL("بدون", "None")]], 0, 1)}${f.C("color", LL("لون السهم", "Arrow colour"))}${f.B("fr", LL("يتبع دوران الخريطة", "Follow map rotation"))}</div>`;
    case "scale": return `<div class="lyg">${f.S("style", LL("النمط", "Style"), SCALES.map(s => [s[0], LL(s[1], s[2])]))}${f.S("unit", LL("الوحدة", "Unit"), [["auto", LL("تلقائي", "Auto")], ["m", LL("متر", "Metre")], ["km", LL("كيلومتر", "Kilometre")], ["mi", LL("ميل", "Mile")], ["ft", LL("قدم", "Foot")]])}${f.S("div", LL("عدد التقسيمات", "Divisions"), [1, 2, 3, 4, 5, 6, 8, 10].map(n => [n, n]), 1)}${f.B("ratio", LL("إظهار النسبة 1:x", "Show ratio 1:x"))}${f.C("color", LL("لون المقياس", "Scale colour"))}</div>`;
    case "legend": return `<div class="lyg">${f.T("text", LL("عنوان المفتاح", "Legend title"))}${f.G("cols", LL("الأعمدة", "Columns"), [[1, 1], [2, 2], [3, 3]], 1)}${f.N("ss", LL("حجم الرموز", "Symbol size"), .1, .5, 3)}<button class="btn sec2 lyfb" data-a="lgr">${LL("تحديث من الخريطة", "Refresh from map")}</button><div class="lyfb" id="lg_it">${(e.items || []).map((it, i) => `<div class="lgr"><input type="checkbox" data-li="${i}" ${it.on ? "checked" : ""}><input class="in" data-lt="${i}" value="${esc6(it.label)}"><input type="color" data-lc="${i}" value="${lyHex(it.color)}"></div>`).join("") || `<div class="hint">${LL("لا توجد طبقات معروضة", "No visible layers")}</div>`}</div></div>`;
    case "text": return `<div class="lyg"><label class="lyf lyfb"><span>${LL("النص", "Text")}</span><textarea class="in ta" data-k="text" rows="3">${esc6(e.text)}</textarea></label><div class="lyfb lytk">${["date", "time", "scale", "center", "zoom", "paper"].map(k => `<button type="button" class="chip" data-tk="{${k}}">{${k}}</button>`).join("")}</div>${f.B("auto", LL("ارتفاع تلقائي حسب النص", "Auto height"))}</div>`;
    case "image": return `<div class="lyg"><button class="btn lyfb" data-a="img">${I("img")}<span>${e.asset ? LL("تغيير الصورة", "Change image") : LL("اختيار صورة / شعار", "Choose image / logo")}</span></button>${f.G("fit", LL("الملاءمة", "Fit"), [["contain", LL("احتواء", "Contain")], ["cover", LL("تغطية", "Cover")], ["stretch", LL("تمديد", "Stretch")]])}${f.B("gray", LL("أبيض وأسود", "Greyscale"))}<div class="hint lyfb">${LL("من تبويب «الإطار»: لون الإطار وسماكته ونمطه والزوايا والشكل الدائري والظل والخلفية.", "Use the Frame tab for border colour, width, style, corners, round shape, shadow and background.")}</div></div>`;
    case "symbol": return `<div class="lygl">${Object.keys(GL).map(k => `<button type="button" data-gl="${k}" class="${e.glyph === k ? "on" : ""}" title="${esc6(GL[k][0])}"><svg viewBox="0 0 24 24"><path d="${GL[k][1]}" fill="${FILLED.has(k) ? "currentColor" : "none"}" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg></button>`).join("")}</div><div class="lyg">${f.C("color", LL("لون الرمز", "Symbol colour"))}</div>`;
    case "shape": { const ln = e.kind === "line" || e.kind === "arrow"; return `<div class="lyg">${f.G("kind", LL("الشكل", "Shape"), [["rect", LL("مستطيل", "Rect")], ["ellipse", LL("قطع", "Ellipse")], ["line", LL("خط", "Line")], ["arrow", LL("سهم", "Arrow")]], 0, 1)}${ln ? f.C("bc", LL("لون الخط", "Line colour")) + f.N("bw", LL("السماكة mm", "Width mm"), .1, .1, 10) + f.S("bs", LL("النمط", "Style"), [["solid", LL("متصل", "Solid")], ["dashed", LL("متقطع", "Dashed")], ["dotted", LL("منقط", "Dotted")]]) : ""}</div>`; }
    case "qr": return `<div class="lyg">${f.T("text", LL("المحتوى (رابط / نص)", "Content (link / text)"))}${f.C("color", LL("لون الرمز", "Code colour"))}</div>`;
    case "table": return `<div class="lyg">${f.S("ds", LL("الطبقة", "Layer"), S.ds.filter(d => d.kind !== "reference").map(d => [d.id, d.label]))}${f.N("rows", LL("عدد الصفوف", "Rows"), 1, 1, 200)}<div class="lyfb lytk">${FIELDS.map(k => `<label class="lyf chk"><input type="checkbox" data-tc="${k}" ${(e.cols || []).includes(k) ? "checked" : ""}><span>${t(k)}</span></label>`).join("")}</div>${f.C("hdr", LL("لون الرأس", "Header colour"))}${f.B("zebra", LL("تظليل الصفوف", "Zebra rows"))}</div>`;
  }
  return "";
}
function lyTxt(e, f) {
  const tx = e.type === "text";
  return `<div class="lyg">${f.S("font", LL("الخط", "Font"), FONTS)}${f.N("size", LL("الحجم (pt)", "Size (pt)"), .5, 1, 400)}${f.C("color", LL("لون الخط", "Text colour"))}
    <div class="lyf"><span>${LL("النمط", "Style")}</span><div class="lysg"><button type="button" data-tg="bold" class="${e.bold ? "on" : ""}"><b>B</b></button><button type="button" data-tg="italic" class="${e.italic ? "on" : ""}"><i>I</i></button><button type="button" data-tg="ul" class="${e.ul ? "on" : ""}"><u>U</u></button></div></div>
    ${tx ? f.G("al", LL("المحاذاة", "Align"), [["start", LL("بداية", "Start")], ["center", LL("وسط", "Centre")], ["end", LL("نهاية", "End")]]) + f.G("va", LL("رأسياً", "Vertical"), [["top", LL("أعلى", "Top")], ["mid", LL("وسط", "Mid")], ["bot", LL("أسفل", "Bottom")]]) + f.N("lh", LL("تباعد الأسطر", "Line height"), .05, .8, 3) + f.N("ls", LL("تباعد الأحرف mm", "Letter spacing mm"), .05, -1, 5) : ""}
    ${f.C("halo", LL("لون الهالة", "Halo colour"))}${f.N("hw", LL("سماكة الهالة mm", "Halo width mm"), .1, 0, 3)}</div>`;
}
function lyPos(e, f) {
  const al = [["l", "alL"], ["c", "alC"], ["r", "alR"], ["t", "alT"], ["m", "alM"], ["b", "alB"]];
  return `<div class="lyg">${f.T("name", LL("الاسم", "Name"))}${f.N("x", "X mm", .5)}${f.N("y", "Y mm", .5)}${f.N("w", LL("العرض mm", "Width mm"), .5, 1)}${f.N("h", LL("الارتفاع mm", "Height mm"), .5, .5)}${f.R("rot", LL("التدوير °", "Rotation °"), -180, 180, 1)}
    <div class="lyf lyfb"><span>${LL("محاذاة للصفحة", "Align to page")}</span><div class="lysg ico">${al.map(a => `<button type="button" data-al="${a[0]}">${I(a[1])}</button>`).join("")}</div></div>
    <div class="lyf lyfb"><span>${LL("الترتيب", "Order")}</span><div class="lysg"><button type="button" data-a="top">${LL("أمام الكل", "Front")}</button><button type="button" data-a="upz">${LL("للأمام", "Forward")}</button><button type="button" data-a="dnz">${LL("للخلف", "Back")}</button><button type="button" data-a="bot">${LL("خلف الكل", "Behind")}</button></div></div>
    ${f.B("ar", LL("قفل النسبة", "Keep ratio"))}${f.B("lock", LL("قفل العنصر", "Lock"))}${f.B("vis", LL("ظاهر", "Visible"))}</div>`;
}
function lyFrm(e, f) {
  return `<div class="lyg">${f.B("fillOn", LL("تعبئة الخلفية", "Background fill"))}${f.C("fill", LL("لون التعبئة", "Fill colour"))}${f.R("fa", LL("شفافية التعبئة", "Fill opacity"), 0, 1, .05)}${f.G("shp", LL("الشكل", "Shape"), [["rect", LL("مستطيل", "Rectangle")], ["ellipse", LL("بيضاوي / دائري", "Oval / round")]])}
    ${f.N("br", LL("استدارة الزوايا mm", "Corner radius mm"), .5, 0, 50)}${f.N("bw", LL("سماكة الإطار mm", "Border width mm"), .1, 0, 20)}${f.C("bc", LL("لون الإطار", "Border colour"))}${f.S("bs", LL("نمط الإطار", "Border style"), [["solid", LL("متصل", "Solid")], ["dashed", LL("متقطع", "Dashed")], ["dotted", LL("منقط", "Dotted")], ["double", LL("مزدوج", "Double")]])}
    ${f.N("pad", LL("الحشو الداخلي mm", "Padding mm"), .5, 0, 30)}${f.B("sh", LL("ظل", "Shadow"))}${f.R("op", LL("شفافية العنصر", "Element opacity"), .1, 1, .05)}</div>`;
}
function lyProps() {
  const P = $("#lyp"); if (!P) return; const e = lyEl(LY.sel);
  if (LY.pv) { P.style.display = "none"; return; } P.style.display = "";
  if (!e) { P.className = "lyp idle"; P.innerHTML = `<div class="lyq">${["title", "north", "scale", "legend", "text", "image"].map(k => `<button class="chip" data-q="${k}">+ ${LL(LYD[k].ar, LYD[k].en)}</button>`).join("")}</div>`; $$("[data-q]", P).forEach(b => b.onclick = () => lyAddItem(b.dataset.q)); return; }
  P.className = "lyp"; const sc = P.querySelector(".lypb"), keep = sc ? sc.scrollTop : 0, tabs = lyTabs(e); if (!tabs.some(x => x[0] === LY.tab)) LY.tab = tabs[0][0]; const f = lyF(e);
  P.innerHTML = `<div class="lyph"><b>${esc6(e.name)}</b><span class="lyb2"><button data-a="lock" title="${LL("قفل", "Lock")}">${I(e.lock ? "lock" : "unlock")}</button><button data-a="dup" title="${LL("نسخ", "Duplicate")}">${I("copy")}</button><button data-a="del" class="er" title="${LL("حذف", "Delete")}">${I("trash")}</button><button data-a="x">${I("x")}</button></span></div>
    <div class="lytabs">${tabs.map(([k, l]) => `<button data-tab="${k}" class="${LY.tab === k ? "on" : ""}">${l}</button>`).join("")}</div><div class="lypb">${{ cnt: lyCnt, txt: lyTxt, pos: lyPos, frm: lyFrm }[LY.tab](e, f)}</div>`;
  if (keep) P.querySelector(".lypb").scrollTop = keep;
  $$("[data-tab]", P).forEach(b => b.onclick = () => { LY.tab = b.dataset.tab; lyProps(); });
  $$("[data-k]", P).forEach(i => { const k = i.dataset.k, fn = () => { let v = i.type === "checkbox" ? i.checked : (i.type === "number" || i.type === "range" || i.dataset.n) ? (i.value === "" ? 0 : +i.value) : i.value; if (k === "ds") ensureDs(S.ds.find(d => d.id === v)).then(lyDraw); e[k] = v; if (i.type === "range") { const s = $(`[data-v="${k}"]`, P); if (s) s.textContent = lyN(v); } if (k === "name") { const h = $(".lyph b", P); if (h) h.textContent = v; } if (k === "gr" || k === "ds") { } lyChanged(); }; i.oninput = fn; i.onchange = fn; });
  $$("[data-g]", P).forEach(i => i.onchange = () => { LY[i.dataset.g] = +i.value; lySave(); });
  $$("[data-sw]", P).forEach(s => s.onclick = () => { const i = s.parentNode.querySelector("input[type=color]"); i.value = s.dataset.sw; i.dispatchEvent(new Event("input")); });
  $$("[data-sg]", P).forEach(b => b.onclick = () => {
    const k = b.dataset.sg; let v = b.dataset.v; if (b.dataset.n) v = +v; e[k] = v; if (k === "kind") { e.shp = v === "ellipse" ? "ellipse" : "rect"; if ((v === "line" || v === "arrow") && e.h > 8) e.h = v === "line" ? 3 : 6; }
    $$(`[data-sg="${k}"]`, P).forEach(x => x.classList.toggle("on", x === b)); lyChanged(); if (b.dataset.re) lyProps();
  });
  $$("[data-tg]", P).forEach(b => b.onclick = () => { const k = b.dataset.tg; e[k] = !e[k]; b.classList.toggle("on", e[k]); lyChanged(); });
  $$("[data-al]", P).forEach(b => b.onclick = () => { lyAlign(e, b.dataset.al); lyChanged(); lyProps(); });
  $$("[data-ns]", P).forEach(b => b.onclick = () => { e.style = b.dataset.ns; $$("[data-ns]", P).forEach(x => x.classList.toggle("on", x === b)); lyChanged(); });
  $$("[data-nc]", P).forEach(cv => { const col = getComputedStyle(P).color; lyDrawNorth(cv.getContext("2d"), { style: cv.dataset.nc, lt: e.lt, color: col, fr: false, font: "sans-serif", hw: 0 }, cv.width, cv.height, 3, 0); });
  $$("[data-gl]", P).forEach(b => b.onclick = () => { e.glyph = b.dataset.gl; e.name = GL[e.glyph][0]; $$("[data-gl]", P).forEach(x => x.classList.toggle("on", x === b)); $(".lyph b", P).textContent = e.name; lyChanged(); });
  $$("[data-tk]", P).forEach(b => b.onclick = () => { const ta = $("textarea[data-k=text]", P); ta.value += b.dataset.tk; ta.dispatchEvent(new Event("input")); });
  $$("[data-li]", P).forEach(i => i.onchange = () => { e.items[+i.dataset.li].on = i.checked; e.live = false; lyChanged(); });
  $$("[data-lt]", P).forEach(i => i.oninput = () => { e.items[+i.dataset.lt].label = i.value; e.live = false; lyChanged(); });
  $$("[data-lc]", P).forEach(i => i.oninput = () => { e.items[+i.dataset.lc].color = i.value; e.live = false; lyChanged(); });
  $$("[data-tc]", P).forEach(i => i.onchange = () => { const s = new Set(e.cols); i.checked ? s.add(i.dataset.tc) : s.delete(i.dataset.tc); e.cols = FIELDS.filter(k => s.has(k)); lyChanged(); });
  $$("[data-a]", P).forEach(b => b.onclick = () => {
    const a = b.dataset.a, [pw, ph] = lyPaper();
    if (a === "x") { LY.sel = null; lyDraw(); lyProps(); } else if (a === "del") lyDelete(e); else if (a === "dup") lyDup(e); else if (a === "lock") { e.lock = !e.lock; lyPush(true); lyDraw(); lyProps(); }
    else if (["top", "bot", "upz", "dnz"].includes(a)) { lyMoveZ(e, a === "upz" ? "up" : a === "dnz" ? "down" : a); lyPush(true); lyDraw(); }
    else if (a === "cap") lyCapture(e.cid);
    else if (a === "mpan") { LY.mpan = !LY.mpan; b.classList.toggle("on", LY.mpan); if (LY.mpan) toast(LL("اسحب على الخريطة لتحريكها داخل الإطار، واقرص بإصبعين للتكبير", "Drag on the map to pan inside the frame; pinch to zoom")); }
    else if (a === "fit") { e.iz = 1; e.ox = 0; e.oy = 0; lyPush(true); lyDraw(); lyProps(); }
    else if (a === "full") { e.x = 0; e.y = 0; e.w = pw; e.h = ph; lyPush(true); lyDraw(); lyProps(); }
    else if (a === "setsc") { const N = +$("#ly_sc", P).value, cap = lyCapOf(e); if (N > 0 && cap) { e.iz = lyClamp(cap.mpp * 1000 / N / lyTf({ iz: 1 }, cap, e.w, e.h).s, .05, 40); e.ox = 0; e.oy = 0; lyPush(true); lyDraw(); lyProps(); } }
    else if (a === "lgr") { e.items = lyLegendItems(); e.live = true; lyPush(true); lyDraw(); lyProps(); }
    else if (a === "img") lyChooseImage(e);
  });
}

/* ---------------- إضافة العناصر ---------------- */
const LYPAL = [
  [["عناصر الخريطة", "Map elements"], [["map", "map"], ["inset", "area"], ["north", "compass"], ["scale", "ruler"], ["legend", "layers"]]],
  [["النصوص", "Text"], [["title", "text"], ["sub", "text"], ["text", "edit"], ["date", "text"], ["coord", "locate"], ["scaletxt", "ruler"], ["credit", "tag"]]],
  [["رسومات ورموز", "Graphics & symbols"], [["image", "img"], ["symbol", "star"], ["rect", "frame"], ["ellipse", "shape"], ["line", "more"], ["arrow", "up"], ["qr", "qr"], ["table", "table"], ["border", "frame"]]]
];
async function lyAddItem(key) {
  if (key === "table" && !S.ds.some(d => d.kind !== "reference")) return toast(t("nol"));
  const e = lyAdd(key); if ((key === "map" || key === "inset") && !LY.caps.main) await lyCapture("main", true);
  if (key === "table") await ensureDs(S.ds.find(d => d.id === e.ds));
  if (key === "inset") { LY.caps[e.cid] = LY.caps.main; toast(LL("حرّك الخريطة الرئيسية ثم اضغط «التقاط الخريطة» داخل هذا الإطار", "Move the main map, then tap Capture inside this frame")); }
  LY.tab = "cnt"; lyPush(true); lyDraw(); lyProps(); if (key === "image") lyChooseImage(e);
}
function lyPalette() {
  lyDlg(LL("إضافة عنصر", "Add element"), (b, close) => {
    b.innerHTML = LYPAL.map(g => `<div class="sec">${LL(g[0][0], g[0][1])}</div><div class="grid">${g[1].map(([k, ic]) => `<button class="tile" data-add="${k}">${I(ic)}<span>${LL(LYD[k].ar, LYD[k].en)}</span></button>`).join("")}</div>`).join("");
    $$("[data-add]", b).forEach(x => x.onclick = () => { close(); lyAddItem(x.dataset.add); });
  });
}

/* ---------------- القوالب ---------------- */
function lyTpl(name) {
  if (name === "side" && LY.ori === "p") LY.ori = "l"; const [pw, ph] = lyPaper(), k = lyClamp(Math.min(pw, ph) / 210, .5, 4), m = Math.max(5, Math.min(pw, ph) * .035), A = lyAdd, card = { fillOn: true, fa: .92, bw: .25, bc: "#b8c2cc", br: 1.5 * k, sh: true };
  LY.els = []; LY.sel = null; LY.zoom = 1;
  if (name === "overlay") {
    A("map", { x: 0, y: 0, w: pw, h: ph, bw: 0, lock: true });
    A("title", Object.assign({ x: m, y: m, w: Math.min(pw * .62, 130 * k), size: 20 * k, al: "start", va: "mid", pad: 2.5 * k }, card));
    A("north", Object.assign({ x: pw - m - 20 * k, y: m, w: 20 * k, h: 26 * k, pad: 1.5 * k }, card));
    const lg = A("legend", { x: m, y: 0, w: Math.min(pw * .4, 60 * k), br: 1.5 * k, sh: true, pad: 2.5 * k }); lg.y = ph - m - lyLegNeed(lg);
    A("scale", { x: pw - m - Math.min(pw * .45, 78 * k), y: ph - m - 15 * k, w: Math.min(pw * .45, 78 * k), h: 15 * k, br: 1.5 * k, sh: true });
  } else if (name === "classic") {
    A("border", { x: m / 2, y: m / 2, w: pw - m, h: ph - m, bw: .9 * k });
    A("title", { x: m, y: m, w: pw - 2 * m, h: 13 * k, size: 22 * k, auto: false });
    const lg = A("legend", { x: m, w: Math.min(pw * .44, 80 * k), cols: 1 }), bot = Math.max(lyLegNeed(lg), 28 * k), my = m + 16 * k, mh = ph - my - m - bot - 3 * k;
    A("map", { x: m, y: my, w: pw - 2 * m, h: mh, bw: .6 * k, bc: "#16202b" }); lg.y = ph - m - bot;
    A("north", Object.assign({ x: pw - m - 19 * k - 2, y: my + 2, w: 19 * k, h: 25 * k, pad: 1.5 * k }, card));
    A("scale", { x: pw - m - Math.min(pw * .46, 80 * k), y: ph - m - bot + (bot - 15 * k) / 2, w: Math.min(pw * .46, 80 * k), h: 15 * k });
  } else if (name === "side") {
    const mw = pw * .68, px0 = mw + m / 2, pw2 = pw - px0 - m;
    A("map", { x: m, y: m, w: mw - m, h: ph - 2 * m, bw: .6 * k, bc: "#16202b" });
    A("rect", { x: px0, y: m, w: pw2, h: ph - 2 * m, fill: "#f2f5f8", fa: 1, bw: .3, bc: "#cfd6de", name: LL("لوحة جانبية", "Side panel") });
    A("title", { x: px0 + 2, y: m + 2, w: pw2 - 4, size: 16 * k, al: "center", va: "mid" });
    A("north", { x: px0 + (pw2 - 22 * k) / 2, y: m + 26 * k, w: 22 * k, h: 28 * k });
    const lg = A("legend", { x: px0 + 3, y: m + 58 * k, w: pw2 - 6, size: 8.5 * k });
    A("scale", { x: px0 + 3, y: ph - m - 18 * k, w: pw2 - 6, h: 16 * k });
  } else if (name === "table") {
    if (!S.ds.some(d => d.kind !== "reference")) toast(t("nol"));
    const my = m + 16 * k, mh = ph * .55; A("title", { x: m, y: m, w: pw - 2 * m, h: 13 * k, size: 20 * k, auto: false }); A("map", { x: m, y: my, w: pw - 2 * m, h: mh, bw: .6 * k, bc: "#16202b" });
    A("north", Object.assign({ x: pw - m - 17 * k - 2, y: my + 2, w: 17 * k, h: 23 * k, pad: 1.2 * k }, card)); A("scale", Object.assign({ x: m + 2, y: my + mh - 16 * k - 2, w: 70 * k, h: 14 * k }, { sh: true }));
    if (S.ds.some(d => d.kind !== "reference")) { const tb = A("table", { x: m, y: my + mh + 4 * k, w: pw - 2 * m, rows: Math.max(4, Math.floor((ph - my - mh - m - 8 * k) / (8 * k * PT * 1.9 * 1) - 1)) }); ensureDs(S.ds.find(d => d.id === tb.ds)).then(lyDraw); }
  } else if (name === "poster") {
    A("map", { x: 0, y: 0, w: pw, h: ph, bw: 0, lock: true });
    A("title", { x: 0, y: 0, w: pw, size: 30 * k, fill: "#0f2a43", fillOn: true, fa: .9, color: "#ffffff", pad: 5 * k });
    A("north", Object.assign({ x: pw - m - 20 * k, y: 30 * k, w: 20 * k, h: 26 * k, pad: 1.5 * k }, card));
    const lg = A("legend", { x: m, y: 0, w: Math.min(pw * .4, 60 * k), br: 1.5 * k, sh: true, pad: 2.5 * k }); lg.y = ph - m - 10 * k - lyLegNeed(lg);
    A("scale", { x: pw - m - Math.min(pw * .45, 78 * k), y: ph - m - 25 * k, w: Math.min(pw * .45, 78 * k), h: 15 * k, br: 1.5 * k, sh: true });
    A("text", { x: 0, y: ph - 8 * k, w: pw, h: 8 * k, text: LL("التاريخ: {date}    المقياس: {scale}", "Date: {date}    Scale: {scale}"), size: 8 * k, color: "#ffffff", fill: "#0f2a43", fillOn: true, fa: .9, bw: 0, al: "center", va: "mid", br: 0 });
  }
  LY.sel = null; lyPush(true); lyDraw(); lyProps(); lyUpd();
}
const lySavedGet = () => { try { return JSON.parse(localStorage.getItem("layouts2") || "{}") || {}; } catch (e) { return {}; } };
function lyTplDlg() {
  lyDlg(LL("القوالب والتخطيطات", "Templates & layouts"), (b, close) => {
    const T = [["overlay", LL("نظيف عائم ★", "Clean overlay ★"), "layers"], ["classic", LL("كلاسيكي بإطار", "Classic framed"), "frame"], ["side", LL("لوحة جانبية", "Side panel"), "tpl"], ["table", LL("خريطة + جدول", "Map + table"), "table"], ["poster", LL("ملصق", "Poster"), "img"], ["blank", LL("صفحة فارغة", "Blank page"), "page"]];
    const draw = () => {
      const sv = lySavedGet(), names = Object.keys(sv);
      b.innerHTML = `<div class="sec">${LL("قوالب جاهزة", "Ready templates")}</div><div class="grid">${T.map(x => `<button class="tile" data-tp="${x[0]}">${I(x[2])}<span>${x[1]}</span></button>`).join("")}</div>
        <div class="sec">${LL("تخطيطاتي", "My layouts")}</div><div class="lysv"><input class="in" id="sv_n" placeholder="${LL("اسم التخطيط", "Layout name")}"><button class="btn" id="sv_b">${I("save")}${LL("حفظ الحالي", "Save current")}</button></div>
        ${names.map(n => `<div class="lylay"><span class="n">${esc6(n)}</span><button data-ld="${esc6(n)}">${LL("فتح", "Open")}</button><button data-dl="${esc6(n)}">${I("trash")}</button></div>`).join("")}`;
      $$("[data-tp]", b).forEach(x => x.onclick = () => { const go = () => { close(); x.dataset.tp === "blank" ? (LY.els = [], LY.sel = null, lyPush(true), lyDraw(), lyProps()) : lyTpl(x.dataset.tp); }; LY.els.length ? lyConfirm(LL("سيُستبدل التخطيط الحالي بالقالب. متابعة؟", "The current layout will be replaced. Continue?"), go) : go(); });
      $("#sv_b", b).onclick = () => { const n = $("#sv_n", b).value.trim(); if (!n) return; const s = lySavedGet(); s[n] = { paper: LY.paper, ori: LY.ori, cw: LY.cw, ch: LY.ch, bg: LY.bg, els: LY.els }; try { localStorage.setItem("layouts2", JSON.stringify(s)); toast(LL("تم الحفظ", "Saved")); } catch (e) { toast(LL("تعذّر الحفظ (المساحة ممتلئة)", "Could not save (storage full)")); } draw(); };
      $$("[data-ld]", b).forEach(x => x.onclick = () => { const s = lySavedGet()[x.dataset.ld]; if (!s) return; Object.assign(LY, { paper: s.paper, ori: s.ori, cw: s.cw, ch: s.ch, bg: s.bg, els: JSON.parse(JSON.stringify(s.els)), sel: null, zoom: 1 }); lyRefreshLive(); close(); lyPush(true); lyDraw(); lyProps(); lyUpd(); });
      $$("[data-dl]", b).forEach(x => x.onclick = () => { const s = lySavedGet(); delete s[x.dataset.dl]; try { localStorage.setItem("layouts2", JSON.stringify(s)); } catch (e) { } draw(); });
    }; draw();
  });
}

/* ---------------- الطبقات ---------------- */
function lyLayersDlg() {
  lyDlg(LL("طبقات التخطيط", "Layout layers"), (b, close) => {
    const draw = () => {
      b.innerHTML = lySorted().reverse().map(e => `<div class="lylay${LY.sel === e.id ? " on" : ""}"><button data-v="${e.id}">${I(e.vis === false ? "eyeoff" : "eye")}</button><span class="n" data-s="${e.id}">${esc6(e.name)}</span><button data-l="${e.id}">${I(e.lock ? "lock" : "unlock")}</button><button data-u="${e.id}">${I("up")}</button><button data-d="${e.id}">${I("down")}</button></div>`).join("") || `<div class="hint">${LL("لا توجد عناصر بعد", "No elements yet")}</div>`;
      const on = (a, fn) => $$(`[data-${a}]`, b).forEach(x => x.onclick = () => { const e = lyEl(x.dataset[a]); if (e) { fn(e); lyPush(true); lyDraw(); lyProps(); draw(); } });
      on("v", e => e.vis = e.vis === false); on("l", e => e.lock = !e.lock); on("u", e => lyMoveZ(e, "up")); on("d", e => lyMoveZ(e, "down"));
      $$("[data-s]", b).forEach(x => x.onclick = () => { LY.sel = x.dataset.s; close(); lyDraw(); lyProps(); });
    }; draw();
  });
}

/* ---------------- الورقة والعرض والتصدير ---------------- */
function lyApplyPaper(o, scaleEls) {
  const [ow, oh] = lyPaper(); Object.assign(LY, o); const [nw, nh] = lyPaper();
  if (scaleEls && (Math.abs(nw - ow) > .01 || Math.abs(nh - oh) > .01)) {
    const sx = nw / ow, sy = nh / oh, f = Math.sqrt(sx * sy);
    LY.els.forEach(e => { const cx = (e.x + e.w / 2) * sx, cy = (e.y + e.h / 2) * sy, w = e.ar ? e.w * f : e.w * sx, h = e.ar ? e.h * f : e.h * sy; e.w = w; e.h = h; e.x = cx - w / 2; e.y = cy - h / 2; ["size", "bw", "pad", "br", "hw", "ls", "gz"].forEach(k => { if (e[k]) e[k] *= f; }); });
  }
  LY.zoom = 1; lyPush(true); lyDraw(); lyProps(); lyUpd();
}
function lyPageDlg() {
  lyDlg(LL("إعدادات الورقة", "Page setup"), b => {
    const opts = PGROUPS.map(g => `<optgroup label="${g[0]}">${Object.keys(g[1]).map(k => `<option value="${k}"${LY.paper === k ? " selected" : ""}>${k} — ${g[1][k][0]}×${g[1][k][1]}</option>`).join("")}</optgroup>`).join("") + `<option value="custom"${LY.paper === "custom" ? " selected" : ""}>${LL("حجم مخصص…", "Custom size…")}</option>`;
    b.innerHTML = `<div class="lyg"><label class="lyf lyfb"><span>${LL("نوع / حجم الورقة", "Paper type / size")}</span><select id="pg_s">${opts}</select></label>
      <div class="lyf lyfb"><span>${LL("اتجاه الورقة", "Orientation")}</span><div class="lysg"><button type="button" data-o="p" class="${LY.ori === "p" ? "on" : ""}">${LL("عمودي ▯", "Portrait ▯")}</button><button type="button" data-o="l" class="${LY.ori === "l" ? "on" : ""}">${LL("أفقي ▭", "Landscape ▭")}</button></div></div>
      <div class="lyg lyfb" id="pg_c" style="${LY.paper === "custom" ? "" : "display:none"}"><label class="lyf"><span>${LL("العرض mm", "Width mm")}</span><input type="number" id="pg_w" value="${LY.cw}"></label><label class="lyf"><span>${LL("الارتفاع mm", "Height mm")}</span><input type="number" id="pg_h" value="${LY.ch}"></label></div>
      <div class="lyf"><span>${LL("لون الورقة", "Paper colour")}</span><span class="lycw"><input type="color" id="pg_bg" value="${lyHex(LY.bg)}"><i data-sw="#ffffff" style="background:#fff"></i><i data-sw="#f5f0e1" style="background:#f5f0e1"></i><i data-sw="#e8eef5" style="background:#e8eef5"></i><i data-sw="#16202b" style="background:#16202b"></i></span></div>
      <label class="lyf"><span>${LL("الهامش الإرشادي mm", "Margin guide mm")}</span><input type="number" id="pg_m" value="${LY.margin}"></label>
      <label class="lyf chk lyfb"><input type="checkbox" id="pg_sc" checked><span>${LL("تكييف العناصر مع الحجم الجديد", "Scale elements to the new size")}</span></label><div class="hint lyfb" id="pg_i"></div></div>`;
    const info = () => { const [pw, ph] = lyPaper(); $("#pg_i", b).textContent = `${Math.round(pw * 10) / 10} × ${Math.round(ph * 10) / 10} mm`; }, sc = () => $("#pg_sc", b).checked; info();
    $("#pg_s", b).onchange = ev => { $("#pg_c", b).style.display = ev.target.value === "custom" ? "" : "none"; lyApplyPaper({ paper: ev.target.value }, sc()); info(); };
    $$("[data-o]", b).forEach(x => x.onclick = () => { $$("[data-o]", b).forEach(y => y.classList.toggle("on", y === x)); lyApplyPaper({ ori: x.dataset.o }, sc()); info(); });
    const cu = () => { const w = +$("#pg_w", b).value, h = +$("#pg_h", b).value; if (w >= 30 && h >= 30 && w <= 3000 && h <= 3000) { lyApplyPaper({ paper: "custom", cw: w, ch: h }, sc()); info(); } }; $("#pg_w", b).oninput = cu; $("#pg_h", b).oninput = cu;
    $("#pg_bg", b).oninput = ev => { LY.bg = ev.target.value; lyChanged(); }; $$("[data-sw]", b).forEach(s => s.onclick = () => { LY.bg = s.dataset.sw; $("#pg_bg", b).value = LY.bg; lyChanged(); });
    $("#pg_m", b).oninput = ev => { LY.margin = Math.max(0, +ev.target.value || 0); lySave(); lyDraw(); };
  });
}
function lyViewDlg() {
  lyDlg(LL("العرض والمساعدات", "View & helpers"), b => {
    b.innerHTML = `<div class="lyg"><label class="lyf chk lyfb"><input type="checkbox" data-vw="grid" ${LY.grid ? "checked" : ""}><span>${LL("إظهار الشبكة وخطوط الهامش", "Show grid and margin guides")}</span></label>
      <label class="lyf chk lyfb"><input type="checkbox" data-vw="snap" ${LY.snap ? "checked" : ""}><span>${LL("الالتصاق بالحواف والمنتصف والعناصر", "Snap to edges, centre and elements")}</span></label>
      <label class="lyf chk lyfb"><input type="checkbox" data-vw="rulers" ${LY.rulers ? "checked" : ""}><span>${LL("إظهار المساطر (مم)", "Show rulers (mm)")}</span></label>
      <button class="btn sec2 lyfb" data-z="1">${LL("ملاءمة الصفحة للشاشة", "Fit page to screen")}</button>
      <div class="hint lyfb">${LL("نصائح: اضغط مرتين على نص لتحريره • اسحب الدائرة العلوية للتدوير • اقرص بإصبعين لتكبير الصفحة • فعّل «تحريك الخريطة داخل الإطار» من تبويب الخريطة.", "Tips: double-tap text to edit • drag the top handle to rotate • pinch to zoom the page • enable “Pan map inside frame” in the Map tab.")}</div></div>`;
    $$("[data-vw]", b).forEach(i => i.onchange = () => { LY[i.dataset.vw] = i.checked; lySave(); lyDraw(); }); $("[data-z]", b).onclick = () => { LY.zoom = 1; lyDraw(); };
  });
}
function lyExportDlg() {
  lyDlg(LL("تصدير / طباعة", "Export / Print"), b => {
    b.innerHTML = `<div class="lyg"><label class="lyf"><span>${LL("الصيغة", "Format")}</span><select id="lx_f"><option value="pdf">PDF</option><option value="png">PNG</option><option value="jpg">JPG</option></select></label><label class="lyf"><span>${LL("الدقة DPI", "Resolution DPI")}</span><select id="lx_d">${[72, 96, 150, 200, 300, 450, 600].map(d => `<option${d === 300 ? " selected" : ""}>${d}</option>`).join("")}</select></label>
      <label class="lyf lyfb"><span>${LL("اسم الملف", "File name")}</span><input class="in" id="lx_n" value="layout"></label><div class="hint lyfb" id="lx_i"></div></div>
      <div class="btns"><button class="btn" id="lx_s">${I("save")}${LL("حفظ", "Save")}</button><button class="btn sec2" id="lx_o">${I("open")}${LL("فتح", "Open")}</button></div><div class="btns"><button class="btn sec2" id="lx_h">${I("share")}${LL("مشاركة", "Share")}</button><button class="btn sec2" id="lx_p">${LL("طباعة", "Print")}</button></div>`;
    const info = () => { const D = lyDims(+$("#lx_d", b).value); $("#lx_i", b).textContent = `${D.pw.toFixed(0)}×${D.ph.toFixed(0)} mm — ${D.w}×${D.h} px` + (D.d < +$("#lx_d", b).value ? " — " + LL(`خُفّضت الدقة إلى ${D.d} DPI بسبب حدّ الذاكرة`, `resolution reduced to ${D.d} DPI (memory limit)`) : ""); }; info(); $("#lx_d", b).onchange = info;
    const go = async mode => { const f = $("#lx_f", b).value, nm = ($("#lx_n", b).value || "layout") + "." + f; toast(LL("جارٍ التصدير…", "Exporting…")); try { const bl = await lyRender(+$("#lx_d", b).value, f);
      if (mode === "print") { if (window.Android) return saveBlob(bl, nm, "open"); const u = URL.createObjectURL(bl), w = window.open(u); w && w.addEventListener("load", () => w.print()); return; } await saveBlob(bl, nm, mode); } catch (e) { fail(e); } };
    $("#lx_s", b).onclick = () => go("save"); $("#lx_o", b).onclick = () => go("open"); $("#lx_h", b).onclick = () => go("share"); $("#lx_p", b).onclick = () => go("print");
  });
}
function lyEditText(e) {
  lyDlg(LL("تحرير النص", "Edit text"), b => {
    b.innerHTML = `<textarea class="in ta" id="lt_v" rows="5">${esc6(e.text)}</textarea><div class="lytk" style="margin-top:8px">${["date", "time", "scale", "center", "zoom", "paper"].map(k => `<button type="button" class="chip" data-tk="{${k}}">{${k}}</button>`).join("")}</div>`;
    const ta = $("#lt_v", b); ta.oninput = () => { e.text = ta.value; lyChanged(); }; ta.onblur = () => lyProps(); $$("[data-tk]", b).forEach(x => x.onclick = () => { ta.value += x.dataset.tk; ta.oninput(); }); setTimeout(() => ta.focus(), 60);
  });
}

/* ---------------- اللمس والتفاعل ---------------- */
function lyLocal(e, x, y) { const a = -(e.rot || 0) * Math.PI / 180, dx = x - (e.x + e.w / 2), dy = y - (e.y + e.h / 2); return [dx * Math.cos(a) - dy * Math.sin(a), dx * Math.sin(a) + dy * Math.cos(a)]; }
function lyHit(x, y) {
  for (const e of lySorted().reverse()) { if (e.vis === false) continue; const [lx, ly] = lyLocal(e, x, y), hh = Math.max(e.h, e.type === "shape" && (e.kind === "line" || e.kind === "arrow") ? 4 : 0); if (Math.abs(lx) <= e.w / 2 && Math.abs(ly) <= hh / 2) return e; }
  return null;
}
function lyHandleAt(e, x, y) {
  const [lx, ly] = lyLocal(e, x, y), mm = (LY.k || 1) / LY.px, tol = 14 * mm, w = e.w, h = e.h;
  if (Math.hypot(lx, ly - (-h / 2 - 22 * mm)) < tol) return { rot: true };
  for (const [hx, hy] of [[-1, -1], [1, -1], [1, 1], [-1, 1], [0, -1], [1, 0], [0, 1], [-1, 0]]) if (Math.hypot(lx - hx * w / 2, ly - hy * h / 2) < tol) return { hx, hy };
  return null;
}
function lyMagnet(e, nx, ny) {
  LY.guides = []; if (!LY.snap || e.rot) return [nx, ny]; const [pw, ph] = lyPaper(), th = 5 * (LY.k || 1) / LY.px, m = LY.margin || 0, xs = [0, pw / 2, pw, m, pw - m], ys = [0, ph / 2, ph, m, ph - m];
  LY.els.filter(o => o !== e && o.vis !== false && !o.rot).forEach(o => { xs.push(o.x, o.x + o.w / 2, o.x + o.w); ys.push(o.y, o.y + o.h / 2, o.y + o.h); });
  let dx = th, dy = th, rx = nx, ry = ny, gx = null, gy = null;
  [0, e.w / 2, e.w].forEach(o => xs.forEach(v => { const d = Math.abs(nx + o - v); if (d < dx) { dx = d; rx = v - o; gx = v; } })); [0, e.h / 2, e.h].forEach(o => ys.forEach(v => { const d = Math.abs(ny + o - v); if (d < dy) { dy = d; ry = v - o; gy = v; } }));
  if (gx != null) LY.guides.push({ v: gx }); if (gy != null) LY.guides.push({ h: gy }); return [rx, ry];
}
function lyDouble(e) { if (e.type === "text") lyEditText(e); else if (e.type === "image") lyChooseImage(e); else if (e.type === "map") { LY.mpan = !LY.mpan; toast(LY.mpan ? LL("وضع تحريك الخريطة داخل الإطار: مفعّل", "Pan-inside-frame: on") : LL("وضع تحريك الخريطة داخل الإطار: متوقف", "Pan-inside-frame: off")); lyProps(); } }
function lyTap(e) { if (LY.lastTap && LY.lastTap.id === e.id && Date.now() - LY.lastTap.t < 450) { LY.lastTap = null; lyDouble(e); } else LY.lastTap = { id: e.id, t: Date.now() }; }
function lyPointer() {
  const cv = $("#lyc"), W = $(".lyw"), P = new Map(); let mode = null, st = null;
  const pos = ev => { const r = cv.getBoundingClientRect(), s = cv.width / r.width; return [(ev.clientX - r.left) * s / LY.px - PM, (ev.clientY - r.top) * s / LY.px - PM]; };
  cv.addEventListener("pointerdown", ev => {
    try { cv.setPointerCapture(ev.pointerId); } catch (_) { } P.set(ev.pointerId, [ev.clientX, ev.clientY]);
    if (P.size === 2) { const [a, b] = [...P.values()], s = lyEl(LY.sel); st = { d: Math.hypot(a[0] - b[0], a[1] - b[1]), z: LY.zoom, iz: s && s.type === "map" ? (s.iz || 1) : 1 }; mode = "pinch"; return; } if (P.size > 2) return;
    const [x, y] = pos(ev), s = lyEl(LY.sel), pan = { sx: ev.clientX, sy: ev.clientY, l: W.scrollLeft, tp: W.scrollTop };
    if (!LY.pv && s && !s.lock && s.vis !== false) { const hd = lyHandleAt(s, x, y); if (hd) { mode = hd.rot ? "rot" : "rs"; st = { hd, w0: s.w, h0: s.h, cx: s.x + s.w / 2, cy: s.y + s.h / 2, rot: s.rot || 0, ar: s.ar }; return; } }
    const hit = LY.pv ? null : lyHit(x, y);
    if (hit) {
      LY.sel = hit.id;
      if (LY.mpan && hit.type === "map") { mode = "mp"; st = { x, y, ox: hit.ox || 0, oy: hit.oy || 0 }; }
      else if (hit.lock) { mode = "pan"; st = Object.assign(pan, { tap: { id: hit.id, t: Date.now(), x: ev.clientX, y: ev.clientY } }); }
      else { mode = "mv"; st = { x, y, ex: hit.x, ey: hit.y, t: Date.now() }; } lyDraw(); lyProps();
    } else { if (LY.sel) { LY.sel = null; lyDraw(); lyProps(); } mode = "pan"; st = pan; }
  });
  cv.addEventListener("pointermove", ev => {
    if (P.has(ev.pointerId)) P.set(ev.pointerId, [ev.clientX, ev.clientY]); if (!mode) return;
    if (mode === "pinch") { if (P.size < 2) return; const [a, b] = [...P.values()], r = Math.hypot(a[0] - b[0], a[1] - b[1]) / (st.d || 1), s = lyEl(LY.sel); if (s && s.type === "map" && LY.mpan) s.iz = lyClamp(st.iz * r, .2, 8); else LY.zoom = lyClamp(st.z * r, .3, 6); lyDraw(); return; }
    if (mode === "pan") { W.scrollLeft = st.l - (ev.clientX - st.sx); W.scrollTop = st.tp - (ev.clientY - st.sy); return; }
    const e = lyEl(LY.sel); if (!e) return; const [x, y] = pos(ev);
    if (mode === "mv") { const [nx, ny] = lyMagnet(e, st.ex + x - st.x, st.ey + y - st.y); e.x = nx; e.y = ny; }
    else if (mode === "mp") { e.ox = st.ox + (x - st.x) / e.w * 100; e.oy = st.oy + (y - st.y) / e.h * 100; }
    else if (mode === "rot") { let r = ((Math.atan2(y - st.cy, x - st.cx) * 180 / Math.PI + 90 + 540) % 360) - 180; [-180, -135, -90, -45, 0, 45, 90, 135, 180].forEach(sn => { if (Math.abs(r - sn) < 3) r = sn === 180 ? -180 : sn; }); e.rot = Math.round(r * 10) / 10; }
    else if (mode === "rs") {
      const { hx, hy } = st.hd, a = -st.rot * Math.PI / 180, dx = x - st.cx, dy = y - st.cy, lx = dx * Math.cos(a) - dy * Math.sin(a), ly = dx * Math.sin(a) + dy * Math.cos(a); let nw = st.w0, nh = st.h0;
      if (hx) nw = Math.max(3, (lx + hx * st.w0 / 2) * hx); if (hy) nh = Math.max(1.5, (ly + hy * st.h0 / 2) * hy);
      if (st.ar && st.w0 > 0 && st.h0 > 0) { const r = st.w0 / st.h0; if (hx && hy) { if (nw / r > nh) nh = nw / r; else nw = nh * r; } else if (hx) nh = nw / r; else nw = nh * r; }
      if (hy && (e.type === "legend" || e.type === "table")) nh = st.h0; if (hy && e.type === "text" && e.auto) e.auto = false;
      const ox = hx ? hx * (nw - st.w0) / 2 : 0, oy = hy ? hy * (nh - st.h0) / 2 : 0, rr = st.rot * Math.PI / 180, cx = st.cx + ox * Math.cos(rr) - oy * Math.sin(rr), cy = st.cy + ox * Math.sin(rr) + oy * Math.cos(rr);
      e.w = nw; e.h = nh; e.x = cx - nw / 2; e.y = cy - nh / 2;
    }
    lyDraw();
  });
  const end = ev => {
    P.delete(ev.pointerId); if (mode === "pinch") { if (P.size < 2) { const s = lyEl(LY.sel); if (s && s.type === "map") lyPush(true); mode = null; lyProps(); } return; } if (!mode) return; const e = lyEl(LY.sel);
    if (mode === "mv" && e && Date.now() - st.t < 300 && Math.abs(e.x - st.ex) < .6 && Math.abs(e.y - st.ey) < .6) lyTap(e);
    if (mode === "pan" && st.tap && Math.hypot(ev.clientX - st.tap.x, ev.clientY - st.tap.y) < 6 && Date.now() - st.tap.t < 350) { const e2 = lyEl(st.tap.id); if (e2) lyTap(e2); }
    mode = null; LY.guides = []; lyPush(true); lyDraw(); lyProps();
  };
  cv.addEventListener("pointerup", end); cv.addEventListener("pointercancel", end);
  W.addEventListener("wheel", ev => { if (ev.ctrlKey) { ev.preventDefault(); LY.zoom = lyClamp(LY.zoom * (ev.deltaY < 0 ? 1.1 : .9), .3, 6); lyDraw(); } }, { passive: false });
}
function lyKeys() {
  LY.kh = ev => {
    if (!$("#lyroot")) return; if (/INPUT|TEXTAREA|SELECT/.test(ev.target && ev.target.tagName || "")) return; const e = lyEl(LY.sel), cm = ev.ctrlKey || ev.metaKey;
    if (cm && ev.key.toLowerCase() === "z") { ev.preventDefault(); lyHistGo(ev.shiftKey ? 1 : -1); return; } if (cm && ev.key.toLowerCase() === "y") { ev.preventDefault(); lyHistGo(1); return; } if (!e) return;
    if (ev.key === "Delete" || ev.key === "Backspace") { ev.preventDefault(); lyDelete(e); } else if (ev.key === "Escape") { LY.sel = null; lyDraw(); lyProps(); } else if (cm && ev.key.toLowerCase() === "d") { ev.preventDefault(); lyDup(e); }
    else if (/^Arrow/.test(ev.key) && !e.lock) { const d = ev.shiftKey ? 5 : .5; if (ev.key === "ArrowLeft") e.x -= d; else if (ev.key === "ArrowRight") e.x += d; else if (ev.key === "ArrowUp") e.y -= d; else e.y += d; ev.preventDefault(); lyDraw(); lyPush(); }
  }; document.addEventListener("keydown", LY.kh);
}

/* ---------------- الفتح والإغلاق ---------------- */
function lyRefreshLive() { LY.els.forEach(e => { if (e.type === "legend" && e.live !== false) e.items = lyMergeItems(e.items, lyLegendItems()); if (e.type === "table" && e.ds) { const d = S.ds.find(x => x.id === e.ds); if (d) ensureDs(d).then(() => LY.open && lyDraw()); } }); }
function lyClose() {
  lySave(); const used = new Set(LY.els.map(e => e.asset).filter(Boolean)); Object.keys(LY.assets).forEach(k => { if (!used.has(k)) delete LY.assets[k]; }); lySaveAssets();
  if (LY.kh) document.removeEventListener("keydown", LY.kh); if (LY.ro) { LY.ro.disconnect(); LY.ro = null; } const r = $("#lyroot"); if (r) r.remove(); LY.open = false;
}
function lyBack() { const r = $("#lyroot"); if (!r) return false; const d = $(".lyd", r); if (d) { d.remove(); return true; } if (LY.sel) { LY.sel = null; lyDraw(); lyProps(); return true; } lyClose(); return true; }
function openLayout() {
  closeSheet(); document.body.classList.remove("dr"); if ($("#lyroot")) lyClose(); lyLoad(); LY.open = true; LY.pv = false; LY.sel = null; LY.zoom = 1; LY.tab = "cnt"; LY.hist = []; LY.hi = -1;
  const root = el(`<div id="lyroot"><div class="lyt"><button class="lyi" id="ly_x">${I("x")}</button><div class="lyti"><b>Layout</b><small id="ly_info"></small></div><span class="lysp"></span><button class="lyi" id="ly_un">${I("undo")}</button><button class="lyi" id="ly_re">${I("redo")}</button><button class="lyi" id="ly_pv">${I("eye")}</button><button class="btn" id="ly_ex">${I("open")}<span>${LL("تصدير", "Export")}</span></button></div>
    <div class="lymid"><div class="lyw"><canvas id="lyc"></canvas></div><div class="lyz"><button id="lz_i">+</button><button id="lz_o">−</button><button id="lz_f">⤢</button></div></div>
    <div class="lyp" id="lyp"></div>
    <div class="lyb"><button class="pri" data-b="add">${I("plus")}<span>${LL("إضافة", "Add")}</span></button><button data-b="cap">${I("camera")}<span>${LL("التقاط الخريطة", "Capture map")}</span></button><button data-b="page">${I("page")}<span>${LL("الورقة", "Page")}</span></button><button data-b="tpl">${I("tpl")}<span>${LL("قوالب", "Templates")}</span></button><button data-b="lay">${I("layers")}<span>${LL("الطبقات", "Layers")}</span></button><button data-b="view">${I("grid")}<span>${LL("عرض", "View")}</span></button><button data-b="clr">${I("trash")}<span>${LL("مسح الكل", "Clear")}</span></button></div></div>`, document.body);
  $("#ly_x", root).onclick = lyClose; $("#ly_ex", root).onclick = lyExportDlg; $("#ly_un", root).onclick = () => lyHistGo(-1); $("#ly_re", root).onclick = () => lyHistGo(1);
  $("#ly_pv", root).onclick = () => { LY.pv = !LY.pv; LY.sel = null; root.classList.toggle("pv", LY.pv); $("#ly_pv", root).classList.toggle("on", LY.pv); lyDraw(); lyProps(); };
  $("#lz_i", root).onclick = () => { LY.zoom = Math.min(6, LY.zoom * 1.3); lyDraw(); }; $("#lz_o", root).onclick = () => { LY.zoom = Math.max(.3, LY.zoom / 1.3); lyDraw(); }; $("#lz_f", root).onclick = () => { LY.zoom = 1; lyDraw(); };
  $$(".lyb button", root).forEach(b => b.onclick = () => {
    const k = b.dataset.b; if (k === "add") lyPalette(); else if (k === "cap") { const s = lyEl(LY.sel); lyCapture(s && s.type === "map" ? s.cid : "main"); } else if (k === "page") lyPageDlg(); else if (k === "tpl") lyTplDlg(); else if (k === "lay") lyLayersDlg(); else if (k === "view") lyViewDlg();
    else if (k === "clr") lyConfirm(LL("حذف جميع عناصر التخطيط؟", "Delete all layout elements?"), () => { LY.els = []; LY.sel = null; lyPush(true); lyDraw(); lyProps(); });
  });
  if (!LY.els.length) lyTpl("overlay"); lyRefreshLive(); LY.hist = [lySnapStr()]; LY.hi = 0;
  lyPointer(); lyKeys(); const W = $(".lyw", root); let ow = 0, oh = 0; LY.ro = new ResizeObserver(() => { if (W.clientWidth !== ow || W.clientHeight !== oh) { ow = W.clientWidth; oh = W.clientHeight; lyDraw(); } }); LY.ro.observe(W);
  lyUpd(); lyDraw(); lyProps(); lyCapture("main", true).then(() => { if (!LY.caps.main) toast(LL("تعذّر التقاط الخريطة تلقائياً — اضغط «التقاط الخريطة»", "Auto-capture failed — tap “Capture map”")); });
}
