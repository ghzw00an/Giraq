"use strict";
/* ===== app5: سرعة الجلب، رموز المعالم، تحرير الرسومات، علامة +، أسماء بلا إنترنت ===== */
Object.assign(TX.ar, {
  fspeed: "سرعة الجلب", fs_old: "نمط ١ — الأبطأ (خادم واحد، أجزاء متتابعة)", fs_prev: "نمط ٢ — متدرج (أسرع قليلاً)", fs_fast: "نمط ٣ — الأسرع (أجزاء متوازية + استئناف + مساحات كبيرة)",
  fs_h: "تُطبَّق على الجلب التالي. المساحات الكبيرة تُقسَّم تلقائياً بلا حدّ.",
  cr_h: "علامة + في مركز الخريطة", cr_shape: "الشكل", cr_size: "الحجم", cr_w: "السماكة", cr_col: "اللون", cr_op: "الشفافية", cr_auto: "تلقائي",
  cs_plus: "زائد", cs_gap: "زائد بفراغ", cs_dot: "نقطة", cs_ring: "حلقة", cs_target: "هدف", cs_none: "إخفاء",
  ic_h: "رموز المعالم", ic_on: "إظهار الرموز", ic_size: "حجم الرمز", ic_zoom: "تتلاءم مع تكبير الخريطة", ic_menu: "الرمز…", ic_scope: "تطبيق على", ic_f: "هذا المعلم", ic_t: "كل المعالم من نوع", ic_s: "القطاع", ic_d: "المجموعة كاملة",
  ic_none: "بدون رمز", ic_def: "الافتراضي", ic_reset: "استعادة الرموز الافتراضية", ic_sz: "الحجم", ic_sel: "كل الرموز المحددة", ic_sectors: "رموز القطاعات", ic_pick: "اختر الرمز",
  dr: "الرسومات", dr_edit: "تحرير النقاط", dr_pts: "النقاط", dr_color: "اللون", dr_w: "السماكة", dr_dash: "النمط", solid: "متصل", dashed: "متقطع", dotted: "منقط", dr_fill: "شفافية التعبئة", dr_seg: "إظهار أطوال الأضلاع", dr_tot: "إظهار الإجمالي",
  dr_icon: "رمز", dr_iat: "موضع الرمز", at_all: "كل النقاط", at_first: "البداية", at_last: "النهاية", at_ctr: "الوسط", dr_del: "حذف", dr_dup: "نسخ", dr_zoom: "تكبير", dr_save: "حفظ كطبقة", dr_add: "إضافة نقطة", dr_done: "تم", dr_hint: "اسحب النقطة لتحريكها، اضغط + لإدراج نقطة، اضغط رقم النقطة للتفاصيل",
  dr_none: "لا توجد رسومات بعد. استعمل أداة قياس أو مسار أو تتبع", dr_made: "أُضيف إلى الرسومات", dr_clear_q: "مسح كل الرسومات المحفوظة أيضاً؟", dr_all: "الرسومات", from_prev: "عن السابقة", cum: "تراكمي", dr_kind_line: "خط", dr_kind_area: "مساحة", dr_kind_route: "مسار", dr_kind_track: "تتبع", dr_kind_ruler: "مسطرة",
  dr_coord: "الإحداثية (خط العرض، خط الطول)", dr_geo: "تصدير GeoJSON", dr_view: "عرض", pt: "نقطة"
});
Object.assign(TX.en, {
  fspeed: "Fetch speed", fs_old: "Mode 1: slowest (one server, sequential parts)", fs_prev: "Mode 2: staggered (a bit faster)", fs_fast: "Mode 3: fastest (parallel parts + resume + huge areas)",
  fs_h: "Applies to the next fetch. Large areas are split automatically with no limit.",
  cr_h: "Centre + mark", cr_shape: "Shape", cr_size: "Size", cr_w: "Thickness", cr_col: "Colour", cr_op: "Opacity", cr_auto: "Auto",
  cs_plus: "Plus", cs_gap: "Plus with gap", cs_dot: "Dot", cs_ring: "Ring", cs_target: "Target", cs_none: "Hidden",
  ic_h: "Landmark icons", ic_on: "Show icons", ic_size: "Icon size", ic_zoom: "Scale with map zoom", ic_menu: "Icon…", ic_scope: "Apply to", ic_f: "This landmark", ic_t: "All landmarks of type", ic_s: "Sector", ic_d: "Whole group",
  ic_none: "No icon", ic_def: "Default", ic_reset: "Restore default icons", ic_sz: "Size", ic_sel: "All selected icons", ic_sectors: "Sector icons", ic_pick: "Pick icon",
  dr: "Drawings", dr_edit: "Edit points", dr_pts: "Points", dr_color: "Colour", dr_w: "Width", dr_dash: "Style", solid: "Solid", dashed: "Dashed", dotted: "Dotted", dr_fill: "Fill opacity", dr_seg: "Show segment lengths", dr_tot: "Show total",
  dr_icon: "Icon", dr_iat: "Icon position", at_all: "All points", at_first: "Start", at_last: "End", at_ctr: "Middle", dr_del: "Delete", dr_dup: "Duplicate", dr_zoom: "Zoom to", dr_save: "Save as layer", dr_add: "Add point", dr_done: "Done", dr_hint: "Drag a point to move it, tap + to insert one, tap a number for details",
  dr_none: "No drawings yet. Use measure, route or tracking", dr_made: "Added to drawings", dr_clear_q: "Also clear all saved drawings?", dr_all: "Drawings", from_prev: "from previous", cum: "cumulative", dr_kind_line: "Line", dr_kind_area: "Area", dr_kind_route: "Route", dr_kind_track: "Track", dr_kind_ruler: "Ruler",
  dr_coord: "Coordinate (lat, lon)", dr_geo: "Export GeoJSON", dr_view: "View", pt: "Point"
});
const SECT_NAMES = ["قطاع المواصلات", "القطاع السياسي", "القطاع الإداري", "القطاع المدني", "القطاع التجاري", "القطاع المالي", "القطاع التربوي والتعليم", "القطاع الترفيهي", "القطاع الرياضي", "القطاع الخدماتي", "القطاع الديني", "القطاع الزراعي", "القطاع الصحي", "القطاع الصناعي", "القطاع الثقافي"];
const rangeRow = (label, id, min, max, step, val) => `<label class="f">${label} <b id="${id}_v" style="color:var(--pr)">${val}</b></label><input type="range" class="rg" id="${id}" min="${min}" max="${max}" step="${step}" value="${val}">`;
const normA = s => String(s || "").replace(/[أإآٱ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه");
const COLS = ["#1e88ff", "#e8590c", "#0ca678", "#862e9c", "#f59f00", "#e03131", "#15aabf", "#5f3dc4", "#66a80f", "#d6336c", "#212529", "#ffffff"];

/* ===== مكتبة الرموز (24×24) ===== */
const GL = {
  mosque: ["مسجد", "M5 21v-8a7 7 0 0114 0v8M3 21h18M12 3v3M10 21v-4a2 2 0 014 0v4"], cross: ["صليب طبي", "M10 4h4v6h6v4h-6v6h-4v-6H4v-4h6z", 1], cart: ["عربة تسوق", "M3 4h3l2.5 11h10l2-8H7M10 20h.01M18 20h.01"],
  car: ["سيارة", "M4 16v-4l2-5h12l2 5v4M4 16h16M7 16v2M17 16v2M6 12h12"], school: ["مدرسة", "M3 10l9-6 9 6M5 10v9h14v-9M10 19v-5h4v5"], bank: ["مصرف", "M3 9l9-5 9 5M5 9v9M10 9v9M14 9v9M19 9v9M3 20h18"],
  fuel: ["وقود", "M5 20V5a1 1 0 011-1h7a1 1 0 011 1v15M4 20h11M14 9h3l2 2v6a1.5 1.5 0 003 0"], food: ["مطعم", "M7 3v8M5 3v5a2 2 0 004 0V3M7 11v10M17 3c-2 2-2 6 0 8v10"], cafe: ["مقهى", "M4 8h12v6a5 5 0 01-5 5H9a5 5 0 01-5-5zM16 9h2a2 2 0 010 5h-2M7 3v2M11 3v2"],
  hotel: ["فندق", "M3 18V8M3 14h18v4M21 14v-2a3 3 0 00-3-3h-7v5"], tree: ["شجرة/متنزه", "M12 21v-6M12 3l6 8h-3l4 6H5l4-6H6z"], shield: ["درع/أمن", "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"], flame: ["لهب", "M12 3c1 4 5 5 5 10a5 5 0 01-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z", 1],
  pin: ["دبوس", "M12 21s-7-6-7-11a7 7 0 0114 0c0 5-7 11-7 11zM12 10h.01"], star: ["نجمة", "M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z", 1], flag: ["علم", "M5 21V4M5 4h12l-2 4 2 4H5"],
  home: ["منزل", "M3 11l9-7 9 7M5 10v10h14V10M10 20v-6h4v6"], building: ["مبنى", "M5 21V4h9v17M14 9h5v12M8 8h2M8 12h2M8 16h2"], factory: ["معمل", "M3 21V10l6 4V10l6 4V6h3v15zM7 17h2M12 17h2"],
  tower: ["برج اتصالات", "M12 3v18M8 21h8M8 7a5 5 0 000 6M16 7a5 5 0 010 6"], plane: ["طائرة", "M10 14L3 11V9l7 1 3-6h2l-1 7 6 2v2l-6-1-1 5h-2z"], bus: ["حافلة", "M5 4h14v13H5zM5 11h14M8 20v-3M16 20v-3"],
  train: ["قطار", "M7 3h10a2 2 0 012 2v10a3 3 0 01-3 3H8a3 3 0 01-3-3V5a2 2 0 012-2zM5 11h14M8 21l2-3M16 21l-2-3"], ship: ["سفينة", "M3 17l2 4h14l2-4zM6 17V9h12v8M12 9V4"],
  pill: ["صيدلية", "M8 16l8-8a3.5 3.5 0 00-5-5l-8 8a3.5 3.5 0 005 5zM9 7l6 6"], book: ["كتاب/مكتبة", "M4 5a2 2 0 012-2h13v15H6a2 2 0 00-2 2zM4 20a2 2 0 012-2h13v3H6"], ball: ["كرة/رياضة", "M12 3a9 9 0 100 18 9 9 0 000-18zM12 3v18M3 12h18"],
  cap: ["قبعة تخرج", "M2 9l10-5 10 5-10 5zM6 11v5c3 3 9 3 12 0v-5"], drop: ["ماء", "M12 3s6 7 6 11a6 6 0 01-12 0c0-4 6-11 6-11z", 1], bolt: ["كهرباء", "M13 2L5 14h6l-1 8 8-12h-6z", 1],
  church: ["كنيسة", "M12 2v5M10 4h4M6 21V12l6-5 6 5v9zM10 21v-4a2 2 0 014 0v4"], camera: ["كاميرا", "M4 7h3l2-3h6l2 3h3v13H4zM12 17a4 4 0 100-8 4 4 0 000 8z"], phone: ["هاتف", "M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z"],
  heart: ["قلب", "M12 21s-8-5-8-11a4.5 4.5 0 018-2.5A4.5 4.5 0 0120 10c0 6-8 11-8 11z", 1], wrench: ["خدمات/صيانة", "M14 6a4 4 0 005 5l-9 9a2.1 2.1 0 01-3-3l9-9a4 4 0 01-2-2z"], mail: ["بريد", "M3 6h18v12H3zM3 7l9 7 9-7"],
  tomb: ["مقبرة", "M7 21V9a5 5 0 0110 0v12zM12 11v6M10 13h4"], farm: ["زراعة", "M3 20l9-15 9 15zM9 20l3-5 3 5"], gavel: ["إدارة/محكمة", "M3 21h8M7 21v-4M13 3l6 6-3 3-6-6zM8 8l-4 4 3 3 4-4"],
  museum: ["متحف/ثقافة", "M3 10l9-6 9 6zM5 10v8M9 10v8M15 10v8M19 10v8M3 20h18"], bed: ["سرير/مأوى", "M3 18V6M3 12h18v6M7 10h4"], dot: ["نقطة", "M12 8a4 4 0 100 8 4 4 0 000-8z", 1], tent: ["مخيم", "M3 20L12 4l9 16zM12 4v16"], key: ["مفتاح", "M14 10a4 4 0 11-2 3.4L4 21v-3l3-1v-2l2-1 3-3a4 4 0 012-1z"]
};
const SEC_DEF = { "مواصلات": "car", "سياسي": "flag", "اداري": "gavel", "مدني": "heart", "تجاري": "cart", "مالي": "bank", "تربوي": "school", "ترفيهي": "tree", "رياضي": "ball", "خدماتي": "wrench", "ديني": "mosque", "زراعي": "farm", "صحي": "cross", "صناعي": "factory", "ثقافي": "museum" };
const TYP_DEF = { "كنيسه": "church", "مقبره": "tomb", "صيدليه": "pill", "مصرف": "bank", "مطعم": "food", "مقهي": "cafe", "فندق": "hotel", "جامعه": "cap", "كليه": "cap", "مكتبه": "book", "سفاره": "flag", "قنصليه": "flag", "سيطره": "shield", "محطه قطار": "train", "كراج": "bus", "سوق": "cart", "مول": "cart", "متنزه": "tree", "حديقه": "tree", "ملعب": "ball", "مسرح": "museum", "سينما": "camera", "معمل": "factory", "مصنع": "factory", "محطه صرف صحي": "drop" };
const FILLED = new Set(Object.keys(GL).filter(k => GL[k][2]));
function defGlyph(p) {
  const ty = normA(p.type).trim(); if (TYP_DEF[ty]) return TYP_DEF[ty];
  const sc = normA(p.Gategory); for (const k in SEC_DEF) if (sc.includes(k)) return SEC_DEF[k]; return "";
}
const glyphSvg = (g, col, px) => `<svg viewBox="0 0 64 64" width="${px}" height="${px}"><circle cx="32" cy="32" r="29" fill="${col}" stroke="#fff" stroke-width="4"/><g transform="translate(14 14) scale(1.5)" fill="${FILLED.has(g) ? "#fff" : "none"}" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${(GL[g] || GL.pin)[1]}"/></g></svg>`;

/* ===== صور الرموز والأسماء تُولَّد عند الطلب (تعمل بلا إنترنت) ===== */
window.addEventListener("DOMContentLoaded", () => {
  map.on("styleimagemissing", e => {
    const id = e.id; if (!id || map.hasImage(id)) return;
    try {
      if (id.startsWith("ic|")) {
        const [, g, col] = id.split("|"), cv = document.createElement("canvas"); cv.width = cv.height = 64; const x = cv.getContext("2d");
        x.beginPath(); x.arc(32, 32, 29, 0, 7); x.fillStyle = col || "#1e88ff"; x.fill(); x.lineWidth = 4; x.strokeStyle = "#fff"; x.stroke();
        x.translate(14, 14); x.scale(1.5, 1.5); x.lineWidth = 2; x.lineCap = x.lineJoin = "round"; x.strokeStyle = x.fillStyle = "#fff"; const p = new Path2D((GL[g] || GL.pin)[1]); FILLED.has(g) ? x.fill(p) : x.stroke(p);
        map.addImage(id, x.getImageData(0, 0, 64, 64));
      } else if (id.startsWith("nm|")) {
        const txt = id.slice(3), d = 2, c = document.createElement("canvas"), x = c.getContext("2d"), f = `600 ${12.5 * d}px sans-serif`; x.font = f;
        const w = Math.ceil(Math.min(x.measureText(txt).width, 170 * d)) + 10 * d, h = 20 * d; c.width = w; c.height = h; x.font = f; x.textAlign = "center"; x.textBaseline = "middle"; x.lineJoin = "round";
        x.lineWidth = 4 * d; x.strokeStyle = "rgba(255,255,255,.95)"; x.strokeText(txt, w / 2, h / 2, w - 4); x.fillStyle = "#16202b"; x.fillText(txt, w / 2, h / 2, w - 4);
        map.addImage(id, x.getImageData(0, 0, w, h), { pixelRatio: d });
      }
    } catch (er) { }
  });
});

/* ===== رموز المعالم: الحل والتجهيز ===== */
function iconFor(p, dsid) {
  const O = S.set.icons || {};
  for (const [k, v] of [["f", p.id], ["t", p.type], ["s", p.Gategory], ["d", dsid]]) { if (!v) continue; const o = O[k + ":" + v]; if (o) return o; }
  return null;
}
function iconRes(p, dsid) {
  if (S.set.icon_on === false) return null;
  const o = iconFor(p, dsid); if (o) { if (o.g === "none") return null; const g = o.g || defGlyph(p); return g ? { g, s: o.s || 1 } : null; }
  const g = defGlyph(p); return g ? { g, s: 1 } : null;
}
function decorate(g, d) {
  g.features.forEach(f => { if (!f.geometry || f.geometry.type !== "Point") return; const p = f.properties, r = iconRes(p, d.id); p._ic = r ? r.g + "|" + (p.color || d.color) : ""; p._is = r ? r.s : 1; if (r) p._ic = "ic|" + p._ic; });
}
const iconSizeExpr = () => {
  const b = (+S.set.icon_size || 26) / 64, m = ["get", "_is"];
  if (S.set.icon_zoom === false) return ["*", m, b];
  return ["interpolate", ["linear"], ["zoom"], 5, ["*", m, b * .45], 10, ["*", m, b * .65], 14, ["*", m, b * .95], 18, ["*", m, b * 1.3]];
};
const GJ = {};
dsLayers = function (id) { return ["f", "l", "c", "i"].map(k => `d-${id}-${k}`); };
function dsVis(d) {
  dsLayers(d.id).forEach(l => map.getLayer(l) && map.setLayoutProperty(l, "visibility", d.visible ? "visible" : "none"));
  const tl = `d-${d.id}-t`; if (map.getLayer(tl)) map.setLayoutProperty(tl, "visibility", S.names && d.visible ? "visible" : "none");
}
function paintDs(d) {
  const sid = "d-" + d.id, g = GJ[d.id]; if (!g) return; decorate(g, d);
  if (map.getSource(sid)) { map.getSource(sid).setData(g); return; }
  map.addSource(sid, { type: "geojson", data: g });
  const col = ["coalesce", ["get", "color"], d.color], pt = ["==", ["geometry-type"], "Point"], hasI = ["!=", ["get", "_ic"], ""];
  map.addLayer({ id: sid + "-f", type: "fill", source: sid, filter: ["==", "$type", "Polygon"], paint: { "fill-color": col, "fill-opacity": .22 } }, "area-f");
  map.addLayer({ id: sid + "-l", type: "line", source: sid, filter: ["!=", "$type", "Point"], paint: { "line-color": col, "line-width": 2.2 } }, "area-f");
  map.addLayer({ id: sid + "-c", type: "circle", source: sid, filter: ["all", pt, ["==", ["get", "_ic"], ""]], paint: { "circle-radius": ["interpolate", ["linear"], ["zoom"], 8, 3, 14, 6, 18, 9], "circle-color": col, "circle-stroke-width": 2, "circle-stroke-color": "#fff" } }, "area-f");
  map.addLayer({ id: sid + "-i", type: "symbol", source: sid, filter: ["all", pt, hasI], layout: { "icon-image": ["get", "_ic"], "icon-size": iconSizeExpr(), "icon-allow-overlap": true, "icon-ignore-placement": true } }, "area-f");
  map.addLayer({ id: sid + "-t", type: "symbol", source: sid, minzoom: 11, filter: ["all", ["has", "name"], ["!=", ["get", "name"], ""]], layout: { "icon-image": ["concat", "nm|", ["get", "name"]], "icon-anchor": "top", "icon-offset": [0, 13], "icon-allow-overlap": false, "icon-optional": false, visibility: "none" } }, "area-f");
  dsLayers(d.id).forEach(l => { map.on("click", l, e => featClick(e)); map.on("mouseenter", l, () => map.getCanvas().style.cursor = "pointer"); map.on("mouseleave", l, () => map.getCanvas().style.cursor = ""); });
}
ensureDs = async function (d, force) {
  if (!map.getSource("d-" + d.id) || force || !GJ[d.id]) { GJ[d.id] = await api(`/api/datasets/${d.id}/geojson`); paintDs(d); }
  dsVis(d);
};
addNameLayer = function (d) { dsVis(d); };
ensureGlyphs = function () { };
function restyleAll() {
  S.ds.forEach(d => { if (GJ[d.id] && map.getSource("d-" + d.id)) { decorate(GJ[d.id], d); map.getSource("d-" + d.id).setData(GJ[d.id]); const l = `d-${d.id}-i`; if (map.getLayer(l)) map.setLayoutProperty(l, "icon-size", iconSizeExpr()); } });
}
const _refreshDs5 = refreshDs;
refreshDs = async function (ids) { (ids || []).forEach(i => delete GJ[i]); S.ds.forEach(d => { }); await _refreshDs5(ids); Object.keys(GJ).forEach(k => { if (!dsIds().includes(k)) delete GJ[k]; }); };

/* ===== منتقي الرمز ===== */
async function saveIcons(O) { S.set.icons = O; await setSet("icons", O); restyleAll(); }
function openIconPicker(c) {
  const sc = []; if (c.m) sc.push(["m", t("ic_sel") + " (" + c.m.length + ")"]); if (c.f) sc.push(["f", t("ic_f")]); if (c.t) sc.push(["t", t("ic_t") + " «" + c.t + "»"]); if (c.s) sc.push(["s", t("ic_s") + " " + c.s]); if (c.d) sc.push(["d", t("ic_d")]);
  if (!sc.length) return; let scope = (sc.find(x => x[0] === "s") || sc[0])[0], g = undefined, size = 1; const col = c.color || "#1e88ff";
  const cur = () => (S.set.icons || {})[scope + ":" + (c[scope] || "")];
  const b = el(`<div><label class="f">${t("ic_scope")}</label><select class="in" id="ip_s">${sc.map(([k, l]) => `<option value="${k}" ${k === scope ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>
    <label class="f">${t("ic_pick")}</label><div class="icg" id="ip_g"></div>${rangeRow(t("ic_sz"), "ip_z", 0.5, 2.5, 0.1, 1)}
    <div class="card" style="margin-top:10px"><div class="row"><div class="t">${t("ic_zoom")}</div><span id="ip_zm"></span></div></div></div>`);
  const grid = $("#ip_g", b);
  const draw = () => {
    grid.innerHTML = ""; const o = cur(); if (g === undefined && o) { g = o.g || "def"; size = o.s || 1; $("#ip_z", b).value = size; $("#ip_z_v", b).textContent = size; } if (g === undefined) g = "def";
    const add = (k, html, lab) => { const x = el(`<button class="ig ${g === k ? "on" : ""}" title="${esc(lab)}">${html}</button>`, grid); x.onclick = () => { g = k; draw(); }; };
    add("def", `<span class="igt">${t("ic_def")}</span>`, t("ic_def")); add("none", `<span class="igt">${t("ic_none")}</span>`, t("ic_none"));
    Object.keys(GL).forEach(k => add(k, glyphSvg(k, col, 38), GL[k][0]));
  };
  draw();
  $("#ip_s", b).onchange = e => { scope = e.target.value; g = undefined; draw(); };
  $("#ip_z", b).oninput = e => { size = +e.target.value; $("#ip_z_v", b).textContent = size; };
  $("#ip_zm", b).appendChild(sw(S.set.icon_zoom !== false, async v => { await setSet("icon_zoom", v); restyleAll(); }));
  modal(t("ic_menu"), b, async () => {
    const O = Object.assign({}, S.set.icons || {}), keys = scope === "m" ? c.m.map(i => "f:" + i) : [scope + ":" + c[scope]];
    keys.forEach(k => { if (g === "def" && size === 1) delete O[k]; else O[k] = Object.assign({}, g === "def" ? {} : { g }, size !== 1 ? { s: size } : {}); if (g === "def" && size === 1) delete O[k]; });
    await saveIcons(O);
  });
}
function iconMenu(fs, x, y) {
  const f = fs[0], p = f.properties, m = /^d-(.+)-[ci]$/.exec(f.layer.id), dsid = m ? m[1] : "", ds = S.ds.find(d => d.id === dsid), color = p.color || (ds && ds.color);
  const items = [["pin", t("ic_menu") + " — " + (p.name || p.type || "…"), () => openIconPicker({ f: p.id, t: p.type, s: p.Gategory, d: dsid, color })]];
  if (fs.length > 1) items.push(["pin", t("ic_sel") + " (" + fs.length + ")", () => openIconPicker({ m: fs.map(z => z.properties.id), s: p.Gategory, t: p.type, d: dsid, color })]);
  items.push(["x", t("ic_none"), () => { const O = Object.assign({}, S.set.icons || {}); O["f:" + p.id] = { g: "none" }; saveIcons(O); }]);
  menuAt(items, x, y);
}
window.addEventListener("DOMContentLoaded", () => {
  const cv = map.getCanvas(); let tm, sx, sy;
  cv.addEventListener("pointerdown", e => {
    if (e.pointerType === "mouse" && e.button !== 0) return; sx = e.clientX; sy = e.clientY; clearTimeout(tm);
    tm = setTimeout(() => {
      if (window.__mode || ADD.mode) return; const r = cv.getBoundingClientRect(), px = sx - r.left, py = sy - r.top;
      const lays = S.ds.flatMap(d => [`d-${d.id}-c`, `d-${d.id}-i`]).filter(l => map.getLayer(l)); if (!lays.length) return;
      const fs = map.queryRenderedFeatures([[px - 16, py - 16], [px + 16, py + 16]], { layers: lays }); if (!fs.length) return;
      window.__lpT = Date.now(); try { cv.dispatchEvent(new PointerEvent("pointercancel")); } catch (er) { } navigator.vibrate && navigator.vibrate(15); iconMenu(fs, sx, sy);
    }, 520);
  });
  ["pointerup", "pointercancel"].forEach(ev => cv.addEventListener(ev, () => clearTimeout(tm)));
  cv.addEventListener("pointermove", e => { if (Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) > 8) clearTimeout(tm); });
  map.on("movestart", () => clearTimeout(tm)); map.on("zoomstart", () => clearTimeout(tm));
});
const _featClick5 = featClick; featClick = function (e) { if (window.__lpT && Date.now() - window.__lpT < 900) return; _featClick5(e); };
const _dsMenu5 = dsMenu;
dsMenu = function (d, x, y) {
  const mu = menuAt; menuAt = (items, x2, y2) => { menuAt = mu; items.push(["pin", t("ic_menu"), () => openIconPicker({ d: d.id, color: d.color })]); mu(items, x2, y2); };
  try { _dsMenu5(d, x, y); } finally { menuAt = mu; }
};

/* ===== علامة + في مركز الخريطة ===== */
function applyCross() {
  const c = $("#cross"); if (!c) return; const s = S.set, sh = s.cross_shape || "plus", sz = +s.cross_size || 34, w = +s.cross_width || 2, col = s.cross_color || "#1e7bff", op = s.cross_opacity == null ? .9 : +s.cross_opacity;
  c.style.display = sh === "none" ? "none" : ""; c.style.width = c.style.height = sz + "px"; c.style.margin = `${-sz / 2}px 0 0 ${-sz / 2}px`; c.style.opacity = op;
  const L = (a, b, c2, d) => `<line x1="${a}" y1="${b}" x2="${c2}" y2="${d}"/>`, C = (r, f) => `<circle cx="50" cy="50" r="${r}" ${f ? "" : 'fill="none"'}/>`;
  const parts = { plus: L(50, 4, 50, 96) + L(4, 50, 96, 50), gap: L(50, 4, 50, 38) + L(50, 62, 50, 96) + L(4, 50, 38, 50) + L(62, 50, 96, 50), dot: C(10, 1), ring: C(38) + C(3, 1), target: C(32) + L(50, 4, 50, 24) + L(50, 76, 50, 96) + L(4, 50, 24, 50) + L(76, 50, 96, 50) + C(3, 1) }[sh] || "";
  const g = (stroke, wd) => `<g stroke="${stroke}" stroke-width="${wd}" stroke-linecap="round" fill="${stroke}" vector-effect="non-scaling-stroke">${parts}</g>`;
  c.innerHTML = `<svg viewBox="0 0 100 100" width="100%" height="100%" style="overflow:visible">${g("rgba(255,255,255,.95)", w + 3)}${g(col, w)}</svg>`;
  c.querySelectorAll("*").forEach(n => n.setAttribute("vector-effect", "non-scaling-stroke"));
}
const _drawArea5 = drawArea;
drawArea = function (l) { _drawArea5(l); if (hd.mv) hd.mv.getElement().style.display = (A.show && !A.follow) ? "" : "none"; };
window.addEventListener("DOMContentLoaded", () => { applyCross(); });

/* ===== الرسومات القابلة للتحرير ===== */
const DR = { items: [], sel: null, vis: true }; let drN = 0;
try { DR.items = JSON.parse(localStorage.getItem("drawings") || "[]"); } catch (e) { }
const drSave = () => { try { localStorage.setItem("drawings", JSON.stringify(DR.items)); } catch (e) { } };
const drOf = id => DR.items.find(d => d.id === id);
DR.add = o => { const d = Object.assign({ id: "dr" + Date.now().toString(36) + (drN++), kind: "line", pts: [], color: "#f08c00", width: 4, dash: "solid", fillop: .25, seg: false, tot: true, icon: "", iat: "last", name: "", vis: true }, o); DR.items.push(d); drSave(); drRender(); return d; };
const drKindName = d => t("dr_kind_" + d.kind);
function simp(pts, tol) {
  if (pts.length < 3) return pts; const k = 111320, cl = Math.cos(pts[0][0] * Math.PI / 180), X = p => [p[1] * k * cl, p[0] * k], keep = new Uint8Array(pts.length); keep[0] = keep[pts.length - 1] = 1; const st = [[0, pts.length - 1]], Q = pts.map(X);
  while (st.length) { const [a, b] = st.pop(); let m = -1, dm = 0; const [ax, ay] = Q[a], [bx, by] = Q[b], dx = bx - ax, dy = by - ay, L = dx * dx + dy * dy;
    for (let i = a + 1; i < b; i++) { const [px, py] = Q[i]; let tt = L ? ((px - ax) * dx + (py - ay) * dy) / L : 0; tt = Math.max(0, Math.min(1, tt)); const d = Math.hypot(px - ax - tt * dx, py - ay - tt * dy); if (d > dm) { dm = d; m = i; } }
    if (dm > tol && m > 0) { keep[m] = 1; st.push([a, m], [m, b]); } }
  return pts.filter((_, i) => keep[i]);
}
function drStat(d) {
  const n = d.pts.length; if (d.kind === "area") return `${t("area_")}: <b>${n >= 3 ? fa(parea(d.pts)) : "—"}</b> · ${t("perim")}: ${fm(plen(d.pts.concat(n > 2 ? [d.pts[0]] : [])))} · ${n} ${t("pts_")}`;
  return `${t("total")}: <b>${fm(plen(d.pts))}</b> · ${n} ${t("pts_")}`;
}
function drFC() {
  const f = []; if (!DR.vis) return fc();
  DR.items.forEach(d => {
    if (!d.vis || !d.pts.length) return; const co = d.pts.map(p => [p[1], p[0]]), n = co.length, closed = d.kind === "area" && n >= 3, sel = DR.sel === d.id ? 1 : 0, P = { id: d.id, c: d.color, w: d.width, dash: d.dash, sel };
    if (closed) f.push(ft({ type: "Polygon", coordinates: [co.concat([co[0]])] }, Object.assign({ fo: d.fillop }, P)));
    if (n >= 2) f.push(ft({ type: "LineString", coordinates: closed ? co.concat([co[0]]) : co }, P));
    co.forEach((c, i) => f.push(ft({ type: "Point", coordinates: c }, { id: d.id, c: d.color, k: "v", i })));
    if (d.icon && GL[d.icon]) { const at = { all: co, first: [co[0]], last: [co[n - 1]], ctr: [co[Math.floor((n - 1) / 2)]] }[d.iat] || [co[n - 1]]; at.forEach(c => f.push(ft({ type: "Point", coordinates: c }, { id: d.id, k: "i", ic: `ic|${d.icon}|${d.color}` }))); }
    const lab = (c, txt) => f.push(ft({ type: "Point", coordinates: c }, { id: d.id, k: "t", lbl: txt }));
    if (d.tot && n >= 2) { if (closed) { const cx = co.reduce((s, c) => s + c[0], 0) / n, cy = co.reduce((s, c) => s + c[1], 0) / n; lab([cx, cy], fa(parea(d.pts))); } else { const i = Math.floor((n - 1) / 2); lab([(co[i][0] + co[i + 1][0]) / 2, (co[i][1] + co[i + 1][1]) / 2], fm(plen(d.pts))); } }
    if (d.seg && n >= 2) for (let i = 0; i < (closed ? n : n - 1); i++) { const a = d.pts[i], b = d.pts[(i + 1) % n]; lab([(a[1] + b[1]) / 2, (a[0] + b[0]) / 2], fm(hav(a, b))); }
  });
  return fc(...f);
}
function drRender() { const s = map && map.getSource && map.getSource("dr"); if (s) s.setData(drFC()); }
function initDr() {
  if (map.getSource("dr")) return; map.addSource("dr", { type: "geojson", data: drFC() });
  const L = ["==", ["geometry-type"], "LineString"], dsh = k => ["all", L, ["==", ["get", "dash"], k]], lp = { "line-cap": "round", "line-join": "round" };
  map.addLayer({ id: "dr-f", type: "fill", source: "dr", filter: ["==", "$type", "Polygon"], paint: { "fill-color": ["get", "c"], "fill-opacity": ["get", "fo"] } });
  map.addLayer({ id: "dr-sel", type: "line", source: "dr", filter: ["all", L, ["==", ["get", "sel"], 1]], layout: lp, paint: { "line-color": "#fff", "line-width": ["+", ["get", "w"], 7], "line-opacity": .85 } });
  map.addLayer({ id: "dr-b", type: "line", source: "dr", filter: L, layout: lp, paint: { "line-color": "#fff", "line-width": ["+", ["get", "w"], 2.5], "line-opacity": .75 } });
  map.addLayer({ id: "dr-l-solid", type: "line", source: "dr", filter: dsh("solid"), layout: lp, paint: { "line-color": ["get", "c"], "line-width": ["get", "w"] } });
  map.addLayer({ id: "dr-l-dashed", type: "line", source: "dr", filter: dsh("dashed"), layout: { "line-join": "round" }, paint: { "line-color": ["get", "c"], "line-width": ["get", "w"], "line-dasharray": [2.5, 1.5] } });
  map.addLayer({ id: "dr-l-dotted", type: "line", source: "dr", filter: dsh("dotted"), layout: { "line-cap": "round" }, paint: { "line-color": ["get", "c"], "line-width": ["get", "w"], "line-dasharray": [.1, 2] } });
  map.addLayer({ id: "dr-v", type: "circle", source: "dr", filter: ["all", ["==", ["geometry-type"], "Point"], ["==", ["get", "k"], "v"]], paint: { "circle-radius": 4, "circle-color": "#fff", "circle-stroke-color": ["get", "c"], "circle-stroke-width": 2.5 } });
  map.addLayer({ id: "dr-i", type: "symbol", source: "dr", filter: ["all", ["==", ["geometry-type"], "Point"], ["==", ["get", "k"], "i"]], layout: { "icon-image": ["get", "ic"], "icon-size": .55, "icon-allow-overlap": true, "icon-ignore-placement": true } });
  map.addLayer({ id: "dr-t", type: "symbol", source: "dr", filter: ["all", ["==", ["geometry-type"], "Point"], ["==", ["get", "k"], "t"]], layout: { "icon-image": ["concat", "nm|", ["get", "lbl"]], "icon-allow-overlap": true, "icon-ignore-placement": true } });
  ["dr-f", "dr-b", "dr-l-solid", "dr-l-dashed", "dr-l-dotted", "dr-v", "dr-i"].forEach(l => { map.on("click", l, e => { if (window.__mode || ADD.mode) return; const f = e.features[0]; if (f && f.properties.id) { e._fc = 1; window.__drT = Date.now(); openDraw(f.properties.id); } }); });
}
window.addEventListener("DOMContentLoaded", () => { if (map.loaded()) initDr(); else map.on("load", initDr); });

const _stopMode5 = stopMode;
stopMode = function (keep) {
  const m = MODE;
  if (m && m.getPts && !keep && !window.__noDraw) {
    const raw = m.getPts().slice(), k = m.dk;
    if (raw.length >= 2) { const kind = k === "area" && raw.length >= 3 ? "area" : "line", nm = k === "ruler" ? t("dr_kind_ruler") : ""; const d = DR.add({ kind: k === "ruler" ? "ruler" : kind, pts: raw, name: nm, color: k === "area" ? "#f59f00" : k === "ruler" ? "#e03131" : "#f08c00", seg: raw.length > 2 }); setTimeout(() => toast(t("dr_made"), [[t("dr_edit"), () => drEdit(d.id)], [t("dr"), () => openDraw(d.id)]]), 30); }
  }
  _stopMode5(keep);
};
const _trkStop5 = trkStop;
trkStop = function (save) { const pts = (TRK.pts || []).slice(); _trkStop5(save); if (save && pts.length >= 2) { const d = DR.add({ kind: "track", pts: simp(pts.map(p => [p[0], p[1]]), 2), color: "#12a36b", width: 5, tot: true, name: "Track " + new Date().toISOString().slice(0, 16).replace("T", " ") }); toast(t("dr_made"), [[t("dr_edit"), () => drEdit(d.id)]]); } };
const _showRouteInfo5 = showRouteInfo;
showRouteInfo = function (b) {
  _showRouteInfo5(b); const bt = $("#rt_sv", b); if (!bt || $("#rt_ed", b)) return;
  const x = el(`<button class="btn sec2" id="rt_ed">${I("edit")}${t("dr_edit")}</button>`); bt.parentNode.insertBefore(x, bt);
  x.onclick = () => { const pts = simp(RT.line.map(c => [c[1], c[0]]), 3), d = DR.add({ kind: "route", pts, color: "#1e7bff", width: 5, name: (RT.from ? RT.from.label : "") + " → " + (RT.to ? RT.to.label : "") }); RT.line = null; RT.info = null; RT.from = RT.to = null; drawRouteEnds(); closeSheet(); drEdit(d.id); };
};
const ptTxt = p => p[0].toFixed(6) + ", " + p[1].toFixed(6);
function drCoordEdit(d, i, done) {
  const b = el(`<div>${fieldRow(t("dr_coord"), "dc_v", ptTxt(d.pts[i]))}</div>`);
  modal(t("dr_pts") + " " + (i + 1), b, () => { const m = $("#dc_v", b).value.match(/-?\d+(\.\d+)?/g); if (!m || m.length < 2) return false; d.pts[i] = [+m[0], +m[1]]; drSave(); drRender(); done && done(); });
}
function openDrPts(id) {
  const d = drOf(id); if (!d) return;
  openSheet("drpts", (d.name || drKindName(d)) + " — " + t("dr_pts"), b => {
    b.innerHTML = `<div class="hint">${drStat(d)}</div><div class="card" id="dp_l"></div>`; let cum = 0;
    d.pts.forEach((p, i) => { const seg = i ? hav(d.pts[i - 1], p) : 0; cum += seg;
      const r = el(`<div class="row"><div class="t"><b>${i + 1}</b> · <span dir="ltr">${ptTxt(p)}</span><small>${i ? t("from_prev") + ": " + fm(seg) + " · " + t("cum") + ": " + fm(cum) : "—"}</small></div><button class="ib sm" data-a="go">${I("pin")}</button><button class="ib sm" data-a="ed">${I("edit")}</button><button class="ib sm er" data-a="rm">${I("trash")}</button></div>`, $("#dp_l", b));
      $("[data-a=go]", r).onclick = () => { map.flyTo({ center: [p[1], p[0]], zoom: Math.max(map.getZoom(), 16) }); marker("sr", p[1], p[0]); };
      $("[data-a=ed]", r).onclick = () => drCoordEdit(d, i, () => openDrPts(id));
      $("[data-a=rm]", r).onclick = () => { d.pts.splice(i, 1); drSave(); drRender(); openDrPts(id); }; });
    b.appendChild(el(`<div class="btns"><button class="btn" id="dp_e">${I("edit")}${t("dr_edit")}</button><button class="btn sec2" id="dp_b">${t("dr_view")}</button></div>`)); $("#dp_e", b).onclick = () => drEdit(id); $("#dp_b", b).onclick = () => openDraw(id);
  }, { full: true });
}
function drEdit(id) {
  const d = drOf(id); if (!d) return; DR.sel = id; drRender(); let mks = [], mids = [], addMode = false; const hist = [], snap = () => hist.push(JSON.stringify(d.pts)), closed = () => d.kind === "area";
  const stat = () => { const bar = MODE && MODE.bar; if (bar) $(".mv", bar).innerHTML = drStat(d) + `<br><span class="hint">${t("dr_hint")}</span>`; };
  const vmenu = (i, x, y) => { const p = d.pts[i], seg = i ? hav(d.pts[i - 1], p) : 0, cum = plen(d.pts.slice(0, i + 1));
    menuAt([["pin", `${i + 1} · ${ptTxt(p)}`, () => copyText(ptTxt(p))], ["ruler", i ? `${t("from_prev")}: ${fm(seg)} · ${t("cum")}: ${fm(cum)}` : "—", () => { }], ["edit", t("dr_coord"), () => drCoordEdit(d, i, build)], ["nav", t("goto"), () => navStart({ lat: p[0], lon: p[1], name: ptTxt(p) })], ["trash", t("dr_del"), () => { snap(); d.pts.splice(i, 1); drSave(); drRender(); build(); stat(); }, "er"]], x, y); };
  function build() {
    mks.forEach(m => m.remove()); mids.forEach(m => m.remove()); mks = []; mids = [];
    d.pts.forEach((p, i) => { const e = document.createElement("div"); e.className = "dv"; e.textContent = i + 1; const m = new maplibregl.Marker({ element: e, draggable: true }).setLngLat([p[1], p[0]]).addTo(map); let moved = false;
      m.on("dragstart", () => { moved = true; snap(); }); m.on("drag", () => { const l = m.getLngLat(); d.pts[i] = [l.lat, l.lng]; drRender(); stat(); }); m.on("dragend", () => { drSave(); build(); });
      e.addEventListener("click", ev => { ev.stopPropagation(); if (moved) { moved = false; return; } vmenu(i, ev.clientX, ev.clientY); }); mks.push(m); });
    const n = d.pts.length, last = closed() ? n : n - 1;
    for (let i = 0; i < last; i++) { const a = d.pts[i], b2 = d.pts[(i + 1) % n], e = document.createElement("div"); e.className = "dmid"; e.textContent = "+"; const ll = [(a[1] + b2[1]) / 2, (a[0] + b2[0]) / 2], m = new maplibregl.Marker({ element: e }).setLngLat(ll).addTo(map);
      e.addEventListener("click", ev => { ev.stopPropagation(); snap(); d.pts.splice(i + 1, 0, [ll[1], ll[0]]); drSave(); drRender(); build(); stat(); }); mids.push(m); }
  }
  startMode({
    start(bar) { bar.innerHTML = barHtml(t("dr_edit"), "", [["e_u", "rot", t("undo")], ["e_a", "plus", t("dr_add")], ["e_l", "table", t("dr_pts")], ["e_d", "check", t("dr_done"), "btn"]]); build(); stat();
      $("#e_u", bar).onclick = () => { const h = hist.pop(); if (h) { d.pts = JSON.parse(h); drSave(); drRender(); build(); stat(); } };
      $("#e_a", bar).onclick = e => { addMode = !addMode; e.currentTarget.classList.toggle("on", addMode); };
      $("#e_l", bar).onclick = () => { stopMode(true); openDrPts(id); }; $("#e_d", bar).onclick = () => { stopMode(true); openDraw(id); }; },
    click(e) { if (addMode) { snap(); d.pts.push([e.lngLat.lat, e.lngLat.lng]); drSave(); drRender(); build(); stat(); } },
    stop() { mks.forEach(m => m.remove()); mids.forEach(m => m.remove()); DR.sel = null; drRender(); }
  });
}
function openDraw(id) {
  const d = drOf(id); if (!d) return; DR.sel = id; drRender();
  openSheet("draw", (d.name || drKindName(d)), b => {
    const opts = (arr, cur) => arr.map(([v, l]) => `<option value="${v}" ${v === cur ? "selected" : ""}>${l}</option>`).join("");
    b.innerHTML = `<div class="card" style="padding:12px"><b>${drKindName(d)}</b><div class="hint" id="dw_s" style="margin:4px 0 0">${drStat(d)}</div></div>
      ${fieldRow(t("name"), "dw_n", d.name || "")}
      <label class="f">${t("dr_color")}</label><div class="swr" id="dw_c">${COLS.map(c => `<button class="swc ${c === d.color ? "on" : ""}" data-c="${c}" style="background:${c}"></button>`).join("")}<input type="color" id="dw_cc" value="${/^#[0-9a-f]{6}$/i.test(d.color) ? d.color : "#1e88ff"}"></div>
      ${rangeRow(t("dr_w"), "dw_w", 1, 14, 1, d.width)}
      <label class="f">${t("dr_dash")}</label><select class="in" id="dw_d">${opts([["solid", t("solid")], ["dashed", t("dashed")], ["dotted", t("dotted")]], d.dash)}</select>
      ${d.kind === "area" ? rangeRow(t("dr_fill"), "dw_f", 0, 0.8, 0.05, d.fillop) : ""}
      <label class="f">${t("dr_icon")}</label><div class="btns" style="margin:0"><button class="btn sec2" id="dw_i">${d.icon ? glyphSvg(d.icon, d.color, 22) : ""} ${d.icon ? GL[d.icon][0] : t("ic_none")}</button><select class="in" id="dw_at" style="flex:1">${opts([["all", t("at_all")], ["first", t("at_first")], ["last", t("at_last")], ["ctr", t("at_ctr")]], d.iat)}</select></div>
      <div class="card" style="margin-top:12px"><div class="row"><div class="t">${t("dr_tot")}</div><span id="dw_t"></span></div><div class="row"><div class="t">${t("dr_seg")}</div><span id="dw_g"></span></div></div>
      <div class="btns"><button class="btn" id="dw_e">${I("edit")}${t("dr_edit")}</button><button class="btn sec2" id="dw_p">${I("table")}${t("dr_pts")}</button></div>
      <div class="btns"><button class="btn sec2" id="dw_z">${I("zoom")}${t("dr_zoom")}</button><button class="btn sec2" id="dw_sv">${I("save")}${t("dr_save")}</button><button class="btn sec2" id="dw_x">${I("share")}${t("dr_geo")}</button></div>
      <div class="btns"><button class="btn sec2" id="dw_dup">${I("copy")}${t("dr_dup")}</button><button class="btn sec2 er" id="dw_del">${I("trash")}${t("dr_del")}</button></div>`;
    const up = () => { drSave(); drRender(); }, chg = (k, v) => { d[k] = v; up(); };
    $("#dw_n", b).onchange = e => { chg("name", e.target.value); $("#sh-t").textContent = d.name || drKindName(d); };
    const setCol = c => { chg("color", c); $$(".swc", b).forEach(x => x.classList.toggle("on", x.dataset.c === c)); }; $$(".swc", b).forEach(x => x.onclick = () => setCol(x.dataset.c)); $("#dw_cc", b).oninput = e => setCol(e.target.value);
    $("#dw_w", b).oninput = e => { $("#dw_w_v", b).textContent = e.target.value; chg("width", +e.target.value); }; $("#dw_d", b).onchange = e => chg("dash", e.target.value);
    if ($("#dw_f", b)) $("#dw_f", b).oninput = e => { $("#dw_f_v", b).textContent = e.target.value; chg("fillop", +e.target.value); };
    $("#dw_at", b).onchange = e => chg("iat", e.target.value);
    $("#dw_i", b).onclick = () => openDrIcon(d, () => openDraw(id));
    $("#dw_t", b).appendChild(sw(d.tot, v => chg("tot", v))); $("#dw_g", b).appendChild(sw(d.seg, v => chg("seg", v)));
    $("#dw_e", b).onclick = () => drEdit(id); $("#dw_p", b).onclick = () => openDrPts(id);
    $("#dw_z", b).onclick = () => { const bb = new maplibregl.LngLatBounds(); d.pts.forEach(p => bb.extend([p[1], p[0]])); closeSheet(); map.fitBounds(bb, { padding: 70, maxZoom: 18 }); };
    $("#dw_sv", b).onclick = () => saveDraw(d.kind === "area" ? "polygon" : "line", d.pts.slice());
    $("#dw_x", b).onclick = () => { const co = d.pts.map(p => [p[1], p[0]]), g = d.kind === "area" ? { type: "Polygon", coordinates: [co.concat([co[0]])] } : { type: "LineString", coordinates: co }; saveBlob(new Blob([JSON.stringify(fc(ft(g, { name: d.name })))], { type: "application/geo+json" }), (d.name || "drawing").replace(/[^\w؀-ۿ]+/g, "_") + ".geojson", "share"); };
    $("#dw_dup", b).onclick = () => { const c = DR.add(Object.assign({}, JSON.parse(JSON.stringify(d)), { id: undefined, name: (d.name || "") + " 2" })); drOf(c.id) && openDraw(c.id); };
    $("#dw_del", b).onclick = () => { if (!confirm(t("confirm"))) return; DR.items = DR.items.filter(x => x !== d); DR.sel = null; up(); closeSheet(); };
  }, { full: true });
}
function openDrIcon(d, back) {
  let g = d.icon || ""; const b = el(`<div><div class="icg" id="di_g"></div></div>`), grid = $("#di_g", b);
  const draw = () => { grid.innerHTML = ""; const add = (k, h, l) => { const x = el(`<button class="ig ${g === k ? "on" : ""}" title="${esc(l)}">${h}</button>`, grid); x.onclick = () => { g = k; draw(); }; }; add("", `<span class="igt">${t("ic_none")}</span>`, ""); Object.keys(GL).forEach(k => add(k, glyphSvg(k, d.color, 38), GL[k][0])); }; draw();
  modal(t("dr_icon"), b, () => { d.icon = g; drSave(); drRender(); back && back(); });
}
function openDrawings() {
  openSheet("drawings", t("dr_all"), b => {
    if (!DR.items.length) { b.innerHTML = `<div class="hint">${t("dr_none")}</div>`; return; }
    b.innerHTML = `<div class="card" id="dl_l"></div>`;
    DR.items.forEach(d => { const r = el(`<div class="row"><i class="dot" style="background:${d.color}"></i><div class="t" style="cursor:pointer"><b>${esc(d.name || drKindName(d))}</b><small>${drKindName(d)} · ${d.kind === "area" ? fa(parea(d.pts)) : fm(plen(d.pts))} · ${d.pts.length} ${t("pts_")}</small></div></div>`, $("#dl_l", b)); $(".t", r).onclick = () => openDraw(d.id); r.appendChild(sw(d.vis, v => { d.vis = v; drSave(); drRender(); })); });
  });
}
const _openTools5 = openTools;
openTools = async function () { await _openTools5(); const b = $("#sh-b"); if (SHEET !== "tools" || !b) return; const g = $(".grid", b); if (!g) return; const x = el(`<button class="tile">${I("pen")}<span>${t("dr")}${DR.items.length ? " (" + DR.items.length + ")" : ""}</span></button>`, g); x.onclick = openDrawings; };
const _renderShown5 = renderShown;
renderShown = function () { _renderShown5(); const c = $("#shown"); if (!c || !DR.items.length) return; const r = el(`<div class="row"><i class="dot" style="background:#f08c00"></i><div class="t"><b>${t("dr_all")}</b><small>${DR.items.length}</small></div></div>`, c); $(".t", r).onclick = openDrawings; r.appendChild(sw(DR.vis, v => { DR.vis = v; drRender(); })); };
const _clearOverlays5 = clearOverlays;
clearOverlays = function () { window.__noDraw = true; try { _clearOverlays5(); } finally { window.__noDraw = false; } if (DR.items.length && confirm(t("dr_clear_q"))) { DR.items = []; DR.sel = null; drSave(); drRender(); } };

/* ===== الإعدادات: سرعة الجلب + علامة + + الرموز ===== */
function settingsExtra(b) {
  const seg = (id, opts, cur) => `<div class="seg" id="${id}">${opts.map(([v, l]) => `<button data-v="${v}" class="${String(cur) === String(v) ? "on" : ""}">${l}</button>`).join("")}</div>`;
  const wrap = el(`<div id="st5"></div>`, b), fs = S.set.fetch_speed || "fast";
  wrap.innerHTML = `<label class="f" style="margin-top:14px">${t("fspeed")}</label><div class="seg col" id="st_fs">${[["old", "fs_old"], ["prev", "fs_prev"], ["fast", "fs_fast"]].map(([v, k]) => `<button data-v="${v}" class="${fs === v ? "on" : ""}">${t(k)}</button>`).join("")}</div><div class="hint">${t("fs_h")}</div>
    <div class="card" style="margin-top:14px;padding:12px"><b>${t("cr_h")}</b>
      <label class="f">${t("cr_shape")}</label>${seg("st_cs", ["plus", "gap", "dot", "ring", "target", "none"].map(k => [k, t("cs_" + k)]), S.set.cross_shape || "plus")}
      ${rangeRow(t("cr_size"), "st_cz", 16, 90, 2, +S.set.cross_size || 34)}${rangeRow(t("cr_w"), "st_cw", 1, 8, 1, +S.set.cross_width || 2)}${rangeRow(t("cr_op"), "st_co", 0.2, 1, 0.05, S.set.cross_opacity == null ? .9 : +S.set.cross_opacity)}
      <label class="f">${t("cr_col")}</label><div class="swr" id="st_cc5">${COLS.slice(0, 11).map(c => `<button class="swc ${(S.set.cross_color || "#1e7bff") === c ? "on" : ""}" data-c="${c}" style="background:${c}"></button>`).join("")}<input type="color" id="st_ccc" value="${S.set.cross_color || "#1e7bff"}"></div></div>
    <div class="card" style="margin-top:14px;padding:12px"><b>${t("ic_h")}</b>
      <div class="row"><div class="t">${t("ic_on")}</div><span id="st_ion"></span></div><div class="row"><div class="t">${t("names")}</div><span id="st_nm"></span></div><div class="row"><div class="t">${t("ic_zoom")}</div><span id="st_izm"></span></div>
      ${rangeRow(t("ic_size"), "st_isz", 14, 56, 2, +S.set.icon_size || 26)}
      <label class="f">${t("ic_sectors")}</label><div id="st_isl"></div><div class="btns"><button class="btn sec2 er" id="st_irs">${t("ic_reset")}</button></div></div>`;
  $$("#st_fs button", wrap).forEach(x => x.onclick = () => { $$("#st_fs button", wrap).forEach(y => y.classList.toggle("on", y === x)); setSet("fetch_speed", x.dataset.v); });
  const cs = (k, v) => { setSet(k, v); applyCross(); };
  $$("#st_cs button", wrap).forEach(x => x.onclick = () => { $$("#st_cs button", wrap).forEach(y => y.classList.toggle("on", y === x)); cs("cross_shape", x.dataset.v); });
  [["st_cz", "cross_size"], ["st_cw", "cross_width"], ["st_co", "cross_opacity"]].forEach(([i, k]) => { const r = $("#" + i, wrap); r.oninput = () => { $("#" + i + "_v", wrap).textContent = r.value; S.set[k] = +r.value; applyCross(); }; r.onchange = () => setSet(k, +r.value); });
  const cc = c => { $$("#st_cc5 .swc", wrap).forEach(x => x.classList.toggle("on", x.dataset.c === c)); cs("cross_color", c); }; $$("#st_cc5 .swc", wrap).forEach(x => x.onclick = () => cc(x.dataset.c)); $("#st_ccc", wrap).oninput = e => cc(e.target.value);
  $("#st_ion", wrap).appendChild(sw(S.set.icon_on !== false, async v => { await setSet("icon_on", v); restyleAll(); }));
  $("#st_nm", wrap).appendChild(sw(!!S.names, v => setNames(v)));
  $("#st_izm", wrap).appendChild(sw(S.set.icon_zoom !== false, async v => { await setSet("icon_zoom", v); restyleAll(); }));
  const isz = $("#st_isz", wrap); isz.oninput = () => { $("#st_isz_v", wrap).textContent = isz.value; S.set.icon_size = +isz.value; restyleAll(); }; isz.onchange = () => setSet("icon_size", +isz.value);
  const sl = $("#st_isl", wrap);
  SECT_NAMES.forEach((n, i) => { const g = defGlyph({ Gategory: n }), o = (S.set.icons || {})["s:" + n], gg = o && o.g && o.g !== "none" ? o.g : o && o.g === "none" ? "" : g; const col = ["#e8590c", "#862e9c", "#495057", "#0ca678", "#f59f00", "#2b8a3e", "#1c7ed6", "#e64980", "#74b816", "#15aabf", "#5f3dc4", "#66a80f", "#e03131", "#7b5e57", "#d6336c"][i];
    const r = el(`<button class="row" style="width:100%;border:0;background:none;text-align:start;cursor:pointer">${gg ? glyphSvg(gg, col, 30) : `<i class="dot" style="background:${col}"></i>`}<div class="t"><b>${esc(n)}</b><small>${gg ? GL[gg][0] : t("ic_none")}</small></div></button>`, sl); r.onclick = () => openIconPicker({ s: n, color: col }); });
  $("#st_irs", wrap).onclick = async () => { if (confirm(t("confirm"))) { await saveIcons({}); openSettings(); } };
}
const _openSettings5 = openSettings;
openSettings = function () { _openSettings5(); const b = $("#sh-b"); if (SHEET === "set" && b && !$("#st5", b)) settingsExtra(b); };
const _openFetch5 = openFetch;
openFetch = function () {
  _openFetch5(); const b = $("#sh-b"), go = b && $("#f_go", b); if (!go || $("#f_sp", b)) return; const fs = S.set.fetch_speed || "fast";
  const x = el(`<div id="f_sp"><label class="f">${t("fspeed")}</label><select class="in" id="f_spd">${[["old", "fs_old"], ["prev", "fs_prev"], ["fast", "fs_fast"]].map(([v, k]) => `<option value="${v}" ${fs === v ? "selected" : ""}>${t(k)}</option>`).join("")}</select></div>`);
  go.parentNode.parentNode.insertBefore(x, go.parentNode); $("#f_spd", x).onchange = e => setSet("fetch_speed", e.target.value);
};
