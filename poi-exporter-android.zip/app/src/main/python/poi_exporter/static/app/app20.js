"use strict";
/* ===== app20 (v3.15): مقابض المنطقة بأيقونات + ×، التتبع المحسّن، تفاصيل الرسم، دمج ===== */

/* ---------- مقابض المنطقة ---------- */
const HDI = {
  sz: `<svg viewBox="0 0 24 24"><path d="M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7"/></svg>`,
  rot: `<svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 11-2.6-5.9M20 4v5h-5"/></svg>`,
  x: `<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>`,
  mv: `<svg viewBox="0 0 24 24"><path d="M12 3v18M3 12h18M12 3l-2.5 2.5M12 3l2.5 2.5M12 21l-2.5-2.5M12 21l2.5-2.5M3 12l2.5-2.5M3 12l2.5 2.5M21 12l-2.5-2.5M21 12l-2.5 2.5"/></svg>`
};
function styleHandles() {
  const s = S.set, r = document.documentElement; r.style.setProperty("--hds", (+s.hd_size || 40) + "px"); r.style.setProperty("--hdc", s.hd_color || "#1e7bff"); r.dataset.hds = s.hd_style || "glass";
  Object.entries(hd).forEach(([k, m]) => { const e = m.getElement(); if (e.dataset.ic !== k) { e.dataset.ic = k; e.innerHTML = HDI[k] || ""; } });
  if (hd.x) hd.x.getElement().style.display = (s.hd_x !== false && A.show) ? "" : "none";
}
function applyAreaStyle() {
  if (!map || !map.getLayer || !map.getLayer("area-l")) return; const s = S.set, c = s.ar_col || "#1e7bff";
  map.setPaintProperty("area-l", "line-color", c); map.setPaintProperty("area-l", "line-width", +s.ar_w || 3); map.setPaintProperty("area-f", "fill-color", c); map.setPaintProperty("area-f", "fill-opacity", s.ar_fill == null ? .1 : +s.ar_fill);
}
const _drawArea20 = drawArea;
drawArea = function (l) {
  _drawArea20(l); if (!hd.mv) return;
  if (!hd.x) {
    const e = document.createElement("div"); e.className = "hd hx"; e.title = LL("إغلاق منطقة التحديد", "Close selection");
    hd.x = new maplibregl.Marker({ element: e }).setLngLat([0, 0]).addTo(map);
    const close = ev => { ev.preventDefault(); ev.stopPropagation(); A.show = false; setSet("area_on", false); drawArea(); const sw_ = $("#ar_sw"); if (sw_) sw_.checked = false; };
    e.addEventListener("pointerup", close); e.addEventListener("click", ev => ev.stopPropagation()); e.addEventListener("pointerdown", ev => ev.stopPropagation());
    applyAreaStyle();
  }
  styleHandles();
  if (A.shape === "circle") hd.x.setLngLat(offs(A.lat, A.lon, -A.r * .7071, A.r * .7071));
  else { const [e, n] = rotL(-A.w / 2, A.h / 2, A.deg); hd.x.setLngLat(offs(A.lat, A.lon, e, n)); }
  const rz = hd.sz.getElement().firstChild, rr = hd.rot.getElement().firstChild; if (rz) rz.style.transform = `rotate(${A.shape === "circle" ? 0 : A.deg}deg)`; if (rr) rr.style.transform = `rotate(${A.deg}deg)`;
  /* الدوران بسهم دائري، التحريك فقط عند إيقاف التتبّع التلقائي */
};
setTimeout(() => { try { applyAreaStyle(); styleHandles(); } catch (e) { } }, 1500);

/* ---------- التتبع ---------- */
const TGL = {
  person: `<path d="M12 4.2a1.8 1.8 0 100-3.6 1.8 1.8 0 000 3.6zM12 6.5v6M12 8.5l-3 2.5M12 8.5l3 2.5M12 12.5l-2.5 6M12 12.5l2.5 6"/>`,
  car: `<path d="M5 16v-4l2-5h10l2 5v4M3 16h18v2H3zM7 19.8a1.4 1.4 0 100-2.8M17 19.8a1.4 1.4 0 100-2.8M5 12h14"/>`,
  moto: `<path d="M6 18a3 3 0 100-6 3 3 0 000 6zM18 18a3 3 0 100-6 3 3 0 000 6zM6 15l4-6h4l4 6M10 9L9 7H7M14 9h3"/>`
};
let TH = null;               // آخر اتجاه معروف
function trkIconHtml() {
  const k = S.set.trk_icon || "arrow", c = S.set.trk_icol || "#1e7bff", z = +S.set.trk_isz || 40;
  const cone = `<svg class="tcone" viewBox="0 0 40 40"><path d="M20 0l9 14H11z" fill="${c}" opacity=".85"/></svg>`;
  if (k === "arrow") return `<div class="trkm" style="width:${z}px;height:${z}px"><div class="trot"><svg viewBox="0 0 24 24"><path d="M12 2l7.5 19.5-7.5-4.5-7.5 4.5z" fill="${c}" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg></div></div>`;
  return `<div class="trkm" style="width:${z}px;height:${z}px"><div class="trot">${cone}</div><div class="tbadge" style="background:${c}"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${TGL[k]}</svg></div></div>`;
}
function trkMark(ll, h) {
  if (h != null) TH = h;
  if (!MK.trk) { const e = document.createElement("div"); e.className = "trkw"; e.innerHTML = trkIconHtml(); MK.trk = new maplibregl.Marker({ element: e, rotationAlignment: "map", pitchAlignment: "map" }).setLngLat([ll[1], ll[0]]).addTo(map); }
  MK.trk.setLngLat([ll[1], ll[0]]); const r = MK.trk.getElement().querySelector(".trot"); if (r && TH != null) r.style.transform = `rotate(${TH - map.getBearing()}deg)`;
}
function trkMarkRefresh() { if (!MK.trk) { const l = TRK.last; if (TRK.id == null) return; if (l) trkMark(l); return; } const e = MK.trk.getElement(); e.innerHTML = trkIconHtml(); const r = e.querySelector(".trot"); if (r && TH != null) r.style.transform = `rotate(${TH - map.getBearing()}deg)`; }
const trkReBtn = () => {
  let b = $("#trkre"); if (b) return b; const side = $("#side"); b = el(`<button class="fab" id="trkre" title="${LL("العودة إلى موقعي", "Back to my position")}">${I("locate")}</button>`, side); side.insertBefore(b, $("#zoomc") || null); b.onclick = () => { TRK.follow = true; b.classList.add("on"); const l = TRK.last; if (l) trkCenter(l, true); }; return b;
};
function trkCenter(ll, force) {
  if (!TRK.follow && !force) return; const hdg = S.set.trk_hd && TH != null && !isNaN(TH);
  const o = { center: [ll[1], ll[0]], duration: 600, essential: true }; if (hdg) o.bearing = TH; map.easeTo(o);
}
let _trkDrag = false;
document.addEventListener("DOMContentLoaded", () => setTimeout(() => { try { map.on("dragstart", e => { if (TRK.id != null && e.originalEvent) { TRK.follow = false; const b = $("#trkre"); b && b.classList.remove("on"); } }); } catch (e) { } }, 1500));
setTimeout(() => { try { if (!_trkDrag) { _trkDrag = true; map.on("dragstart", e => { if (TRK.id != null && e.originalEvent) { TRK.follow = false; const b = $("#trkre"); b && b.classList.remove("on"); } }); } } catch (e) { } }, 2500);

trkStart = function () {
  if (!navigator.geolocation) return toast("GPS ✕"); if (TRK.id != null) return;
  Object.assign(TRK, { pts: [], t: [], wps: [], pause: false, max: 0, t0: Date.now(), follow: S.set.trk_follow !== false, last: null }); TH = null; MK.me && MK.me.remove(); delete MK.me; setSrc("track");
  try { navigator.wakeLock && navigator.wakeLock.request("screen").then(w => WL = w).catch(() => { }); } catch (e) { }
  const rb = trkReBtn(); rb.style.display = "grid"; rb.classList.toggle("on", TRK.follow);
  const bar = el(`<div id="trkbar" class="mbar" style="bottom:calc(env(safe-area-inset-bottom) + 82px)"></div>`, document.body);
  const upd = () => {
    const L = plen(TRK.pts), dur = (Date.now() - TRK.t0) / 1000, avg = dur > 0 ? L / dur * 3.6 : 0;
    bar.innerHTML = barHtml(t("lp_track"), `${LL("المسافة المقطوعة", "Distance")}: <b>${fm(L)}</b> · ${fdur(dur)}<br>${t("trk_spd")}: ${avg.toFixed(1)} / ${(TRK.max * 3.6).toFixed(1)} km/h · ${t("trk_acc")}: ±${Math.round(TRK.acc || 0)} m`, [["tk_p", TRK.pause ? "play" : "pause", t(TRK.pause ? "trk_resume" : "trk_pause")], ["tk_w", "flag2", t("trk_wp")], ["tk_s", "check", t("lp_stop"), "btn"]]);
    $("#tk_p", bar).onclick = () => { TRK.pause = !TRK.pause; upd(); }; $("#tk_w", bar).onclick = () => { const l = TRK.last; if (l) { TRK.wps.push({ lat: l[0], lon: l[1], name: "WP" + (TRK.wps.length + 1) }); toast(t("trk_wp") + " " + TRK.wps.length); } }; $("#tk_s", bar).onclick = () => trkStop(true);
  };
  upd(); TRK.tm = setInterval(upd, 1500);
  TRK.id = navigator.geolocation.watchPosition(p => {
    const ll = [p.coords.latitude, p.coords.longitude, p.coords.altitude]; TRK.acc = p.coords.accuracy || 0; const prev = TRK.last; TRK.last = ll;
    let h = p.coords.heading; if ((h == null || isNaN(h)) && prev && hav(prev, ll) > 3) h = (Math.atan2(ll[1] - prev[1], ll[0] - prev[0]) * 0 + brg(prev, ll));
    trkMark(ll, h == null || isNaN(h) ? null : h);
    if (TRK.pause) return;
    if (p.coords.speed != null && p.coords.speed > TRK.max) TRK.max = p.coords.speed; const last = TRK.pts[TRK.pts.length - 1];
    if (TRK.acc <= (+S.set.trk_acc || 60) && (!last || hav(last, ll) > Math.max(+S.set.trk_dist || 3, TRK.acc / 3)) && (!TRK.t.length || !(+S.set.trk_time) || Date.now() - TRK.t[TRK.t.length - 1] >= S.set.trk_time * 1000)) {
      TRK.pts.push(ll); TRK.t.push(Date.now()); setSrc("track", fc(ft({ type: "LineString", coordinates: TRK.pts.map(q => [q[1], q[0]]) }))); upd();
    }
    trkCenter(ll);
  }, e => toast("GPS: " + e.message), { enableHighAccuracy: true, maximumAge: 1000 });
};
trkStop = function (save) {
  if (TRK.id != null) navigator.geolocation.clearWatch(TRK.id); TRK.id = null; clearInterval(TRK.tm); try { WL && WL.release(); } catch (e) { } WL = null;
  const b = $("#trkbar"); b && b.remove(); const rb = $("#trkre"); rb && (rb.style.display = "none"); MK.trk && MK.trk.remove(); delete MK.trk; if (S.set.trk_hd) map.easeTo({ bearing: 0 });
  const pts = TRK.pts.slice(), times = TRK.t.slice(), wps = TRK.wps.slice(); TRK.pts = []; TRK.t = [];
  if (!save || pts.length < 2) { setSrc("track"); return; }
  const nm = "Track " + new Date().toISOString().slice(0, 16).replace("T", " "), dur = (times[times.length - 1] - times[0]) / 1000, L = plen(pts);
  const meta = `${LL("المسافة المقطوعة", "Distance")}: ${fm(L)} · ${t("trk_dur")}: ${fdur(dur)} · ${t("trk_spd")}: ${(dur > 0 ? L / dur * 3.6 : 0).toFixed(1)} km/h`;
  const m = el(`<div class="modal"><div class="p"><h3>${t("trk_end")}</h3><div class="hint">${LL("المسافة المقطوعة", "Distance")}: <b>${fm(L)}</b> · ${t("trk_dur")}: ${fdur(dur)} · ${pts.length} ${t("pts_")}</div><div class="qbtns" style="grid-template-columns:1fr"><button class="btn" id="tk0">${I("layers")}${LL("إضافة المسار إلى الخريطة (قابل للتعديل)", "Add track to map (editable)")}</button><button class="btn sec2" id="tk1">${I("save")}${t("trk_save")}</button><button class="btn sec2" id="tk2">${I("fetch")}${t("trk_gpx")}</button><button class="btn sec2 er" id="tk3">${I("trash")}${t("trk_drop")}</button></div></div></div>`, document.body);
  $("#tk0", m).onclick = () => { m.remove(); const d = DR.add({ kind: "track", pts: pts.map(p => [p[0], p[1]]), name: nm, color: S.set.trk_icol || "#1e7bff", width: 5, meta }); setSrc("track"); toast(t("dr_made"), [[LL("التفاصيل", "Details"), () => openDraw(d.id)], [LL("تحرير النقاط", "Edit points"), () => drEdit(d.id)]]); };
  $("#tk1", m).onclick = () => { m.remove(); saveDraw("line", pts.map(p => [p[0], p[1]]), () => setSrc("track")); };
  $("#tk2", m).onclick = () => saveBlob(new Blob([gpxOf(pts, times, wps, nm)], { type: "application/gpx+xml" }), nm.replace(/[ :]/g, "_") + ".gpx", "share");
  $("#tk3", m).onclick = () => { m.remove(); setSrc("track"); };
};
const _drStat20 = drStat; drStat = function (d) { return _drStat20(d) + (d.meta ? `<br><small>${esc(d.meta)}</small>` : ""); };

/* ---------- دمج الرسم مع خط آخر من نافذة التحرير ---------- */
const _openDraw20 = openDraw;
openDraw = function (id) {
  _openDraw20(id); const d = drOf(id), b = $("#sh-b"), c = b && $("#dw_cv", b); if (!d || !c || $("#dw_mg", c) || d.kind === "area" || d.pts.length < 2) return;
  const bt = el(`<button class="btn sec2" id="dw_mg">${I("plus")}${LL("دمج مع…", "Merge with…")}</button>`); $(".btns", c).appendChild(bt);
  bt.onclick = () => {
    const others = DR.items.filter(o => o !== d && o.kind !== "area" && o.pts.length > 1); if (!others.length) return toast(LL("لا يوجد خط آخر للدمج", "No other line to merge"));
    const body = el(`<div><select class="in" id="mg_s">${others.map(o => `<option value="${o.id}">${esc(o.name || drKindName(o))} — ${fm(plen(o.pts))}</option>`).join("")}</select></div>`);
    modal(LL("دمج مع", "Merge with"), body, () => { const o = drOf($("#mg_s", body).value); if (o) { drMerge(d, o); openDraw(id); } }, LL("دمج", "Merge"));
  };
};
