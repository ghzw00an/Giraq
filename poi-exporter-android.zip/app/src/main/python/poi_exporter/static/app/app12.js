"use strict";
/* ===== app12: تحديد بالشروط (Select by Attributes) + إحصاء الحقول ===== */
const SELF = ["name", "type", "Gategory", "gathaa", "Nahia", "mohafadha", "x", "y", "link"];
const SELOP = [["has", "يحتوي", "contains"], ["eq", "يساوي", "equals"], ["ne", "لا يساوي", "not equal"], ["sw", "يبدأ بـ", "starts with"], ["gt", "أكبر من", ">"], ["lt", "أصغر من", "<"], ["em", "فارغ", "is empty"], ["ne2", "غير فارغ", "not empty"]];
function selTest(op, v, q) {
  v = v == null ? "" : String(v); const a = v.toLowerCase(), b = String(q).toLowerCase(), n = parseFloat(v), m = parseFloat(q);
  switch (op) { case "has": return a.includes(b); case "eq": return a === b; case "ne": return a !== b; case "sw": return a.startsWith(b); case "gt": return n > m; case "lt": return n < m; case "em": return a === ""; case "ne2": return a !== ""; }
  return false;
}
function openSelAttr() {
  const ds = S.ds.filter(d => d.kind !== "reference"); if (!ds.length) return toast(t("nodata"));
  openSheet("selattr", LL("تحديد بالشروط", "Select by attributes"), b => {
    b.innerHTML = `<label class="f">${LL("الطبقة", "Layer")}</label><select class="in" id="sa_d">${ds.map(d => `<option value="${d.id}">${esc6(d.label)}</option>`).join("")}</select>
    <div class="two"><div><label class="f">${LL("الحقل", "Field")}</label><select class="in" id="sa_f">${SELF.map(k => `<option value="${k}">${t(k)}</option>`).join("")}</select></div>
    <div><label class="f">${LL("الشرط", "Operator")}</label><select class="in" id="sa_o">${SELOP.map(o => `<option value="${o[0]}">${LL(o[1], o[2])}</option>`).join("")}</select></div></div>
    <label class="f">${LL("القيمة", "Value")}</label><input class="in" id="sa_v">
    <div class="btns"><button class="btn" id="sa_go">${I("check")}${LL("تحديد", "Select")}</button><button class="btn sec2" id="sa_st">${LL("إحصاء الحقل", "Field stats")}</button></div>
    <div id="sa_r"></div>`;
    let hit = [];
    const data = async () => { const id = $("#sa_d", b).value; await ensureDs(S.ds.find(x => x.id === id)); return GJ[id].features; };
    const get = (f, k) => { const p = f.properties || {}; return p[k]; };
    $("#sa_go", b).onclick = async () => {
      const fs = await data(), k = $("#sa_f", b).value, op = $("#sa_o", b).value, q = $("#sa_v", b).value;
      hit = fs.filter(f => selTest(op, get(f, k), q)); const r = $("#sa_r", b);
      r.innerHTML = `<div class="sec">${hit.length} / ${fs.length} ${LL("معلم محدد", "selected")}</div>${hit.length ? `<div class="btns"><button class="btn sec2" id="sa_z">${LL("عرض على الخريطة", "Show on map")}</button><button class="btn sec2" id="sa_c">${LL("نسخ إلى طبقة جديدة", "Copy to new layer")}</button><button class="btn sec2" id="sa_x" style="color:#e03131">${LL("حذف المحدد", "Delete selected")}</button></div>` : ""}`;
      if (!hit.length) return;
      $("#sa_z", r).onclick = () => { const pts = hit.map(f => f.geometry && f.geometry.coordinates).filter(c => c && typeof c[0] === "number"); if (!pts.length) return; const xs = pts.map(c => c[0]), ys = pts.map(c => c[1]); closeSheet(); map.fitBounds([[Math.min(...xs), Math.min(...ys)], [Math.max(...xs), Math.max(...ys)]], { padding: 60, maxZoom: 16 }); };
      const ids = () => hit.map(f => f.id || (f.properties && f.properties.id)).filter(Boolean);
      $("#sa_c", r).onclick = async () => { try { await post("/api/merge", { ids: ids(), target: "", name: LL("تحديد", "Selection") + " " + (hit.length), copy: true }); await refreshDs(dsIds()); toast(t("done")); } catch (e) { fail(e); } };
      $("#sa_x", r).onclick = () => lyConfirm(LL("حذف " + hit.length + " معلم؟", "Delete " + hit.length + " features?"), async () => { try { await post("/api/features/delete", { ids: ids() }); await refreshDs(dsIds()); closeSheet(); toast(t("done")); } catch (e) { fail(e); } });
    };
    $("#sa_st", b).onclick = async () => {
      const fs = await data(), k = $("#sa_f", b).value, c = {}; fs.forEach(f => { const v = get(f, k); const s = v == null || v === "" ? "—" : v; c[s] = (c[s] || 0) + 1; });
      const rows = Object.entries(c).sort((p, q) => q[1] - p[1]).slice(0, 15), mx = rows.length ? rows[0][1] : 1;
      $("#sa_r", b).innerHTML = `<div class="sec">${LL("القيم الأكثر تكراراً", "Top values")} (${Object.keys(c).length} ${LL("قيمة فريدة", "unique")})</div>` + rows.map(([v, n]) => `<div class="lgr"><span style="flex:1">${esc6(v)}</span><div style="flex:1;background:var(--sf2);border-radius:6px"><div style="width:${Math.round(n / mx * 100)}%;background:var(--pr);height:10px;border-radius:6px"></div></div><b>${n}</b></div>`).join("");
    };
  });
}
const _openTools12 = openTools;
openTools = async function () {
  await _openTools12(); const b = $("#sh-b"); if (SHEET !== "tools" || !b) return; const g = $(".grid", b); if (!g || $("#tl_sel", b)) return;
  const x = el(`<button class="tile" id="tl_sel">${I("check")}<span>${LL("تحديد بالشروط", "Select by attributes")}</span></button>`, g); x.onclick = openSelAttr;
};
