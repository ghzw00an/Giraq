"use strict";
/* ===== app18 (v3.15): مزودو API (خرائط/بيانات)، قاعدة الجلب، حول وشكر المصادر، الجلب من القطاعات، تفاصيل ===== */
Object.assign(ICONS, {
  info: "M12 21a9 9 0 100-18 9 9 0 000 18zM12 11v6M12 7.5h.01",
  key: "M15 8a4 4 0 11-3.9 4.9L4 20v-3h3v-2h2l2.1-2.1A4 4 0 0115 8zM16 8h.01",
  lock: "M6 11h12v9H6zM8 11V8a4 4 0 118 0v3M12 15v2",
  zoomin: "M12 5v14M5 12h14", zoomout: "M5 12h14"
});

/* ---------- اسم المعلم يُفرَّغ بعد كل إضافة ---------- */
const _addAt18 = addAt; addAt = async function (lat, lon, open) { const multi = ADD.mode === "multi"; await _addAt18(lat, lon, open); if (!multi) ADD.name = ""; };
const _saveMany18 = saveMany; saveMany = async function () { await _saveMany18(); ADD.name = ""; };

/* ---------- المزوّدون ---------- */
const PV = {
  list() { try { const v = JSON.parse(S.set.providers_json || "[]"); return Array.isArray(v) ? v : []; } catch (e) { return []; } },
  async save(l) { S.set.providers_json = JSON.stringify(l); await setSet("providers_json", S.set.providers_json); },
  get(id) { return this.list().find(p => p.id === id); },
  isMap(p) { return p.kind !== "data" && (p.type === "google" || !!p.tiles); },
  isData(p) { return p.kind !== "map" && (p.type === "google" || !!p.url); }
};
const tilesOf = p => p.type === "google" ? (p.session ? `https://tile.googleapis.com/v1/2dtiles/{z}/{x}/{y}?session=${p.session}&key=${encodeURIComponent(p.key)}` : null) : (p.tiles || "").split("{key}").join(encodeURIComponent(p.key || ""));
async function gSession(p) {
  const r = await fetch("https://tile.googleapis.com/v1/createSession?key=" + encodeURIComponent(p.key), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ mapType: "roadmap", language: S.set.lang === "ar" ? "ar" : "en", region: "IQ" }) });
  if (!r.ok) throw new Error("Google " + r.status); const j = await r.json(); p.session = j.session; p.sessExp = Date.now() + 10 * 864e5; return p;
}
function regProv() {
  PV.list().forEach(p => {
    const u = tilesOf(p); if (!u || !PV.isMap(p)) return; const id = "p_" + p.id;
    if (!BASES[id]) { BASES[id] = [id]; ALLB.push(id); }
    if (DIRECT[id] !== u && map && map.getLayer && map.getLayer("b-" + id)) { map.removeLayer("b-" + id); map.removeSource("b-" + id); if (map._added) delete map._added[id]; }
    DIRECT[id] = u; TF.direct[id] = true;
  });
}
const _srcUrl18 = srcUrl; srcUrl = function (id) { return String(id).startsWith("p_") ? DIRECT[id] : _srcUrl18(id); };
const attrBox = () => $("#pattr") || el(`<div id="pattr"></div>`, document.body);
const _setBase18 = setBase;
setBase = function (m) {
  regProv(); const p = String(m).startsWith("p_") ? PV.get(m.slice(2)) : null;
  if (String(m).startsWith("p_")) { if (!p || !DIRECT[m]) { toast(LL("المزوّد غير جاهز", "Provider not ready")); m = "osm"; } else addRasterSrc(m); }
  _setBase18(m); const a = attrBox(); a.textContent = p && p.attribution ? p.attribution : ""; a.style.display = a.textContent ? "" : "none";
};
setTimeout(() => { try { if (String(S.set.base).startsWith("p_")) { const p = PV.get(S.set.base.slice(2)); if (p && p.type === "google" && (!p.session || p.sessExp < Date.now())) gSession(p).then(async () => { const l = PV.list().map(x => x.id === p.id ? p : x); await PV.save(l); setBase(S.set.base); }).catch(() => { }); } } catch (e) { } }, 3000);

/* ---------- نافذة الخرائط: صفوف المزوّدين + زر الإدارة ---------- */
const _openBase18 = openBase;
openBase = function () {
  _openBase18(); const b = $("#sh-b"), bl = b && $("#bl", b); if (SHEET !== "base" || !bl || $("#pv_mg", b)) return;
  PV.list().filter(PV.isMap.bind(PV)).forEach(p => {
    const k = "p_" + p.id, on = S.base === k;
    const x = el(`<button class="row" style="width:100%;border:0;background:${on ? "var(--pr)" : "none"};color:${on ? "var(--on)" : "var(--tx)"};cursor:pointer;font-weight:${on ? 700 : 500};justify-content:center">${on ? "✔ " : ""}${esc(p.name)} <small style="opacity:.7">API</small></button>`, bl);
    x.onclick = async () => { try { if (p.type === "google" && (!p.session || p.sessExp < Date.now())) { toast(LL("جارٍ فتح جلسة Google…", "Opening Google session…")); await gSession(p); await PV.save(PV.list().map(q => q.id === p.id ? p : q)); } setBase(k); setSet("base", k); openBase(); } catch (e) { fail(e); } };
  });
  const c = el(`<div class="card" id="pv_mg" style="margin-top:12px"><div class="row"><div class="t"><b>${LL("مزوّدو خرائط وبيانات (API)", "Map & data providers (API)")}</b><small>${LL("Google · MapAtlas · Overture · أي مفتاح أو قالب رابط", "Google · MapAtlas · Overture · any key or URL template")}</small></div><button class="btn sec2" id="pv_o" style="flex:none;min-width:0;padding:6px 14px">${I("key")}${LL("إدارة", "Manage")}</button></div></div>`, b);
  $("#pv_o", c).onclick = () => openProviders();
};

function openProviders() {
  openSheet("prov", LL("مزوّدو API", "API providers"), b => {
    const draw = () => {
      const L = PV.list(), ds = S.set.data_source || "osm";
      b.innerHTML = `<div class="hint">${LL("أضف مفتاح API أو رابطاً. تظهر الخرائط في نافذة الخرائط، ويمكن اختيار مصدر جلب المعالم هنا أو من الإعدادات.", "Add an API key or URL. Maps appear in the Maps window; pick the data source here or in Settings.")}</div>
      <div class="card"><div class="row"><div class="t"><b>OpenStreetMap</b><small>Overpass</small></div><button class="btn ${ds === "osm" ? "" : "sec2"}" data-ds="osm" style="flex:none;min-width:0;padding:6px 12px">${ds === "osm" ? "✔ " + LL("مصدر الجلب", "Data source") : LL("اجعله المصدر", "Use")}</button></div>
      ${L.map(p => `<div class="row"><div class="t"><b>${esc(p.name)}</b><small>${PV.isMap(p) ? LL("خريطة", "Map") : ""}${PV.isMap(p) && PV.isData(p) ? " + " : ""}${PV.isData(p) ? LL("بيانات", "Data") : ""} · ${S.base === "p_" + p.id ? "✔ " + LL("القياسية", "Standard") : ""}</small></div>
        ${PV.isData(p) ? `<button class="btn ${ds === p.id ? "" : "sec2"}" data-ds="${p.id}" style="flex:none;min-width:0;padding:6px 10px">${ds === p.id ? "✔" : LL("مصدر", "Source")}</button>` : ""}
        ${PV.isMap(p) ? `<button class="ib sm" data-mp="${p.id}" title="${LL("اجعلها القياسية", "Make standard")}">${I("layers")}</button>` : ""}<button class="ib sm" data-t="${p.id}" title="${LL("اختبار", "Test")}">${I("check")}</button><button class="ib sm er" data-x="${p.id}">${I("trash")}</button></div>`).join("")}</div>
      <div class="btns"><button class="btn blk" id="pv_a">${I("plus")}${LL("إضافة مزوّد / مفتاح", "Add provider / key")}</button></div><div class="hint" id="pv_s"></div>`;
      $$("[data-ds]", b).forEach(x => x.onclick = async () => { await setSet("data_source", x.dataset.ds); draw(); });
      $$("[data-mp]", b).forEach(x => x.onclick = () => { const k = "p_" + x.dataset.mp; setBase(k); setSet("base", k); draw(); });
      $$("[data-x]", b).forEach(x => x.onclick = async () => { if (!(await ask(LL("حذف هذا المزوّد؟", "Delete this provider?"), null, true))) return; const id = x.dataset.x; if (S.base === "p_" + id) { setBase("osm"); setSet("base", "osm"); } if (S.set.data_source === id) await setSet("data_source", "osm"); await PV.save(PV.list().filter(p => p.id !== id)); draw(); });
      $$("[data-t]", b).forEach(x => x.onclick = () => testProv(PV.get(x.dataset.t), $("#pv_s", b)));
      $("#pv_a", b).onclick = () => provForm(b, draw);
    };
    draw();
  });
}
async function testProv(p, out) {
  out.style.color = ""; out.textContent = LL("جارٍ الاختبار…", "Testing…"); const c = map.getCenter();
  try {
    let msg = [];
    if (PV.isData(p)) { const r = await post("/api/providers/test", { provider: p, lat: c.lat, lon: c.lng, q: S.set.lang === "ar" ? "مستشفى" : "hospital" }); if (!r.ok) throw new Error(r.error); msg.push(LL("البيانات: ", "Data: ") + r.count + " " + LL("نتيجة", "results")); }
    if (PV.isMap(p)) { if (p.type === "google") { await gSession(p); msg.push(LL("الخريطة: جلسة Google جاهزة", "Map: Google session OK")); } else { const u = tilesOf(p).replace("{z}", 5).replace("{x}", 20).replace("{y}", 12); const r = await fetch(u, { mode: "no-cors" }); msg.push(LL("الخريطة: الرابط يستجيب", "Map: URL responds")); } }
    out.style.color = "var(--ok)"; out.textContent = "✔ " + msg.join(" · ");
  } catch (e) { out.style.color = "var(--er)"; out.textContent = "⚠ " + (e.message || e); }
}
function provForm(b, back) {
  const PRE = { google: { name: "Google", type: "google", kind: "both", attribution: "© Google" }, mapatlas: { name: "MapAtlas", type: "template", kind: "both", attribution: "© MapAtlas (CC BY 4.0) · mapatlas.eu" }, overture: { name: "Overture Maps", type: "template", kind: "data", attribution: "Overture Maps Foundation (CDLA-Permissive-2.0; Foursquare Apache-2.0; AllThePlaces CC0) - modified" }, custom: { name: "", type: "template", kind: "both", attribution: "" } };
  let cur = "google";
  b.innerHTML = `<div class="seg" id="pf_p">${Object.keys(PRE).map(k => `<button data-v="${k}" class="${k === cur ? "on" : ""}">${{ google: "Google", mapatlas: "MapAtlas", overture: "Overture", custom: LL("مخصص", "Custom") }[k]}</button>`).join("")}</div>
  <label class="f">${LL("الاسم", "Name")}</label><input class="in" id="pf_n">
  <label class="f">${LL("مفتاح API", "API key")}</label><input class="in" id="pf_k" dir="ltr" autocomplete="off" placeholder="AIza…"><div class="two"><div><label class="f">App ID</label><input class="in" id="pf_aid" dir="ltr" autocomplete="off" placeholder="{appid}"></div><div><label class="f">Navigation SDK</label><input class="in" id="pf_nav" dir="ltr" autocomplete="off" placeholder="{navkey}"></div></div><div class="hint">${LL("اختياري: مفاتيح App ID وNavigation SDK تُصدرها الجهة المزوّدة من لوحة المطوّرين ولا يمكن توليدها من التطبيق؛ تتوفر كمتغيرات {appid} و{navkey} في الروابط.", "Optional: App ID / Navigation SDK keys are issued by the provider in its developer console and cannot be generated by the app; usable as {appid} and {navkey} in URLs.")}</div>
  <label class="f">${LL("الاستخدام", "Use")}</label><div class="seg" id="pf_kd"><button data-v="both" class="on">${LL("خريطة + بيانات", "Map + data")}</button><button data-v="map">${LL("خريطة", "Map")}</button><button data-v="data">${LL("بيانات", "Data")}</button></div>
  <div id="pf_ex"><label class="f">${LL("رابط البلاطات (خريطة)", "Tiles URL (map)")}</label><input class="in" id="pf_t" dir="ltr" placeholder="https://…/{z}/{x}/{y}.png?key={key}">
  <label class="f">${LL("رابط البيانات (قالب)", "Data URL (template)")}</label><input class="in" id="pf_u" dir="ltr" placeholder="https://…?bbox={west},{south},{east},{north}&q={q}&key={key}"><div class="hint">${LL("المتغيرات: {south} {west} {north} {east} {lat} {lon} {radius} {q} {key}. يُقبل GeoJSON أو JSON فيه قائمة عناصر بإحداثيات.", "Variables: {south} {west} {north} {east} {lat} {lon} {radius} {q} {key}. GeoJSON or JSON lists with coordinates accepted.")}</div></div>
  <label class="f">${LL("نص الإسناد (يظهر على الخريطة)", "Attribution (shown on map)")}</label><input class="in" id="pf_a">
  <div class="btns"><button class="btn" id="pf_s">${I("check")}${LL("حفظ واعتماد", "Save & use")}</button><button class="btn sec2" id="pf_b">${LL("رجوع", "Back")}</button></div><div class="hint" id="pf_st"></div>`;
  let kind = "both"; const fill = k => { cur = k; const p = PRE[k]; $("#pf_n", b).value = p.name; $("#pf_a", b).value = p.attribution; kind = p.kind; $$("#pf_kd button", b).forEach(x => x.classList.toggle("on", x.dataset.v === kind)); $("#pf_ex", b).style.display = k === "google" ? "none" : ""; $$("#pf_p button", b).forEach(x => x.classList.toggle("on", x.dataset.v === k)); };
  $$("#pf_p button", b).forEach(x => x.onclick = () => fill(x.dataset.v)); $$("#pf_kd button", b).forEach(x => x.onclick = () => { kind = x.dataset.v; $$("#pf_kd button", b).forEach(y => y.classList.toggle("on", y === x)); }); fill("google");
  $("#pf_b", b).onclick = back;
  $("#pf_s", b).onclick = async () => {
    const st = $("#pf_st", b), p = { id: "k" + Date.now().toString(36), name: $("#pf_n", b).value.trim() || PRE[cur].name || "API", type: PRE[cur].type, kind, key: $("#pf_k", b).value.trim(), appid: $("#pf_aid", b).value.trim(), navkey: $("#pf_nav", b).value.trim(), tiles: $("#pf_t", b).value.trim(), url: $("#pf_u", b).value.trim(), attribution: $("#pf_a", b).value.trim() };
    if (!p.key && !p.tiles && !p.url) { st.style.color = "var(--er)"; st.textContent = "⚠ " + LL("أدخل مفتاحاً أو رابطاً", "Enter a key or URL"); return; }
    st.style.color = ""; st.textContent = LL("جارٍ التحقق…", "Verifying…");
    try {
      if (p.type === "google" && PV.isMap(p)) await gSession(p);
      const l = PV.list(); l.push(p); await PV.save(l); regProv();
      if (PV.isMap(p)) { const k = "p_" + p.id; setBase(k); await setSet("base", k); }
      if (PV.isData(p)) { const c = map.getCenter(); const r = await post("/api/providers/test", { provider: p, lat: c.lat, lon: c.lng, q: S.set.lang === "ar" ? "مستشفى" : "hospital" }); await setSet("data_source", p.id); S.set.data_source = p.id; if (r.ok) toast(LL("اعتُمد مصدراً للجلب: ", "Now the data source: ") + r.count); else { toast(LL("حُفظ المزوّد واعتُمد، لكن الاختبار فشل: ", "Saved, but test failed: ") + r.error); } }
      back();
    } catch (e) { st.style.color = "var(--er)"; st.textContent = "⚠ " + (e.message || e); }
  };
}

/* ---------- الجلب: مصدر البيانات + جلب من القطاعات ---------- */
const _openFetch18 = openFetch;
openFetch = function () {
  _openFetch18(); const b = $("#sh-b"), box = $("#f_l", b); if (SHEET !== "fetch" || !box || $("#f_src", b)) return;
  const L = PV.list().filter(PV.isData.bind(PV)), ds = S.set.data_source || "osm";
  const top = el(`<div class="card" id="f_src" style="margin-bottom:10px;padding:8px 12px"><div class="row"><div class="t"><b>${LL("مصدر البيانات", "Data source")}</b></div><select class="in" style="width:auto;margin:0"><option value="osm">OpenStreetMap</option>${L.map(p => `<option value="${p.id}" ${p.id === ds ? "selected" : ""}>${esc(p.name)}</option>`).join("")}</select></div></div>`);
  $("select", top).value = L.some(p => p.id === ds) ? ds : "osm"; $("select", top).onchange = e => setSet("data_source", e.target.value);
  b.insertBefore(top, b.firstChild);
  const SX = (S.boot.sxl || []); if (!SX.length) return;
  const d = el(`<details class="card" style="padding:8px 12px;margin-bottom:8px"><summary style="cursor:pointer;font-weight:700"><span>${LL("جلب من القطاعات", "Fetch by sector")} (${SX.length})</span></summary><div id="sx_b" style="margin-top:8px"></div></details>`);
  box.appendChild(d);
  SX.forEach(s => {
    const w = el(`<div style="margin-bottom:10px"><div class="row" style="padding:4px 0"><b style="flex:1">${esc(s.sector)}</b><button class="btn sec2" style="flex:none;min-width:0;padding:3px 10px;font-size:12px">${t("all_")}</button></div><div class="chips"></div></div>`, $("#sx_b", d)), cs = [];
    s.items.forEach(it => { const c = el(`<span class="chip ${F.poi.has(it.id) ? "on" : ""}">${esc(it.name)}</span>`, $(".chips", w)); c.onclick = () => { F.poi.has(it.id) ? F.poi.delete(it.id) : F.poi.add(it.id); c.classList.toggle("on", F.poi.has(it.id)); }; cs.push([it, c]); });
    $("button", w).onclick = () => { const all = cs.every(([it]) => F.poi.has(it.id)); cs.forEach(([it, c]) => { all ? F.poi.delete(it.id) : F.poi.add(it.id); c.classList.toggle("on", !all); }); };
  });
};

/* ---------- حول وشكر المصادر ---------- */
const CREDITS = [
  ["OpenStreetMap contributors", "ODbL 1.0", "openstreetmap.org/copyright", LL("بيانات المعالم والطرق والحدود وخرائط الأساس", "Landmarks, roads, boundaries and base map")],
  ["Overpass API", "", "overpass-api.de", LL("خدمة استعلام بيانات OSM", "OSM query service")],
  ["Overture Maps Foundation", "CDLA-Permissive-2.0 · Foursquare Apache-2.0 · AllThePlaces CC0 — modified", "overturemaps.org", LL("بيانات أماكن مفتوحة (معدّلة)", "Open places data (modified)")],
  ["MapAtlas", "CC BY 4.0", "mapatlas.eu", LL("خرائط وبيانات (بمفتاح API)", "Maps and data (API key)")],
  ["Google Maps Platform", "", "developers.google.com/maps", LL("خرائط وأماكن عبر مفتاحك الخاص", "Maps and Places via your own key")],
  ["MapLibre GL JS", "BSD-3-Clause", "maplibre.org", LL("محرك عرض الخرائط", "Map rendering engine")],
  ["OpenFreeMap · OpenMapTiles", "ODbL / CC BY 4.0", "openfreemap.org", LL("أسماء الخرائط بالعربية", "Arabic map labels")],
  ["Esri World Imagery", "", "arcgis.com", LL("صور الأقمار الصناعية", "Satellite imagery")],
  ["CARTO Basemaps", "CC BY 3.0", "carto.com/attributions", LL("خرائط الطرق", "Road maps")],
  ["OSRM", "BSD-2-Clause", "project-osrm.org", LL("توجيه الطرق", "Road routing")],
  ["Photon (Komoot) · Nominatim", "ODbL", "photon.komoot.io", LL("البحث عن الأماكن", "Place search")],
  ["Chaquopy · Python · Flask", "MIT / PSF / BSD", "chaquo.com", LL("بيئة تشغيل التطبيق على أندرويد", "App runtime on Android")]
];
function openAbout() {
  openSheet("about", LL("حول", "About"), b => {
    b.innerHTML = `<div class="abt"><div class="abt-lg">${I("pin")}</div><h2>POI Exporter</h2><div class="abt-by">${LL("تم برمجة هذا التطبيق بواسطة رضوان", "This app was developed by Radwan")}</div><small>${LL("الإصدار", "Version")} ${APP_VER}</small></div>
    <div class="hint" style="margin-top:14px">${LL("شكراً للمصادر والمشاريع التالية:", "Thanks to the following sources and projects:")}</div>
    <div class="card">${CREDITS.map(c => `<div class="row"><div class="t"><b dir="ltr" style="text-align:start">${esc(c[0])}</b><small>${esc(c[3])}${c[1] ? " · " + esc(c[1]) : ""}</small><small dir="ltr" style="color:var(--pr)">${esc(c[2])}</small></div></div>`).join("")}</div>
    <div class="hint">${LL("البيانات المعروضة تخضع لتراخيص أصحابها. عند استخدام مفاتيح API الخاصة بك تسري شروط المزوّد.", "Displayed data is subject to its owners' licences. When using your own API keys the provider's terms apply.")}</div>`;
  });
}
const _buildDrawer18 = buildDrawer;
buildDrawer = function () { _buildDrawer18(); const g = $("#dgrid"); if (g && !$("#dr_about", g)) { const x = el(`<button class="tile" id="dr_about">${I("info")}<span>${LL("حول", "About")}</span></button>`, g); x.onclick = openAbout; } };
setTimeout(() => { try { buildDrawer(); } catch (e) { } }, 800);
