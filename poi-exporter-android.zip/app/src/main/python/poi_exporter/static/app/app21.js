"use strict";
/* ===== app21 (v3.16): منطقة بالحدود/الرسم، إصلاح المقابض، الجلب المطوي، مزوّدو API، ضغط مطوّل على إضافة،
   مجموعات المعالم، ثيمات مخصصة وتباين النص، إصلاح PIN، لمس البنى التحتية ===== */
Object.assign(ICONS, {
  group: "M4 7h16M4 12h10M4 17h7M18 14v6M15 17h6", poly: "M5 18l2-11 8-3 4 9-6 6z", globe: "M12 21a9 9 0 100-18 9 9 0 000 18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18",
  chev: "M6 9l6 6 6-6", eye_off: "M3 3l18 18M10.6 6.1A9.8 9.8 0 0112 6c6 0 10 6 10 6a17 17 0 01-3.2 3.7M6.6 6.6A17 17 0 002 12s4 7 10 7a9.7 9.7 0 004-.9"
});
const LL21 = (a, b) => (S.set.lang === "en" ? b : a);
const J21 = k => { try { const v = JSON.parse(S.set[k] || "[]"); return Array.isArray(v) ? v : []; } catch (e) { return []; } };

/* ---------------- 1) المقابض: تختفي عند الإيقاف، ومقبض التحريك مخفي دائماً ---------------- */
const noAr21 = () => document.documentElement.classList.toggle("noar", !A.show || !!A.poly);
function polyBBox() { let a = 90, b = 180, c = -90, d = -180; A.poly.forEach(r => r.forEach(p => { if (p[1] < a) a = p[1]; if (p[1] > c) c = p[1]; if (p[0] < b) b = p[0]; if (p[0] > d) d = p[0]; })); return [a, b, c, d]; }
function polyKm2(rings) {
  let tot = 0; rings.forEach(r => { if (r.length < 4) return; let la = 0; r.forEach(p => la += p[1]); la = la / r.length * Math.PI / 180; const kx = 111320 * Math.cos(la), ky = 110574; let s = 0;
    for (let i = 0; i < r.length - 1; i++) s += (r[i][0] * kx) * (r[i + 1][1] * ky) - (r[i + 1][0] * kx) * (r[i][1] * ky); tot += Math.abs(s) / 2; });
  return tot / 1e6;
}
const _bb21 = areaBBox; areaBBox = function () { return A.poly ? polyBBox() : _bb21(); };
function drawPoly() {
  try {
    if (!map.getSource("apoly")) {
      if (!map.getSource("area")) return;
      map.addSource("apoly", { type: "geojson", data: fc() });
      map.addLayer({ id: "apoly-f", type: "fill", source: "apoly", paint: { "fill-color": S.set.ar_col || "#1e7bff", "fill-opacity": .12 } });
      map.addLayer({ id: "apoly-l", type: "line", source: "apoly", paint: { "line-color": S.set.ar_col || "#1e7bff", "line-width": 3, "line-dasharray": [3, 1.5] } });
    }
    const on = A.show && A.poly;
    map.getSource("apoly").setData(on ? fc(...A.poly.map(r => ft({ type: "Polygon", coordinates: [r] }))) : fc());
    ["area-f", "area-l"].forEach(l => { if (map.getLayer(l) && on) map.setLayoutProperty(l, "visibility", "none"); });
  } catch (e) { }
}
const _da21 = drawArea; drawArea = function (l) { _da21(l); noAr21(); drawPoly(); };
function setPoly(rings, name) {
  A.poly = rings; A.polyName = name || ""; A.show = true; A.follow = false; try { setSet("area_on", true); } catch (e) { }
  drawArea(); const b = polyBBox(); try { map.fitBounds([[b[1], b[0]], [b[3], b[2]]], { padding: 50, duration: 600 }); } catch (e) { }
  toast(LL21("حُدّدت المنطقة: ", "Area set: ") + (name || "") + " — " + polyKm2(rings).toFixed(1) + " km²");
}
function clearPoly() { A.poly = null; A.polyName = ""; drawArea(); }
/* إرسال المضلع مع طلب الجلب */
(function () {
  const _f = window.fetch; window.fetch = function (u, o) {
    try { if (A.poly && o && o.method === "POST" && /\/api\/download\/start$/.test(String(u)) && typeof o.body === "string") { const j = JSON.parse(o.body); j.poly = A.poly; j.bbox = polyBBox(); o = Object.assign({}, o, { body: JSON.stringify(j) }); } } catch (e) { }
    return _f.call(this, u, o);
  };
})();
function polyDrawMode() {
  const pts = [];
  const draw = () => { const co = pts.map(p => [p[1], p[0]]), f = pts.map(p => ft({ type: "Point", coordinates: [p[1], p[0]] })); if (pts.length >= 3) f.push(ft({ type: "Polygon", coordinates: [co.concat([co[0]])] })); else if (pts.length >= 2) f.push(ft({ type: "LineString", coordinates: co })); setSrc("meas", fc(...f)); };
  startMode({
    dk: "apoly", start(bar) {
      const upd = () => {
        bar.innerHTML = barHtml(LL21("رسم حدود منطقة الجلب", "Draw fetch boundary"), pts.length ? `${pts.length} ${t("pts_")}` + (pts.length >= 3 ? ` · ${polyKm2([pts.map(p => [p[1], p[0]])]).toFixed(2)} km²` : "") : t("tapadd"), [["ap_u", "rot", t("undo")], ["ap_c", "x", t("clear")], ["ap_d", "check", LL21("اعتماد", "Use"), "btn"]]);
        $("#ap_u", bar).onclick = () => { pts.pop(); draw(); upd(); }; $("#ap_c", bar).onclick = () => { pts.length = 0; draw(); upd(); };
        $("#ap_d", bar).onclick = () => { if (pts.length < 3) return toast(LL21("3 نقاط على الأقل", "At least 3 points")); const r = pts.map(p => [p[1], p[0]]); r.push(r[0]); stopMode(); setPoly([r], LL21("رسم يدوي", "Hand-drawn")); };
      }; this.upd = upd; upd();
    }, click(e) { pts.push([e.lngLat.lat, e.lngLat.lng]); draw(); this.upd(); }
  });
}
let ADM = null;
async function admData() { if (!ADM) ADM = await api("/api/admin/list"); return ADM; }
function openBoundary() {
  openSheet("bnd", LL21("تحديد المنطقة بالحدود", "Area by boundary"), async b => {
    b.innerHTML = `<div class="hint">${LL21("اختر قضاءً أو عدة أقضية معاً، أو محافظة، أو العراق كاملاً. تُجلب المعالم داخل الحدود فقط.", "Pick districts, governorates or all of Iraq. Only data inside the boundary is fetched.")}</div>
    <div class="btns"><button class="btn" id="bd_iq">${I("globe")}${LL21("العراق كاملاً", "All Iraq")}</button><button class="btn sec2" id="bd_dr">${I("poly")}${LL21("رسم يدوي", "Draw")}</button></div>
    <div class="seg" id="bd_lv" style="margin:10px 0"><button data-v="2" class="on">${LL21("أقضية", "Districts")}</button><button data-v="1">${LL21("محافظات", "Governorates")}</button></div>
    <input class="in" id="bd_q" placeholder="${LL21("بحث…", "Search…")}"><div id="bd_l" style="max-height:44vh;overflow:auto;margin-top:8px"></div>
    <div class="btns"><button class="btn" id="bd_go">${I("check")}<span id="bd_n"></span></button></div>`;
    let lv = 2; const sel = new Set(); const d = await admData();
    const upd = () => { $("#bd_n", b).textContent = LL21("اعتماد", "Use") + " (" + sel.size + ")"; };
    const render = () => {
      const q = ($("#bd_q", b).value || "").trim().toLowerCase(), box = $("#bd_l", b); box.innerHTML = "";
      const mk = (key, label, sub) => { const r = el(`<label class="row" style="cursor:pointer;gap:10px"><input type="checkbox" ${sel.has(key) ? "checked" : ""}><div class="t"><b>${esc(label)}</b>${sub ? `<small>${esc(sub)}</small>` : ""}</div></label>`, box); $("input", r).onchange = e => { e.target.checked ? sel.add(key) : sel.delete(key); upd(); }; };
      if (lv === 1) d.governorates.filter(g => !q || (g.ar + g.en).toLowerCase().includes(q)).forEach(g => mk(g.en, g.ar || g.en, g.en));
      else {
        const by = {}; d.districts.filter(x => !q || (x.ar + x.en + x.gov).toLowerCase().includes(q)).forEach(x => (by[x.gov || x.gov_en] = by[x.gov || x.gov_en] || []).push(x));
        Object.keys(by).forEach(g => { const h = el(`<div class="row" style="background:var(--sf2);border-radius:10px;padding:6px 10px;margin-top:6px"><b>${esc(g)}</b><button class="btn sec2" style="flex:none;min-width:0;padding:3px 10px;font-size:12px">${LL21("كل الأقضية", "All")}</button></div>`, box);
          $("button", h).onclick = () => { by[g].forEach(x => sel.add(x.gov_en + "|" + x.en)); render(); upd(); }; by[g].forEach(x => mk(x.gov_en + "|" + x.en, x.ar || x.en, x.en)); });
      }
    };
    $$("#bd_lv button", b).forEach(x => x.onclick = () => { lv = +x.dataset.v; sel.clear(); $$("#bd_lv button", b).forEach(y => y.classList.toggle("on", y === x)); render(); upd(); });
    $("#bd_q", b).oninput = render; render(); upd();
    const go = async (body) => { try { const r = await post("/api/admin/rings", body); if (!r.rings || !r.rings.length) return toast(LL21("لا حدود", "No boundary")); closeSheet(); setPoly(r.rings, r.names.length > 3 ? r.names.slice(0, 3).join("، ") + " +" + (r.names.length - 3) : r.names.join("، ")); } catch (e) { fail(e); } };
    $("#bd_go", b).onclick = () => { if (!sel.size) return toast(LL21("اختر وحدة واحدة على الأقل", "Pick at least one")); go(lv === 1 ? { level: 1, names: [...sel] } : { level: 2, keys: [...sel] }); };
    $("#bd_iq", b).onclick = () => go({ level: 1, all: true }); $("#bd_dr", b).onclick = () => polyDrawMode();
  });
}
const _oa21 = openArea;
openArea = function () {
  _oa21(); const b = $("#sh-b"); if (SHEET !== "area" || !b || $("#ar_bd", b)) return;
  /* مفتاح التشغيل تحت مربع العرض */
  const sw = $("#ar_sw", b), row = sw && (sw.closest(".row") || sw.parentNode);
  const place = () => { if (!row) return; const host = A.shape === "circle" ? $("#ar_circ", b) : $("#ar_rect", b), two = host && $(".two", host); if (two && row.previousElementSibling !== two) { two.after(row); row.style.cssText = "margin:6px 0;padding:8px 12px;background:var(--sf2);border-radius:12px"; } };
  place(); b.addEventListener("click", () => setTimeout(place, 30));
  const card = el(`<div class="card" id="ar_bd" style="margin-top:12px"><b>${LL21("التحديد بالحدود أو الرسم", "Boundary / drawn area")}</b><div class="hint" id="ar_bds">${A.poly ? LL21("منطقة مخصصة: ", "Custom: ") + esc(A.polyName) + " — " + polyKm2(A.poly).toFixed(1) + " km²" : LL21("المنطقة الحالية مستطيل/دائرة.", "Current area is a rectangle/circle.")}</div>
    <div class="btns"><button class="btn sec2" id="bd_a">${I("poly")}${LL21("رسم يدوي", "Draw")}</button><button class="btn sec2" id="bd_b">${I("globe")}${LL21("قضاء/محافظة/العراق", "District/Gov./Iraq")}</button></div>${A.poly ? `<button class="btn sec2 er blk" id="bd_x">${I("x")}${LL21("إلغاء والعودة للمستطيل", "Clear custom area")}</button>` : ""}</div>`, b);
  $("#bd_a", card).onclick = () => polyDrawMode(); $("#bd_b", card).onclick = openBoundary; const x = $("#bd_x", card); if (x) x.onclick = () => { clearPoly(); openArea(); };
};

/* ---------------- 2) نافذة الجلب: أقسام قابلة للطي ---------------- */
function fold(title, count, open, bodyNodes, extra) {
  const d = el(`<details class="fold card" ${open ? "open" : ""}><summary><span class="ft">${title}${count != null ? ` (${count})` : ""}</span><span class="fx"></span><i class="fa">${I("chev")}</i></summary><div class="fb"></div></details>`);
  if (extra) $(".fx", d).append(...extra); bodyNodes.forEach(n => $(".fb", d).appendChild(n)); return d;
}
const _of21 = openFetch;
openFetch = function () {
  _of21(); const b = $("#sh-b"); if (SHEET !== "fetch" || !b || $("#f_land", b)) return;
  const p = $("#f_p", b), box = $("#f_l", b); if (!p || !box) return;
  /* المعالم: إزالة قطاعات sx من الخيارات */
  const cats = S.boot.cats; $$(".chip", p).forEach((c, i) => { if (cats[i] && String(cats[i].id).startsWith("sx:")) c.remove(); });
  const secs = $$(".sec", b), pbtn = p.nextElementSibling;
  const allB = $("#f_all", b); if (allB) allB.onclick = () => { cats.forEach(x => { if (!String(x.id).startsWith("sx:")) F.poi.add(x.id); }); $$(".chip", p).forEach(c => c.classList.add("on")); };
  const land = fold(LL21("المعالم", "Landmarks"), $$(".chip", p).length, true, [p, pbtn]); land.id = "f_land"; secs[0] && secs[0].replaceWith(land);
  /* الطبقات: بنى تحتية / طرق / عوارض اصطناعية / طبيعية */
  const sx = $("#f_src", b) || null, old = [...box.children].find(n => n.id === "sx_b" || (n.querySelector && n.querySelector("#sx_b")));
  const keep = old ? old.closest("details") || old : null; if (keep) keep.remove();
  box.innerHTML = ""; box.className = "";
  const L = S.boot.layers, isRoad = x => /^roads?_/.test(x.id);
  [["infra", LL21("البنية التحتية", "Infrastructure"), L.filter(x => (x.g || "main") === "main" && !isRoad(x))], ["roads", LL21("الطرق", "Roads"), L.filter(isRoad)], ["mm", t("mm_grp"), L.filter(x => x.g === "mm")], ["nat", t("nat_grp"), L.filter(x => x.g === "nat")]].forEach(([k, title, arr]) => {
    if (!arr.length) return; const chips = el(`<div class="chips"></div>`), cs = [];
    arr.forEach(x => { const c = el(`<span class="chip ${F.layers.has(x.id) ? "on" : ""}">${esc(S.set.lang === "ar" ? x.ar : x.en)}</span>`, chips); c.onclick = () => { F.layers.has(x.id) ? F.layers.delete(x.id) : F.layers.add(x.id); c.classList.toggle("on", F.layers.has(x.id)); }; cs.push([x, c]); });
    const mk = (txt, want) => { const x = el(`<button class="btn sec2" style="flex:none;min-width:0;padding:3px 10px;font-size:12px">${txt}</button>`); x.onclick = e => { e.preventDefault(); e.stopPropagation(); cs.forEach(([y, c]) => { want ? F.layers.add(y.id) : F.layers.delete(y.id); c.classList.toggle("on", want); }); }; return x; };
    box.appendChild(fold(title, arr.length, false, [chips], [mk(LL21("الكل", "All"), true), mk(LL21("لا شيء", "None"), false)]));
  });
  if (keep) { keep.classList.add("fold"); box.appendChild(keep); }
  const lsec = $$(".sec", b).find(n => n !== land && n.nextElementSibling && (n.nextElementSibling.id === "fl_btns" || n.nextElementSibling.contains(box) || n.nextElementSibling === box)); void lsec;
};

/* ---------------- 4) الضغط المطوّل على «إضافة» ---------------- */
const _bd21 = buildDock;
buildDock = function () {
  _bd21(); const first = $("#dock button"); if (!first || first._lp21) return; first._lp21 = 1; let tm = null, fired = false;
  const items = () => [["plus", LL21("إضافة معلم هنا (موقعي)", "Add landmark here (my location)"), () => locate(true)], ["pin", LL21("إضافة معلم في وسط الشاشة", "Add at screen centre"), () => { ADD.at = null; openAdd(); }], ["layers", LL21("إضافة عدة معالم", "Add several landmarks"), () => startTouch("multi")], ["group", LL21("تجميع معالم في مجموعة", "Group landmarks"), () => openGroups()]];
  const show = () => { fired = true; const r = first.getBoundingClientRect(); menuAt(items(), r.left, r.top - 190); navigator.vibrate && navigator.vibrate(15); };
  first.addEventListener("pointerdown", () => { fired = false; tm = setTimeout(show, 450); }); ["pointerup", "pointerleave", "pointercancel"].forEach(ev => first.addEventListener(ev, () => clearTimeout(tm)));
  first.addEventListener("click", e => { if (fired) { e.stopImmediatePropagation(); e.preventDefault(); fired = false; } }, true);
  first.addEventListener("contextmenu", e => e.preventDefault());
};
setTimeout(buildDock, 900);

/* ---------------- 5) رمز القفل: ثبات الشكل وإغلاقه عند الرجوع ---------------- */
const _lu21 = lockUI;
lockUI = function (...a) {
  const o = _lu21(...a); const pad = $(".lk-pad", o);
  if (pad) { Object.assign(pad.style, { display: "grid", gridTemplateColumns: "repeat(3,72px)", gap: "12px", justifyContent: "center", direction: "ltr", width: "auto" }); $$("button", pad).forEach(x => Object.assign(x.style, { width: "72px", height: "72px", display: "flex", alignItems: "center", justifyContent: "center", padding: "0", writingMode: "horizontal-tb", whiteSpace: "nowrap", direction: "ltr", borderRadius: "50%" })); }
  const dots = $(".lk-dots", o); if (dots) dots.style.cssText += ";display:flex;flex-direction:row;justify-content:center";
  return o;
};
const _b21 = window.__back;
window.__back = () => { const m = $(".lockscr.lk-m"); if (m) { const x = $("#lk_x", m); x ? x.click() : m.remove(); return true; } if ($(".lockscr")) return true; return _b21 ? _b21() : false; };

/* ---------------- 6) الثيمات: تباين النص تلقائياً + لون نص يدوي + ثيم مخصص ---------------- */
const parseCol = s => { s = String(s || "").trim(); let m = /^#([0-9a-f]{3})$/i.exec(s); if (m) return m[1].split("").map(c => parseInt(c + c, 16)); m = /^#([0-9a-f]{6})$/i.exec(s); if (m) { const n = parseInt(m[1], 16); return [n >> 16, (n >> 8) & 255, n & 255]; } m = /rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/i.exec(s); return m ? [+m[1], +m[2], +m[3]] : null; };
const relL = c => { const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(c[0]) + .7152 * f(c[1]) + .0722 * f(c[2]); };
const contrastR = (a, b) => { const x = relL(a), y = relL(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
const toHex = c => "#" + c.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("");
const mixC = (a, b, t_) => toHex(a.map((v, i) => v * (1 - t_) + b[i] * t_));
function fixContrast() {
  try {
    const r = document.documentElement, st = r.style, cs = getComputedStyle(r), g = k => parseCol(cs.getPropertyValue(k)), bg = g("--bg"), sf = g("--sf"); if (!bg) return;
    const man = parseCol(S.set.txt_col);
    if (man && /^#/.test(S.set.txt_col)) { st.setProperty("--tx", S.set.txt_col); st.setProperty("--mu", mixC(man, bg, .35)); }
    else { const tx = g("--tx"); if (!tx || contrastR(tx, bg) < 4.5 || (sf && contrastR(tx, sf) < 4.5)) { const c = relL(bg) > .4 ? [20, 32, 46] : [242, 245, 249]; st.setProperty("--tx", toHex(c)); st.setProperty("--mu", mixC(c, bg, .4)); } }
    const pr = g("--pr"), on = g("--on"); if (pr && (!on || contrastR(on, pr) < 3.5)) st.setProperty("--on", relL(pr) > .5 ? "#0b1220" : "#ffffff");
  } catch (e) { }
}
function regThemes() { J21("themes_json").forEach(t_ => { THEMES["c_" + t_.id] = { n: [t_.name, t_.name], m: t_.m, c: t_.c, v: t_.v, custom: 1 }; }); }
function buildTheme(name, mode, bg, sf, pr, tx) {
  const B = parseCol(bg), S_ = parseCol(sf), P = parseCol(pr); let T = parseCol(tx); if (!T) T = relL(B) > .4 ? [20, 32, 46] : [242, 245, 249];
  const dark = mode === "dark", sf2 = mixC(S_, dark ? [255, 255, 255] : [0, 0, 0], .08), br = mixC(B, T, .16);
  return { id: Date.now().toString(36), name, m: mode, c: B.join(","), v: { "--bg": bg, "--sf": sf, "--sf2": sf2, "--tx": toHex(T), "--mu": mixC(T, B, .4), "--br": br, "--pr": pr, "--pr2": pr, "--on": relL(P) > .5 ? "#0b1220" : "#ffffff", "--neon": pr } };
}
const _al21 = applyLook; applyLook = function () { regThemes(); _al21(); fixContrast(); };
if (typeof EXTRA !== "undefined") {
  const lp0 = EXTRA[0][3];
  EXTRA[0][3] = function () {
    regThemes(); const p = lp0();
    const txtCard = secCard(LL21("لون النص", "Text colour"), colorRow(LL21("لون النص (يدوي)", "Text colour (manual)"), "txt_col", "", ["#ffffff", "#f2f5f9", "#14202e", "#000000", "#ffd43b", "#8ce99a"], applyLook),
      (() => { const x = el(`<button class="btn sec2 blk" style="margin-top:6px">${LL21("تلقائي (تباين مضمون مع الخلفية)", "Auto (guaranteed contrast)")}</button>`); x.onclick = async () => { S.set.txt_col = ""; await setSet("txt_col", ""); applyLook(); openSettings(); }; return x; })(),
      el(`<div class="hint">${LL21("افتراضياً يضبط التطبيق لون النص تلقائياً ليختلف عن الخلفية ويبقى مقروءاً.", "By default the text colour is adjusted automatically so it stays readable.")}</div>`));
    const bld = el(`<div></div>`); const cur = { mode: "dark", bg: "#10161d", sf: "#18212b", pr: "#2f8cff", tx: "" };
    bld.innerHTML = `<label class="f">${LL21("اسم الثيم", "Theme name")}</label><input class="in" id="ct_n" placeholder="${LL21("ثيمي", "My theme")}"><div class="seg" id="ct_m" style="margin:8px 0"><button data-v="dark" class="on">${LL21("داكن", "Dark")}</button><button data-v="light">${LL21("فاتح", "Light")}</button></div>
      <div class="two"><div><label class="f">${LL21("الخلفية", "Background")}</label><input type="color" class="in" id="ct_bg" value="${cur.bg}"></div><div><label class="f">${LL21("النوافذ", "Surface")}</label><input type="color" class="in" id="ct_sf" value="${cur.sf}"></div></div>
      <div class="two"><div><label class="f">${LL21("لون التمييز", "Accent")}</label><input type="color" class="in" id="ct_pr" value="${cur.pr}"></div><div><label class="f">${LL21("لون النص (اتركه تلقائياً)", "Text (blank=auto)")}</label><input type="color" class="in" id="ct_tx" value="#ffffff"><label style="font-size:12px"><input type="checkbox" id="ct_ta" checked> ${LL21("تلقائي", "Auto")}</label></div></div>
      <div class="btns"><button class="btn" id="ct_s">${I("save")}${LL21("حفظ وتطبيق", "Save & apply")}</button></div>`;
    const lst = el(`<div></div>`), mkList = () => { lst.innerHTML = ""; J21("themes_json").forEach(t_ => { const r = el(`<div class="row"><div class="t"><b>${esc(t_.name)}</b></div><button class="ib er" data-id="${t_.id}">${I("trash")}</button></div>`, lst); $("button", r).onclick = async () => { const l = J21("themes_json").filter(x => x.id !== t_.id); delete THEMES["c_" + t_.id]; S.set.themes_json = JSON.stringify(l); await setSet("themes_json", S.set.themes_json); if (S.set.look === "c_" + t_.id) { S.set.look = null; await setSet("look", null); } applyLook(); openSettings(); }; }); }; mkList();
    $$("#ct_m button", bld).forEach(x => x.onclick = () => { $$("#ct_m button", bld).forEach(y => y.classList.toggle("on", y === x)); cur.mode = x.dataset.v; if (cur.mode === "light") { $("#ct_bg", bld).value = "#eef4fb"; $("#ct_sf", bld).value = "#ffffff"; } else { $("#ct_bg", bld).value = "#10161d"; $("#ct_sf", bld).value = "#18212b"; } });
    $("#ct_s", bld).onclick = async () => { const nm = $("#ct_n", bld).value.trim() || LL21("ثيمي", "My theme"), tx = $("#ct_ta", bld).checked ? "" : $("#ct_tx", bld).value; const th = buildTheme(nm, cur.mode, $("#ct_bg", bld).value, $("#ct_sf", bld).value, $("#ct_pr", bld).value, tx); const l = J21("themes_json"); l.push(th); S.set.themes_json = JSON.stringify(l); await setSet("themes_json", S.set.themes_json); regThemes(); S.set.look = "c_" + th.id; await setSet("look", S.set.look); applyLook(); toast(LL21("حُفظ الثيم", "Theme saved")); openSettings(); };
    p.append(txtCard, secCard(LL21("إنشاء ثيم يدوياً", "Create custom theme"), bld, lst)); return p;
  };
}

/* ---------------- 7) مجموعات المعالم ---------------- */
const GR = { live: null };
const grList = () => GR.live || J21("groups_json");
async function grSave(l) { S.set.groups_json = JSON.stringify(l); GR.live = null; await setSet("groups_json", S.set.groups_json); drawGroups(); }
function featIndex() {
  const m = {}; S.ds.forEach(d => GJ[d.id] && GJ[d.id].features.forEach(f => { const p = f.properties || {}, id = p.id != null ? p.id : f.id; if (id == null) return; let ll = null; if (f.geometry && f.geometry.type === "Point") ll = f.geometry.coordinates; else if (p.lat != null && p.lon != null) ll = [+p.lon, +p.lat]; if (ll) m[id] = { id, name: p.name || "", lon: ll[0], lat: ll[1], type: p.type || "", p }; }));
  return m;
}
function hull(P) {
  P = P.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]); if (P.length < 3) return P; const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]), lo = [], up = [];
  P.forEach(p => { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], p) <= 0) lo.pop(); lo.push(p); }); for (let i = P.length - 1; i >= 0; i--) { const p = P[i]; while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], p) <= 0) up.pop(); up.push(p); } lo.pop(); up.pop(); return lo.concat(up);
}
function drawGroups() {
  try {
    if (!map.getSource("grp21")) { map.addSource("grp21", { type: "geojson", data: fc() }); ensureGlyphs();
      map.addLayer({ id: "grp21-f", type: "fill", source: "grp21", filter: ["==", ["geometry-type"], "Polygon"], paint: { "fill-color": ["get", "c"], "fill-opacity": .13 } });
      map.addLayer({ id: "grp21-l", type: "line", source: "grp21", filter: ["!=", ["geometry-type"], "Point"], paint: { "line-color": ["get", "c"], "line-width": 2.5, "line-dasharray": [2, 1.5] } });
      map.addLayer({ id: "grp21-m", type: "circle", source: "grp21", filter: ["==", ["get", "k"], "m"], paint: { "circle-radius": 13, "circle-color": "rgba(0,0,0,0)", "circle-stroke-color": ["get", "c"], "circle-stroke-width": 3 } });
      map.addLayer({ id: "grp21-t", type: "symbol", source: "grp21", filter: ["==", ["get", "k"], "t"], layout: { "text-field": ["get", "lbl"], "text-font": ["Noto Sans Regular"], "text-size": 13, "text-allow-overlap": true }, paint: { "text-color": ["get", "c"], "text-halo-color": "#fff", "text-halo-width": 2 } }); }
    const ix = featIndex(), fs = [];
    grList().forEach(g => { if (g.hidden) return; const pts = g.ids.map(i => ix[i]).filter(Boolean); if (!pts.length) return; pts.forEach(p => fs.push(ft({ type: "Point", coordinates: [p.lon, p.lat] }, { k: "m", c: g.color })));
      const co = pts.map(p => [p.lon, p.lat]); if (co.length >= 3) { const h = hull(co); if (h.length >= 3) fs.push(ft({ type: "Polygon", coordinates: [h.concat([h[0]])] }, { c: g.color })); } else if (co.length === 2) fs.push(ft({ type: "LineString", coordinates: co }, { c: g.color }));
      const cx = co.reduce((s, p) => s + p[0], 0) / co.length, cy = co.reduce((s, p) => s + p[1], 0) / co.length; fs.push(ft({ type: "Point", coordinates: [cx, cy] }, { k: "t", c: g.color, lbl: `${g.name} (${pts.length})` })); });
    map.getSource("grp21").setData(fc(...fs));
  } catch (e) { }
}
setTimeout(() => { const t0 = setInterval(() => { try { if (map && map.loaded() && S.ds) { clearInterval(t0); drawGroups(); } } catch (e) { } }, 1500); }, 2500);
const GCOL = ["#e8590c", "#1e88ff", "#0ca678", "#862e9c", "#f59f00", "#e03131", "#15aabf", "#d6336c"];
function pickMode(g, done) {
  const ids = new Set(g.ids), live = () => { const l = J21("groups_json").filter(x => x.id !== g.id); l.push(Object.assign({}, g, { ids: [...ids] })); GR.live = l; drawGroups(); };
  startMode({
    dk: "grp", start(bar) { const upd = () => { bar.innerHTML = barHtml(LL21("تجميع: ", "Group: ") + esc(g.name), LL21("المعالم المختارة: ", "Selected: ") + ids.size + "<br>" + LL21("المس معلماً لإضافته/إزالته", "Tap a landmark to add/remove"), [["gp_d", "check", LL21("تم", "Done"), "btn"], ["gp_c", "x", t("cancel")]]); $("#gp_d", bar).onclick = () => { stopMode(); done([...ids]); }; $("#gp_c", bar).onclick = () => { GR.live = null; stopMode(); drawGroups(); done(null); }; }; this.upd = upd; upd(); },
    click(e) { const r = 14, bb = [[e.point.x - r, e.point.y - r], [e.point.x + r, e.point.y + r]], ls = map.getStyle().layers.filter(l => l.id.startsWith("d-")).map(l => l.id), fs = map.queryRenderedFeatures(bb, { layers: ls }), f = fs.find(x => x.properties && x.properties.id != null); if (!f) return; const id = f.properties.id; ids.has(id) ? ids.delete(id) : ids.add(id); live(); this.upd(); }
  });
}
async function newGroup() {
  const nm = await askText(LL21("اسم المجموعة", "Group name")); if (!nm) return; const g = { id: Date.now().toString(36), name: nm, color: GCOL[grList().length % GCOL.length], ids: [], hidden: false };
  pickMode(g, async ids => { if (!ids) return; if (!ids.length) return toast(LL21("لم يُختر معلم", "Nothing selected")); g.ids = ids; const l = J21("groups_json"); l.push(g); await grSave(l); openGroup(g.id); });
}
function zoomIds(ids) { const ix = featIndex(), pts = ids.map(i => ix[i]).filter(Boolean); if (!pts.length) return toast(LL21("لا معالم محمّلة", "No loaded landmarks")); const bb = new maplibregl.LngLatBounds(); pts.forEach(p => bb.extend([p.lon, p.lat])); map.fitBounds(bb, { padding: 70, maxZoom: 17 }); }
function openGroups() {
  openSheet("groups", LL21("مجموعات المعالم", "Landmark groups"), b => {
    b.innerHTML = `<div class="btns"><button class="btn" id="g_new">${I("plus")}${LL21("مجموعة جديدة", "New group")}</button></div><div id="g_l"></div>`;
    const l = J21("groups_json"), box = $("#g_l", b); if (!l.length) box.innerHTML = `<div class="hint">${LL21("لا مجموعات بعد. أنشئ مجموعة وحدّد المعالم بلمسها على الخريطة.", "No groups yet.")}</div>`;
    l.forEach(g => { const r = el(`<div class="card"><div class="row"><span style="width:14px;height:14px;border-radius:50%;background:${g.color};flex:none"></span><div class="t"><b>${esc(g.name)}</b><small>${g.ids.length} ${LL21("معلم", "landmarks")}</small></div><button class="ib" data-a="z">${I("locate")}</button><button class="ib" data-a="v">${I(g.hidden ? "eye_off" : "eye")}</button><button class="ib" data-a="e">${I("edit")}</button></div></div>`, box);
      $("[data-a=z]", r).onclick = () => zoomIds(g.ids); $("[data-a=e]", r).onclick = () => openGroup(g.id);
      $("[data-a=v]", r).onclick = async () => { const a = J21("groups_json"), x = a.find(y => y.id === g.id); x.hidden = !x.hidden; await grSave(a); openGroups(); }; });
    $("#g_new", b).onclick = newGroup;
  });
}
function openGroup(id) {
  const g = J21("groups_json").find(x => x.id === id); if (!g) return openGroups();
  openSheet("group", g.name, b => {
    const ix = featIndex(), upd = async fn => { const a = J21("groups_json"), x = a.find(y => y.id === id); fn(x, a); await grSave(a); openGroup(id); };
    b.innerHTML = `${fieldRow(LL21("الاسم", "Name"), "g_n", g.name)}<div class="swr">${GCOL.map(c => `<button class="swc ${g.color === c ? "on" : ""}" data-c="${c}" style="background:${c}"></button>`).join("")}</div>
    <div class="btns" style="margin-top:10px"><button class="btn sec2" id="g_z">${I("locate")}${LL21("تكبير", "Zoom")}</button><button class="btn sec2" id="g_a">${I("plus")}${LL21("تحرير الأعضاء", "Edit members")}</button><button class="btn sec2" id="g_v">${I(g.hidden ? "eye_off" : "eye")}${g.hidden ? LL21("إظهار", "Show") : LL21("إخفاء", "Hide")}</button></div>
    <div class="btns"><button class="btn sec2" id="g_j">${I("share")}GeoJSON</button><button class="btn sec2" id="g_c">${I("share")}CSV</button><button class="btn sec2" id="g_m">${I("merge")}${LL21("دمج مع…", "Merge with…")}</button></div>
    <div class="sec">${LL21("الأعضاء", "Members")} (${g.ids.length})</div><div id="g_mem"></div>
    <div class="btns"><button class="btn sec2 er" id="g_d">${I("trash")}${LL21("حذف المجموعة", "Delete group")}</button><button class="btn sec2 er" id="g_dd">${I("trash")}${LL21("حذف المجموعة والمعالم", "Delete group + landmarks")}</button></div>`;
    $("#g_n", b).onchange = e => upd(x => x.name = e.target.value.trim() || x.name); $$(".swc", b).forEach(x => x.onclick = () => upd(y => y.color = x.dataset.c));
    $("#g_z", b).onclick = () => zoomIds(g.ids); $("#g_v", b).onclick = () => upd(x => x.hidden = !x.hidden);
    $("#g_a", b).onclick = () => pickMode(g, async ids => { if (ids) await upd(x => x.ids = ids); else openGroup(id); });
    const mem = g.ids.map(i => ix[i]).filter(Boolean), box = $("#g_mem", b);
    mem.forEach(p => { const r = el(`<div class="row"><div class="t"><b>${esc(p.name || "—")}</b><small>${esc(p.type)}</small></div><button class="ib" data-a="z">${I("locate")}</button><button class="ib er" data-a="x">${I("x")}</button></div>`, box); $("[data-a=z]", r).onclick = () => map.flyTo({ center: [p.lon, p.lat], zoom: Math.max(map.getZoom(), 16) }); $("[data-a=x]", r).onclick = () => upd(x => x.ids = x.ids.filter(i => i !== p.id)); });
    const gj = () => ({ type: "FeatureCollection", features: mem.map(p => ft({ type: "Point", coordinates: [p.lon, p.lat] }, { name: p.name, type: p.type, group: g.name })) });
    $("#g_j", b).onclick = () => saveBlob(new Blob([JSON.stringify(gj())], { type: "application/geo+json" }), g.name + ".geojson", "share");
    $("#g_c", b).onclick = () => saveBlob(new Blob(["﻿name,type,lat,lon,group\n" + mem.map(p => [p.name, p.type, p.lat, p.lon, g.name].map(v => '"' + String(v).replace(/"/g, '""') + '"').join(",")).join("\n")], { type: "text/csv" }), g.name + ".csv", "share");
    $("#g_m", b).onclick = async () => { const o = J21("groups_json").filter(x => x.id !== id); if (!o.length) return toast(LL21("لا مجموعة أخرى", "No other group")); const nm = await askText(LL21("اكتب اسم المجموعة المراد دمجها:\n", "Name of group to merge: ") + o.map(x => x.name).join("، ")); const t_ = o.find(x => x.name === nm); if (!t_) return toast(LL21("غير موجودة", "Not found")); await upd((x, a) => { x.ids = [...new Set(x.ids.concat(t_.ids))]; a.splice(a.indexOf(a.find(y => y.id === t_.id)), 1); }); };
    $("#g_d", b).onclick = async () => { if (await ask(LL21("حذف المجموعة (تبقى المعالم)؟", "Delete group (landmarks kept)?"))) { await grSave(J21("groups_json").filter(x => x.id !== id)); openGroups(); } };
    $("#g_dd", b).onclick = async () => { if (await ask(LL21("حذف المجموعة وكل معالمها نهائياً؟", "Delete group and all its landmarks?"))) { await post("/api/features/delete", { ids: g.ids }).catch(fail); await grSave(J21("groups_json").filter(x => x.id !== id)); try { refreshDs(dsIds()); } catch (e) { } openGroups(); } };
  });
}
const _bdr21 = buildDrawer;
buildDrawer = function () { _bdr21(); const g = $("#dgrid"); if (!g || $("#tl_grp", g)) return; const x = el(`<button class="tile" id="tl_grp">${I("group")}<span>${LL21("المجموعات", "Groups")}</span></button>`, g); x.onclick = openGroups; };
setTimeout(() => { try { buildDrawer(); } catch (e) { } }, 1000);

/* ---------------- 8) لمس أي جزء من خط/مضلع مجلوب يعرض بياناته ---------------- */
window.addEventListener("DOMContentLoaded", () => {
  const hook = () => map.on("click", e => {
    if (window.__mode || (typeof ADD !== "undefined" && ADD.mode)) return;
    setTimeout(() => {
      if (e._fc) return; const r = 9, ls = map.getStyle().layers.filter(l => /^d-.+-(l|f)$/.test(l.id)).map(l => l.id); if (!ls.length) return;
      const fs = map.queryRenderedFeatures([[e.point.x - r, e.point.y - r], [e.point.x + r, e.point.y + r]], { layers: ls }); if (!fs.length) return;
      e._fc = 1; featClick({ features: [fs[0]], lngLat: e.lngLat });
    }, 30);
  });
  if (typeof map !== "undefined") { if (map.loaded && map.loaded()) hook(); else map.on("load", hook); }
});

/* ---------------- 9) رمز قطاع الاتصالات ---------------- */
try { if (typeof SEC_DEF !== "undefined") SEC_DEF["اتصالات"] = SEC_DEF["اتصالات"] || "tower"; } catch (e) { }
