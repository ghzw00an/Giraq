"use strict";
/* ===== app19 (v3.15): الثيمات والمظهر الكامل، الأداء، أزرار التكبير، قفل التطبيق، تبويبات الإعدادات الجديدة ===== */
Object.assign(ICONS, { palette: "M12 3a9 9 0 100 18c1.3 0 2-.8 2-1.7 0-.5-.2-.9-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1 .8-1.7 1.8-1.7H17a4 4 0 004-4c0-4-4-8-9-8zM7.5 11h.01M10 7.5h.01M14 7.5h.01", resize: "M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7", rotarr: "M20 12a8 8 0 11-2.6-5.9M20 4v5h-5", shield: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z", route2: "M5 19a2 2 0 100-4 2 2 0 000 4zM19 9a2 2 0 100-4 2 2 0 000 4zM7 17h6a3 3 0 000-6h-2a3 3 0 010-6h6" });

/* ================= الثيمات ================= */
const THEMES = {
  def: { n: ["تلقائي (زجاجي)", "Auto glass"] },
  night: { n: ["ليل زجاجي", "Night glass"], m: "dark", c: "16,26,38", v: { "--bg": "#10161d", "--sf": "#18212b", "--sf2": "#212c38", "--tx": "#e8eef5", "--mu": "#93a3b6", "--br": "#2b3745", "--pr": "#2f8cff", "--pr2": "#5aa7ff", "--on": "#fff", "--neon": "#22d3ee" } },
  gold: { n: ["ذهبي ملكي", "Royal gold"], m: "dark", c: "18,28,50", v: { "--bg": "#0f1626", "--sf": "#17213a", "--sf2": "#1f2b48", "--tx": "#f2ede1", "--mu": "#9aa6c0", "--br": "#2a3858", "--pr": "#d4b06a", "--pr2": "#e8c98a", "--on": "#1a1405", "--neon": "#e8c98a" } },
  emerald: { n: ["زمردي", "Emerald"], m: "dark", c: "10,32,28", v: { "--bg": "#0a1a17", "--sf": "#10261f", "--sf2": "#16332b", "--tx": "#e6f5ef", "--mu": "#8fb5a8", "--br": "#1f4036", "--pr": "#18c08a", "--pr2": "#4fe0b0", "--on": "#04140e", "--neon": "#4fe0b0" } },
  violet: { n: ["بنفسجي", "Violet"], m: "dark", c: "30,20,52", v: { "--bg": "#150f26", "--sf": "#1e1636", "--sf2": "#291f48", "--tx": "#efe9fb", "--mu": "#a79bc7", "--br": "#3a2d62", "--pr": "#8b6cff", "--pr2": "#ad97ff", "--on": "#fff", "--neon": "#c6a8ff" } },
  sunset: { n: ["غروب", "Sunset"], m: "dark", c: "40,22,24", v: { "--bg": "#1c1011", "--sf": "#2a1819", "--sf2": "#392122", "--tx": "#fbeeea", "--mu": "#c19b95", "--br": "#4d2e2f", "--pr": "#ff7a45", "--pr2": "#ffa07a", "--on": "#1b0900", "--neon": "#ffb347" } },
  mono: { n: ["أسود وأبيض", "Mono"], m: "dark", c: "0,0,0", v: { "--bg": "#000", "--sf": "#0d0d0d", "--sf2": "#181818", "--tx": "#fff", "--mu": "#a0a0a0", "--br": "#2a2a2a", "--pr": "#fff", "--pr2": "#ddd", "--on": "#000", "--neon": "#fff" } },
  ice: { n: ["جليدي فاتح", "Ice light"], m: "light", c: "255,255,255", v: { "--bg": "#eef4fb", "--sf": "#fff", "--sf2": "#e4edf7", "--tx": "#14202e", "--mu": "#5f7188", "--br": "#d3deea", "--pr": "#1e7bff", "--pr2": "#0f5fd6", "--on": "#fff", "--neon": "#0a8fb3" } },
  paper: { n: ["ورقي دافئ", "Warm paper"], m: "light", c: "255,250,240", v: { "--bg": "#f7f1e6", "--sf": "#fffaf0", "--sf2": "#efe6d4", "--tx": "#2b2418", "--mu": "#7d7260", "--br": "#e0d5bd", "--pr": "#b7791f", "--pr2": "#975a16", "--on": "#fff", "--neon": "#b7791f" } },
  rose: { n: ["وردي فاتح", "Rose light"], m: "light", c: "255,246,249", v: { "--bg": "#fbeff3", "--sf": "#fff7fa", "--sf2": "#f5e1e8", "--tx": "#2b1a21", "--mu": "#85606c", "--br": "#ecd0da", "--pr": "#d6336c", "--pr2": "#b02a58", "--on": "#fff", "--neon": "#d6336c" } }
};
const LOWEND = (navigator.hardwareConcurrency || 8) <= 4 || (navigator.deviceMemory || 4) <= 3;
const LOOKV = ["--bg", "--sf", "--sf2", "--tx", "--mu", "--br", "--pr", "--pr2", "--on", "--neon", "--gl", "--gl2", "--glb", "--blur", "--r"];
function applyLook() {
  const s = S.set, r = document.documentElement, st = r.style; LOOKV.forEach(k => st.removeProperty(k));
  const th = THEMES[s.look] || THEMES.def; let mode = th.m || (s.theme === "auto" ? (matchMedia("(prefers-color-scheme:dark)").matches ? "dark" : "light") : s.theme);
  if (th.m) r.dataset.theme = th.m; else applyThemeBase();
  mode = r.dataset.theme; const dark = mode === "dark";
  if (th.v) Object.entries(th.v).forEach(([k, v]) => st.setProperty(k, v));
  const q = s.fx || (LOWEND ? "mid" : "high"); r.dataset.fx = q;
  let a = s.glass_a == null ? (dark ? .62 : .66) : +s.glass_a, blur = s.glass_b == null ? (dark ? 20 : 18) : +s.glass_b; if (q === "low") { a = Math.max(a, .93); blur = 0; }
  const c = th.c || (dark ? "16,26,38" : "255,255,255"), c2 = dark ? (th.c ? th.c.split(",").map(x => Math.min(255, +x + 16)).join(",") : "30,44,60") : c;
  st.setProperty("--gl", `rgba(${c},${a})`); st.setProperty("--gl2", `rgba(${c2},${Math.max(.2, a - .12)})`);
  st.setProperty("--glb", th.v && th.v["--pr"] && dark ? `${hexA(th.v["--pr"], .22)}` : dark ? "rgba(255,255,255,.13)" : "rgba(255,255,255,.65)");
  st.setProperty("--blur", blur ? `blur(${blur}px) saturate(165%)` : "none");
  if (s.look_r != null) st.setProperty("--r", s.look_r + "px");
  if (s.accent) { st.setProperty("--pr", s.accent); st.setProperty("--pr2", s.accent); st.setProperty("--neon", s.accent); }
  r.style.fontSize = ""; document.body.style.fontFamily = { naskh: "'Noto Naskh Arabic','Amiri',serif", mono: "ui-monospace,Menlo,monospace", round: "'Nunito','Segoe UI',system-ui,sans-serif" }[s.font] || "";
  if (s.fscale && +s.fscale !== 1) document.body.style.setProperty("zoom", +s.fscale); else document.body.style.removeProperty("zoom");
  r.classList.toggle("noanim", s.anim === false);
  try { applyCross(); } catch (e) { }
}
const hexA = (h, a) => { const m = /^#?([0-9a-f]{6})$/i.exec(h); if (!m) return "rgba(255,255,255,.2)"; const n = parseInt(m[1], 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
const applyThemeBase = applyTheme; applyTheme = function () { applyLook(); };
document.addEventListener("DOMContentLoaded", () => setTimeout(applyLook, 50));
setTimeout(applyLook, 400);
try { matchMedia("(prefers-color-scheme:dark)").addEventListener("change", () => applyLook()); } catch (e) { }

/* ================= أزرار التكبير والتصغير ================= */
function zoomBtns() {
  const side = $("#side"); if (!side || $("#zoomc")) return;
  const z = el(`<div id="zoomc"><button id="zin" aria-label="Zoom in">${I("zoomin")}</button><button id="zout" aria-label="Zoom out">${I("zoomout")}</button></div>`, side);
  $("#zin", z).onclick = () => map.zoomIn({ duration: 220 }); $("#zout", z).onclick = () => map.zoomOut({ duration: 220 });
}
document.addEventListener("DOMContentLoaded", () => setTimeout(zoomBtns, 200)); setTimeout(zoomBtns, 1200);

/* ================= قفل التطبيق ================= */
const LK = { on: false, bg: 0 };
const sha = async s => { try { const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join(""); } catch (e) { let h = 5381; for (const ch of s) h = ((h << 5) + h + ch.charCodeAt(0)) | 0; return "f" + (h >>> 0).toString(16); } };
const lkHash = (code) => sha((S.set.lock_salt || "") + "|" + code);
function syncSecure() { try { window.Android && Android.setSecure && Android.setSecure(!!S.set.secure_flag); } catch (e) { } }
function lockUI(mode, title, onCode, opts = {}) {
  /* mode: pin | pattern — يعرض لوحة إدخال ويستدعي onCode(code) ويتوقع true/false */
  const o = el(`<div class="lockscr${opts.cancel ? " lk-m" : ""}"><div class="lk-c"><div class="lk-ic">${I("lock")}</div><h2>${title}</h2><div class="lk-s" id="lk_s">${opts.sub || ""}</div><div id="lk_in"></div>${opts.cancel ? `<button class="btn sec2" id="lk_x">${t("cancel")}</button>` : ""}</div></div>`, document.body);
  const box = $("#lk_in", o), msg = $("#lk_s", o); let done = false;
  const bad = m => { msg.textContent = m; msg.classList.add("bad"); o.classList.remove("shake"); void o.offsetWidth; o.classList.add("shake"); navigator.vibrate && navigator.vibrate(40); };
  const submit = async code => { if (done) return; const r = await onCode(code); if (r === true) { done = true; o.remove(); } else if (r !== "again") bad(typeof r === "string" ? r : LL("رمز غير صحيح", "Wrong code")); return r; };
  if (mode === "pin") {
    let v = ""; const n = opts.len || 4;
    box.innerHTML = `<div class="lk-dots">${"<i></i>".repeat(n)}</div><div class="lk-pad">${[1, 2, 3, 4, 5, 6, 7, 8, 9, "", 0, "⌫"].map(k => `<button data-k="${k}" ${k === "" ? "disabled" : ""}>${k}</button>`).join("")}</div>`;
    const dots = () => $$(".lk-dots i", box).forEach((d, i) => d.classList.toggle("on", i < v.length));
    $$(".lk-pad button", box).forEach(b => b.onclick = async () => { const k = b.dataset.k; msg.classList.remove("bad"); if (k === "⌫") v = v.slice(0, -1); else if (v.length < n) v += k; dots(); if (v.length === n) { const c = v; v = ""; setTimeout(async () => { const r = await submit(c); dots(); }, 120); } });
  } else {
    box.innerHTML = `<canvas class="lk-cv" width="300" height="300"></canvas>`; const cv = $("canvas", box), g = cv.getContext("2d"), P = []; for (let i = 0; i < 9; i++) P.push([50 + (i % 3) * 100, 50 + Math.floor(i / 3) * 100]);
    let seq = [], cur = null; const col = () => getComputedStyle(document.documentElement).getPropertyValue("--pr").trim() || "#1e7bff";
    const draw = () => { g.clearRect(0, 0, 300, 300); const c = col(); P.forEach(([x, y], i) => { g.beginPath(); g.arc(x, y, seq.includes(i) ? 14 : 9, 0, 7); g.fillStyle = seq.includes(i) ? c : "rgba(160,170,190,.55)"; g.fill(); if (seq.includes(i)) { g.beginPath(); g.arc(x, y, 30, 0, 7); g.strokeStyle = c; g.globalAlpha = .35; g.lineWidth = 3; g.stroke(); g.globalAlpha = 1; } });
      if (seq.length) { g.beginPath(); seq.forEach((i, k) => k ? g.lineTo(...P[i]) : g.moveTo(...P[i])); if (cur) g.lineTo(...cur); g.strokeStyle = c; g.lineWidth = 6; g.lineCap = g.lineJoin = "round"; g.stroke(); } };
    const pos = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * 300 / r.width, (e.clientY - r.top) * 300 / r.height]; };
    const hit = p => P.findIndex(([x, y], i) => Math.hypot(p[0] - x, p[1] - y) < 36);
    const move = e => { if (!seq.length) return; cur = pos(e); const h = hit(cur); if (h >= 0 && !seq.includes(h)) { seq.push(h); navigator.vibrate && navigator.vibrate(8); } draw(); };
    cv.onpointerdown = e => { cv.setPointerCapture(e.pointerId); msg.classList.remove("bad"); seq = []; cur = pos(e); const h = hit(cur); if (h >= 0) seq.push(h); draw(); };
    cv.onpointermove = move;
    cv.onpointerup = async () => { const s = seq.slice(); seq = []; cur = null; draw(); if (s.length < 4) { if (s.length) bad(LL("4 نقاط على الأقل", "Min 4 dots")); return; } await submit(s.join("")); };
    draw();
  }
  if (opts.cancel) $("#lk_x", o).onclick = () => { done = true; o.remove(); opts.cancel(); };
  return o;
}
function lockNow() {
  if (LK.on || !S.set.lock_mode || S.set.lock_mode === "none") return; LK.on = true; document.documentElement.classList.add("locked");
  lockUI(S.set.lock_mode, LL("التطبيق مقفل", "App locked"), async c => { const ok = (await lkHash(c)) === S.set.lock_hash; if (ok) { LK.on = false; document.documentElement.classList.remove("locked"); } return ok; }, { sub: S.set.lock_mode === "pin" ? LL("أدخل الرمز", "Enter your PIN") : LL("ارسم النمط", "Draw your pattern"), len: +S.set.lock_len || 4 });
}
/* إعداد/تغيير/إزالة القفل */
async function lockSetup(mode) {
  const verify = () => new Promise(res => {
    if (!S.set.lock_mode || S.set.lock_mode === "none") return res(true);
    lockUI(S.set.lock_mode, LL("أكّد هويتك", "Verify it's you"), async c => { const ok = (await lkHash(c)) === S.set.lock_hash; if (ok) res(true); return ok; }, { cancel: () => res(false), len: +S.set.lock_len || 4 });
  });
  if (!(await verify())) return false;
  if (mode === "none") { await setSet("lock_mode", "none"); await setSet("lock_hash", ""); toast(LL("أُزيل القفل", "Lock removed")); return true; }
  const len = 4;
  const code = await new Promise(res => { let first = null; lockUI(mode, mode === "pin" ? LL("رمز جديد", "New PIN") : LL("نمط جديد", "New pattern"), async c => { if (first === null) { first = c; const el_ = $(".lockscr.lk-m #lk_s"); el_ && (el_.textContent = LL("أعد الإدخال للتأكيد", "Repeat to confirm")); el_ && el_.classList.remove("bad"); return "again"; } if (c !== first) { first = null; return LL("غير متطابق — ابدأ من جديد", "Mismatch — start over"); } res(c); return true; }, { cancel: () => res(null), sub: LL("لا يمكن استرجاع الرمز إن نسيته", "The code cannot be recovered"), len });
  });
  if (!code) return false;
  const salt = Math.random().toString(36).slice(2) + Date.now().toString(36); S.set.lock_salt = salt; await setSet("lock_salt", salt);
  await setSet("lock_hash", await lkHash(code)); await setSet("lock_mode", mode); await setSet("lock_len", len); toast(LL("تم تفعيل القفل", "Lock enabled")); return true;
}
document.addEventListener("visibilitychange", () => {
  const m = S.set.lock_mode; if (!m || m === "none") return;
  if (document.hidden) LK.bg = Date.now(); else { const d = +S.set.lock_delay; if (LK.bg && (Date.now() - LK.bg) / 1000 >= (isNaN(d) ? 0 : d)) lockNow(); }
});
const lockBoot = () => { syncSecure(); lockNow(); };
document.addEventListener("DOMContentLoaded", () => setTimeout(lockBoot, 30)); setTimeout(lockBoot, 700);
(function () { const _ss = setSet; setSet = async function (k, v) { const r = await _ss(k, v); if (k === "secure_flag") syncSecure(); if (["look", "glass_a", "glass_b", "look_r", "accent", "font", "fscale", "fx", "anim", "theme"].includes(k)) applyLook(); return r; }; })();

/* ================= تبويبات الإعدادات الجديدة ================= */
const rng = (label, key, min, max, step, def, fmt, live) => {
  const v = S.set[key] == null ? def : +S.set[key]; const w = el(`<div><label class="f">${label} <b style="color:var(--pr)" class="rv">${fmt ? fmt(v) : v}</b></label><input type="range" class="rg" min="${min}" max="${max}" step="${step}" value="${v}"></div>`), i = $("input", w);
  i.oninput = () => { S.set[key] = +i.value; $(".rv", w).textContent = fmt ? fmt(+i.value) : i.value; live && live(); }; i.onchange = () => setSet(key, +i.value); return w;
};
const colorRow = (label, key, def, cols, live) => {
  const cur = S.set[key] || def, w = el(`<div><label class="f">${label}</label><div class="swr">${cols.map(c => `<button class="swc ${cur === c ? "on" : ""}" data-c="${c}" style="background:${c}"></button>`).join("")}<input type="color" value="${/^#[0-9a-f]{6}$/i.test(cur) ? cur : "#1e7bff"}"></div></div>`);
  const set = c => { $$(".swc", w).forEach(x => x.classList.toggle("on", x.dataset.c === c)); S.set[key] = c; live && live(); setSet(key, c); };
  $$(".swc", w).forEach(x => x.onclick = () => set(x.dataset.c)); $("input[type=color]", w).oninput = e => { S.set[key] = e.target.value; live && live(); }; $("input[type=color]", w).onchange = e => set(e.target.value); return w;
};
const secCard = (title, ...ns) => { const c = el(`<div class="card" style="padding:12px;margin-bottom:12px"><b style="display:block;margin-bottom:6px">${title}</b></div>`); ns.flat().forEach(n => n && c.appendChild(n)); return c; };
function lookPanel() {
  const p = el(`<div class="tabp" data-k="look"></div>`);
  const grid = el(`<div class="thgrid"></div>`);
  Object.entries(THEMES).forEach(([k, th]) => {
    const dark = th.m !== "light", v = th.v || {}, x = el(`<button class="thc ${(S.set.look || "def") === k ? "on" : ""}" data-k="${k}"><span class="thp" style="background:${v["--bg"] || "linear-gradient(135deg,#10161d 50%,#f4f6f9 50%)"}"><i style="background:${v["--pr"] || "#2f8cff"}"></i><i style="background:${v["--neon"] || "#22d3ee"}"></i></span><small>${LL(th.n[0], th.n[1])}</small></button>`, grid);
    x.onclick = async () => { $$(".thc", grid).forEach(y => y.classList.toggle("on", y === x)); S.set.look = k; applyLook(); await setSet("look", k); };
  });
  p.append(secCard(LL("الثيم", "Theme"), grid, el(`<div class="hint">${LL("يطبَّق فوراً على الواجهة والنوافذ والأزرار والإعدادات كلها بتنسيق موحّد.", "Applies instantly to the whole UI with unified styling.")}</div>`)));
  p.append(secCard(LL("الزجاج والشفافية", "Glass & transparency"),
    rng(LL("شفافية الزجاج", "Glass opacity"), "glass_a", .3, .98, .02, S.set.glass_a == null ? .64 : S.set.glass_a, v => Math.round(v * 100) + "%", applyLook),
    rng(LL("قوة الضباب", "Blur"), "glass_b", 0, 32, 1, S.set.glass_b == null ? 18 : S.set.glass_b, v => v + "px", applyLook),
    rng(LL("استدارة الزوايا", "Corner radius"), "look_r", 6, 28, 1, S.set.look_r == null ? 16 : S.set.look_r, v => v + "px", applyLook)));
  const sg = segCtl(LL("جودة التأثيرات", "Effects quality"), "fx", [["high", LL("عالية", "High")], ["mid", LL("متوازنة", "Balanced")], ["low", LL("خفيفة (أسرع)", "Light (fastest)")]], LOWEND ? "mid" : "high", applyLook);
  p.append(secCard(LL("الأداء", "Performance"), sg, el(`<div class="hint">${LL("«خفيفة» تُلغي الضباب وتزيد السلاسة على الأجهزة الضعيفة. «متوازنة» تُبقي الضباب على النوافذ فقط.", "“Light” removes blur for smoother use on weaker phones. “Balanced” keeps blur on windows only.")}</div>`), swRow(LL("حركات الانتقال", "Transition animations"), "", S.set.anim !== false, v => { S.set.anim = v; setSet("anim", v); applyLook(); })));
  p.append(secCard(LL("الخط واللون", "Font & colour"),
    segCtl(LL("نوع الخط", "Font"), "font", [["", LL("افتراضي", "Default")], ["naskh", LL("نسخ", "Naskh")], ["round", LL("مدوّر", "Rounded")], ["mono", LL("ثابت", "Mono")]], "", applyLook),
    rng(LL("حجم النص", "Text size"), "fscale", .9, 1.2, .05, S.set.fscale || 1, v => Math.round(v * 100) + "%", applyLook),
    colorRow(LL("لون التمييز (يغيّر الأزرار والأيقونات)", "Accent colour"), "accent", "", ["#2f8cff", "#22d3ee", "#18c08a", "#d4b06a", "#ff7a45", "#d6336c", "#8b6cff"], applyLook),
    (() => { const b = el(`<button class="btn sec2 blk" style="margin-top:8px">${LL("إعادة المظهر الافتراضي", "Reset look")}</button>`); b.onclick = async () => { for (const k of ["look", "glass_a", "glass_b", "look_r", "accent", "font", "fscale", "fx", "anim"]) { S.set[k] = null; await setSet(k, null); } applyLook(); openSettings(); }; return b; })()));
  return p;
}
function areaPanel() {
  const p = el(`<div class="tabp" data-k="areaT"></div>`), live = () => { try { styleHandles(); drawArea(true); } catch (e) { } };
  p.append(secCard(LL("وحدة إدخال الحجم", "Size input unit"),
    segCtl(LL("الوحدة", "Unit"), "area_unit", [["m", LL("متر", "Metre")], ["km", LL("كيلومتر", "Km")], ["donum", LL("دونم عراقي", "Iraqi dunam")]], "m", () => { if (SHEET === "area") openArea(); }),
    el(`<div class="hint">${LL("الدونم العراقي = 2500 م². عند اختيار الدونم تُدخل المساحة الكلية ويبقى شكل المستطيل ثابتاً.", "Iraqi dunam = 2,500 m². With dunam you enter the total area and the rectangle keeps its shape.")}</div>`)));
  p.append(secCard(LL("مقابض المنطقة", "Area handles"),
    segCtl(LL("الأسلوب", "Style"), "hd_style", [["glass", LL("زجاجي", "Glass")], ["solid", LL("ممتلئ", "Solid")], ["outline", LL("إطار", "Outline")]], "glass", live),
    rng(LL("الحجم", "Size"), "hd_size", 28, 64, 2, S.set.hd_size || 40, v => v + "px", live),
    colorRow(LL("اللون", "Colour"), "hd_color", "#1e7bff", ["#1e7bff", "#22d3ee", "#18c08a", "#f59f00", "#e03131", "#d6336c", "#ffffff"], live),
    swRow(LL("زر الإغلاق ×", "Close button ×"), LL("يغلق منطقة التحديد عند الضغط", "Closes the selection area"), S.set.hd_x !== false, v => { S.set.hd_x = v; setSet("hd_x", v); live(); })));
  p.append(secCard(LL("المنطقة", "Area"),
    segCtl(LL("لون المنطقة", "Area colour"), "ar_col", [["#1e7bff", LL("أزرق", "Blue")], ["#22d3ee", LL("سماوي", "Cyan")], ["#18c08a", LL("أخضر", "Green")], ["#f59f00", LL("برتقالي", "Orange")], ["#e03131", LL("أحمر", "Red")]], "#1e7bff", () => { applyAreaStyle(); }),
    rng(LL("سمك الخط", "Line width"), "ar_w", 1, 8, 1, S.set.ar_w || 3, v => v, applyAreaStyle),
    rng(LL("تعبئة المنطقة", "Fill"), "ar_fill", 0, .6, .02, S.set.ar_fill == null ? .1 : S.set.ar_fill, v => Math.round(v * 100) + "%", applyAreaStyle)));
  return p;
}
function trackPanel() {
  const p = el(`<div class="tabp" data-k="trkT"></div>`);
  p.append(secCard(LL("رمز التتبع على الخريطة", "Tracking marker"),
    segCtl(LL("الشكل", "Shape"), "trk_icon", [["arrow", LL("سهم", "Arrow")], ["person", LL("ماشٍ", "Walker")], ["car", LL("سيارة", "Car")], ["moto", LL("دراجة نارية", "Motorbike")]], "arrow", () => { try { trkMarkRefresh(); } catch (e) { } }),
    rng(LL("الحجم", "Size"), "trk_isz", 24, 72, 2, S.set.trk_isz || 40, v => v + "px", () => { try { trkMarkRefresh(); } catch (e) { } }),
    colorRow(LL("اللون", "Colour"), "trk_icol", "#1e7bff", ["#1e7bff", "#22d3ee", "#18c08a", "#f59f00", "#e03131", "#8b6cff", "#ffffff"], () => { try { trkMarkRefresh(); } catch (e) { } })));
  p.append(secCard(LL("سلوك الخريطة أثناء التتبع", "Map behaviour while tracking"),
    swRow(LL("توجيه الخريطة بحسب اتجاه السير", "Heading-up map"), LL("تدور الخريطة ليكون الأمام للأعلى", "Map rotates so forward points up"), !!S.set.trk_hd, v => setSet("trk_hd", v)),
    swRow(LL("متابعة موقعي تلقائياً", "Follow my position"), LL("يمكنك تحريك الخريطة وتعود بزر يظهر أثناء التتبع", "You can pan away and return with a button"), S.set.trk_follow !== false, v => setSet("trk_follow", v))));
  return p;
}
function secPanel() {
  const p = el(`<div class="tabp" data-k="secT"></div>`);
  const ms = S.set.lock_mode || "none", seg = el(`<div class="seg"><button data-v="none" class="${ms === "none" ? "on" : ""}">${LL("بلا قفل", "No lock")}</button><button data-v="pin" class="${ms === "pin" ? "on" : ""}">PIN</button><button data-v="pattern" class="${ms === "pattern" ? "on" : ""}">${LL("نمط", "Pattern")}</button></div>`);
  $$("button", seg).forEach(b => b.onclick = async () => { const ok = await lockSetup(b.dataset.v); $$("button", seg).forEach(x => x.classList.toggle("on", x.dataset.v === (S.set.lock_mode || "none"))); if (ok) openSettings(); });
  const dl = segCtl(LL("القفل عند العودة للتطبيق", "Lock when returning"), "lock_delay", [["0", LL("فوراً", "Now")], ["30", "30s"], ["60", "1m"], ["300", "5m"]], "0");
  p.append(secCard(`${I("lock").replace("<svg", '<svg style="width:18px;height:18px;vertical-align:-3px;margin-inline-end:6px"')}${LL("الأمان وقفل التطبيق", "Security & app lock")}`, el(`<div class="hint">${LL("يُطلب الرمز عند فتح التطبيق وعند العودة إليه بعد المدة المحددة. يُحفظ بصمة الرمز مشفّرة بملح ولا يُخزَّن الرمز نفسه.", "The code is asked on launch and after the chosen delay. Only a salted hash is stored, never the code.")}</div>`), seg, ms !== "none" ? dl : null,
    swRow(LL("إخفاء محتوى التطبيق في لقطات الشاشة وقائمة التطبيقات الأخيرة", "Hide content in screenshots and recents"), "", !!S.set.secure_flag, v => setSet("secure_flag", v))));
  /* مصدر الجلب والمزوّدون */
  const L = PV.list().filter(PV.isData.bind(PV)), ds = S.set.data_source || "osm";
  const opts = [["osm", "OpenStreetMap"]].concat(L.map(x => [x.id, x.name]));
  const srcSeg = el(`<div class="seg col" style="flex-direction:column">${opts.map(([v, n]) => `<button data-v="${v}" class="${ds === v ? "on" : ""}">${esc(n)}</button>`).join("")}</div>`);
  $$("button", srcSeg).forEach(b => b.onclick = async () => { $$("button", srcSeg).forEach(x => x.classList.toggle("on", x === b)); await setSet("data_source", b.dataset.v); });
  const mg = el(`<button class="btn blk">${I("key")}${LL("إدارة مزوّدي API (Google · MapAtlas · Overture · …)", "Manage API providers")}</button>`); mg.onclick = () => openProviders();
  p.append(secCard(LL("مصدر جلب المعالم", "Landmark data source"), el(`<div class="hint">${LL("القاعدة التي تُجلب منها المعالم. لست مقيّداً بـ OpenStreetMap: أضف مفتاح API ثم اخترها هنا.", "Where landmarks are fetched from. Add an API key then pick it here.")}</div>`), srcSeg, mg));
  p.append(secCard(LL("حول التطبيق", "About"), (() => { const b = el(`<button class="btn sec2 blk">${I("info")}${LL("حول وشكر المصادر", "About & credits")}</button>`); b.onclick = openAbout; return b; })()));
  return p;
}
const EXTRA = [["look", "palette", LL("المظهر", "Look"), lookPanel], ["areaT", "resize", LL("تحديد المنطقة", "Area"), areaPanel], ["trkT", "route2", LL("التتبع", "Tracking"), trackPanel], ["secT", "shield", LL("الأمان والمصادر", "Security & sources"), secPanel]];
const _os19 = openSettings;
openSettings = function () {
  _os19(); const b = $("#sh-b"); if (SHEET !== "set" || !b) return; const bar = $(".stabs", b); if (!bar || bar.dataset.x19) return; bar.dataset.x19 = 1;
  const mine = EXTRA.map(([k, ic, lb, fn]) => { const btn = el(`<button data-k="${k}">${I(ic)}<span>${lb}</span></button>`, bar), panel = fn(); panel.style.display = "none"; b.appendChild(panel); return { k, btn, panel }; });
  const place = () => { const ind = $(".sind", bar), a = $("button.on", bar); if (!ind || !a) return; ind.style.width = a.offsetWidth + "px"; ind._x = (ind._x || 0) + a.getBoundingClientRect().left - ind.getBoundingClientRect().left; ind.style.transform = `translateX(${ind._x}px)`; a.scrollIntoView({ inline: "center", block: "nearest", behavior: "smooth" }); };
  const showMine = k => { $$(".tabp", b).forEach(p => p.style.display = p.dataset.k === k ? "" : "none"); $$("button", bar).forEach(x => x.classList.toggle("on", x.dataset.k === k)); b.scrollTop = 0; S.set.set_tab = k; setSet("set_tab", k); requestAnimationFrame(place); };
  mine.forEach(m => m.btn.onclick = () => showMine(m.k));
  $$("button", bar).filter(x => !mine.some(m => m.btn === x)).forEach(x => x.addEventListener("click", () => mine.forEach(m => m.panel.style.display = "none")));
  if (mine.some(m => m.k === S.set.set_tab)) setTimeout(() => showMine(S.set.set_tab), 60);
};
/* ---------- نافذة المنطقة: الإدخال بوحدة مختارة ---------- */
const DUN = 2500;
const _oa19 = openArea;
openArea = function () {
  _oa19(); const b = $("#sh-b"); if (SHEET !== "area" || !b) return; const u = S.set.area_unit || "m"; if (u === "m" || $("#ar_dn", b)) return;
  const rect = $("#ar_rect", b); if (!rect) return;
  const unitLbl = u === "km" ? "km" : t_dun();
  if (u === "donum") {
    const w = el(`<div id="ar_dn" class="two" style="grid-template-columns:1fr 110px;align-items:end;margin-top:8px"><div><label class="f">${LL("المساحة الكلية", "Total area")} (${unitLbl})</label><input class="in" type="number" inputmode="decimal" step="any" min="0.05" id="ar_dv"></div><div class="hint" id="ar_dh" style="margin:0 0 10px"></div></div>`);
    rect.parentNode.insertBefore(w, rect.nextSibling);
    const upd = () => { if (!$("#ar_dv", b)) return; $("#ar_dv", b).value = +(A.w * A.h / DUN).toFixed(2); $("#ar_dh", b).textContent = `${A.shape === "circle" ? "" : fm(A.w) + " × " + fm(A.h)}`; };
    $("#ar_dv", b).onchange = e => { const v = Math.max(.05, +e.target.value) * DUN; if (A.shape === "circle") A.r = Math.sqrt(v / Math.PI); else { const k = Math.sqrt(v / (A.w * A.h)); A.w = Math.round(A.w * k); A.h = Math.round(A.h * k); } drawArea(); syncAreaUI(); upd(); };
    b.addEventListener("input", () => setTimeout(upd, 0)); b.addEventListener("click", () => setTimeout(upd, 30)); upd(); window.__dunUpd = upd;
  } else {
    /* كيلومتر: حقول بالكيلومتر بجانب الحقول بالمتر */
    const w = el(`<div id="ar_dn" class="two" style="margin-top:8px"><div><label class="f">${LL("العرض", "Width")} (km)</label><input class="in" type="number" inputmode="decimal" step="any" id="ar_kw"></div><div><label class="f">${LL("الارتفاع", "Height")} (km)</label><input class="in" type="number" inputmode="decimal" step="any" id="ar_kh"></div></div>`);
    rect.parentNode.insertBefore(w, rect.nextSibling);
    const upd = () => { if (!$("#ar_kw", b)) return; $("#ar_kw", b).value = +(A.w / 1000).toFixed(3); $("#ar_kh", b).value = +(A.h / 1000).toFixed(3); };
    $("#ar_kw", b).onchange = e => { A.w = Math.max(40, Math.round(+e.target.value * 1000)); drawArea(); syncAreaUI(); upd(); }; $("#ar_kh", b).onchange = e => { A.h = Math.max(40, Math.round(+e.target.value * 1000)); drawArea(); syncAreaUI(); upd(); };
    b.addEventListener("input", () => setTimeout(upd, 0)); upd();
  }
};
const t_dun = () => LL("دونم", "dunam");

try { syncSecure(); lockNow(); } catch (e) { }
