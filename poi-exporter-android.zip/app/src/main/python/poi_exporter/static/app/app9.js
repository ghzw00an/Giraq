"use strict";
/* ===== app9: مزامنة بيانات المتصفح (رسومات، تخطيطات، شعارات…) مع الخادم لتدخل في النسخة الاحتياطية ===== */
const CS_KEYS = ["drawings", "layout2", "layout2_assets", "layouts2", "layout2_logos", "names", "symbology", "defq", "seen_ver"];
const csRead = () => { const o = {}; CS_KEYS.forEach(k => { try { const v = localStorage.getItem(k); if (v != null) o[k] = v; } catch (e) { } }); return o; };
let _csLast = "";
async function csPush(force) {
  const o = csRead(), h = JSON.stringify(o); if (!force && h === _csLast) return; if (!Object.keys(o).length) return;
  await post("/api/clientstate", o); _csLast = h;
}
function csApply(o, overwrite) {
  if (!o || typeof o !== "object") return 0; let n = 0;
  CS_KEYS.forEach(k => { if (typeof o[k] !== "string") return; try { if (overwrite || localStorage.getItem(k) == null) { localStorage.setItem(k, o[k]); n++; } } catch (e) { } });
  if (n && overwrite) { try { if (typeof LY !== "undefined") { LY.loaded = false; } } catch (e) { } toast(LL("تمت استعادة بيانات الواجهة (الرسومات والتخطيطات). أعد فتح التطبيق لتظهر الرسومات.", "UI data restored (drawings, layouts). Reopen the app to see drawings.")); }
  return n;
}
window.addEventListener("DOMContentLoaded", async () => {
  try { const o = await api("/api/clientstate"); const n = csApply(o, false); if (n) { try { LY.loaded = false; } catch (e) { } } _csLast = JSON.stringify(csRead()); } catch (e) { }
  setInterval(() => csPush().catch(() => { }), 45000);
  document.addEventListener("visibilitychange", () => { if (document.hidden) csPush().catch(() => { }); }); window.addEventListener("pagehide", () => csPush().catch(() => { }));
});
