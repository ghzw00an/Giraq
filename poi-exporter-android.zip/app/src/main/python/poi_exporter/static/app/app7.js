"use strict";
/* ===== app7: Layout — المحرّك (الحالة، الرسم، الالتقاط، التصدير) =====
   الواجهة (اللوحات والنوافذ) في app8.js */
Object.assign(ICONS, {
  undo: "M9 14L4 9l5-5M4 9h10a6 6 0 010 12h-3", redo: "M15 14l5-5-5-5M20 9H10a6 6 0 000 12h3", text: "M5 6V4h14v2M12 4v16M9 20h6",
  ruler: "M3 17L17 3l4 4L7 21zM8 12l2 2M11 9l2 2M14 6l2 2", grid: "M4 4h16v16H4zM4 9.3h16M4 14.7h16M9.3 4v16M14.7 4v16",
  lock: "M6 11h12v10H6zM8 11V8a4 4 0 018 0v3", unlock: "M6 11h12v10H6zM8 11V8a4 4 0 017.5-2", copy: "M9 9h11v11H9zM5 15V4h11",
  up: "M12 19V5M6 11l6-6 6 6", down: "M12 5v14M6 13l6 6 6-6", frame: "M4 4h16v16H4zM8 8h8v8H8z", qr: "M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h2v2M18 14h2M14 18h2v2M18 18h2v2",
  star: "M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z", page: "M6 3h9l4 4v14H6zM15 3v4h4", tpl: "M3 4h18v6H3zM3 14h8v6H3zM15 14h6v6h-6z",
  eyeoff: "M3 3l18 18M10 6.2A9 9 0 0112 6c6 0 10 6 10 6a17 17 0 01-3 3.6M6.5 7.5C3.8 9.3 2 12 2 12s4 7 10 7a9 9 0 004-1",
  camera: "M4 7h3l2-3h6l2 3h3v13H4zM12 17a4 4 0 100-8 4 4 0 000 8z", alL: "M4 3v18M8 7h12v4H8zM8 14h7v4H8z", alC: "M12 3v18M6 7h12v4H6zM8 14h8v4H8z", alR: "M20 3v18M4 7h12v4H4zM9 14h7v4H9z",
  alT: "M3 4h18M7 8v12h4V8zM14 8v7h4V8z", alM: "M3 12h18M7 6v12h4V6zM14 8v8h4V8z", alB: "M3 20h18M7 4v12h4V4zM14 9v7h4V9z", shape: "M4 4h9v9H4zM11 11a5 5 0 105 5",
  front: "M8 8h12v12H8zM4 4h8v4M4 4v8h4", gear: ICONS.settings, img2: ICONS.img
});

/* ---------------- ثوابت ---------------- */
const PT = 0.3528, PM = 14;
const PGROUPS = [
  ["ISO A", { A0: [841, 1189], A1: [594, 841], A2: [420, 594], A3: [297, 420], A4: [210, 297], A5: [148, 210], A6: [105, 148] }],
  ["ISO B", { B2: [500, 707], B3: [353, 500], B4: [250, 353], B5: [176, 250] }],
  ["US / ANSI", { Letter: [216, 279], Legal: [216, 356], Tabloid: [279, 432], "ANSI C": [432, 559], "ANSI D": [559, 864], "ANSI E": [864, 1118] }]
];
const PAPERS = {}; PGROUPS.forEach(g => Object.assign(PAPERS, g[1]));
const FONTS = [["sans-serif", "Sans"], ["serif", "Serif"], ["monospace", "Mono"], ["Arial", "Arial"], ["Tahoma", "Tahoma"], ["Verdana", "Verdana"], ["Georgia", "Georgia"], ["Times New Roman", "Times New Roman"], ["Courier New", "Courier New"], ["Noto Naskh Arabic", "Naskh"], ["Noto Kufi Arabic", "Kufi"], ["Noto Sans Arabic", "Noto Sans Arabic"]];
const LYCOL = ["#16202b", "#ffffff", "#1e88ff", "#e03131", "#0ca678", "#f59f00", "#862e9c", "#868e96", "#1e5aa8", "#e8590c"];
const NORTHS = ["n1", "n2", "n3", "n4", "n5", "n6", "n7", "n8", "n9", "n10", "n11", "n12", "n13"];
const SCALES = [["alt", "متناوب", "Alternating"], ["hollow", "مفرغ", "Hollow"], ["checker", "شطرنجي", "Checker"], ["line", "خطي", "Line"], ["ticks", "تدريجي", "Ticks"], ["bar", "كتلة", "Block"], ["double", "مزدوج متري/إمبراطوري", "Double metric/imperial"], ["text", "نسبة فقط", "Ratio only"], ["verbal", "لفظي", "Verbal"]];

const lyClamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lyN = v => +(+v || 0).toFixed(2);
const lyHex = v => /^#[0-9a-f]{6}$/i.test(v) ? v : /^#[0-9a-f]{3}$/i.test(v) ? "#" + v.slice(1).split("").map(x => x + x).join("") : "#000000";
const lyRtl = s => /[؀-ۿ]/.test(s);
const lyFam = f => /^(sans-serif|serif|monospace)$/.test(f) ? f : `"${f}", sans-serif`;
const lyFont = (e, px, m) => `${e.italic ? "italic " : ""}${e.bold ? "700" : "400"} ${Math.max(1, (e.size || 10) * PT * px * (m || 1))}px ${lyFam(e.font || "sans-serif")}`;

/* ---------------- الحالة والحفظ ---------------- */
const LY = { open: false, paper: "A4", ori: "p", cw: 210, ch: 297, bg: "#ffffff", els: [], sel: null, zoom: 1, caps: {}, assets: {}, imgs: {}, guides: [], n: 0, snap: true, grid: false, rulers: true, margin: 8, q: 2, mpan: false, hist: [], hi: -1, pv: false, tab: "cnt", px: 5, k: 1, loaded: false };
function lyLoad() {
  if (LY.loaded) return; LY.loaded = true;
  try { const s = JSON.parse(localStorage.getItem("layout2") || "null"); if (s && s.v === 2) ["paper", "ori", "cw", "ch", "bg", "els", "snap", "grid", "rulers", "margin", "q"].forEach(k => { if (s[k] !== undefined) LY[k] = s[k]; }); } catch (e) { }
  try { LY.assets = JSON.parse(localStorage.getItem("layout2_assets") || "{}") || {}; } catch (e) { LY.assets = {}; }
}
function lySave() { try { localStorage.setItem("layout2", JSON.stringify({ v: 2, paper: LY.paper, ori: LY.ori, cw: LY.cw, ch: LY.ch, bg: LY.bg, els: LY.els, snap: LY.snap, grid: LY.grid, rulers: LY.rulers, margin: LY.margin, q: LY.q })); } catch (e) { } }
function lySaveAssets() { try { localStorage.setItem("layout2_assets", JSON.stringify(LY.assets)); } catch (e) { toast(LL("تعذّر حفظ الصورة محلياً (ستبقى في الجلسة الحالية)", "Could not store the image locally (kept for this session)")); } }
const lyId = () => "e" + Date.now().toString(36) + (LY.n++);
const lyEl = id => LY.els.find(e => e.id === id);
const lySorted = () => LY.els.slice().sort((a, b) => a.z - b.z);
function lyPaper() { let [w, h] = LY.paper === "custom" ? [LY.cw, LY.ch] : (PAPERS[LY.paper] || PAPERS.A4); if (w > h) [w, h] = [h, w]; return LY.ori === "l" ? [h, w] : [w, h]; }
function lyPX() { const [pw, ph] = lyPaper(); return lyClamp(2600 / (Math.max(pw, ph) + 2 * PM), 1, 6); }

/* ---------------- التاريخ (تراجع / إعادة) ---------------- */
const lySnapStr = () => JSON.stringify({ paper: LY.paper, ori: LY.ori, cw: LY.cw, ch: LY.ch, bg: LY.bg, els: LY.els });
function lyPush(now) {
  clearTimeout(LY._ht);
  const go = () => { const s = lySnapStr(); if (LY.hist[LY.hi] === s) return; LY.hist = LY.hist.slice(0, LY.hi + 1); LY.hist.push(s); if (LY.hist.length > 80) LY.hist.shift(); LY.hi = LY.hist.length - 1; lySave(); if (typeof lyUpd === "function") lyUpd(); };
  if (now) go(); else LY._ht = setTimeout(go, 400);
}
function lyHistGo(d) {
  clearTimeout(LY._ht); const i = LY.hi + d; if (i < 0 || i >= LY.hist.length) return; LY.hi = i; const s = JSON.parse(LY.hist[i]);
  Object.assign(LY, { paper: s.paper, ori: s.ori, cw: s.cw, ch: s.ch, bg: s.bg, els: s.els }); if (!lyEl(LY.sel)) LY.sel = null; lySave(); lyDraw(); lyProps(); lyUpd();
}

/* ---------------- العناصر: القيم الافتراضية ---------------- */
const LYD = {
  map: { type: "map", ar: "إطار خريطة", en: "Map frame", w: 190, h: 150 }, inset: { type: "map", ar: "خريطة مصغّرة", en: "Inset map", w: 62, h: 46 },
  north: { ar: "سهم الشمال", en: "North arrow", w: 22, h: 28 }, scale: { ar: "مقياس الرسم", en: "Scale bar", w: 80, h: 16 }, legend: { ar: "مفتاح الخريطة", en: "Legend", w: 55, h: 40 },
  title: { type: "text", ar: "العنوان", en: "Title", w: 130, h: 14 }, sub: { type: "text", ar: "عنوان فرعي", en: "Subtitle", w: 110, h: 9 }, text: { type: "text", ar: "مربع نص", en: "Text box", w: 70, h: 28 },
  date: { type: "text", ar: "التاريخ", en: "Date", w: 45, h: 8 }, credit: { type: "text", ar: "المصدر / الحقوق", en: "Credits", w: 90, h: 7 }, coord: { type: "text", ar: "إحداثيات المركز", en: "Centre coordinates", w: 60, h: 7 }, scaletxt: { type: "text", ar: "نسبة المقياس", en: "Scale ratio", w: 36, h: 8 },
  image: { ar: "شعار / صورة", en: "Logo / image", w: 32, h: 32 }, symbol: { ar: "رمز", en: "Symbol", w: 14, h: 14 },
  rect: { type: "shape", ar: "مستطيل", en: "Rectangle", w: 50, h: 30 }, ellipse: { type: "shape", ar: "قطع ناقص", en: "Ellipse", w: 40, h: 30 }, line: { type: "shape", ar: "خط", en: "Line", w: 60, h: 3 }, arrow: { type: "shape", ar: "سهم", en: "Arrow", w: 50, h: 6 },
  qr: { ar: "رمز QR", en: "QR code", w: 24, h: 24 }, table: { ar: "جدول", en: "Table", w: 180, h: 60 }, border: { type: "shape", ar: "إطار الصفحة", en: "Page border", w: 200, h: 287 }
};
const LYX = {
  map: k => ({ fillOn: true, fill: "#dfe5ea", iz: 1, ox: 0, oy: 0, cid: "main", gr: "off", gf: "dd", gn: 4, gc: "#1b2a3a", gw: .15, gz: 6 * k, ind: "", bw: .5, ar: false }),
  inset: k => Object.assign(LYX.map(k), { cid: "c" + (LY.n++), bw: .7, sh: true, ind: (lySorted().find(m => m.type === "map") || {}).id || "" }),
  north: k => ({ style: "n2", lt: "N", color: "#16202b", fr: true, ar: true, pad: 1.5 }),
  scale: k => ({ style: "alt", unit: "auto", div: 4, ratio: true, size: 8 * k, fillOn: true, fa: .92, pad: 1.5, bw: .25, bc: "#b8c2cc", br: 1.2 * k, color: "#16202b" }),
  legend: k => ({ text: LL("مفتاح الخريطة", "Legend"), size: 9 * k, fillOn: true, fa: .94, bw: .25, bc: "#b8c2cc", br: 1.2 * k, pad: 2.2 * k, cols: 1, ss: 1, live: true, items: lyLegendItems() }),
  title: k => ({ text: LL("عنوان الخريطة", "Map title"), size: 24 * k, bold: true, al: "center", va: "mid", auto: true, pad: 1.5 }),
  sub: k => ({ text: LL("عنوان فرعي", "Subtitle"), size: 14 * k, color: "#44505e", al: "center", va: "mid", auto: true, pad: 1 }),
  text: k => ({ text: LL("اكتب هنا…", "Type here…"), size: 11 * k, fillOn: true, fa: .92, bw: .25, bc: "#b8c2cc", pad: 1.8, br: 1 * k }),
  date: k => ({ text: LL("التاريخ: {date}", "Date: {date}"), size: 9 * k, auto: true, pad: 1 }),
  credit: k => ({ text: LL("المصدر: © مساهمو OpenStreetMap", "Source: © OpenStreetMap contributors"), size: 7 * k, auto: true, pad: .8, color: "#44505e" }),
  coord: k => ({ text: "{center}", size: 8 * k, auto: true, pad: .8 }), scaletxt: k => ({ text: "{scale}", size: 10 * k, bold: true, auto: true, al: "center", pad: 1 }),
  image: k => ({ fit: "contain", gray: false, asset: "", ar: true }), symbol: k => ({ glyph: "pin", fillOn: true, fill: "#e03131", color: "#ffffff", shp: "ellipse", pad: 1.6, ar: true }),
  rect: k => ({ kind: "rect", fillOn: true, fill: "#ffffff", fa: .6, bw: .4 }), ellipse: k => ({ kind: "ellipse", shp: "ellipse", fillOn: true, fill: "#ffffff", fa: .6, bw: .4 }),
  line: k => ({ kind: "line", bw: .6, bc: "#16202b" }), arrow: k => ({ kind: "arrow", bw: .7, bc: "#16202b" }),
  qr: k => ({ text: "https://", color: "#000000", fillOn: true, fill: "#ffffff", pad: 1.6, ar: true }),
  table: k => ({ size: 8 * k, ds: (S.ds.find(d => d.kind !== "reference") || {}).id || "", cols: ["name", "type", "Gategory", "Nahia"], rows: 12, bw: .2, bc: "#8a96a3", hdr: "#1e5aa8", zebra: true, w: 180 }),
  border: k => ({ kind: "rect", fillOn: false, bw: .9, bs: "double", bc: "#16202b" })
};
function lyAdd(key, o) {
  const d = LYD[key], [pw, ph] = lyPaper(), k = lyClamp(Math.min(pw, ph) / 210, .5, 4), type = d.type || key, z = LY.els.length ? Math.max(...LY.els.map(e => e.z)) + 1 : 1;
  const w = Math.min(d.w * k, pw), h = Math.min(d.h * k, ph);
  const e = Object.assign({ id: lyId(), type, role: key, name: LL(d.ar, d.en), x: (pw - w) / 2, y: (ph - h) / 2, w, h, z, rot: 0, lock: false, vis: true, op: 1, fillOn: false, fill: "#ffffff", fa: 1, bw: 0, bc: "#16202b", bs: "solid", br: 0, shp: "rect", sh: false, pad: 0, font: "sans-serif", size: 11 * k, color: "#16202b", bold: false, italic: false, ul: false, al: "start", va: "top", lh: 1.3, ls: 0, halo: "#ffffff", hw: 0, text: "", ar: false }, LYX[key] ? LYX[key](k) : {}, o || {});
  if (key === "border") Object.assign(e, { x: 5 * k, y: 5 * k, w: pw - 10 * k, h: ph - 10 * k }, o || {});
  if (key === "table" && o && o.w == null) e.w = Math.min(pw - 10, d.w * k);
  LY.els.push(e); LY.sel = e.id; return e;
}
function lyLegendItems() {
  const it = []; S.ds.filter(d => d.visible && d.kind !== "reference").forEach(d => {
    const g = GJ[d.id], f = g && g.features[0], r = f && f.geometry.type === "Point" ? iconRes(f.properties, d.id) : null, gt = f ? f.geometry.type : "Point";
    it.push({ label: d.label, color: d.color, shape: r ? "icon" : /Polygon/.test(gt) ? "area" : /Line/.test(gt) ? "line" : "point", g: r ? r.g : "", on: true });
  });
  DR.items.filter(d => d.vis).forEach(d => it.push({ label: d.name || drKindName(d), color: d.color, shape: d.kind === "area" ? "area" : "line", g: "", on: true, dash: d.dash, w: d.width }));
  return it;
}
const lyLegNeed = e => { const fs = e.size * PT, rows = Math.ceil((e.items || []).filter(i => i.on).length / (e.cols || 1)); return (e.pad || 0) * 2 + fs * 1.15 * 1.7 + rows * fs * 1.9 * (e.ss || 1); };

/* ---------------- الخريطة الملتقطة والتحويلات الجغرافية ---------------- */
const lyRefMap = () => lySorted().find(m => m.type === "map" && m.vis !== false) || null;
const lyCapOf = e => LY.caps[e && e.cid || "main"] || LY.caps.main || null;
function lyTf(e, cap, wm, hm) { const s = Math.max(wm / cap.w, hm / cap.h) * (e.iz || 1), dw = cap.w * s, dh = cap.h * s; return { s, ax: (wm - dw) / 2 + (e.ox || 0) / 100 * wm, ay: (hm - dh) / 2 + (e.oy || 0) / 100 * hm }; }
function lyScaleInfo(m) { const cap = m && lyCapOf(m); if (!cap) return null; const tf = lyTf(m, cap, m.w, m.h); return { mmpp: cap.mpp / tf.s, cap, tf }; }
const MWd = z => 512 * Math.pow(2, z), mXf = (lo, W) => (lo + 180) / 360 * W, mYf = (la, W) => (.5 - Math.log(Math.tan(Math.PI / 4 + la * Math.PI / 360)) / (2 * Math.PI)) * W;
const uXf = (x, W) => x / W * 360 - 180, uYf = (y, W) => (Math.atan(Math.exp((.5 - y / W) * 2 * Math.PI)) * 2 - Math.PI / 2) * 180 / Math.PI;
function lyXY2LL(e, cap, fx, fy) {
  const tf = lyTf(e, cap, e.w, e.h), kx = cap.cw / cap.w, sx = (fx - tf.ax) / tf.s * kx - cap.cw / 2, sy = (fy - tf.ay) / tf.s * kx - cap.ch / 2, b = cap.bearing * Math.PI / 180, W = MWd(cap.zoom);
  const wx = sx * Math.cos(b) - sy * Math.sin(b), wy = sx * Math.sin(b) + sy * Math.cos(b); return [uXf(mXf(cap.lng, W) + wx, W), uYf(mYf(cap.lat, W) + wy, W)];
}
function lyLL2XY(e, cap, lng, lat) {
  const tf = lyTf(e, cap, e.w, e.h), kx = cap.cw / cap.w, b = cap.bearing * Math.PI / 180, W = MWd(cap.zoom), wx = mXf(lng, W) - mXf(cap.lng, W), wy = mYf(lat, W) - mYf(cap.lat, W);
  const sx = wx * Math.cos(b) + wy * Math.sin(b), sy = -wx * Math.sin(b) + wy * Math.cos(b); return [(sx + cap.cw / 2) / kx * tf.s + tf.ax, (sy + cap.ch / 2) / kx * tf.s + tf.ay];
}
const lyIdle = ms => new Promise(r => { let d = false; const f = () => { if (!d) { d = true; r(); } }; try { map.once("idle", f); } catch (e) { } setTimeout(f, ms); try { map.triggerRepaint(); } catch (e) { } });
async function lyCapture(cid, quiet) {
  cid = cid || "main"; const cv = map.getCanvas(), pitch = map.getPitch(); let restore = null, ok = false;
  try {
    if (pitch > .5) map.jumpTo({ pitch: 0 });
    const q = +LY.q || 1, base = (map.getPixelRatio ? map.getPixelRatio() : window.devicePixelRatio) || 1, want = Math.min(base * q, 4096 / Math.max(cv.clientWidth, cv.clientHeight, 1));
    if (map.setPixelRatio && want > base + .05) { map.setPixelRatio(want); restore = base; await lyIdle(3500); }
    await new Promise(res => {
      let done = false; const fin = () => { if (!done) { done = true; res(); } };
      map.once("render", () => { try { const u = cv.toDataURL("image/jpeg", .93), im = new Image(); im.onload = () => { const c0 = map.getCenter(); LY.caps[cid] = { img: im, w: cv.width, h: cv.height, cw: cv.clientWidth, ch: cv.clientHeight, mpp: 40075016.686 * Math.cos(c0.lat * Math.PI / 180) / (512 * Math.pow(2, map.getZoom())) * (cv.clientWidth / cv.width), bearing: map.getBearing(), pitch: 0, lng: c0.lng, lat: c0.lat, zoom: map.getZoom(), ts: Date.now() }; ok = true; fin(); }; im.onerror = fin; im.src = u; } catch (er) { fin(); } });
      try { map.triggerRepaint(); } catch (er) { } setTimeout(fin, 7000);
    });
  } catch (e) { } finally { try { if (restore != null) map.setPixelRatio(restore); if (pitch > .5) map.jumpTo({ pitch }); } catch (e) { } }
  if (LY.open) { lyDraw(); lyProps(); } if (!quiet) toast(ok ? LL("تم التقاط الخريطة المعروضة", "Current map captured") : LL("تعذّر التقاط الخريطة", "Could not capture the map")); return ok;
}

/* ---------------- نصوص ديناميكية ---------------- */
function lyTok(s) {
  s = String(s == null ? "" : s); if (s.indexOf("{") < 0) return s;
  const m = lyRefMap(), inf = m && lyScaleInfo(m), cap = m && lyCapOf(m), d = new Date();
  return s.replace(/\{(date|time|scale|center|zoom|paper)\}/g, (_, k) => k === "date" ? d.toLocaleDateString("en-GB") : k === "time" ? d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })
    : k === "scale" ? (inf ? "1 : " + Math.round(inf.mmpp * 1000).toLocaleString("en") : "—") : k === "center" ? (cap ? cap.lat.toFixed(5) + ", " + cap.lng.toFixed(5) : "—") : k === "zoom" ? (cap ? cap.zoom.toFixed(1) : "—") : LY.paper + " " + lyPaper().map(Math.round).join("×"));
}

/* ---------------- الرسم: أدوات مساعدة ---------------- */
function lyRR(c, x, y, w, h, r) { r = Math.max(0, Math.min(r, w / 2, h / 2)); c.beginPath(); if (r <= 0) { c.rect(x, y, w, h); return; } c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
function lyPath(c, e, x, y, w, h, r) { if (e.shp === "ellipse") { c.beginPath(); c.ellipse(x + w / 2, y + h / 2, Math.max(.1, w / 2), Math.max(.1, h / 2), 0, 0, 7); } else lyRR(c, x, y, w, h, r); }
function lyFill(c, e, w, h, px) {
  if (!e.fillOn) return; c.save(); c.globalAlpha *= (e.fa == null ? 1 : e.fa); c.fillStyle = e.fill;
  if (e.sh) { c.shadowColor = "rgba(0,0,0,.4)"; c.shadowBlur = 2.4 * px; c.shadowOffsetY = .8 * px; }
  lyPath(c, e, 0, 0, w, h, (e.br || 0) * px); c.fill(); c.restore();
}
function lyStroke(c, e, w, h, px) {
  if (!(e.bw > 0)) return; c.save(); c.strokeStyle = e.bc; const lw = e.bw * px, st = e.bs || "solid", r = (e.br || 0) * px;
  if (e.sh && !e.fillOn) { c.shadowColor = "rgba(0,0,0,.4)"; c.shadowBlur = 2.4 * px; c.shadowOffsetY = .8 * px; }
  if (st === "double") { c.lineWidth = lw * .6; lyPath(c, e, lw * .3, lw * .3, w - lw * .6, h - lw * .6, r); c.stroke(); c.shadowColor = "transparent"; lyPath(c, e, lw * 1.8, lw * 1.8, w - lw * 3.6, h - lw * 3.6, Math.max(0, r - lw)); c.stroke(); }
  else { c.lineWidth = lw; if (st === "dashed") c.setLineDash([lw * 4, lw * 2.5]); else if (st === "dotted") { c.setLineDash([lw * .1, lw * 2.2]); c.lineCap = "round"; } lyPath(c, e, lw / 2, lw / 2, w - lw, h - lw, r); c.stroke(); }
  c.restore();
}
function lyLines(c, e, txt, w, px) {
  c.save(); c.font = lyFont(e, px); try { c.letterSpacing = ((e.ls || 0) * px) + "px"; } catch (er) { } const maxw = w - 2 * (e.pad || 0) * px, out = [];
  String(txt).split("\n").forEach(par => { let cur = ""; par.split(" ").forEach(wd => { const t2 = cur ? cur + " " + wd : wd; if (c.measureText(t2).width > maxw && cur) { out.push(cur); cur = wd; } else cur = t2; }); out.push(cur); });
  c.restore(); return out;
}
function lyAuto(c, e, px) {
  if (e.type === "text" && e.auto) { const L = lyLines(c, e, lyTok(e.text), e.w * px, px); e.h = Math.max(3, (L.length * e.size * PT * px * (e.lh || 1.3) + 2 * (e.pad || 0) * px) / px); }
  else if (e.type === "legend") e.h = lyLegNeed(e);
  else if (e.type === "table") { const g = GJ[e.ds], n = g ? Math.min(g.features.length, e.rows || 10) : 0; e.h = (n + 1) * e.size * PT * 1.9; }
}
function lyHalo(c, e, px, txt, x, y) { if (e.hw > 0) { c.save(); c.lineJoin = "round"; c.lineWidth = e.hw * px * 2; c.strokeStyle = e.halo; c.strokeText(txt, x, y); c.restore(); } c.fillText(txt, x, y); }
function lyDrawText(c, e, w, h, px) {
  const fs = e.size * PT * px, lh = fs * (e.lh || 1.3), pad = (e.pad || 0) * px, L = lyLines(c, e, lyTok(e.text), w, px), th = L.length * lh;
  c.save(); lyPath(c, e, 0, 0, w, h, (e.br || 0) * px); c.clip(); c.font = lyFont(e, px); try { c.letterSpacing = ((e.ls || 0) * px) + "px"; } catch (er) { } c.fillStyle = e.color; c.textBaseline = "middle"; c.textAlign = "left";
  let y0 = e.va === "mid" ? (h - th) / 2 : e.va === "bot" ? h - pad - th : pad;
  L.forEach((l, i) => {
    const tw = c.measureText(l).width, r = lyRtl(l), al = e.al === "start" ? (r ? "right" : "left") : e.al === "end" ? (r ? "left" : "right") : e.al === "justify" ? (r ? "right" : "left") : "center", x = al === "center" ? (w - tw) / 2 : al === "right" ? w - pad - tw : pad, y = y0 + i * lh + lh / 2;
    lyHalo(c, e, px, l, x, y); if (e.ul) { c.fillRect(x, y + fs * .55, tw, Math.max(1, fs * .06)); }
  });
  c.restore();
}

/* ---------------- سهم الشمال ---------------- */
function lyNorthShape(c, st, R, col, e) {
  const poly = (pts, f) => { c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0] * R, p[1] * R) : c.moveTo(p[0] * R, p[1] * R)); c.closePath(); f ? c.fill() : c.stroke(); };
  const star = (n, alt, r2) => { for (let k = 0; k < n; k++) { const a = k * 2 * Math.PI / n - Math.PI / 2, len = k % 2 ? R * alt : R, va = Math.PI / n; [-1, 1].forEach((sd, j) => { const b = a + sd * va; c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(a) * len, Math.sin(a) * len); c.lineTo(Math.cos(b) * r2 * R, Math.sin(b) * r2 * R); c.closePath(); if (j === 0) c.fill(); c.stroke(); }); } };
  const ring = r => { c.beginPath(); c.arc(0, 0, R * r, 0, 7); c.stroke(); };
  switch (st) {
    case "n1": poly([[0, -1], [.5, .9], [0, .45], [-.5, .9]], true); break;
    case "n2": poly([[0, -1], [0, .45], [-.5, .9]], true); poly([[0, -1], [.5, .9], [0, .45]], false); break;
    case "n3": star(4, 1, .2); break;
    case "n4": star(8, .62, .2); break;
    case "n5": star(16, .72, .14); break;
    case "n6": ring(.95); poly([[0, -.78], [.3, .55], [0, .3], [-.3, .55]], true); break;
    case "n7": c.beginPath(); c.arc(0, 0, R * .98, 0, 7); c.fill(); c.fillStyle = "#fff"; poly([[0, -.72], [.34, .6], [0, .32], [-.34, .6]], true); break;
    case "n8": c.beginPath(); c.moveTo(0, R * .95); c.lineTo(0, -R * .5); c.lineWidth = R * .12; c.stroke(); poly([[0, -1], [.34, -.48], [-.34, -.48]], true); break;
    case "n9": c.lineWidth = R * .16; c.beginPath(); c.moveTo(-.62 * R, .15 * R); c.lineTo(0, -.75 * R); c.lineTo(.62 * R, .15 * R); c.stroke(); c.beginPath(); c.moveTo(0, -.7 * R); c.lineTo(0, R * .95); c.stroke(); break;
    case "n10": poly([[0, -1], [.36, 0], [-.36, 0]], true); poly([[0, 1], [.36, 0], [-.36, 0]], false); break;
    case "n11": ring(.72); c.beginPath(); c.moveTo(0, -R); c.lineTo(0, R); c.moveTo(-R, 0); c.lineTo(R, 0); c.stroke(); poly([[0, -.72], [.2, 0], [-.2, 0]], true); break;
    case "n12": ring(.9); for (let i = 0; i < 36; i++) { const a = i * Math.PI / 18, l = i % 9 === 0 ? .3 : i % 3 === 0 ? .18 : .1; c.beginPath(); c.moveTo(Math.sin(a) * R * .9, -Math.cos(a) * R * .9); c.lineTo(Math.sin(a) * R * (.9 - l), -Math.cos(a) * R * (.9 - l)); c.stroke(); } poly([[0, -.55], [.2, .35], [0, .18], [-.2, .35]], true); break;
    default: star(8, .6, .18); ring(.72); c.font = `700 ${R * .3}px sans-serif`; c.textAlign = "center"; c.textBaseline = "middle"; [["N", "ش", 0, -1], ["E", "ش", 1, 0], ["S", "ج", 0, 1], ["W", "غ", -1, 0]].forEach(l => c.fillText(e && e.lt === "ش" ? ["ش", "ق", "ج", "غ"][[[0, -1], [1, 0], [0, 1], [-1, 0]].findIndex(p => p[0] === l[2] && p[1] === l[3])] : l[0], l[2] * R * 1.14, l[3] * R * 1.14));
  }
}
function lyDrawNorth(c, e, w, h, px, bearing) {
  const lt = e.lt == null ? "N" : e.lt, rose = e.style === "n13", letH = lt && !rose ? Math.min(h * .26, w * .5) : 0, R = Math.max(2, Math.min(w / 2, (h - letH) / 2) * (rose ? .78 : .94));
  c.save(); c.translate(w / 2, letH + (h - letH) / 2); if (e.fr !== false) c.rotate(-bearing * Math.PI / 180); c.fillStyle = c.strokeStyle = e.color; c.lineWidth = Math.max(1, R * .06); c.lineJoin = "round"; lyNorthShape(c, e.style || "n2", R, e.color, e); c.restore();
  if (letH) { c.save(); c.fillStyle = e.color; c.font = `700 ${letH * .92}px ${lyFam(e.font || "sans-serif")}`; c.textAlign = "center"; c.textBaseline = "alphabetic"; lyHalo(c, e, px, lt, w / 2, letH * .86); c.restore(); }
}

/* ---------------- مقياس الرسم ---------------- */
const lyNice = mx => { if (!(mx > 0)) return 1; const p = Math.pow(10, Math.floor(Math.log10(mx))); for (const k of [5, 2, 1]) if (k * p <= mx) return k * p; return p; };
const lyUnitLab = u => ({ m: LL("م", "m"), km: LL("كم", "km"), mi: LL("ميل", "mi"), ft: LL("قدم", "ft") }[u]);
const lyFmtV = v => String(+v.toFixed(2));
function lyDrawScale(c, e, w, h, px) {
  const m = lyRefMap(), inf = m && lyScaleInfo(m), fs = e.size * PT * px; c.save(); c.fillStyle = c.strokeStyle = e.color; c.font = lyFont(e, px); c.textBaseline = "alphabetic"; c.lineWidth = Math.max(1, .25 * px);
  if (!inf) { c.textAlign = "center"; c.fillText(LL("أضف إطار خريطة", "Add a map frame"), w / 2, h / 2); c.restore(); return; }
  const mmpp = inf.mmpp, rt = "1 : " + Math.round(mmpp * 1000).toLocaleString("en"), st = e.style || "alt"; c.textAlign = "center";
  if (st === "text") { lyHalo(c, e, px, rt, w / 2, h / 2 + fs * .35); c.restore(); return; }
  const F = { m: 1, km: 1000, mi: 1609.344, ft: .3048 }, availMm = Math.max(10, e.w - 2 * (e.pad || 0) - 12);
  let u = e.unit || "auto"; if (u === "auto") u = availMm * mmpp >= 1500 ? "km" : "m";
  if (st === "verbal") { const L = lyNice(10 * mmpp / F[u] * 1), txt = LL(`1 سم على الخريطة = ${lyFmtV(10 * mmpp / F[u])} ${lyUnitLab(u)}`, `1 cm on map = ${lyFmtV(10 * mmpp / F[u])} ${lyUnitLab(u)}`); lyHalo(c, e, px, txt, w / 2, h / 2 + fs * .35); c.restore(); return; }
  const L = lyNice(availMm * mmpp / F[u]), barPx = L * F[u] / mmpp * px, n = lyClamp(e.div || 4, 1, 10), bh = Math.max(fs * .5, px), bx = (w - barPx) / 2;
  const total = (e.ratio ? fs * 1.45 : 0) + bh * (st === "double" || st === "checker" ? 2 : 1) + fs * 1.5, y0 = (h - total) / 2 + (e.ratio ? fs * 1.1 : 0), by = y0 + (e.ratio ? fs * .45 : 0);
  if (e.ratio) lyHalo(c, e, px, rt, w / 2, y0);
  const lab = (i, nn, yy, LL2, uu, bx0, bw0) => { if (nn <= 5 || i === 0 || i === nn || (nn % 2 === 0 && i === nn / 2)) { const v = LL2 * i / nn, tx = lyFmtV(v) + (i === nn ? " " + lyUnitLab(uu) : ""); c.fillStyle = e.color; c.font = lyFont(e, px, .85); lyHalo(c, e, px, tx, bx0 + bw0 / nn * i, yy); } };
  const seg = (x, y, ww, hh, fillCol) => { c.fillStyle = fillCol; c.fillRect(x, y, ww, hh); c.strokeRect(x, y, ww, hh); };
  if (st === "alt" || st === "hollow") { for (let i = 0; i < n; i++) seg(bx + barPx / n * i, by, barPx / n, bh, st === "alt" && i % 2 === 0 ? e.color : "#ffffff"); for (let i = 0; i <= n; i++) lab(i, n, by + bh + fs * 1.15, L, u, bx, barPx); }
  else if (st === "checker") { for (let i = 0; i < n; i++) { seg(bx + barPx / n * i, by, barPx / n, bh, i % 2 ? "#ffffff" : e.color); seg(bx + barPx / n * i, by + bh, barPx / n, bh, i % 2 ? e.color : "#ffffff"); } for (let i = 0; i <= n; i++) lab(i, n, by + bh * 2 + fs * 1.15, L, u, bx, barPx); }
  else if (st === "line" || st === "ticks") { const up = st === "line"; c.beginPath(); c.moveTo(bx, by + bh); c.lineTo(bx + barPx, by + bh); for (let i = 0; i <= n; i++) { const xx = bx + barPx / n * i, tl = i === 0 || i === n ? bh * 1.3 : bh * .8; c.moveTo(xx, by + bh); c.lineTo(xx, by + bh + (up ? -tl : tl)); } c.stroke(); for (let i = 0; i <= n; i++) lab(i, n, up ? by + bh + fs * 1.15 : by - fs * .2, L, u, bx, barPx); }
  else if (st === "bar") { c.fillStyle = e.color; c.fillRect(bx, by, barPx, bh); c.fillRect(bx, by - bh * .5, Math.max(1, px * .35), bh * 2); c.fillRect(bx + barPx - Math.max(1, px * .35), by - bh * .5, Math.max(1, px * .35), bh * 2); lab(0, 1, by + bh + fs * 1.15, L, u, bx, barPx); lab(1, 1, by + bh + fs * 1.15, L, u, bx, barPx); }
  else if (st === "double") {
    for (let i = 0; i < n; i++) seg(bx + barPx / n * i, by, barPx / n, bh, i % 2 ? "#ffffff" : e.color); for (let i = 0; i <= n; i++) lab(i, n, by - fs * .25, L, u, bx, barPx);
    const u2 = u === "km" || u === "m" ? (L * F[u] >= 1609 ? "mi" : "ft") : "m", L2 = lyNice(L * F[u] / F[u2]), b2 = L2 * F[u2] / mmpp * px;
    for (let i = 0; i < n; i++) seg(bx + b2 / n * i, by + bh, b2 / n, bh, i % 2 ? e.color : "#ffffff"); for (let i = 0; i <= n; i++) lab(i, n, by + bh * 2 + fs * 1.15, L2, u2, bx, b2);
  }
  c.restore();
}

/* ---------------- مفتاح الخريطة والجدول وغيرها ---------------- */
function lyDrawLegend(c, e, w, h, px) {
  const fs = e.size * PT * px, pad = (e.pad || 0) * px, ss = e.ss || 1, ht = fs * 1.15 * 1.7; c.save(); lyPath(c, e, 0, 0, w, h, (e.br || 0) * px); c.clip(); c.fillStyle = e.color; c.textBaseline = "middle";
  c.font = `700 ${fs * 1.15}px ${lyFam(e.font)}`; const rtl = lyRtl(e.text); c.textAlign = rtl ? "right" : "left"; lyHalo(c, e, px, lyTok(e.text), rtl ? w - pad : pad, pad + ht / 2);
  const items = (e.items || []).filter(i => i.on), cols = e.cols || 1, cw = (w - 2 * pad) / cols, rh = fs * 1.9 * ss, sw = fs * 1.5 * ss; c.font = `${e.bold ? "700 " : "400 "}${fs}px ${lyFam(e.font)}`;
  items.forEach((it, i) => {
    const col = i % cols, row = Math.floor(i / cols), cy = pad + ht + row * rh + rh / 2, rr = lyRtl(it.label), x0 = rr ? pad + (col + 1) * cw : pad + col * cw, sx = rr ? x0 - sw : x0, tx = rr ? x0 - sw - fs * .5 : x0 + sw + fs * .5;
    c.fillStyle = c.strokeStyle = it.color;
    if (it.shape === "icon") { const g = GL[it.g] || GL.pin; c.save(); c.translate(sx, cy - sw / 2); c.scale(sw / 64, sw / 64); c.beginPath(); c.arc(32, 32, 29, 0, 7); c.fillStyle = it.color; c.fill(); c.lineWidth = 4; c.strokeStyle = "#fff"; c.stroke(); c.translate(14, 14); c.scale(1.5, 1.5); c.lineWidth = 2; c.lineCap = c.lineJoin = "round"; c.fillStyle = c.strokeStyle = "#fff"; const p = new Path2D(g[1]); FILLED.has(it.g) ? c.fill(p) : c.stroke(p); c.restore(); }
    else if (it.shape === "point") { c.beginPath(); c.arc(sx + sw / 2, cy, sw * .32, 0, 7); c.fill(); c.strokeStyle = "#fff"; c.lineWidth = px * .3; c.stroke(); }
    else if (it.shape === "line") { c.lineWidth = Math.max(px * .4, (it.w || 3) * px * .12); c.setLineDash(it.dash === "dashed" ? [px * 1.5, px] : it.dash === "dotted" ? [px * .3, px] : []); c.beginPath(); c.moveTo(sx, cy); c.lineTo(sx + sw, cy); c.stroke(); c.setLineDash([]); }
    else { c.save(); c.globalAlpha *= .45; c.fillRect(sx, cy - sw * .35, sw, sw * .7); c.restore(); c.lineWidth = px * .3; c.strokeRect(sx, cy - sw * .35, sw, sw * .7); }
    c.fillStyle = e.color; c.textAlign = rr ? "right" : "left"; lyHalo(c, e, px, it.label, tx, cy);
  });
  c.restore();
}
function lyDrawTable(c, e, w, h, px) {
  const g = GJ[e.ds], rows = g ? g.features.slice(0, e.rows || 10).map(f => f.properties) : [], cols = e.cols && e.cols.length ? e.cols : ["name"], fs = e.size * PT * px, rh = fs * 1.9, cw = w / cols.length;
  c.save(); c.textBaseline = "middle"; c.lineWidth = Math.max(.5, e.bw * px);
  [{ h: 1 }].concat(rows).forEach((r, ri) => {
    const yy = ri * rh; if (ri === 0) { c.fillStyle = e.hdr; c.fillRect(0, yy, w, rh); } else if (e.zebra && ri % 2 === 0) { c.fillStyle = "rgba(0,0,0,.06)"; c.fillRect(0, yy, w, rh); } else if (e.fillOn) { c.fillStyle = e.fill; c.fillRect(0, yy, w, rh); }
    cols.forEach((k, ci) => { const txt = ri === 0 ? t(k) : String(r[k] == null ? "" : r[k]); c.fillStyle = ri === 0 ? "#fff" : e.color; c.font = `${ri === 0 ? "700 " : ""}${fs}px ${lyFam(e.font)}`; c.save(); c.beginPath(); c.rect(ci * cw, yy, cw, rh); c.clip(); const rr = lyRtl(txt); c.textAlign = rr ? "right" : "left"; c.fillText(txt, rr ? (ci + 1) * cw - fs * .4 : ci * cw + fs * .4, yy + rh / 2); c.restore(); });
    if (e.bw > 0) { c.strokeStyle = e.bc; c.strokeRect(0, yy, w, rh); }
  });
  c.restore();
}
function lyImg(id) { if (!id) return null; let im = LY.imgs[id]; if (!im && LY.assets[id]) { im = LY.imgs[id] = new Image(); im.onload = () => { if (LY.open) lyDraw(); }; im.src = LY.assets[id]; } return im; }
function lyDrawImage(c, e, w, h, px) {
  const im = lyImg(e.asset), pad = (e.pad || 0) * px;
  if (im && im.complete && im.naturalWidth) {
    c.save(); lyPath(c, e, 0, 0, w, h, (e.br || 0) * px); c.clip(); const iw = w - 2 * pad, ih = h - 2 * pad, nw = im.naturalWidth, nh = im.naturalHeight; let dw = iw, dh = ih;
    if (e.fit !== "stretch") { const s = e.fit === "cover" ? Math.max(iw / nw, ih / nh) : Math.min(iw / nw, ih / nh); dw = nw * s; dh = nh * s; }
    c.beginPath(); c.rect(pad, pad, iw, ih); c.clip(); if (e.gray) c.filter = "grayscale(1)"; c.drawImage(im, pad + (iw - dw) / 2, pad + (ih - dh) / 2, dw, dh); c.restore();
  } else { c.save(); c.fillStyle = "#98a2ad"; c.font = `${Math.min(w, h) * .16}px sans-serif`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(LL("شعار / صورة", "Logo / image"), w / 2, h / 2); c.restore(); }
}
function lyDrawSymbol(c, e, w, h, px) {
  const g = GL[e.glyph] || GL.pin, s = (Math.min(w, h) - 2 * (e.pad || 0) * px) / 24; c.save(); c.translate((w - 24 * s) / 2, (h - 24 * s) / 2); c.scale(s, s); c.lineWidth = 1.9; c.lineCap = c.lineJoin = "round"; c.strokeStyle = c.fillStyle = e.color; const p = new Path2D(g[1]); FILLED.has(e.glyph) ? c.fill(p) : c.stroke(p); c.restore();
}
function lyDrawQR(c, e, w, h, px) {
  const txt = String(lyTok(e.text) || " "); let q = LY._qr && LY._qr.t === txt ? LY._qr.q : null;
  if (!q) { try { q = qrcode(0, "M"); q.addData(txt); q.make(); LY._qr = { t: txt, q }; } catch (er) { c.save(); c.fillStyle = "#e03131"; c.font = `${Math.min(w, h) * .12}px sans-serif`; c.textAlign = "center"; c.fillText(t("qr_big"), w / 2, h / 2); c.restore(); return; } }
  const n = q.getModuleCount(), s = Math.min(w, h) - 2 * (e.pad || 0) * px, cs = s / n, ox = (w - s) / 2, oy = (h - s) / 2; c.fillStyle = e.color;
  for (let r = 0; r < n; r++) for (let cc = 0; cc < n; cc++) if (q.isDark(r, cc)) c.fillRect(ox + cc * cs, oy + r * cs, cs + .4, cs + .4);
}
function lyDrawShape(c, e, w, h, px) {
  if (e.kind === "line" || e.kind === "arrow") {
    c.save(); const lw = Math.max(.5, e.bw * px); c.strokeStyle = c.fillStyle = e.bc; c.lineWidth = lw; c.lineCap = "round"; if (e.bs === "dashed") c.setLineDash([lw * 4, lw * 2.5]); else if (e.bs === "dotted") c.setLineDash([lw * .1, lw * 2.2]);
    const hd = e.kind === "arrow" ? Math.min(w * .4, Math.max(lw * 4, 3 * px)) : 0; c.beginPath(); c.moveTo(0, h / 2); c.lineTo(w - hd * .6, h / 2); c.stroke(); c.setLineDash([]);
    if (hd) { c.beginPath(); c.moveTo(w, h / 2); c.lineTo(w - hd, h / 2 - hd * .5); c.lineTo(w - hd, h / 2 + hd * .5); c.closePath(); c.fill(); } c.restore(); return;
  }
  lyFill(c, e, w, h, px); lyStroke(c, e, w, h, px);
}

/* ---------------- شبكة الإحداثيات ومؤشر النطاق ---------------- */
function lyFmtDeg(v, st, lon, dms) {
  const hemi = lon ? (v >= 0 ? "E" : "W") : (v >= 0 ? "N" : "S"), a = Math.abs(v);
  if (!dms) { const dec = Math.max(0, Math.min(6, Math.ceil(-Math.log10(st) - 1e-9))); return a.toFixed(dec) + "°" + hemi; }
  let d = Math.floor(a + 1e-9), mm = (a - d) * 60, m = Math.floor(mm + 1e-6), s = (mm - m) * 60; if (st >= .99) return d + "°" + hemi; if (st >= 1 / 60 - 1e-9) return d + "°" + String(m).padStart(2, "0") + "′" + hemi; return d + "°" + String(m).padStart(2, "0") + "′" + s.toFixed(st < 1 / 3600 ? 1 : 0).padStart(2, "0") + "″" + hemi;
}
function lyGraticule(c, e, w, h, px, cap) {
  if (!cap || cap.pitch > 1) return; const wm = w / px, hm = h / px, ll = []; for (let i = 0; i <= 8; i++) for (let j = 0; j <= 8; j++) ll.push(lyXY2LL(e, cap, i / 8 * wm, j / 8 * hm));
  const xs = ll.map(p => p[0]), ys = ll.map(p => p[1]), x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys), span = Math.max(x1 - x0, y1 - y0), want = e.gn || 4;
  const STEPS = [10, 5, 2, 1, .5, 1 / 3, .25, .2, 1 / 6, .1, 1 / 12, .05, .025, .02, 1 / 60, .01, .005, .0025, .002, 1 / 360, .001, .0005, .0002, .0001, .00005], st = STEPS.find(s => span / s >= want) || .00005, fs = (e.gz || 6) * PT * px, dms = e.gf === "dms";
  c.save(); c.strokeStyle = e.gc; c.fillStyle = e.gc; c.lineWidth = Math.max(.6, (e.gw || .15) * px); c.font = `${fs}px sans-serif`; c.textBaseline = "middle";
  const tk = Math.min(wm, hm) * .035 * px;
  if (e.gr === "ticks") { c.beginPath(); c.rect(0, 0, w, h); c.rect(tk, tk, w - 2 * tk, h - 2 * tk); c.clip("evenodd"); }
  const toP = (lo, la) => { const p = lyLL2XY(e, cap, lo, la); return [p[0] * px, p[1] * px]; }, inside = p => p[0] >= 0 && p[0] <= w && p[1] >= 0 && p[1] <= h, lbl = (txt, x, y, al) => { c.save(); c.lineJoin = "round"; c.lineWidth = fs * .35; c.strokeStyle = "rgba(255,255,255,.9)"; c.textAlign = al; c.strokeText(txt, x, y); c.fillStyle = e.gc; c.fillText(txt, x, y); c.restore(); };
  if (e.gr === "crosses") {
    for (let lo = Math.ceil(x0 / st) * st; lo <= x1 + 1e-12; lo += st) for (let la = Math.ceil(y0 / st) * st; la <= y1 + 1e-12; la += st) { const p = toP(lo, la); if (!inside(p)) continue; c.beginPath(); c.moveTo(p[0] - fs * .6, p[1]); c.lineTo(p[0] + fs * .6, p[1]); c.moveTo(p[0], p[1] - fs * .6); c.lineTo(p[0], p[1] + fs * .6); c.stroke(); }
  } else {
    for (let lo = Math.ceil(x0 / st) * st; lo <= x1 + 1e-12; lo += st) { c.beginPath(); for (let i = 0; i <= 20; i++) { const p = toP(lo, y0 + (y1 - y0) * i / 20); i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]); } c.stroke(); }
    for (let la = Math.ceil(y0 / st) * st; la <= y1 + 1e-12; la += st) { c.beginPath(); for (let i = 0; i <= 20; i++) { const p = toP(x0 + (x1 - x0) * i / 20, la); i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]); } c.stroke(); }
  }
  c.restore(); c.save(); c.font = `${fs}px sans-serif`; c.textBaseline = "middle";
  for (let lo = Math.ceil(x0 / st) * st; lo <= x1 + 1e-12; lo += st) { let best = null; for (let i = 0; i <= 20; i++) { const p = toP(lo, y0 + (y1 - y0) * i / 20); if (inside(p) && (!best || p[1] > best[1])) best = p; } if (best) { c.save(); c.lineJoin = "round"; c.lineWidth = fs * .35; c.strokeStyle = "rgba(255,255,255,.9)"; c.textAlign = "center"; const tx = lyFmtDeg(lo, st, true, dms), yy = Math.min(best[1], h - fs * .8); c.strokeText(tx, best[0], yy); c.fillStyle = e.gc; c.fillText(tx, best[0], yy); c.restore(); } }
  for (let la = Math.ceil(y0 / st) * st; la <= y1 + 1e-12; la += st) { let best = null; for (let i = 0; i <= 20; i++) { const p = toP(x0 + (x1 - x0) * i / 20, la); if (inside(p) && (!best || p[0] < best[0])) best = p; } if (best) { c.save(); c.lineJoin = "round"; c.lineWidth = fs * .35; c.strokeStyle = "rgba(255,255,255,.9)"; c.textAlign = "left"; const tx = lyFmtDeg(la, st, false, dms), xx = Math.max(best[0], fs * .3) + fs * .3; c.strokeText(tx, xx, best[1] - fs * .7); c.fillStyle = e.gc; c.fillText(tx, xx, best[1] - fs * .7); c.restore(); } }
  c.restore();
}
function lyIndicator(c, e, w, h, px, cap) {
  const m = lyEl(e.ind); if (!m || m === e || m.type !== "map") return; const mc = lyCapOf(m); if (!mc || !cap) return;
  const pts = [[0, 0], [m.w, 0], [m.w, m.h], [0, m.h]].map(p => { const ll = lyXY2LL(m, mc, p[0], p[1]), q = lyLL2XY(e, cap, ll[0], ll[1]); return [q[0] * px, q[1] * px]; });
  c.save(); c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.closePath(); c.fillStyle = "rgba(224,49,49,.18)"; c.fill(); c.strokeStyle = "#e03131"; c.lineWidth = Math.max(1, .5 * px); c.stroke(); c.restore();
}
function lyDrawMap(c, e, w, h, px) {
  const cap = lyCapOf(e); c.save(); lyPath(c, e, 0, 0, w, h, (e.br || 0) * px); c.clip();
  if (e.fillOn) { c.fillStyle = e.fill; c.fillRect(0, 0, w, h); }
  if (cap && cap.img) { const tf = lyTf(e, cap, e.w, e.h); c.drawImage(cap.img, tf.ax * px, tf.ay * px, cap.w * tf.s * px, cap.h * tf.s * px); }
  else { c.fillStyle = "#6b7785"; c.font = `${Math.min(w, h) * .05}px sans-serif`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(LL("اضغط «التقاط الخريطة»", "Tap “Capture map”"), w / 2, h / 2); }
  if (cap && e.gr && e.gr !== "off") lyGraticule(c, e, w, h, px, cap);
  if (cap && e.ind) lyIndicator(c, e, w, h, px, cap);
  c.restore(); lyStroke(c, e, w, h, px);
}
function lyDrawEl(c, e, px) {
  if (e.vis === false) return; lyAuto(c, e, px);
  c.save(); c.globalAlpha = e.op == null ? 1 : e.op; const w = e.w * px, h = e.h * px; c.translate((e.x + e.w / 2) * px, (e.y + e.h / 2) * px); if (e.rot) c.rotate(e.rot * Math.PI / 180); c.translate(-w / 2, -h / 2);
  const box = fn => { lyFill(c, e, w, h, px); fn(); lyStroke(c, e, w, h, px); };
  switch (e.type) {
    case "map": lyDrawMap(c, e, w, h, px); break;
    case "text": box(() => lyDrawText(c, e, w, h, px)); break;
    case "legend": box(() => lyDrawLegend(c, e, w, h, px)); break;
    case "north": { const m = lyRefMap(), cap = m && lyCapOf(m); box(() => lyDrawNorth(c, e, w, h, px, cap ? cap.bearing : 0)); break; }
    case "scale": box(() => lyDrawScale(c, e, w, h, px)); break;
    case "image": box(() => lyDrawImage(c, e, w, h, px)); break;
    case "symbol": box(() => lyDrawSymbol(c, e, w, h, px)); break;
    case "qr": box(() => lyDrawQR(c, e, w, h, px)); break;
    case "table": box(() => lyDrawTable(c, e, w, h, px)); break;
    case "shape": lyDrawShape(c, e, w, h, px); break;
  }
  c.restore();
}

/* ---------------- اللوحة: الورقة، الشبكة، المساطر، التحديد ---------------- */
function lyRulers(c, px, pw, ph, k) {
  c.save(); c.fillStyle = "rgba(255,255,255,.9)"; c.strokeStyle = "rgba(255,255,255,.6)"; c.lineWidth = k; c.font = `${9 * k}px system-ui,sans-serif`; c.textAlign = "center"; c.textBaseline = "middle";
  const mn = Math.max(pw, ph) > 500 ? 50 : 10, lb = mn === 10 ? 50 : 100, o = PM * px;
  for (let v = 0; v <= pw + .01; v += mn) { const x = o + v * px, mj = v % lb === 0, l = (mj ? 5 : 2.5) * k; c.beginPath(); c.moveTo(x, o - 2 * k); c.lineTo(x, o - 2 * k - l); c.stroke(); if (mj) c.fillText(v, x, o - 2 * k - l - 6 * k); }
  for (let v = 0; v <= ph + .01; v += mn) { const y = o + v * px, mj = v % lb === 0, l = (mj ? 5 : 2.5) * k; c.beginPath(); c.moveTo(o - 2 * k, y); c.lineTo(o - 2 * k - l, y); c.stroke(); if (mj) c.fillText(v, o - 2 * k - l - 10 * k, y); }
  c.restore();
}
function lyDrawSel(c, e, px, k) {
  const w = e.w * px, h = e.h * px, hh = Math.max(h, 0); c.save(); c.translate((e.x + e.w / 2) * px, (e.y + e.h / 2) * px); c.rotate((e.rot || 0) * Math.PI / 180); c.translate(-w / 2, -hh / 2);
  c.strokeStyle = "#1e88ff"; c.lineWidth = 1.6 * k; c.setLineDash([6 * k, 4 * k]); c.strokeRect(0, 0, w, hh); c.setLineDash([]);
  if (!e.lock) {
    const hs = 10 * k; [[0, 0], [.5, 0], [1, 0], [1, .5], [1, 1], [.5, 1], [0, 1], [0, .5]].forEach(p => { c.fillStyle = "#fff"; c.strokeStyle = "#1e88ff"; c.lineWidth = 1.8 * k; c.fillRect(p[0] * w - hs / 2, p[1] * hh - hs / 2, hs, hs); c.strokeRect(p[0] * w - hs / 2, p[1] * hh - hs / 2, hs, hs); });
    c.beginPath(); c.moveTo(w / 2, 0); c.lineTo(w / 2, -22 * k); c.stroke(); c.beginPath(); c.arc(w / 2, -22 * k, 6.5 * k, 0, 7); c.fillStyle = "#1e88ff"; c.fill();
  } else { c.fillStyle = "#1e88ff"; c.font = `${13 * k}px sans-serif`; c.fillText("🔒", 4 * k, 15 * k); }
  c.restore();
}
function lyPaint(c, px, scr) {
  const [pw, ph] = lyPaper(), k = LY.k || 1, edit = scr && !LY.pv;
  c.save();
  if (scr) { c.fillStyle = "#59636e"; c.fillRect(0, 0, c.canvas.width, c.canvas.height); c.translate(PM * px, PM * px); c.shadowColor = "rgba(0,0,0,.5)"; c.shadowBlur = 16 * k; c.shadowOffsetY = 3 * k; }
  c.fillStyle = LY.bg; c.fillRect(0, 0, pw * px, ph * px); c.shadowColor = "transparent"; c.shadowBlur = 0; c.shadowOffsetY = 0;
  c.save(); c.beginPath(); c.rect(0, 0, pw * px, ph * px); c.clip(); lySorted().forEach(e => lyDrawEl(c, e, px)); c.restore();
  if (edit) {
    if (LY.grid) {
      const g = Math.max(pw, ph) > 500 ? 50 : 10; c.save(); c.strokeStyle = "rgba(30,136,255,.28)"; c.lineWidth = k * .8; c.beginPath(); for (let v = g; v < pw; v += g) { c.moveTo(v * px, 0); c.lineTo(v * px, ph * px); } for (let v = g; v < ph; v += g) { c.moveTo(0, v * px); c.lineTo(pw * px, v * px); } c.stroke();
      if (LY.margin > 0) { c.strokeStyle = "rgba(255,59,141,.6)"; c.setLineDash([5 * k, 4 * k]); c.strokeRect(LY.margin * px, LY.margin * px, (pw - 2 * LY.margin) * px, (ph - 2 * LY.margin) * px); } c.restore();
    }
    const s = lyEl(LY.sel); if (s && s.vis !== false) lyDrawSel(c, s, px, k);
    c.save(); c.strokeStyle = "#ff3b8d"; c.lineWidth = k; LY.guides.forEach(g => { c.beginPath(); if (g.v != null) { c.moveTo(g.v * px, 0); c.lineTo(g.v * px, ph * px); } else { c.moveTo(0, g.h * px); c.lineTo(pw * px, g.h * px); } c.stroke(); }); c.restore();
  }
  c.restore();
  if (edit && LY.rulers) lyRulers(c, px, pw, ph, k);
}
function lyDraw() {
  const cv = $("#lyc"), W = $(".lyw"); if (!cv || !W) return; const [pw, ph] = lyPaper(), px = lyPX(), nw = Math.round((pw + 2 * PM) * px), nh = Math.round((ph + 2 * PM) * px);
  if (cv.width !== nw || cv.height !== nh) { cv.width = nw; cv.height = nh; }
  const aw = Math.max(120, W.clientWidth - 10), ah = Math.max(120, W.clientHeight - 10), fit = Math.min(aw / (pw + 2 * PM), ah / (ph + 2 * PM)), cssW = (pw + 2 * PM) * fit * LY.zoom;
  cv.style.width = Math.round(cssW) + "px"; cv.style.height = Math.round(cssW * nh / nw) + "px"; LY.px = px; LY.k = nw / cssW; lyPaint(cv.getContext("2d"), px, true);
}

/* ---------------- التصدير ---------------- */
function lyDims(dpi) { const [pw, ph] = lyPaper(); let d = dpi; while ((pw * d / 25.4 > 12000 || ph * d / 25.4 > 12000 || (pw * d / 25.4) * (ph * d / 25.4) > 45e6) && d > 50) d = Math.floor(d * .9); return { d, w: Math.round(pw * d / 25.4), h: Math.round(ph * d / 25.4), pw, ph }; }
async function lyRender(dpi, fmt) {
  const D = lyDims(dpi), cv = document.createElement("canvas"); cv.width = D.w; cv.height = D.h; const c = cv.getContext("2d"), sv = LY.sel; LY.sel = null; lyPaint(c, D.d / 25.4, false); LY.sel = sv;
  const bl = await new Promise(r => cv.toBlob(r, fmt === "png" ? "image/png" : "image/jpeg", .93)); if (!bl) throw new Error(LL("تعذّر إنشاء الصورة (الذاكرة)", "Could not render (memory)"));
  if (fmt === "pdf") return makePdf(new Uint8Array(await bl.arrayBuffer()), D.w, D.h, D.pw, D.ph); return bl;
}
function makePdf(jpg, wp, hp, wm, hm) {
  const W = wm * 72 / 25.4, H = hm * 72 / 25.4, enc = s => new TextEncoder().encode(s), parts = [], off = []; let len = 0; const add = u => { parts.push(u); len += u.length; }, obj = (n, body) => { off[n] = len; add(enc(`${n} 0 obj\n${body}\nendobj\n`)); };
  add(enc("%PDF-1.4\n")); obj(1, "<< /Type /Catalog /Pages 2 0 R >>"); obj(2, "<< /Type /Pages /Kids [3 0 R] /Count 1 >>"); obj(3, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W.toFixed(2)} ${H.toFixed(2)}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`);
  off[4] = len; add(enc(`4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${wp} /Height ${hp} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`)); add(jpg); add(enc("\nendstream\nendobj\n"));
  const cs = `q ${W.toFixed(2)} 0 0 ${H.toFixed(2)} 0 0 cm /Im0 Do Q`; obj(5, `<< /Length ${cs.length} >>\nstream\n${cs}\nendstream`); const xr = len; let x = "xref\n0 6\n0000000000 65535 f \n"; for (let i = 1; i <= 5; i++) x += String(off[i]).padStart(10, "0") + " 00000 n \n"; x += `trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xr}\n%%EOF`; add(enc(x)); return new Blob(parts, { type: "application/pdf" });
}
