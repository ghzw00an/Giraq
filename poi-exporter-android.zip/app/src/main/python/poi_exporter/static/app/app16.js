"use strict";
/* ===== app16: أدوات GIS — استعلام التعريف، Display XY، Construct Points، Append، Feature→Polygon، Polygon→Line،
   التحديد المكاني بقضاء، طريق عبر الشوارع، تحليل الشبكة ===== */
Object.assign(ICONS, { filter: ICONS.filter || "M3 5h18l-7 8v6l-4-2v-4z", line: ICONS.line || "M4 18L10 8l4 6 6-10", route: ICONS.route || "M6 18a2 2 0 100-4 2 2 0 000 4zM18 10a2 2 0 100-4 2 2 0 000 4zM8 16h6a3 3 0 000-6h-4a3 3 0 010-6h6" });
const dsOpts = (geoms, sel) => S.ds.filter(d => d.kind !== "reference" && (!geoms || geoms.includes(d.geom))).map(d => `<option value="${d.id}" ${d.id === sel ? "selected" : ""}>${esc6(d.label)} (${d.count != null ? d.count : ""})</option>`).join("");
const noLayers = (b, what) => { b.innerHTML = `<div class="hint">${LL("لا توجد طبقات مناسبة", "No suitable layers")}${what ? " — " + what : ""}</div>`; };
async function zoomLayer(id) {
  const d = S.ds.find(x => x.id === id); if (!d) return; await ensureDs(d); const bb = new maplibregl.LngLatBounds(); const w = c => typeof c[0] === "number" ? bb.extend(c) : c.forEach(w);
  (GJ[id].features || []).forEach(f => f.geometry && w(f.geometry.coordinates)); if (!bb.isEmpty()) map.fitBounds(bb, { padding: 70, maxZoom: 17 });
}
async function gisRun(url, body, okMsg) {
  try { toast(t("wait")); const r = await post(url, body); await refreshDs(dsIds()); if (r.layer) zoomLayer(r.layer); toast(okMsg ? okMsg(r) : t("done")); return r; } catch (e) { fail(e); return null; }
}

/* ---------- استعلام التعريف (Definition Query) ---------- */
const DQF = ["name", "type", "Gategory", "gathaa", "Nahia", "mohafadha", "x", "y"];
let DQ = null;
const dqAll = () => { if (!DQ) { try { DQ = JSON.parse(localStorage.getItem("defq") || "{}") || {}; } catch (e) { DQ = {}; } } return DQ; };
const dqSave = () => { try { localStorage.setItem("defq", JSON.stringify(DQ || {})); } catch (e) { } };
const dqHide = (q, p) => { if (!q || !q.rows || !q.rows.length) return false; const r = q.rows.map(x => selTest(x.o, p[x.f], x.v)); return !(q.mode === "or" ? r.some(Boolean) : r.every(Boolean)); };
const _dec16 = decorate;
decorate = function (g, d) { _dec16(g, d); const q = dqAll()[d.id], off = new Set(S.set.sect_off || []); g.features.forEach(f => { const p = f.properties || (f.properties = {}); p._dq = (q && dqHide(q, p)) || off.has(p.Gategory) ? 1 : 0; }); };
function dqApply(d) {
  if (!map || !map.getSource("d-" + d.id)) return; map._of = map._of || {};
  ["f", "l", "c", "i", "t"].forEach(k => { const id = `d-${d.id}-${k}`; if (!map.getLayer(id)) return; if (!(id in map._of)) map._of[id] = map.getFilter(id) || null; const o = map._of[id], c = ["!=", ["get", "_dq"], 1]; map.setFilter(id, o ? ["all", o, c] : c); });
}
const _pd16 = paintDs; paintDs = function (d) { _pd16(d); dqApply(d); };
const _rs16 = restyleAll; restyleAll = function () { _rs16(); S.ds.forEach(dqApply); };
function openDefQuery() {
  const ds = S.ds.filter(d => d.kind !== "reference"); if (!ds.length) return toast(t("nodata"));
  openSheet("defq", LL("استعلام التعريف", "Definition query"), b => {
    b.innerHTML = `<div class="hint">${LL("يعرض على الخريطة المعالم المطابقة للشرط فقط ويخفي الباقي (لا يحذف شيئاً).", "Shows only matching features on the map; nothing is deleted.")}</div>
    <label class="f">${LL("الطبقة", "Layer")}</label><select class="in" id="dq_d">${dsOpts()}</select><div class="seg" id="dq_m" style="margin:10px 0"><button data-v="and">${LL("كل الشروط", "All")}</button><button data-v="or">${LL("أي شرط", "Any")}</button></div>
    <div id="dq_r"></div><div class="btns"><button class="btn sec2" id="dq_a">${I("plus")}${LL("إضافة شرط", "Add condition")}</button></div><div class="sec" id="dq_n"></div>
    <div class="btns"><button class="btn" id="dq_go">${I("check")}${LL("تطبيق", "Apply")}</button><button class="btn sec2" id="dq_x">${LL("إلغاء الاستعلام", "Clear query")}</button></div>`;
    let q = { mode: "and", rows: [] }; const cur = () => $("#dq_d", b).value;
    const draw = () => { $$("#dq_m button", b).forEach(x => x.classList.toggle("on", x.dataset.v === q.mode));
      $("#dq_r", b).innerHTML = q.rows.map((r, i) => `<div class="dqr" data-i="${i}"><select class="in" data-k="f">${DQF.map(k => `<option value="${k}" ${r.f === k ? "selected" : ""}>${t(k)}</option>`).join("")}</select><select class="in" data-k="o">${SELOP.map(o => `<option value="${o[0]}" ${r.o === o[0] ? "selected" : ""}>${LL(o[1], o[2])}</option>`).join("")}</select><input class="in" data-k="v" value="${esc6(r.v)}"><button class="ib er" data-x="1">${I("x")}</button></div>`).join("");
      $$("#dq_r .dqr", b).forEach(row => { const i = +row.dataset.i; $$("[data-k]", row).forEach(c => c.onchange = c.oninput = () => { q.rows[i][c.dataset.k] = c.value; }); $("[data-x]", row).onclick = () => { q.rows.splice(i, 1); draw(); }; }); };
    const load = () => { q = JSON.parse(JSON.stringify(dqAll()[cur()] || { mode: "and", rows: [] })); if (!q.rows.length) q.rows.push({ f: "name", o: "has", v: "" }); draw(); count(); };
    const count = async () => { const d = S.ds.find(x => x.id === cur()); await ensureDs(d); const fs = GJ[d.id].features, sh = fs.filter(f => !dqHide(dqAll()[d.id], f.properties || {})).length; $("#dq_n", b).textContent = (dqAll()[d.id] ? LL("مفعّل: ", "Active: ") : "") + sh + " / " + fs.length + " " + LL("معلم معروض", "displayed"); };
    $("#dq_d", b).onchange = load; $$("#dq_m button", b).forEach(x => x.onclick = () => { q.mode = x.dataset.v; draw(); });
    $("#dq_a", b).onclick = () => { q.rows.push({ f: "name", o: "has", v: "" }); draw(); };
    $("#dq_go", b).onclick = async () => { dqAll()[cur()] = { mode: q.mode, rows: q.rows.filter(r => r.v !== "" || r.o === "em" || r.o === "ne2") }; if (!dqAll()[cur()].rows.length) delete dqAll()[cur()]; dqSave(); restyleAll(); await count(); toast(t("done")); };
    $("#dq_x", b).onclick = async () => { delete dqAll()[cur()]; dqSave(); restyleAll(); load(); toast(t("done")); };
    load();
  });
}

/* ---------- Display XY Data ---------- */
function openDisplayXY() {
  openSheet("xy", LL("عرض بيانات XY من جدول", "Display XY data"), b => {
    b.innerHTML = `<div class="hint">${LL("اختر ملف Excel أو CSV فيه أعمدة إحداثيات ليتحول إلى معالم تُحفظ في «المعالم المعروضة».", "Pick an Excel/CSV file with coordinate columns; it becomes a saved layer.")}</div>
    <input type="file" id="xy_f" accept=".csv,.txt,.tsv,.xlsx,.xlsm" class="in"><div id="xy_p"></div>`;
    $("#xy_f", b).onchange = async e => {
      const f = e.target.files[0]; if (!f) return; const fd = new FormData(); fd.append("file", f);
      try { const r = await api("/api/gis/xy/preview", { method: "POST", body: fd }); show(r, f.name); } catch (er) { fail(er); }
    };
    const show = (r, fname) => {
      const op = (sel, none) => (none ? `<option value="-1">${LL("— لا يوجد —", "— none —")}</option>` : "") + r.header.map((h, i) => `<option value="${i}" ${i === sel ? "selected" : ""}>${esc6(h || "#" + (i + 1))}</option>`).join("");
      $("#xy_p", b).innerHTML = `<div class="sec">${r.total} ${LL("صف", "rows")}</div><div style="overflow:auto;max-height:150px"><table class="tb"><tr>${r.header.map(h => `<th>${esc6(h)}</th>`).join("")}</tr>${r.rows.map(x => `<tr>${x.map(c => `<td>${esc6(c)}</td>`).join("")}</tr>`).join("")}</table></div>
      <div class="two"><div><label class="f">${LL("عمود X / خط الطول", "X / Longitude")}</label><select class="in" id="xy_x">${op(r.guess.x)}</select></div><div><label class="f">${LL("عمود Y / خط العرض", "Y / Latitude")}</label><select class="in" id="xy_y">${op(r.guess.y)}</select></div></div>
      <label class="f">${LL("عمود الاسم", "Name column")}</label><select class="in" id="xy_n">${op(r.guess.name, true)}</select>
      <label class="f">${LL("نظام الإحداثيات", "Coordinate system")}</label><select class="in" id="xy_c">${CRSL.map(([v, l]) => `<option value="${v}">${l}</option>`).join("")}</select>
      <div class="btns"><button class="btn" id="xy_go">${I("check")}${LL("عرض كمعالم", "Display as landmarks")}</button></div>`;
      $("#xy_go", b).onclick = async () => { const x = +$("#xy_x", b).value, y = +$("#xy_y", b).value, comb = r.guess.combined >= 0 && x === y ? r.guess.combined : -1;
        const res = await gisRun("/api/gis/xy/run", { token: r.token, x, y, name: +$("#xy_n", b).value, combined: comb, epsg: $("#xy_c", b).value || 4326, label: fname.replace(/\.[^.]+$/, "") }, j => j.n + " " + LL("معلم", "landmarks") + (j.bad ? " · " + j.bad + " " + LL("صف تُجوهل", "skipped") : "")); if (res) closeSheet(); };
    };
  });
}

/* ---------- أدوات بطبقة واحدة ---------- */
function layerTool(id, title, geoms, hint, build) {
  openSheet(id, title, b => {
    if (!dsOpts(geoms)) return noLayers(b, hint);
    b.innerHTML = `<div class="hint">${hint}</div><label class="f">${LL("الطبقة", "Layer")}</label><select class="in" id="${id}_l">${dsOpts(geoms)}</select><div id="${id}_x"></div><div class="btns"><button class="btn" id="${id}_go">${I("check")}${LL("تنفيذ", "Run")}</button></div>`;
    build && build($("#" + id + "_x", b), b);
    $("#" + id + "_go", b).onclick = () => runTool(id, b);
  });
}
const TOOLRUN = {};
function runTool(id, b) { return TOOLRUN[id](b, $("#" + id + "_l", b).value); }
const openF2P = () => layerTool("f2p", LL("خطوط إلى مضلعات", "Feature to polygon"), [3], LL("يحوّل الخطوط المتقاطعة أو المغلقة إلى مضلعات (تُحذف الأطراف السائبة).", "Turns crossing/closed lines into polygons (dangles are dropped)."));
const openP2L = () => layerTool("p2l", LL("مضلعات إلى خطوط", "Polygon to line"), [5], LL("يحوّل حدود المضلعات (والثقوب) إلى طبقة خطوط.", "Converts polygon boundaries to a line layer."));
TOOLRUN.f2p = (b, l) => gisRun("/api/gis/feature_to_polygon", { layer: l }, r => r.n + " " + LL("مضلع", "polygons"));
TOOLRUN.p2l = (b, l) => gisRun("/api/gis/polygon_to_line", { layer: l }, r => r.n + " " + LL("خط", "lines"));

/* ---------- Construct Points ---------- */
function openConstruct() {
  const drs = (typeof DR !== "undefined" ? DR.items : []).filter(d => d.pts && d.pts.length > 1);
  layerTool("cp", LL("نقاط موزعة بانتظام", "Construct points"), [3, 5], LL("يولّد نقاطاً بانتظام على طول خط أو مسار أو حدود مضلع.", "Generates evenly spaced points along a line, track or polygon boundary."), x => {
    x.innerHTML = `${drs.length ? `<label class="f">${LL("المصدر", "Source")}</label><select class="in" id="cp_s"><option value="">${LL("طبقة", "Layer")}</option>${drs.map(d => `<option value="${d.id}">${esc6(d.name || drKindName(d))} (${LL("رسم", "drawing")})</option>`).join("")}</select>` : ""}
      <div class="seg" id="cp_m" style="margin:10px 0"><button data-v="i" class="on">${LL("كل مسافة", "Every distance")}</button><button data-v="n">${LL("عدد النقاط", "Count")}</button></div>
      <div id="cp_v"><label class="f">${LL("المسافة بين النقاط (م)", "Spacing (m)")}</label><input class="in" id="cp_i" type="number" value="100" min="1"></div>
      <label style="display:flex;gap:10px;align-items:center;margin-top:10px"><input type="checkbox" id="cp_e" checked> ${LL("تضمين البداية والنهاية", "Include ends")}</label>`;
    let mode = "i"; $$("#cp_m button", x).forEach(k => k.onclick = () => { mode = k.dataset.v; $$("#cp_m button", x).forEach(y => y.classList.toggle("on", y === k)); $("#cp_v", x).innerHTML = mode === "i" ? `<label class="f">${LL("المسافة بين النقاط (م)", "Spacing (m)")}</label><input class="in" id="cp_i" type="number" value="100" min="1">` : `<label class="f">${LL("عدد النقاط لكل مسار", "Points per path")}</label><input class="in" id="cp_i" type="number" value="10" min="2">`; x.dataset.mode = mode; });
  });
  TOOLRUN.cp = (b, l) => { const x = $("#cp_x", b), mode = x.dataset.mode || "i", v = +$("#cp_i", b).value, s = $("#cp_s", b) && $("#cp_s", b).value, body = { ends: $("#cp_e", b).checked };
    if (mode === "i") body.interval = v; else body.count = v;
    if (s) { const d = DR.items.find(o => String(o.id) === s); body.coords = d.pts; body.closed = d.kind === "area"; } else body.layer = l;
    return gisRun("/api/gis/construct", body, r => r.n + " " + LL("نقطة", "points")); };
}

/* ---------- Append ---------- */
function openAppend() {
  openSheet("ap", LL("إلحاق معالم (Append)", "Append"), b => {
    if (S.ds.filter(d => d.kind !== "reference").length < 2) return noLayers(b, LL("تحتاج طبقتين", "need two layers"));
    b.innerHTML = `<div class="hint">${LL("ينسخ معالم طبقات مصدر إلى طبقة موجودة (يجب تطابق نوع الهندسة).", "Copies features from source layers into an existing layer (same geometry type).")}</div>
    <label class="f">${LL("الطبقة الهدف", "Target layer")}</label><select class="in" id="ap_t">${dsOpts()}</select><label class="f">${LL("الطبقات المصدر", "Source layers")}</label><div id="ap_s"></div>
    <label style="display:flex;gap:10px;align-items:center;margin:10px 0"><input type="checkbox" id="ap_d" checked> ${LL("تجاهل المكرر (نفس الاسم والموقع)", "Skip duplicates (same name & place)")}</label><div class="btns"><button class="btn" id="ap_go">${I("check")}${LL("إلحاق", "Append")}</button></div>`;
    const fill = () => { const t0 = $("#ap_t", b).value; $("#ap_s", b).innerHTML = S.ds.filter(d => d.kind !== "reference" && d.id !== t0).map(d => `<label class="row" style="gap:10px"><input type="checkbox" data-id="${d.id}"><div class="t"><b>${esc6(d.label)}</b><small>${d.count != null ? d.count : ""}</small></div></label>`).join(""); };
    fill(); $("#ap_t", b).onchange = fill;
    $("#ap_go", b).onclick = async () => { const src = $$("#ap_s input:checked", b).map(x => x.dataset.id); if (!src.length) return toast(t("sel"));
      const r = await gisRun("/api/gis/append", { target: $("#ap_t", b).value, sources: src, skip_dups: $("#ap_d", b).checked }, j => j.added + " " + LL("معلم أُلحق", "appended") + (j.skipped ? " · " + j.skipped + " " + LL("مكرر", "dups") : "") + (j.wrong_geom ? " · " + j.wrong_geom + " " + LL("نوع مختلف", "wrong type") : "")); if (r) closeSheet(); };
  });
}

/* ---------- التحديد المكاني بقضاء ---------- */
function openSpatialFilter() {
  let level = 2, res = null; const hi = (ids) => { const set = new Set(ids), fs = []; S.ds.forEach(d => GJ[d.id] && GJ[d.id].features.forEach(f => { const id = f.id || (f.properties && f.properties.id); if (set.has(id)) fs.push(ft(f.geometry)); })); setSrc("meas", fc(...fs)); };
  startMode({ dk: "sf",
    start(bar) { const draw = () => { bar.innerHTML = barHtml(LL("تحديد مكاني", "Spatial filter"), res ? `<b>${esc6(res.unit)}</b>${res.parent ? " — " + esc6(res.parent) : ""}: <b>${res.n}</b> ${LL("معلم", "landmarks")}<br>${res.per.filter(p => p.n).map(p => esc6(p.label) + " " + p.n).join(" · ")}` : LL("اضغط على قضاء (أو محافظة) في الخريطة لتحديد المعالم داخله", "Tap a district on the map to select the landmarks inside"), [["sf_l", "", level === 2 ? LL("قضاء ✓", "District ✓") : LL("قضاء", "District"), level === 2 ? "btn" : "sec2"], ["sf_g", "", level === 1 ? LL("محافظة ✓", "Governorate ✓") : LL("محافظة", "Governorate"), level === 1 ? "btn" : "sec2"], ...(res && res.n ? [["sf_c", "plus", LL("نسخ لطبقة", "Copy to layer")], ["sf_e", "fetch", LL("تصدير", "Export")]] : []), ["sf_d", "check", t("finish"), "btn"]]);
      $("#sf_l", bar).onclick = () => { level = 2; res = null; setSrc("meas"); draw(); }; $("#sf_g", bar).onclick = () => { level = 1; res = null; setSrc("meas"); draw(); }; $("#sf_d", bar).onclick = () => stopMode();
      const cp = $("#sf_c", bar); if (cp) cp.onclick = async () => { const r = await post("/api/gis/spatial_filter", { ...res.q, copy: true }).catch(fail); if (r) { await refreshDs(dsIds()); toast(t("done")); stopMode(); } };
      const ex = $("#sf_e", bar); if (ex) ex.onclick = () => exportDs({ layers: res.per.filter(p => p.n).map(p => p.layer), ids: res.ids, format: S.set.export_fmt || "xlsx", name: res.unit }, "share"); }; this.draw = draw; draw(); },
    async click(e) { const q = { lat: e.lngLat.lat, lon: e.lngLat.lng, level }; try { res = await post("/api/gis/spatial_filter", q); res.q = q; hi(res.ids); this.draw(); } catch (er) { fail(er); } }
  });
}

/* ---------- طريق عبر الشوارع ---------- */
function openRoadRoute() {
  const st = []; let opt = false, out = null;
  const draw = () => { const f = st.map((p, i) => ft({ type: "Point", coordinates: [p[1], p[0]] }, { n: i + 1 })); if (out) f.push(ft({ type: "LineString", coordinates: out.coords })); else if (st.length > 1) f.push(ft({ type: "LineString", coordinates: st.map(p => [p[1], p[0]]) })); setSrc("meas", fc(...f)); };
  startMode({ dk: "rr",
    start(bar) { const ui = () => { bar.innerHTML = barHtml(LL("طريق عبر الشوارع", "Road route"), out ? `${LL("المسافة", "Distance")}: <b>${out.km.toFixed(2)} km</b> · ${LL("الزمن", "Time")}: <b>${Math.round(out.min)} ${LL("دقيقة", "min")}</b>` : st.length ? st.length + " " + LL("نقاط — اضغط لإضافة محطة", "stops — tap to add") : LL("اضغط على الخريطة: البداية ثم النهاية (ويمكنك محطات وسيطة)", "Tap start, then end (and optional stops)"), [["rr_u", "rot", t("undo")], ["rr_m", "pin", LL("المركز", "Centre")], ...(st.length > 2 ? [["rr_o", "", opt ? LL("ترتيب تلقائي ✓", "Optimise ✓") : LL("ترتيب تلقائي", "Optimise"), opt ? "btn" : "sec2"]] : []), ["rr_c", "x", t("clear")], ["rr_g", "check", LL("ارسم الطريق", "Route"), "btn"]]);
      $("#rr_u", bar).onclick = () => { st.pop(); out = null; draw(); ui(); }; $("#rr_c", bar).onclick = () => { st.length = 0; out = null; draw(); ui(); };
      $("#rr_m", bar).onclick = () => { const c = map.getCenter(); st.push([c.lat, c.lng]); out = null; draw(); ui(); };
      const o = $("#rr_o", bar); if (o) o.onclick = () => { opt = !opt; ui(); };
      $("#rr_g", bar).onclick = async () => { if (st.length < 2) return toast(LL("حدّد نقطتين على الأقل", "Pick at least two points")); toast(t("wait")); try { out = await post("/api/gis/route", { stops: st, optimize: opt, name: LL("طريق", "Route") }); draw(); await refreshDs(dsIds()); ui(); } catch (e) { fail(e); } }; };
      this.ui = ui; ui(); },
    click(e) { st.push([e.lngLat.lat, e.lngLat.lng]); out = null; draw(); this.ui(); }
  });
}

/* ---------- تحليل الشبكة ---------- */
const NA = { task: "closest", origin: null };
function openNetwork() {
  openSheet("net", LL("تحليل شبكة الطرق", "Network analysis"), b => {
    const need = NA.task === "closest" || NA.task === "service";
    b.innerHTML = `<div class="hint">${LL("يعتمد على خادم طرق عبر الإنترنت (OSRM). النتائج تُحفظ كطبقات.", "Uses an online routing server (OSRM). Results are saved as layers.")}</div>
    <div class="seg" id="na_t">${[["closest", LL("أقرب منشأة", "Closest facility")], ["service", LL("منطقة خدمة", "Service area")], ["od", LL("مصفوفة زمن/مسافة", "OD matrix")], ["route", LL("مسار متعدد", "Multi-stop")]].map(([v, l]) => `<button data-v="${v}" class="${NA.task === v ? "on" : ""}">${l}</button>`).join("")}</div>
    <div id="na_b" style="margin-top:12px"></div><div id="na_r"></div>
    <label class="f" style="margin-top:14px">${LL("عنوان خادم الطرق (اختياري)", "Routing server URL (optional)")}</label><input class="in" id="na_u" placeholder="https://router.project-osrm.org" value="${esc6(S.set.routing_url || "")}">`;
    $("#na_u", b).onchange = e => setSet("routing_url", e.target.value.trim());
    $$("#na_t button", b).forEach(x => x.onclick = () => { NA.task = x.dataset.v; if (NA.task === "route") { closeSheet(); return openRoadRoute(); } openNetwork(); });
    const body = $("#na_b", b), orig = () => `<div class="row card" style="margin:8px 0"><div class="t"><b>${LL("نقطة البداية", "Origin")}</b><small>${NA.origin ? NA.origin[0].toFixed(5) + ", " + NA.origin[1].toFixed(5) : LL("لم تُحدَّد", "not set")}</small></div><button class="ib" id="na_p">${I("pin")}</button></div>`;
    const pick = () => { closeSheet(); startMode({ dk: "na", start(bar) { bar.innerHTML = barHtml(LL("نقطة البداية", "Origin"), LL("اضغط على الخريطة", "Tap the map"), [["na_c", "pin", LL("المركز", "Centre")], ["na_x", "x", t("cancel")]]); $("#na_c", bar).onclick = () => { const c = map.getCenter(); NA.origin = [c.lat, c.lng]; stopMode(); openNetwork(); }; $("#na_x", bar).onclick = () => { stopMode(); openNetwork(); }; }, click(e) { NA.origin = [e.lngLat.lat, e.lngLat.lng]; stopMode(); openNetwork(); } }); };
    const multi = (id) => `<div id="${id}">${S.ds.filter(d => d.kind !== "reference").map(d => `<label class="row" style="gap:10px"><input type="checkbox" data-id="${d.id}"><div class="t"><b>${esc6(d.label)}</b><small>${d.count != null ? d.count : ""}</small></div></label>`).join("")}</div>`;
    const sel = id => $$("#" + id + " input:checked", b).map(x => x.dataset.id);
    const R = $("#na_r", b), show = h => R.innerHTML = h;
    if (NA.task === "closest") {
      body.innerHTML = orig() + `<label class="f">${LL("المنشآت (طبقات)", "Facilities (layers)")}</label>${multi("na_l")}<label class="f">${LL("عدد النتائج", "How many")}</label><input class="in" id="na_k" type="number" value="3" min="1" max="10"><div class="btns"><button class="btn" id="na_go">${I("check")}${LL("ابحث", "Find")}</button></div>`;
      $("#na_p", b).onclick = pick;
      $("#na_go", b).onclick = async () => { if (!NA.origin) return toast(LL("حدّد نقطة البداية", "Set the origin")); const l = sel("na_l"); if (!l.length) return toast(t("sel")); toast(t("wait"));
        try { const r = await post("/api/gis/closest", { lat: NA.origin[0], lon: NA.origin[1], layers: l, k: +$("#na_k", b).value }); await refreshDs(dsIds());
          show(`<div class="sec">${LL("الأقرب زمنياً", "Closest by drive time")}</div>` + r.results.map((x, i) => `<button class="row" style="width:100%;border:0;background:none;text-align:start" data-i="${i}"><div class="t"><b>${i + 1}. ${esc6(x.name)}</b><small>${x.min} ${LL("دقيقة", "min")} · ${x.km} km</small></div></button>`).join(""));
          setSrc("meas", fc(ft({ type: "Point", coordinates: [NA.origin[1], NA.origin[0]] }), ...r.results.map(x => ft({ type: "LineString", coordinates: x.coords }))));
          $$("#na_r [data-i]", b).forEach(x => x.onclick = () => { const c = r.results[+x.dataset.i]; closeSheet(); map.fitBounds(c.coords.reduce((bb, p) => bb.extend(p), new maplibregl.LngLatBounds(c.coords[0], c.coords[0])), { padding: 80 }); }); } catch (e) { fail(e); } };
    } else if (NA.task === "service") {
      body.innerHTML = orig() + `<label class="f">${LL("الأزمنة بالدقائق (مفصولة بفواصل)", "Minutes (comma separated)")}</label><input class="in" id="na_m" value="5,10,15"><div class="hint">${LL("تقريبية: تُحسب من عيّنات على اتجاهات حول النقطة.", "Approximate: derived from samples around the origin.")}</div><div class="btns"><button class="btn" id="na_go">${I("check")}${LL("أنشئ", "Create")}</button></div>`;
      $("#na_p", b).onclick = pick;
      $("#na_go", b).onclick = async () => { if (!NA.origin) return toast(LL("حدّد نقطة البداية", "Set the origin")); const m = $("#na_m", b).value.split(/[,،\s]+/).map(Number).filter(x => x > 0); if (!m.length) return;
        const r = await gisRun("/api/gis/service_area", { lat: NA.origin[0], lon: NA.origin[1], minutes: m }, j => j.n + " " + LL("نطاق", "zones")); if (r) closeSheet(); };
    } else {
      body.innerHTML = `<label class="f">${LL("النقاط (طبقة أو أكثر، حتى 60 نقطة)", "Points (layers, up to 60 points)")}</label>${multi("na_l")}<div class="btns"><button class="btn" id="na_go">${I("check")}${LL("احسب", "Compute")}</button></div>`;
      $("#na_go", b).onclick = async () => { const l = sel("na_l"); if (!l.length) return toast(t("sel")); toast(t("wait"));
        try { const r = await post("/api/gis/od", { layers: l }); const tbl = (m, u) => `<div style="overflow:auto"><table class="tb"><tr><th></th>${r.names.map(n => `<th>${esc6(n)}</th>`).join("")}</tr>${m.map((row, i) => `<tr><th>${esc6(r.names[i])}</th>${row.map(v => `<td>${v == null ? "—" : v}</td>`).join("")}</tr>`).join("")}</table></div>`;
          show(`<div class="sec">${LL("الزمن (دقيقة)", "Time (min)")}</div>${tbl(r.minutes)}<div class="sec">${LL("المسافة (كم)", "Distance (km)")}</div>${tbl(r.km)}<div class="btns"><button class="btn sec2" id="na_csv">${I("fetch")}CSV</button></div>`);
          $("#na_csv", b).onclick = () => { const rows = [["from/to", ...r.names].join(","), ...r.minutes.map((x, i) => [r.names[i], ...x.map((v, j) => v + "/" + (r.km[i] ? r.km[i][j] : ""))].join(","))]; saveBlob(new Blob(["﻿" + rows.join("\n")], { type: "text/csv" }), "od-matrix.csv", "share"); }; } catch (e) { fail(e); } };
    }
  });
}

/* ---------- ربط الأدوات بالقائمة ---------- */
const _openTools16 = openTools;
openTools = async function () {
  await _openTools16(); const b = $("#sh-b"); if (SHEET !== "tools" || !b) return; const g = $(".grid", b); if (!g || $("#tl_dq", b)) return;
  [["tl_dq", "filter", "استعلام التعريف", "Definition query", openDefQuery], ["tl_xy", "table", "عرض بيانات XY", "Display XY data", openDisplayXY], ["tl_cp", "pin", "نقاط موزعة", "Construct points", openConstruct],
    ["tl_ap", "plus", "إلحاق معالم", "Append", openAppend], ["tl_f2p", "area", "خطوط إلى مضلعات", "Feature to polygon", openF2P], ["tl_p2l", "line", "مضلعات إلى خطوط", "Polygon to line", openP2L],
    ["tl_sf", "check", "تحديد مكاني بقضاء", "Spatial filter", openSpatialFilter], ["tl_rr", "route", "طريق عبر الشوارع", "Road route", openRoadRoute], ["tl_na", "route", "تحليل الشبكة", "Network analysis", openNetwork]]
    .forEach(([id, ic, ar, en, fn]) => { const x = el(`<button class="tile" id="${id}">${I(ICO(ic))}<span>${LL(ar, en)}</span></button>`, g); x.onclick = fn; });
};
const ICO = k => (typeof ICONS !== "undefined" && ICONS[k]) ? k : "layers";
