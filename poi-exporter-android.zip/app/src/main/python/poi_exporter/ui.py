"""غلاف الصفحة: الواجهة نفسها في static/app/app.{css,js,2.js} وتعتمد على MapLibre GL JS المضمّن محلياً."""
PAGE = r"""<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<title>POI Exporter</title>
<link rel="stylesheet" href="/assets/maplibre/maplibre-gl.css">
<link rel="stylesheet" href="/assets/app/app.css?v=9">
</head><body>
<div id="map"></div><div id="cross"></div>
<div id="top">
  <div class="pill"><svg class="i" viewBox="0 0 24 24"><path d="M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3"/></svg><input id="q" autocomplete="off" enterkeyhint="search"><button class="ib sm" id="qgo" style="background:none"><svg class="i" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button></div>
  <button class="fab" id="menu"><svg class="i" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button>
</div>
<div id="sug"></div>
<div id="side">
  <button class="fab" id="lay"><svg class="i" viewBox="0 0 24 24"><path d="M12 3l9 5-9 5-9-5zM3 13l9 5 9-5"/></svg></button>
  <button class="fab" id="compass"><svg class="i" viewBox="0 0 24 24"><path d="M12 2l4 10H8z" fill="#e03131" stroke="#e03131"/><path d="M12 22l-4-10h8z"/></svg></button>
  <button class="fab" id="locate"><svg class="i" viewBox="0 0 24 24"><path d="M12 8a4 4 0 100 8 4 4 0 000-8zM12 2v3M12 19v3M2 12h3M19 12h3"/></svg></button>
</div>
<div id="lpm"><button id="lp1"><svg class="i" viewBox="0 0 24 24"><path d="M12 8a4 4 0 100 8 4 4 0 000-8z"/></svg><span data-i="loc">My location</span></button><button id="lp2"><svg class="i" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg><span data-i="addhere"></span></button><button id="lp3"><svg class="i" viewBox="0 0 24 24"><path d="M12 3l9 5-9 5-9-5zM3 13l9 5 9-5"/></svg><span data-i="addmany"></span></button></div>
<div id="info"></div>
<div id="cpm"></div>
<div id="banner" style="display:none;position:absolute;z-index:6;inset-inline:10px;top:calc(max(10px,env(safe-area-inset-top)) + 62px);background:var(--sf);border-radius:14px;box-shadow:var(--sh);padding:8px 12px;gap:8px;align-items:center"></div>
<div id="mapbad" style="display:none;position:absolute;z-index:6;inset-inline:10px;top:50%;background:var(--sf);border-radius:14px;box-shadow:var(--sh);padding:12px;gap:10px;align-items:center"><span style="flex:1"></span><button class="btn">↻</button></div>
<div id="dock"></div>
<div id="scrim"></div>
<aside id="drawer"><div id="dh"><h1></h1><button class="ib" id="dh-x"><svg class="i" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>
  <div id="dbody"><div class="grid" id="dgrid"></div><div class="sec" id="sec-shown"></div><div class="card" id="shown"></div></div></aside>
<section id="sheet"><div id="sh-h"><h2 id="sh-t"></h2><button class="ib" id="sh-x"><svg class="i" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div><div id="sh-b"></div></section>
<div class="splash" id="splash"><div style="width:42px;height:42px;border:5px solid var(--br);border-top-color:var(--pr);border-radius:50%;animation:s .9s linear infinite"></div></div>
<style>@keyframes s{to{transform:rotate(360deg)}}</style>
<script>window.BOOT={{ boot|tojson }};</script>
<script src="/assets/maplibre/maplibre-gl.js"></script>
<script src="/assets/app/app.js?v=10"></script>
<script src="/assets/app/app2.js?v=6"></script>
<script src="/assets/app/app3.js?v=1"></script>
</body></html>"""
