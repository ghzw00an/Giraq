plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.poiexporter.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.poiexporter.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 11
        versionName = "3.16"
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

chaquopy {
    defaultConfig {
        version = "3.11"
        pip {
            install("numpy")
            install("Pillow")
            install("openpyxl")
            install("reportlab")
            install("flask")
            // install("scipy")   // اختياري: يكبّر الحجم كثيراً وقد لا يتوفر لكل المعماريات
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
