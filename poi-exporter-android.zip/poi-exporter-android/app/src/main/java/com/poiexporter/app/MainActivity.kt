package com.poiexporter.app

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.Manifest
import android.content.pm.PackageManager
import android.webkit.GeolocationPermissions
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private val port = 8000

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!Python.isStarted()) Python.start(AndroidPlatform(this))

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onGeolocationPermissionsShowPrompt(origin: String, cb: GeolocationPermissions.Callback) {
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this@MainActivity,
                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
                    }
                    cb.invoke(origin, true, false)
                }
            }
            addJavascriptInterface(Bridge(), "Android")
            setDownloadListener { url, _, disposition, mime, _ ->
                saveDownload(url, disposition, mime)
            }
        }
        setContentView(web)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        // تشغيل الخادم خارج الخيط الرئيسي ثم فتح الصفحة
        thread {
            try {
                Python.getInstance().getModule("server").callAttr("start", filesDir.absolutePath, port)
                waitForServer()
                runOnUiThread { web.loadUrl("http://127.0.0.1:$port/") }
            } catch (e: Exception) {
                runOnUiThread {
                    web.loadData("<h3 dir='rtl'>تعذّر تشغيل الخادم:<br>${e.message}</h3>", "text/html; charset=utf-8", null)
                }
            }
        }
    }

    private fun waitForServer() {
        repeat(50) {
            try {
                val c = URL("http://127.0.0.1:$port/").openConnection() as HttpURLConnection
                c.connectTimeout = 300
                if (c.responseCode in 200..399) return
            } catch (_: Exception) {
                Thread.sleep(200)
            }
        }
    }

    /** يحفظ الملف الناتج (shp/xlsx/pdf…) في مجلد التنزيلات. */
    private fun saveDownload(url: String, disposition: String?, mime: String?) {
        thread {
            try {
                val name = Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?")
                    .find(disposition ?: "")?.groupValues?.get(1)
                    ?: Uri.parse(url).lastPathSegment ?: "poi_export"
                val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!
                val out = File(dir, Uri.decode(name))
                (URL(url).openConnection() as HttpURLConnection).inputStream.use { i ->
                    out.outputStream().use { o -> i.copyTo(o) }
                }
                runOnUiThread {
                    Toast.makeText(this, "حُفظ: ${out.absolutePath}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "فشل الحفظ: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    /** يحفظ الملف في Download/POIExporter ليظهر في مدير الملفات. */
    private fun saveBytes(name: String, data: ByteArray) {
        try {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "POIExporter")
            val target = try { dir.mkdirs(); File(dir, name).also { it.writeBytes(data) } }
            catch (_: Exception) { File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name).also { it.writeBytes(data) } }
            runOnUiThread { Toast.makeText(this, "حُفظ: ${target.absolutePath}", Toast.LENGTH_LONG).show() }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "فشل الحفظ: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun save(name: String, b64: String) = saveBytes(name, Base64.decode(b64, Base64.DEFAULT))
    }
}
