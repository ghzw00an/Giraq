package com.poiexporter.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Base64
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private val port = 8000
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private val splash = """
        <html><body style="margin:0;display:flex;align-items:center;justify-content:center;height:100vh;
        background:#12181f;color:#eaf0f6;font-family:sans-serif;flex-direction:column">
        <div style="width:46px;height:46px;border:5px solid #2a3643;border-top-color:#1e88ff;border-radius:50%;
        animation:s 0.9s linear infinite"></div><p dir="rtl">جارٍ التشغيل…</p>
        <style>@keyframes s{to{transform:rotate(360deg)}}</style></body></html>
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)   // المحتوى بين شريطي الحالة والتنقل فلا تخرج الأزرار عن الشاشة

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                    fileCb?.onReceiveValue(null)
                    fileCb = cb
                    val i = Intent(Intent.ACTION_GET_CONTENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent.createChooser(i, null), 77)
                    return true
                }

                override fun onGeolocationPermissionsShowPrompt(origin: String, cb: GeolocationPermissions.Callback) {
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this@MainActivity,
                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
                    }
                    cb.invoke(origin, true, false)
                }
            }
            addJavascriptInterface(Bridge(), "Android")
            setDownloadListener { url, _, disposition, _, _ -> saveDownload(url, disposition) }
        }
        setContentView(web)
        web.loadData(splash, "text/html; charset=utf-8", null)   // شاشة فورية أثناء تشغيل بايثون

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // الرجوع يُعالَج داخل الصفحة (إغلاق النافذة/القائمة)؛ وإلا نخرج. لا نستعمل goBack لأنه يعيد شاشة التحميل البيضاء.
                web.evaluateJavascript("(function(){return window.__back?window.__back():false})()") { r ->
                    if (r != "true") finish()
                }
            }
        })

        // بايثون والخادم في خيط خلفي كي لا تتجمد الواجهة
        thread {
            try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                Python.getInstance().getModule("server").callAttr("start", filesDir.absolutePath, port)
                waitForServer()
                runOnUiThread { web.loadUrl("http://127.0.0.1:$port/") }
            } catch (e: Exception) {
                runOnUiThread {
                    web.loadData("<h3 dir='rtl'>تعذّر تشغيل الخادم:<br>${e.message}</h3>", "text/html; charset=utf-8", null)
                }
            }
        }
    }

    private fun waitForServer() {
        repeat(300) {
            try {
                val c = URL("http://127.0.0.1:$port/api/sectors").openConnection() as HttpURLConnection
                c.connectTimeout = 200
                if (c.responseCode in 200..399) return
            } catch (_: Exception) {
                Thread.sleep(80)
            }
        }
    }

    private fun mimeOf(f: File): String = when (f.extension.lowercase()) {
        "pdf" -> "application/pdf"
        "png" -> "image/png"
        "kml" -> "application/vnd.google-earth.kml+xml"
        "kmz" -> "application/vnd.google-earth.kmz"
        "zip" -> "application/zip"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "csv" -> "text/csv"
        "geojson", "json" -> "application/geo+json"
        "gpx" -> "application/gpx+xml"
        else -> "*/*"
    }

    private fun uriFor(path: String): Uri =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", File(path))

    /** يحفظ الملف في Download/<المجلد> ليظهر في مدير الملفات، ويرجع المسار. */
    private fun saveBytes(name: String, data: ByteArray, folder: String = "POIExporter"): String {
        return try {
            val clean = folder.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "POIExporter" }
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), clean)
            val target = try { dir.mkdirs(); File(dir, name).also { it.writeBytes(data) } }
            catch (_: Exception) {
                val d2 = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), clean).also { it.mkdirs() }
                File(d2, name).also { it.writeBytes(data) }
            }
            target.absolutePath
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "فشل الحفظ: ${e.message}", Toast.LENGTH_LONG).show() }
            ""
        }
    }

    private fun saveDownload(url: String, disposition: String?) {
        thread {
            try {
                val name = Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?").find(disposition ?: "")?.groupValues?.get(1)
                    ?: Uri.parse(url).lastPathSegment ?: "poi_export"
                val bytes = (URL(url).openConnection() as HttpURLConnection).inputStream.use { it.readBytes() }
                val p = saveBytes(Uri.decode(name), bytes)
                runOnUiThread { Toast.makeText(this, "حُفظ: $p", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "فشل الحفظ: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77) {
            val r = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data!!.data!!) else null
            fileCb?.onReceiveValue(r); fileCb = null
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun save(name: String, b64: String, folder: String): String =
            saveBytes(name, Base64.decode(b64, Base64.DEFAULT), folder)

        @JavascriptInterface
        fun open(path: String) {
            try {
                val f = File(path)
                startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uriFor(path), mimeOf(f)); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, null))
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "تعذّر الفتح: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface
        fun share(path: String) {
            try {
                val f = File(path)
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = mimeOf(f); putExtra(Intent.EXTRA_STREAM, uriFor(path)); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, null))
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "تعذّرت المشاركة: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }
}
