"""محرك إسقاط صغير بلا اعتماديات: يقرأ تعريفات PROJ4 لـ EPSG (≈5700 نظام) ويدعم longlat وutm/tmerc وmerc وlcc وaea مع
إزاحة المرجعية (towgs84 بـ Helmert) والوحدات. الأنواع الأخرى (stere, omerc …) تحتاج pyproj."""
from __future__ import annotations

import math
import os
import re
from dataclasses import dataclass
from functools import lru_cache
from typing import Callable, Dict, Optional, Tuple

DATA = os.path.join(os.path.dirname(__file__), "data", "epsg_proj4.txt")

ELLPS = {  # a, 1/f (0 كرة)
    "WGS84": (6378137.0, 298.257223563), "GRS80": (6378137.0, 298.257222101), "WGS72": (6378135.0, 298.26),
    "krass": (6378245.0, 298.3), "intl": (6378388.0, 297.0), "bessel": (6377397.155, 299.1528128),
    "bess_nam": (6377483.865, 299.1528128), "clrk80": (6378249.145, 293.4663), "clrk66": (6378206.4, 294.9786982),
    "aust_SA": (6378160.0, 298.25), "GRS67": (6378160.0, 298.247167427), "evrstSS": (6377298.556, 300.8017),
    "airy": (6377563.396, 299.3249646), "mod_airy": (6377340.189, 299.3249646), "WGS66": (6378145.0, 298.25),
    "helmert": (6378200.0, 298.3), "sphere": (6370997.0, 0.0),
}
DATUMS = {  # ellps, towgs84
    "WGS84": ("WGS84", (0, 0, 0, 0, 0, 0, 0)), "NAD83": ("GRS80", (0, 0, 0, 0, 0, 0, 0)),
    "NAD27": ("clrk66", None), "nzgd49": ("intl", (59.47, -5.04, 187.44, 0.47, -0.1, 1.024, -4.5993)),
    "hermannskogel": ("bessel", (577.326, 90.129, 463.919, 5.137, 1.474, 5.297, 2.4232)),
    "potsdam": ("bessel", (598.1, 73.7, 418.2, 0.202, 0.045, -2.455, 6.7)),
    "carthage": ("clrk80", (-263.0, 6.0, 431.0, 0, 0, 0, 0)), "OSGB36": ("airy", (446.448, -125.157, 542.06, 0.15, 0.247, 0.842, -20.489)),
    "ire65": ("mod_airy", (482.5, -130.6, 564.6, -1.042, -0.214, -0.631, 8.15)), "GGRS87": ("GRS80", (-199.87, 74.79, 246.62, 0, 0, 0, 0)),
}
UNITS = {"m": 1.0, "us-ft": 1200 / 3937, "ft": 0.3048, "link": 0.201168}
PRIME = {"paris": 2.337229166667, "ferro": -17.666666667, "jakarta": 106.807719444, "oslo": 10.722916667, "lisbon": -9.131906111,
         "rome": 12.452333333, "bern": 7.439583333, "brussels": 4.367975, "madrid": -3.687938889, "bogota": -74.080916667,
         "stockholm": 18.058277778, "athens": 23.7163375}


@dataclass
class Def:
    code: int
    name: str
    proj: str
    p: Dict[str, str]
    a: float
    f: float
    shift: Optional[Tuple[float, ...]]
    unit: float
    pm: float

    @property
    def geographic(self) -> bool:
        return self.proj == "longlat"

    @property
    def e2(self) -> float:
        return self.f * (2 - self.f)


def _ellipsoid(p: Dict[str, str]) -> Tuple[float, float, Optional[str]]:
    if "ellps" in p:
        a, rf = ELLPS[p["ellps"]]
        return a, (1 / rf if rf else 0.0), None
    if "datum" in p and p["datum"] in DATUMS:
        el, _ = DATUMS[p["datum"]]
        a, rf = ELLPS[el]
        return a, (1 / rf if rf else 0.0), None
    if "a" in p:
        a = float(p["a"])
        if "b" in p:
            b = float(p["b"])
            return a, (a - b) / a, None
        if "rf" in p:
            return a, 1 / float(p["rf"]), None
        return a, 0.0, None
    return 6378137.0, 1 / 298.257223563, None


@lru_cache(maxsize=1)
def _table() -> Dict[int, Tuple[str, str]]:
    out: Dict[int, Tuple[str, str]] = {}
    try:
        import pkgutil
        raw = pkgutil.get_data(__package__ or "poi_exporter", "data/epsg_proj4.txt")
    except (OSError, ValueError):
        raw = None
    if raw is None:
        if not os.path.exists(DATA):
            return out
        raw = open(DATA, "rb").read()
    name = ""
    for line in raw.decode("latin-1").splitlines():
        line = line.strip()
        if line.startswith("#"):
            name = line[1:].strip()
        else:
            m = re.match(r"<(\d+)>\s*(.*?)\s*<>", line)
            if m:
                out[int(m.group(1))] = (name, m.group(2))
    return out


def parse(code: int) -> Def:
    t = _table()
    if code not in t:
        raise ValueError(f"EPSG:{code} غير موجود في الفهرس")
    name, s = t[code]
    p: Dict[str, str] = {}
    for tok in s.split():
        if tok.startswith("+"):
            k, _, v = tok[1:].partition("=")
            p[k] = v
    proj = p.get("proj", "")
    a, f, _ = _ellipsoid(p)
    shift = None
    if "towgs84" in p:
        v = [float(x) for x in p["towgs84"].split(",")]
        shift = tuple(v + [0.0] * (7 - len(v)))
    elif "datum" in p and p["datum"] in DATUMS:
        shift = DATUMS[p["datum"]][1]
    unit = UNITS.get(p.get("units", "m"), 1.0) if "to_meter" not in p else float(p["to_meter"])
    pm = PRIME.get(p.get("pm", ""), 0.0) if not re.match(r"^-?[\d.]+$", p.get("pm", "")) else float(p["pm"])
    return Def(code, name, proj, p, a, f, shift, unit, pm)


def supported(code: int) -> bool:
    try:
        d = parse(code)
    except (ValueError, KeyError):
        return False
    return d.proj in ("longlat", "utm", "tmerc", "merc", "lcc", "aea")


# ---------------------------------------------------------------------------- Helmert (geocentric)
def _to_ecef(lat, lon, h, a, e2):
    sl, cl = math.sin(lat), math.cos(lat)
    n = a / math.sqrt(1 - e2 * sl * sl)
    return (n + h) * cl * math.cos(lon), (n + h) * cl * math.sin(lon), (n * (1 - e2) + h) * sl


def _from_ecef(x, y, z, a, e2):
    lon = math.atan2(y, x)
    p = math.hypot(x, y)
    lat = math.atan2(z, p * (1 - e2))
    for _ in range(8):
        n = a / math.sqrt(1 - e2 * math.sin(lat) ** 2)
        lat = math.atan2(z + e2 * n * math.sin(lat), p)
    n = a / math.sqrt(1 - e2 * math.sin(lat) ** 2)
    h = p / math.cos(lat) - n if abs(lat) < 1.5 else z / math.sin(lat) - n * (1 - e2)
    return lat, lon, h


def _helmert(x, y, z, s, inverse=False):
    dx, dy, dz, rx, ry, rz, ds = s
    rx, ry, rz = (math.radians(v / 3600) for v in (rx, ry, rz))
    k = 1 + ds * 1e-6
    if not inverse:
        return (dx + k * (x - rz * y + ry * z), dy + k * (rz * x + y - rx * z), dz + k * (-ry * x + rx * y + z))
    x, y, z = x - dx, y - dy, z - dz
    return ((x + rz * y - ry * z) / k, (-rz * x + y + rx * z) / k, (ry * x - rx * y + z) / k)


WGS = (6378137.0, 1 / 298.257223563)


def _is_zero(s):
    return s is None or all(abs(v) < 1e-12 for v in s)


# ---------------------------------------------------------------------------- Transverse Mercator (Krüger / Karney)
class _TM:
    def __init__(self, a, f, k0, lon0, lat0, x0, y0):
        n = f / (2 - f)
        n2, n3, n4 = n * n, n ** 3, n ** 4
        self.e = math.sqrt(f * (2 - f))
        self.A = a / (1 + n) * (1 + n2 / 4 + n4 / 64)
        self.al = [n / 2 - 2 * n2 / 3 + 5 * n3 / 16 + 41 * n4 / 180, 13 * n2 / 48 - 3 * n3 / 5 + 557 * n4 / 1440,
                   61 * n3 / 240 - 103 * n4 / 140, 49561 * n4 / 161280]
        self.be = [n / 2 - 2 * n2 / 3 + 37 * n3 / 96 - n4 / 360, n2 / 48 + n3 / 15 - 437 * n4 / 1440,
                   17 * n3 / 480 - 37 * n4 / 840, 4397 * n4 / 161280]
        self.de = [2 * n - 2 * n2 / 3 - 2 * n3 + 116 * n4 / 45, 7 * n2 / 3 - 8 * n3 / 5 - 227 * n4 / 45,
                   56 * n3 / 15 - 136 * n4 / 35, 4279 * n4 / 630]
        self.k0, self.lon0, self.x0, self.y0 = k0, math.radians(lon0), x0, y0
        self.xi0 = self._xi(math.radians(lat0))

    def _xi(self, lat):
        e = self.e
        sp = math.sin(lat)
        t = math.sinh(math.atanh(sp) - e * math.atanh(e * sp))
        xp = math.atan2(t, 1.0)
        xi = xp
        for j in range(1, 5):
            xi += self.al[j - 1] * math.sin(2 * j * xp)
        return xi

    def fwd(self, lon, lat):
        e = self.e
        lam = lon - self.lon0
        sp = math.sin(lat)
        t = math.sinh(math.atanh(sp) - e * math.atanh(e * sp))
        xp = math.atan2(t, math.cos(lam))
        ep = math.atanh(math.sin(lam) / math.sqrt(1 + t * t))
        xi, eta = xp, ep
        for j in range(1, 5):
            xi += self.al[j - 1] * math.sin(2 * j * xp) * math.cosh(2 * j * ep)
            eta += self.al[j - 1] * math.cos(2 * j * xp) * math.sinh(2 * j * ep)
        return self.x0 + self.k0 * self.A * eta, self.y0 + self.k0 * self.A * (xi - self.xi0)

    def inv(self, x, y):
        xi = (y - self.y0) / (self.k0 * self.A) + self.xi0
        eta = (x - self.x0) / (self.k0 * self.A)
        xp, ep = xi, eta
        for j in range(1, 5):
            xp -= self.be[j - 1] * math.sin(2 * j * xi) * math.cosh(2 * j * eta)
            ep -= self.be[j - 1] * math.cos(2 * j * xi) * math.sinh(2 * j * eta)
        chi = math.asin(math.sin(xp) / math.cosh(ep))
        lat = chi
        for j in range(1, 5):
            lat += self.de[j - 1] * math.sin(2 * j * chi)
        return self.lon0 + math.atan2(math.sinh(ep), math.cos(xp)), lat


class _Merc:
    def __init__(self, a, f, k0, lon0, x0, y0, lat_ts=None):
        self.e = math.sqrt(f * (2 - f))
        self.a, self.lon0, self.x0, self.y0 = a, math.radians(lon0), x0, y0
        if lat_ts is not None:
            ph = math.radians(lat_ts)
            k0 = math.cos(ph) / math.sqrt(1 - self.e ** 2 * math.sin(ph) ** 2)
        self.k0 = k0

    def fwd(self, lon, lat):
        e, s = self.e, math.sin(lat)
        y = self.a * self.k0 * (math.atanh(s) - e * math.atanh(e * s))
        return self.x0 + self.a * self.k0 * (lon - self.lon0), self.y0 + y

    def inv(self, x, y):
        e = self.e
        lon = (x - self.x0) / (self.a * self.k0) + self.lon0
        psi = (y - self.y0) / (self.a * self.k0)
        lat = 2 * math.atan(math.exp(psi)) - math.pi / 2
        for _ in range(10):
            s = math.sin(lat)
            lat = 2 * math.atan(math.exp(psi + e * math.atanh(e * s))) - math.pi / 2
        return lon, lat


class _LCC:
    def __init__(self, a, f, lat1, lat2, lat0, lon0, k0, x0, y0):
        self.e = e = math.sqrt(f * (2 - f))
        self.a, self.lon0, self.x0, self.y0 = a, math.radians(lon0), x0, y0
        p1, p2, p0 = (math.radians(v) for v in (lat1, lat2, lat0))
        m = lambda p: math.cos(p) / math.sqrt(1 - e * e * math.sin(p) ** 2)
        t = lambda p: math.tan(math.pi / 4 - p / 2) / ((1 - e * math.sin(p)) / (1 + e * math.sin(p))) ** (e / 2)
        self.n = (math.log(m(p1)) - math.log(m(p2))) / (math.log(t(p1)) - math.log(t(p2))) if abs(p1 - p2) > 1e-10 else math.sin(p1)
        self.F = m(p1) / (self.n * t(p1) ** self.n)
        self.t = t
        self.rho0 = a * k0 * self.F * t(p0) ** self.n

    def fwd(self, lon, lat):
        rho = self.a * self.k0v * self.F * self.t(lat) ** self.n
        th = self.n * (lon - self.lon0)
        return self.x0 + rho * math.sin(th), self.y0 + self.rho0 - rho * math.cos(th)

    k0v = 1.0

    def inv(self, x, y):
        dx, dy = x - self.x0, self.rho0 - (y - self.y0)
        if self.n < 0:
            dx, dy = -dx, -dy
        rho = math.hypot(dx, dy)
        th = math.atan2(dx, dy)
        tt = (rho / (self.a * self.k0v * self.F)) ** (1 / self.n)
        lat = math.pi / 2 - 2 * math.atan(tt)
        for _ in range(10):
            s = self.e * math.sin(lat)
            lat = math.pi / 2 - 2 * math.atan(tt * ((1 - s) / (1 + s)) ** (self.e / 2))
        return th / self.n + self.lon0, lat


class _AEA:
    def __init__(self, a, f, lat1, lat2, lat0, lon0, x0, y0):
        self.e = e = math.sqrt(f * (2 - f))
        self.a, self.lon0, self.x0, self.y0 = a, math.radians(lon0), x0, y0
        p1, p2, p0 = (math.radians(v) for v in (lat1, lat2, lat0))
        m = lambda p: math.cos(p) / math.sqrt(1 - e * e * math.sin(p) ** 2)
        self.q = lambda p: (1 - e * e) * (math.sin(p) / (1 - e * e * math.sin(p) ** 2) - (1 / (2 * e)) * math.log((1 - e * math.sin(p)) / (1 + e * math.sin(p))))
        self.n = (m(p1) ** 2 - m(p2) ** 2) / (self.q(p2) - self.q(p1)) if abs(p1 - p2) > 1e-10 else math.sin(p1)
        self.C = m(p1) ** 2 + self.n * self.q(p1)
        self.rho0 = a * math.sqrt(self.C - self.n * self.q(p0)) / self.n
        self.qp = self.q(math.pi / 2)

    def fwd(self, lon, lat):
        rho = self.a * math.sqrt(self.C - self.n * self.q(lat)) / self.n
        th = self.n * (lon - self.lon0)
        return self.x0 + rho * math.sin(th), self.y0 + self.rho0 - rho * math.cos(th)

    def inv(self, x, y):
        dx, dy = x - self.x0, self.rho0 - (y - self.y0)
        rho = math.hypot(dx, dy)
        th = math.atan2(dx, dy)
        q = (self.C - (rho * self.n / self.a) ** 2) / self.n
        lat = math.asin(max(-1, min(1, q / 2)))
        for _ in range(12):
            s = math.sin(lat)
            e2 = self.e ** 2
            lat += (1 - e2 * s * s) ** 2 / (2 * math.cos(lat)) * (q / (1 - e2) - s / (1 - e2 * s * s) + (1 / (2 * self.e)) * math.log((1 - self.e * s) / (1 + self.e * s)))
        return th / self.n + self.lon0, lat


def _engine(d: Def):
    p = d.p
    g = lambda k, dflt=0.0: float(p.get(k, dflt))
    if d.proj == "utm":
        zone = int(p["zone"])
        y0 = 10000000.0 if "south" in p else 0.0
        return _TM(d.a, d.f, 0.9996, (zone - 1) * 6 - 180 + 3, 0.0, 500000.0, y0)
    if d.proj == "tmerc":
        return _TM(d.a, d.f, g("k_0", g("k", 1.0)), g("lon_0"), g("lat_0"), g("x_0"), g("y_0"))
    if d.proj == "merc":
        return _Merc(d.a, d.f, g("k_0", 1.0), g("lon_0"), g("x_0"), g("y_0"), float(p["lat_ts"]) if "lat_ts" in p else None)
    if d.proj == "lcc":
        l1 = g("lat_1", g("lat_0"))
        e = _LCC(d.a, d.f, l1, g("lat_2", l1), g("lat_0"), g("lon_0"), 1.0, g("x_0"), g("y_0"))
        e.k0v = g("k_0", 1.0)
        e.rho0 = d.a * e.k0v * e.F * e.t(math.radians(g("lat_0"))) ** e.n
        return e
    if d.proj == "aea":
        return _AEA(d.a, d.f, g("lat_1"), g("lat_2", g("lat_1")), g("lat_0"), g("lon_0"), g("x_0"), g("y_0"))
    raise ValueError(f"الإسقاط {d.proj} غير مدعوم دون pyproj")


def to_wgs84_fn(code: int) -> Callable[[float, float], Tuple[float, float]]:
    """(x, y) بوحدة النظام → (lon, lat) WGS84."""
    d = parse(code)
    eng = None if d.geographic else _engine(d)
    e2 = d.e2

    def f(x, y):
        if d.geographic:
            lon, lat = math.radians(x) + math.radians(d.pm), math.radians(y)
        else:
            lon, lat = eng.inv(x * d.unit, y * d.unit)
        lon = (lon + math.pi) % (2 * math.pi) - math.pi
        if not _is_zero(d.shift):
            X, Y, Z = _helmert(*_to_ecef(lat, lon, 0.0, d.a, e2), d.shift)
            lat, lon, _ = _from_ecef(X, Y, Z, WGS[0], 2 * WGS[1] - WGS[1] ** 2)
        return math.degrees(lon), math.degrees(lat)
    return f


def from_wgs84_fn(code: int) -> Callable[[float, float], Tuple[float, float]]:
    d = parse(code)
    eng = None if d.geographic else _engine(d)
    e2 = d.e2

    def f(lon, lat):
        lo, la = math.radians(lon), math.radians(lat)
        if not d.geographic and hasattr(eng, "lon0"):      # لفّ الفرق عن خط الطول المركزي إلى ±180
            lo = eng.lon0 + (lo - eng.lon0 + math.pi) % (2 * math.pi) - math.pi
        if not _is_zero(d.shift):
            X, Y, Z = _helmert(*_to_ecef(la, lo, 0.0, WGS[0], 2 * WGS[1] - WGS[1] ** 2), d.shift, inverse=True)
            la, lo, _ = _from_ecef(X, Y, Z, d.a, e2)
        if d.geographic:
            return math.degrees(lo - math.radians(d.pm)), math.degrees(la)
        x, y = eng.fwd(lo, la)
        return x / d.unit, y / d.unit
    return f


def approximate_shift(code_a: int, code_b: int) -> bool:
    """هل التحويل بين نظامين يمر بإزاحة مرجعية تقريبية (Helmert)؟"""
    def key(c):
        try:
            s = parse(c).shift
        except ValueError:
            return None
        return None if _is_zero(s) else s
    return key(code_a) != key(code_b)


def search(text: str, limit: int = 30):
    """بحث في فهرس EPSG بالرمز أو الاسم؛ يرجع [(code, name)] للأنواع المدعومة فقط."""
    t = text.strip().lower().replace("epsg:", "")
    out = []
    for code, (name, _) in _table().items():
        if (t.isdigit() and str(code).startswith(t)) or (not t.isdigit() and t in name.lower()):
            if supported(code):
                out.append((code, name))
                if len(out) >= limit:
                    break
    return out


def wkt(code: int) -> str:
    """WKT1 (نمط ESRI) مبني من تعريف PROJ4 لملف .prj."""
    d = parse(code)
    rf = 1 / d.f if d.f else 0.0
    geog = ('GEOGCS["GCS_%s",DATUM["D_%s",SPHEROID["Spheroid_%d",%r,%r]%s],PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]'
            % (re.sub(r"\W+", "_", d.name.split(" / ")[0]), re.sub(r"\W+", "_", d.name.split(" / ")[0]), code, d.a, rf,
               (',TOWGS84[' + ",".join(repr(v) for v in d.shift) + ']') if not _is_zero(d.shift) else ""))
    if d.geographic:
        return geog
    g = lambda k, dflt=0.0: float(d.p.get(k, dflt))
    pr = d.proj
    if pr == "utm":
        zone = int(d.p["zone"])
        name, params = "Transverse_Mercator", [("False_Easting", 500000.0), ("False_Northing", 10000000.0 if "south" in d.p else 0.0),
                                                ("Central_Meridian", (zone - 1) * 6 - 177.0), ("Scale_Factor", 0.9996), ("Latitude_Of_Origin", 0.0)]
    elif pr == "tmerc":
        name, params = "Transverse_Mercator", [("False_Easting", g("x_0")), ("False_Northing", g("y_0")), ("Central_Meridian", g("lon_0")),
                                                ("Scale_Factor", g("k_0", g("k", 1.0))), ("Latitude_Of_Origin", g("lat_0"))]
    elif pr == "merc":
        name, params = "Mercator", [("False_Easting", g("x_0")), ("False_Northing", g("y_0")), ("Central_Meridian", g("lon_0")),
                                    ("Standard_Parallel_1", g("lat_ts"))]
    elif pr == "lcc":
        name, params = "Lambert_Conformal_Conic", [("False_Easting", g("x_0")), ("False_Northing", g("y_0")), ("Central_Meridian", g("lon_0")),
                                                   ("Standard_Parallel_1", g("lat_1", g("lat_0"))), ("Standard_Parallel_2", g("lat_2", g("lat_1", g("lat_0")))),
                                                   ("Scale_Factor", g("k_0", 1.0)), ("Latitude_Of_Origin", g("lat_0"))]
    elif pr == "aea":
        name, params = "Albers", [("False_Easting", g("x_0")), ("False_Northing", g("y_0")), ("Central_Meridian", g("lon_0")),
                                  ("Standard_Parallel_1", g("lat_1")), ("Standard_Parallel_2", g("lat_2", g("lat_1"))), ("Latitude_Of_Origin", g("lat_0"))]
    else:
        raise ValueError(f"لا يمكن بناء WKT للإسقاط {pr}")
    return ('PROJCS["%s",%s,PROJECTION["%s"],%s,UNIT["%s",%r]]' % (
        re.sub(r"[^A-Za-z0-9_]+", "_", d.name), geog, name, ",".join('PARAMETER["%s",%r]' % kv for kv in params),
        "Meter" if d.unit == 1.0 else "Foot", d.unit))


@lru_cache(maxsize=1)
def _names() -> Dict[str, int]:
    out: Dict[str, int] = {}
    for code, (name, _) in sorted(_table().items(), reverse=True):   # الرمز الأصغر يفوز
        out[re.sub(r"[^a-z0-9]", "", name.lower().replace("deprecated", ""))] = code
    return out


def by_name(name: str) -> Optional[int]:
    """رمز EPSG من اسم النظام (كما في ملف .prj): تطابق بعد حذف الرموز وكلمة deprecated."""
    return _names().get(re.sub(r"[^a-z0-9]", "", (name or "").lower().replace("deprecated", "")))
