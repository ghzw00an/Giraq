"""جدول خصائص المعلم الثابت: name, type, Gategory, gathaa, Nahia, mohafadha, x, y, link"""
from __future__ import annotations

import math
from typing import Callable, Optional, Tuple

from .coords import utm_from_latlon
from .model import Feature

NAMES = ["name", "type", "Gategory", "gathaa", "Nahia", "mohafadha", "x", "y", "link"]
N_TEXT = 6


def is_std(key: str) -> bool:
    return any(s.lower() == key.lower() for s in NAMES)


def text(f: Feature):
    """الحقول النصية الستة بترتيب الجدول."""
    return [f.name or "", f.type or "", f.category or "", f.qadaa or "", f.nahiya or "", f.governorate or ""]


def link(f: Feature) -> str:
    return f.attrs.get("link", "")


def set_link(f: Feature, v: str) -> None:
    if not v:
        f.attrs.pop("link", None)
    else:
        f.attrs["link"] = v


def xy(f: Feature, tx: Optional[Callable[[float, float], Tuple[float, float]]] = None) -> Tuple[float, float]:
    """x,y للنقطة التمثيلية: UTM تلقائياً إذا tx=None، وإلا بنظام الدالة. NaN إن تعذّر."""
    try:
        if tx is None:
            u = utm_from_latlon(f.lat, f.lon)
            return u.easting, u.northing
        return tx(f.lon, f.lat)
    except Exception:  # noqa: BLE001
        return float("nan"), float("nan")


def num(v: float, dec: int) -> str:
    return "" if math.isnan(v) else "%.*f" % (dec, v)


def index(key: str) -> Optional[int]:
    for i, n in enumerate(NAMES):
        if n.lower() == key.lower():
            return i
    return None
