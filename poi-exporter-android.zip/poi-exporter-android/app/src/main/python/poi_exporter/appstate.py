"""إعدادات التطبيق (Prefs) وسجل الأخطاء (في الذاكرة فقط) والنسخ الاحتياطي اليومي التلقائي."""
from __future__ import annotations

import json
import os
import threading
import time
import traceback
from typing import Dict, List, Optional

KEEP_BACKUPS = 14
BACKUP_INTERVAL_S = 20 * 3600


class Prefs:
    def __init__(self, path: Optional[str] = None):
        self.path = path
        self.data: Dict[str, str] = {}
        if path and os.path.isfile(path):
            try:
                self.data = {str(k): str(v) for k, v in json.load(open(path, encoding="utf-8")).items()}
            except (ValueError, OSError):
                self.data = {}

    def get(self, key: str, default: str = "") -> str:
        return self.data.get(key, default)

    def flag(self, key: str, default: bool = False) -> bool:
        v = self.data.get(key)
        return default if v is None else v in ("1", "true", "True")

    def put(self, key: str, value) -> None:
        self.data[key] = str(int(value)) if isinstance(value, bool) else str(value)
        if self.path:
            os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
            tmp = self.path + ".tmp"
            json.dump(self.data, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
            os.replace(tmp, self.path)


class ErrorLog:
    """سجل في الذاكرة لهذه الجلسة فقط؛ لا يُرسل إلى أي مكان."""
    _items: List[str] = []
    MAX = 200
    _lock = threading.Lock()

    @classmethod
    def add(cls, where: str, exc: Optional[BaseException] = None) -> None:
        line = time.strftime("%H:%M:%S ") + where + (": " + "".join(traceback.format_exception_only(type(exc), exc)).strip() if exc else "")
        with cls._lock:
            cls._items.append(line)
            del cls._items[:-cls.MAX]

    @classmethod
    def text(cls) -> str:
        with cls._lock:
            return "\n".join(cls._items)

    @classmethod
    def clear(cls) -> None:
        with cls._lock:
            cls._items.clear()


# ---------------------------------------------------------------------------- نسخ احتياطي تلقائي
def backup_dir(base: str) -> str:
    d = os.path.join(base, "backups")
    os.makedirs(d, exist_ok=True)
    return d


def list_backups(base: str) -> List[str]:
    d = backup_dir(base)
    fs = [os.path.join(d, f) for f in os.listdir(d) if f.endswith(".poiproj.zip")]
    return sorted(fs, key=os.path.getmtime, reverse=True)


def _safe(name: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9_\-]+", "_", name).strip("_") or "project"


def run_backup(ws, base: str, prefs: Optional[Prefs] = None, keep: int = KEEP_BACKUPS) -> int:
    """يكتب نسخة لكل مشروع غير فارغ ثم يُبقي أحدث `keep` ملفاً. يرجع عدد الملفات المكتوبة."""
    stamp = time.strftime("%Y%m%d_%H%M")
    prev = ws.project
    n = 0
    try:
        for pi in ws.projects():
            ws.open(pi.id)
            if ws.feature_count() == 0 and not ws.layers():
                continue
            dst = os.path.join(backup_dir(base), f"auto_{stamp}_{_safe(pi.name)}_{pi.id[:6]}.poiproj.zip")
            tmp = dst + ".tmp"
            ws.backup(tmp)
            os.replace(tmp, dst)
            n += 1
    finally:
        if prev is not None:
            ws.open(prev.id)
    if prefs:
        prefs.put("lastBackup", int(time.time()))
    for f in list_backups(base)[keep:]:
        os.remove(f)
    for f in os.listdir(backup_dir(base)):
        if f.endswith(".tmp"):
            os.remove(os.path.join(backup_dir(base), f))
    return n


def maybe_backup(ws, base: str, prefs: Prefs) -> int:
    """يشغّل النسخ إن كان مفعّلاً ومضى أكثر من 20 ساعة على آخر نسخة."""
    if not prefs.flag("autoBackup", True):
        return 0
    if time.time() - float(prefs.get("lastBackup", "0") or 0) < BACKUP_INTERVAL_S:
        return 0
    return run_backup(ws, base, prefs)
