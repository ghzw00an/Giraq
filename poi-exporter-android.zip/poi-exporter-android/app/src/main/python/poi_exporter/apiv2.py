"""الجيل الثاني من الواجهات: إعدادات، مجموعات بيانات محفوظة (Attribute table)، حفظ تلقائي، ترتيب القطاعات، تصدير محدد."""
from __future__ import annotations

import json
import os
import re
import tempfile
import time

from flask import jsonify, request, send_file

from . import formats, landmark as lm, sectors as sec
from .model import LINE, POINT, POLYGON, Feature, Layer
from .workspace import Workspace

# الترتيب الذي طلبه المستخدم للقطاعات (كلمة مفتاحية من اسم القطاع بعد التطبيع)
SECTOR_ORDER = ["تجاري", "ديني", "تربوي", "رياضي", "ترفيهي", "صحي", "صناعي", "اداري", "سياسي", "زراعي", "ثقافي", "مالي", "مدني",
                "مواصلات", "خدماتي"]

DEFAULTS = {"theme": "auto", "lang": "ar", "ctype": "DD", "folder": "POIExporter", "autosave": True, "autoexport": False,
            "export_fmt": "xlsx", "base": "osm", "custom_url": "", "scale": True, "shape": "rect", "pitch": False}

PALETTE = ["#1e88ff", "#e8590c", "#0ca678", "#862e9c", "#f59f00", "#e03131", "#15aabf", "#5f3dc4", "#66a80f", "#d6336c"]


def _home() -> str:
    d = os.path.join(os.path.expanduser("~"), "poi_data")
    os.makedirs(d, exist_ok=True)
    return d


def settings() -> dict:
    d = dict(DEFAULTS)
    try:
        d.update(json.load(open(os.path.join(_home(), "settings.json"), encoding="utf-8")))
    except (OSError, ValueError):
        pass
    return d


def save_settings(upd: dict) -> dict:
    d = settings()
    for k, v in upd.items():
        if k in DEFAULTS:
            d[k] = v
    json.dump(d, open(os.path.join(_home(), "settings.json"), "w", encoding="utf-8"), ensure_ascii=False)
    return d


def ordered_sectors():
    out = []
    for key in SECTOR_ORDER:
        for i, s in enumerate(sec.ALL):
            if key in sec.norm_name(s.name):
                out.append((i, s))
                break
    seen = {i for i, _ in out}
    out += [(i, s) for i, s in enumerate(sec.ALL) if i not in seen]          # أي قطاع غير مذكور يأتي أخيراً
    return out


def sector_color(i: int) -> str:
    return "#%06x" % sec.COLORS[i % len(sec.COLORS)]


def _ws() -> Workspace:
    w = Workspace(os.environ.get("POI_DB") or os.path.join(os.path.expanduser("~"), "poi_workspace.db"))
    w.open_default()
    return w


def _layer_obj(w: Workspace, lid: str):
    r = w.db.execute("SELECT * FROM layer WHERE id=? AND deleted=0", (lid,)).fetchone()
    if not r:
        return None
    l = Layer(r["id"], r["name"], r["geom"], kind=r["kind"], color=r["color"], width=r["width"], opacity=r["opacity"],
              order=r["ord"], visible=bool(r["visible"]), source=r["source"], source_date=r["source_date"],
              accuracy_note=r["accuracy_note"], official=bool(r["official"]), project_id=r["project"])
    l.features = w._features(lid)
    return l


def _ds_color(layer_color: int, idx: int) -> str:
    return "#%06x" % (layer_color & 0xFFFFFF) if layer_color else PALETTE[idx % len(PALETTE)]


def datasets(w: Workspace):
    rows = w.db.execute(
        "SELECT l.id,l.name,l.geom,l.kind,l.color,l.visible,l.source,l.source_date,"
        "(SELECT COUNT(*) FROM feature f WHERE f.layer=l.id AND f.deleted=0) n "
        "FROM layer l WHERE l.project=? AND l.deleted=0 ORDER BY l.ord, l.rowid", (w._pid(),)).fetchall()
    return [{"id": r["id"], "label": r["name"], "geom": r["geom"], "kind": r["kind"], "count": r["n"], "visible": bool(r["visible"]),
             "color": _ds_color(r["color"], i), "source": r["source"], "date": r["source_date"]} for i, r in enumerate(rows)]


def row(f: Feature) -> dict:
    x, y = lm.xy(f)
    t = lm.text(f)
    return {"id": f.id, "name": t[0], "type": t[1], "Gategory": t[2], "gathaa": t[3], "Nahia": t[4], "mohafadha": t[5],
            "x": lm.num(x, 2), "y": lm.num(y, 2), "link": lm.link(f), "lat": f.lat, "lon": f.lon}


def _coords(f: Feature):
    return [[(round(x, 6), round(y, 6)) for x, y in p] for p in f.parts]


def to_geojson(layer: Layer, color: str) -> dict:
    sc = {s.name: sector_color(i) for i, s in enumerate(sec.ALL)}
    feats = []
    for f in layer.features:
        p = row(f)
        p["color"] = sc.get(f.category, color)
        if f.geom == POINT:
            g = {"type": "Point", "coordinates": [round(f.lon, 6), round(f.lat, 6)]}
        elif f.geom == LINE:
            g = {"type": "MultiLineString", "coordinates": _coords(f)}
        else:
            polys = []
            for i, part in enumerate(_coords(f)):
                ring = [list(c) for c in part]
                if ring and ring[0] != ring[-1]:
                    ring.append(ring[0])
                if f.is_hole(i) and polys:
                    polys[-1].append(ring)
                else:
                    polys.append([ring])
            g = {"type": "MultiPolygon", "coordinates": polys}
        feats.append({"type": "Feature", "properties": p, "geometry": g})
    return {"type": "FeatureCollection", "features": feats}


def autosave_fetch(layers, label_suffix: str = "") -> list:
    """يحفظ نتائج الجلب داخل التطبيق كمجموعات بيانات (تظهر في الجدول والمعالم المحفوظة)."""
    stamp = label_suffix or time.strftime("%Y-%m-%d %H:%M")
    w = _ws()
    try:
        ids = []
        for l in layers:
            if not l.features:
                continue
            l.label = f"{l.label} — {stamp}"
            l.kind = "download"
            l.source = "OpenStreetMap"
            l.source_date = stamp
            ids.append(w.add_layer_with_features(l).id)
        return ids
    finally:
        w.close()


def merged_points(w: Workspace, ids=None) -> Layer:
    """يدمج كل الطبقات المرئية (نقاط) في طبقة واحدة للتحليل والأدوات."""
    feats = []
    for d in datasets(w):
        if ids is not None and d["id"] not in ids:
            continue
        if ids is None and (not d["visible"] or d["kind"] == "reference"):
            continue
        l = _layer_obj(w, d["id"])
        feats += [f for f in l.features if f.geom == POINT]
    return Layer("merged", "المعالم المرئية", POINT, feats)


def visible_layers(w: Workspace):
    out = []
    for d in datasets(w):
        if d["visible"] and d["kind"] != "reference" and d["count"]:
            out.append(_layer_obj(w, d["id"]))
    return out


def register(app):
    @app.get("/api/settings")
    def settings_get():
        return jsonify(settings())

    @app.post("/api/settings")
    def settings_set():
        return jsonify(save_settings(request.get_json(force=True)))

    @app.get("/api/sectors")
    def sectors_ordered():
        return jsonify([{"name": s.name, "items": list(s.items), "color": sector_color(i)} for i, s in ordered_sectors()])

    # ---------------------------------------------------------------- مجموعات البيانات
    @app.get("/api/datasets")
    def ds_list():
        w = _ws()
        try:
            return jsonify(datasets(w))
        finally:
            w.close()

    @app.post("/api/datasets/<lid>")
    def ds_update(lid):
        j = request.get_json(force=True)
        w = _ws()
        try:
            if "visible" in j:
                w.set_visible(lid, bool(j["visible"]))
            if j.get("label"):
                w.rename_layer(lid, str(j["label"]).strip())
            if j.get("color"):
                w.update_layer_style(lid, color=0xFF000000 | int(str(j["color"]).lstrip("#"), 16))
        finally:
            w.close()
        return jsonify(ok=True)

    @app.delete("/api/datasets/<lid>")
    def ds_delete(lid):
        w = _ws()
        try:
            w.delete_layer(lid)
        finally:
            w.close()
        return jsonify(ok=True)

    @app.get("/api/datasets/<lid>/geojson")
    def ds_geojson(lid):
        w = _ws()
        try:
            l = _layer_obj(w, lid)
            if not l:
                return jsonify(error="غير موجود"), 404
            idx = [d["id"] for d in datasets(w)].index(lid)
            return jsonify(to_geojson(l, _ds_color(l.color, idx)))
        finally:
            w.close()

    @app.get("/api/datasets/<lid>/rows")
    def ds_rows(lid):
        off = max(0, int(request.args.get("offset", 0)))
        lim = min(500, max(1, int(request.args.get("limit", 100))))
        q = sec.norm_name(request.args.get("q", ""))
        key = request.args.get("sort", "")
        rev = request.args.get("dir", "asc") == "desc"
        w = _ws()
        try:
            l = _layer_obj(w, lid)
            if not l:
                return jsonify(error="غير موجود"), 404
            rows = [row(f) for f in l.features]
        finally:
            w.close()
        if q:
            rows = [r for r in rows if q in sec.norm_name(" ".join(str(r[k]) for k in ("name", "type", "Gategory", "gathaa", "Nahia", "mohafadha")))]
        if key in ("name", "type", "Gategory", "gathaa", "Nahia", "mohafadha", "x", "y", "link"):
            if key in ("x", "y"):
                rows.sort(key=lambda r: float(r[key] or 0), reverse=rev)
            else:
                rows.sort(key=lambda r: sec.norm_name(r[key]), reverse=rev)
        return jsonify(total=len(rows), rows=rows[off:off + lim])

    @app.post("/api/features/delete")
    def feats_delete():
        ids = request.get_json(force=True).get("ids", [])
        w = _ws()
        try:
            w.delete_anywhere(ids)
        finally:
            w.close()
        return jsonify(ok=True, n=len(ids))

    @app.post("/api/features/add-many")
    def feats_add_many():
        """يضيف عدة معالم دفعة واحدة إلى طبقة المعالم (الإضافة المتعددة)."""
        j = request.get_json(force=True)
        from .admin import AdminRef
        feats = []
        for it in j.get("items", []):
            f = Feature.point(float(it["lat"]), float(it["lon"]), id=Feature.new_id(), name=(it.get("name") or "").strip(),
                              type=(it.get("type") or "").strip(), category=(it.get("Gategory") or "").strip())
            AdminRef.get().fill(f, True)
            feats.append(f)
        w = _ws()
        try:
            lay = next((l for l in datasets(w) if l["kind"] == "user" and l["label"] == "المعالم"), None)
            lid = lay["id"] if lay else w.add_layer("المعالم", POINT).id
            w.add_features(lid, feats)
        finally:
            w.close()
        return jsonify(added=len(feats), rows=[row(f) for f in feats])

    @app.post("/api/datasets/export")
    def ds_export():
        j = request.get_json(force=True)
        fmt = j.get("format", "xlsx")
        if fmt not in formats.FORMATS:
            return jsonify(error="صيغة غير مدعومة"), 400
        want = set(j.get("ids") or [])
        w = _ws()
        try:
            layers = []
            for lid in j.get("layers") or [d["id"] for d in datasets(w) if d["visible"] and d["kind"] != "reference"]:
                l = _layer_obj(w, lid)
                if not l:
                    continue
                if want:
                    l.features = [f for f in l.features if f.id in want]
                if l.features:
                    layers.append(l)
        finally:
            w.close()
        if not layers:
            return jsonify(error="لا توجد بيانات للتصدير"), 400
        base = re.sub(r"[^\w\-]+", "_", (j.get("name") or layers[0].label))[:40] or "export"
        path = os.path.join(tempfile.mkdtemp(), base + formats.EXT[fmt])
        formats.export_layers(layers, fmt, path)
        return send_file(path, as_attachment=True, download_name=base + formats.EXT[fmt])

    @app.get("/api/admin/geojson")
    def admin_geojson():
        from .admin import AdminRef
        lv = int(request.args.get("level", 1))
        lay = AdminRef.get().layer(lv, True)
        return jsonify(to_geojson(lay, "#868e96"))
