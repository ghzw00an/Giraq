"""فهرس أسماء المناطق العراقية للبحث السريع بالعربية (يبدأ من أول حرف).

المصادر (تُدمج وتُزال المكررات):
1) الحدود الإدارية المضمّنة (18 محافظة + 101 قضاء) — بمضلعات تُظلَّل على الخريطة.
2) data/iq_places.json — يُولَّد من بيانات iraqi-geography-data بواسطة tools/build_gazetteer.py.
3) أي ملفات json/geojson/csv توضع في ~/poi_data/iraqi_geography/ (اختياري).
"""
from __future__ import annotations

import csv
import glob
import json
import os
import re
import threading
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .admin import AdminRef
from .sectors import norm_name

AR_RE = re.compile(r"[\u0600-\u06FF]")

# ترتيب النتائج: الأكبر إدارياً أولاً عند تساوي جودة المطابقة
TYPE_RANK = {"محافظة": 0, "قضاء": 1, "ناحية": 2, "مدينة": 2, "بلدة": 3, "حي": 4, "منطقة": 4, "قرية": 5}

_TYPE_ALIASES = {
    "governorate": "محافظة", "province": "محافظة", "state": "محافظة", "admin1": "محافظة", "adm1": "محافظة",
    "governorates": "محافظة", "provinces": "محافظة", "محافظه": "محافظة", "محافظة": "محافظة", "1": "محافظة",
    "district": "قضاء", "qada": "قضاء", "qadaa": "قضاء", "qadha": "قضاء", "admin2": "قضاء", "adm2": "قضاء",
    "districts": "قضاء", "قضاء": "قضاء", "اقضيه": "قضاء", "أقضية": "قضاء", "2": "قضاء",
    "subdistrict": "ناحية", "sub-district": "ناحية", "sub_district": "ناحية", "sub_districts": "ناحية",
    "nahiya": "ناحية", "nahia": "ناحية", "nahiyah": "ناحية", "nahiyas": "ناحية", "admin3": "ناحية",
    "adm3": "ناحية", "ناحية": "ناحية", "ناحيه": "ناحية", "نواحي": "ناحية", "3": "ناحية",
    "city": "مدينة", "cities": "مدينة", "مدينة": "مدينة", "مدينه": "مدينة",
    "town": "بلدة", "towns": "بلدة", "بلدة": "بلدة", "بلده": "بلدة",
    "village": "قرية", "villages": "قرية", "قرية": "قرية", "قريه": "قرية",
    "neighborhood": "حي", "neighbourhood": "حي", "neighborhoods": "حي", "quarter": "حي", "suburb": "حي", "حي": "حي",
    "area": "منطقة", "areas": "منطقة", "region": "منطقة", "locality": "منطقة", "منطقة": "منطقة", "منطقه": "منطقة",
}

_F_AR = ("name_ar", "ar_name", "arabic", "arabic_name", "name_arabic", "namear", "ar", "title_ar", "الاسم", "اسم")
_F_EN = ("name_en", "en_name", "english", "english_name", "name_english", "nameen", "en", "name_latin", "title_en")
_F_NAME = ("name", "title", "label")
_F_LAT = ("lat", "latitude", "y", "lat_dd", "centroid_lat", "center_lat")
_F_LON = ("lon", "lng", "long", "longitude", "x", "lon_dd", "centroid_lon", "center_lon")
_F_TYPE = ("type", "level", "category", "kind", "admin_level", "class", "place", "place_type", "النوع")
_F_PARENT = ("parent_ar", "governorate_ar", "province_ar", "governorate", "province", "parent", "district_ar",
             "district", "city_ar", "city", "المحافظة", "القضاء")
_CHILD_KEYS = ("districts", "qadas", "areas", "cities", "towns", "villages", "neighborhoods", "neighbourhoods",
               "sub_districts", "subdistricts", "nahiyas", "nahiyat", "children", "sub_areas", "quarters",
               "الاقضية", "الأقضية", "النواحي", "الاحياء", "الأحياء")
_LIST_KEYS = ("governorates", "provinces", "districts", "cities", "places", "data", "items", "areas", "towns",
              "villages", "neighborhoods", "nahiyas", "sub_districts", "features", "records", "results", "locations")


def _key(s: str) -> str:
    """مفتاح بحث: تطبيع عربي لكل كلمة والإبقاء على المسافات بين الكلمات."""
    ws = [norm_name(w) for w in re.split(r"[\s\-_/،,]+", s or "")]
    return " ".join(w for w in ws if w)


def _strip_al(k: str) -> str:
    return " ".join(w[2:] if w.startswith("ال") and len(w) > 3 else w for w in k.split())


def norm_type(v: Any) -> str:
    s = str(v or "").strip()
    if not s:
        return ""
    low = s.lower().replace(" ", "")
    return _TYPE_ALIASES.get(low) or _TYPE_ALIASES.get(s.lower()) or _TYPE_ALIASES.get(norm_name(s)) or s


def _pick(d: Dict[str, Any], names: Iterable[str]) -> Any:
    low = {str(k).lower().strip(): v for k, v in d.items()}
    for n in names:
        v = low.get(n.lower())
        if v not in (None, "", []):
            return v
    return None


def _num(v: Any) -> Optional[float]:
    try:
        x = float(str(v).strip())
        return x if x == x else None
    except (TypeError, ValueError):
        return None


def _valid(lat: Optional[float], lon: Optional[float]) -> bool:
    return lat is not None and lon is not None and 28.0 <= lat <= 38.5 and 38.0 <= lon <= 49.5


class Gazetteer:
    _shared: Optional["Gazetteer"] = None
    _lock = threading.Lock()

    def __init__(self):
        self.items: List[dict] = []
        self.stats = {"total": 0, "by_type": {}, "sources": {}, "skipped_no_coords": 0, "errors": []}
        self._by_first: Dict[str, List[int]] = {}

    # ------------------------------------------------------------ بناء
    @classmethod
    def get(cls) -> "Gazetteer":
        with cls._lock:
            if cls._shared is None:
                g = cls()
                g._build()
                cls._shared = g
            return cls._shared

    def _add(self, ar: str, en: str, typ: str, parent: str, lat: float, lon: float, src: str,
             bb: Optional[Tuple[float, float, float, float]] = None, unit: Any = None, geom: Any = None) -> None:
        ar, en = (ar or "").strip(), (en or "").strip()
        if not ar and not en:
            return
        disp = ar or en
        k = _key(ar) or _key(en)
        item = {"ar": disp, "en": en, "type": typ or "منطقة", "parent": (parent or "").strip(), "lat": lat, "lon": lon,
                "bb": bb, "k": k, "ka": _strip_al(k), "ke": (en or "").lower(), "src": src, "unit": unit, "geom": geom}
        item["w"] = k.split()
        item["wa"] = item["ka"].split()
        self.items.append(item)

    def _build(self) -> None:
        self._load_admin()
        self._load_bundled()
        self._load_user_dir()
        self._dedupe()
        for i, it in enumerate(self.items):
            it["id"] = i
            first = (it["ka"] or it["k"] or "?")[0]
            self._by_first.setdefault(first, []).append(i)
            self.stats["by_type"][it["type"]] = self.stats["by_type"].get(it["type"], 0) + 1
        self.stats["total"] = len(self.items)

    def _load_admin(self) -> None:
        adm = AdminRef.get()
        if not adm:
            return
        n = 0
        for lvl in (1, 2):
            for u in adm.units(lvl):
                self._add(u.name_ar, u.name_en, "محافظة" if lvl == 1 else "قضاء", u.parent_ar if lvl == 2 else "",
                          u.poly.lat, u.poly.lon, "admin", bb=u.bbox, unit=u)
                n += 1
        self.stats["sources"]["admin"] = n

    def _admin_lookup(self, ar: str) -> Optional[dict]:
        k = _strip_al(_key(ar))
        if not k:
            return None
        for it in self.items:
            if it["src"] == "admin" and it["ka"] == k:
                return it
        return None

    def _load_bundled(self) -> None:
        raw = None
        try:
            import pkgutil
            raw = pkgutil.get_data(__package__ or "poi_exporter", "data/iq_places.json")
        except (OSError, ValueError):
            raw = None
        if raw is None:
            p = os.path.join(os.path.dirname(__file__), "data", "iq_places.json")
            if os.path.exists(p):
                raw = open(p, "rb").read()
        if raw is None:
            return
        try:
            self._ingest(json.loads(raw.decode("utf-8")), "iq_places.json")
        except Exception as e:  # noqa: BLE001
            self.stats["errors"].append("iq_places.json: %s" % e)

    def _load_user_dir(self) -> None:
        d = os.path.join(os.path.expanduser("~"), "poi_data", "iraqi_geography")
        if not os.path.isdir(d):
            return
        for p in sorted(glob.glob(os.path.join(d, "**", "*"), recursive=True)):
            ext = os.path.splitext(p)[1].lower()
            if ext not in (".json", ".geojson", ".csv"):
                continue
            try:
                if ext == ".csv":
                    with open(p, encoding="utf-8-sig", newline="") as fh:
                        self._ingest(list(csv.DictReader(fh)), os.path.basename(p))
                else:
                    with open(p, encoding="utf-8-sig") as fh:
                        self._ingest(json.load(fh), os.path.basename(p))
            except Exception as e:  # noqa: BLE001
                self.stats["errors"].append("%s: %s" % (os.path.basename(p), e))

    # ------------------------------------------------------------ قراءة مرنة
    def _ingest(self, obj: Any, src: str) -> None:
        before = len(self.items)
        self._walk(obj, src, "", "", 0)
        self.stats["sources"][src] = len(self.items) - before

    def _walk(self, obj: Any, src: str, parent: str, type_hint: str, depth: int) -> None:
        if depth > 6:
            return
        if isinstance(obj, list):
            for r in obj:
                if isinstance(r, dict):
                    self._record(r, src, parent, type_hint, depth)
            return
        if isinstance(obj, dict):
            if obj.get("type") == "FeatureCollection" or "features" in obj:
                self._walk(obj.get("features") or [], src, parent, type_hint, depth + 1)
                return
            listed = False
            for k, v in obj.items():
                if isinstance(v, list) and v and isinstance(v[0], dict) and str(k).lower() in _LIST_KEYS + _CHILD_KEYS:
                    self._walk(v, src, parent, norm_type(k) if norm_type(k) in TYPE_RANK else type_hint, depth + 1)
                    listed = True
            if not listed and _pick(obj, _F_AR + _F_EN + _F_NAME):
                self._record(obj, src, parent, type_hint, depth)

    def _record(self, r: Dict[str, Any], src: str, parent: str, type_hint: str, depth: int) -> None:
        if r.get("type") == "Feature":
            props = dict(r.get("properties") or {})
            geom = r.get("geometry")
        else:
            props, geom = r, r.get("geometry")
        ar = _pick(props, _F_AR)
        en = _pick(props, _F_EN)
        nm = _pick(props, _F_NAME)
        if nm and not ar and AR_RE.search(str(nm)):
            ar = nm
        elif nm and not en and not AR_RE.search(str(nm)):
            en = nm
        ar, en = str(ar or "").strip(), str(en or "").strip()
        typ = norm_type(_pick(props, _F_TYPE)) or type_hint
        par = _pick(props, _F_PARENT)
        par = par if isinstance(par, str) else parent
        if par and not AR_RE.search(par):
            par = parent
        lat, lon, bb, keep = None, None, None, None
        if isinstance(geom, dict) and geom.get("coordinates") is not None:
            lat, lon, bb, keep = self._geom_info(geom)
        if not _valid(lat, lon):
            lat, lon = _num(_pick(props, _F_LAT)), _num(_pick(props, _F_LON))
        if not _valid(lat, lon):
            for key in ("location", "center", "centroid", "coordinates", "coords", "latlng"):
                v = props.get(key)
                if isinstance(v, dict):
                    lat, lon = _num(_pick(v, _F_LAT)), _num(_pick(v, _F_LON))
                elif isinstance(v, (list, tuple)) and len(v) >= 2:
                    a, b = _num(v[0]), _num(v[1])
                    lat, lon = (b, a) if _valid(b, a) else (a, b)
                if _valid(lat, lon):
                    break
        unit = None
        if not _valid(lat, lon):
            hit = self._admin_lookup(ar) if ar else None
            if hit:
                lat, lon, bb, unit = hit["lat"], hit["lon"], hit["bb"], hit["unit"]
        if (ar or en) and _valid(lat, lon):
            self._add(ar, en, typ, par, lat, lon, src, bb=bb, unit=unit, geom=keep)
        elif ar or en:
            self.stats["skipped_no_coords"] += 1
        me = ar or en
        for ck in _CHILD_KEYS:
            ch = props.get(ck)
            if isinstance(ch, list) and ch and isinstance(ch[0], dict):
                t = norm_type(ck)
                self._walk(ch, src, me if AR_RE.search(me) else par, t if t in TYPE_RANK else "", depth + 1)

    @staticmethod
    def _geom_info(g: dict):
        t, c = g.get("type"), g.get("coordinates")
        try:
            if t == "Point":
                return float(c[1]), float(c[0]), None, None
            polys = [c] if t == "Polygon" else c if t == "MultiPolygon" else None
            if not polys:
                return None, None, None, None
            pts = [p for poly in polys for ring in poly for p in ring]
            xs, ys = [p[0] for p in pts], [p[1] for p in pts]
            bb = (min(xs), min(ys), max(xs), max(ys))
            outer = max((poly[0] for poly in polys), key=len)
            lon = sum(p[0] for p in outer) / len(outer)
            lat = sum(p[1] for p in outer) / len(outer)
            keep = {"type": t, "coordinates": c} if len(pts) <= 6000 else None
            return lat, lon, bb, keep
        except (TypeError, ValueError, IndexError, ZeroDivisionError):
            return None, None, None, None

    def _dedupe(self) -> None:
        """المحافظات والأقضية: يبقى المدخل ذو المضلع (admin) ويُسقط المكرر الخارجي."""
        seen, out = set(), []
        for it in sorted(self.items, key=lambda x: 0 if x["src"] == "admin" else 1):
            if it["type"] in ("محافظة", "قضاء"):
                kk = (it["type"], it["ka"])
                if kk in seen:
                    continue
                seen.add(kk)
            else:
                kk = (it["ka"], it["parent"], round(it["lat"], 3), round(it["lon"], 3))
                if kk in seen:
                    continue
                seen.add(kk)
            out.append(it)
        out.sort(key=lambda x: (TYPE_RANK.get(x["type"], 6), x["ar"]))
        self.items = out

    # ------------------------------------------------------------ بحث
    def suggest(self, q: str, limit: int = 12) -> List[dict]:
        q = (q or "").strip()
        if not q:
            return []
        qk = _key(q)
        qa = _strip_al(qk)
        qe = q.lower()
        is_ar = bool(AR_RE.search(q))
        if not qk and not qe:
            return []
        scored: List[Tuple[Tuple[int, int, int, str], int]] = []
        cand: Iterable[int]
        if qk and is_ar:
            cand = range(len(self.items))
        else:
            cand = range(len(self.items))
        for i in cand:
            it = self.items[i]
            s = None
            if is_ar and qk:
                if it["k"].startswith(qk) or it["ka"].startswith(qa):
                    s = 0 if (it["k"] == qk or it["ka"] == qa) else 1
                elif any(w.startswith(qk) for w in it["w"][1:]) or any(w.startswith(qa) for w in it["wa"][1:]):
                    s = 2
                elif len(qa) >= 2 and (qa in it["ka"] or qk in it["k"]):
                    s = 3
            elif it["ke"]:
                if it["ke"].startswith(qe):
                    s = 1
                elif any(w.startswith(qe) for w in it["ke"].split()[1:]):
                    s = 2
                elif len(qe) >= 3 and qe in it["ke"]:
                    s = 3
            if s is not None:
                scored.append(((s, TYPE_RANK.get(it["type"], 6), len(it["k"]), it["ar"]), i))
        scored.sort()
        out = []
        for _, i in scored[:max(1, min(limit, 30))]:
            it = self.items[i]
            out.append({"id": it["id"], "name": it["ar"], "en": it["en"], "type": it["type"], "parent": it["parent"],
                        "lat": round(it["lat"], 6), "lon": round(it["lon"], 6),
                        "bbox": [round(v, 5) for v in it["bb"]] if it["bb"] else None,
                        "poly": bool(it["unit"] is not None or it["geom"])})
        return out

    def geometry(self, pid: int) -> Optional[dict]:
        if not (0 <= pid < len(self.items)):
            return None
        it = self.items[pid]
        props = {"name": it["ar"], "type": it["type"]}
        u = it["unit"]
        if u is not None and u.poly is not None:
            polys: List[list] = []
            for ring, hole in zip(u.poly.parts, u.poly.holes):
                pts = [[x, y] for x, y in ring]
                if hole and polys:
                    polys[-1].append(pts)
                else:
                    polys.append([pts])
            return {"type": "Feature", "properties": props, "geometry": {"type": "MultiPolygon", "coordinates": polys}}
        if it["geom"]:
            return {"type": "Feature", "properties": props, "geometry": it["geom"]}
        return None


def register(app) -> None:
    from flask import jsonify, request

    @app.get("/api/places/suggest")
    def places_suggest():
        g = Gazetteer.get()
        q = request.args.get("q", "")
        try:
            lim = int(request.args.get("limit", 12))
        except ValueError:
            lim = 12
        return jsonify(q=q, items=g.suggest(q, lim))

    @app.get("/api/places/geom")
    def places_geom():
        g = Gazetteer.get()
        try:
            pid = int(request.args.get("id", "-1"))
        except ValueError:
            return jsonify(error="id غير صالح"), 400
        f = g.geometry(pid)
        return jsonify(feature=f)

    @app.get("/api/places/stats")
    def places_stats():
        g = Gazetteer.get()
        return jsonify(g.stats)
