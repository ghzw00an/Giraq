"""فحص طوبولوجيا طبقة مضلعات: تداخلات، فجوات، تقاطع ذاتي، هندسات مكررة."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Tuple

from . import geodesy, geoops, overlay as ov, quality
from .geo import bbox, set_representative
from .model import POLYGON, Feature, Layer

OVERLAP, GAP, SELF_INTERSECTION, DUPLICATE = "overlap", "gap", "self_intersection", "duplicate"


@dataclass
class Issue:
    kind: str
    ids: Tuple[str, ...]
    lat: float
    lon: float
    area_m2: float = 0.0
    note: str = ""


@dataclass
class Report:
    issues: List[Issue] = field(default_factory=list)

    def count(self, kind: str) -> int:
        return sum(1 for i in self.issues if i.kind == kind)

    def to_text(self) -> str:
        return (f"تداخلات: {self.count(OVERLAP)} • فجوات: {self.count(GAP)} • تقاطع ذاتي: {self.count(SELF_INTERSECTION)}"
                f" • مكرر: {self.count(DUPLICATE)}")


def _boxes_touch(a, b) -> bool:
    return not (a[2] < b[0] or b[2] < a[0] or a[3] < b[1] or b[3] < a[1])


def overlaps(layer: Layer, min_area_m2: float = 1.0) -> List[Issue]:
    polys = [f for f in layer.features if f.geom == POLYGON and f.parts]
    boxes = [bbox(f) for f in polys]
    out = []
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            if not _boxes_touch(boxes[i], boxes[j]):
                continue
            o = geoops.intersection(polys[i], polys[j])
            if o and o.area_m2 >= min_area_m2:
                out.append(Issue(OVERLAP, (polys[i].id, polys[j].id), o.feature.lat, o.feature.lon, o.area_m2))
    return out


def gaps(layer: Layer, min_area_m2: float = 1.0) -> List[Issue]:
    """الفجوات = ثقوب داخلية في اتحاد المضلعات."""
    polys = [f for f in layer.features if f.geom == POLYGON and f.parts]
    if len(polys) < 2:
        return []
    l = geoops.Local(polys)
    res = ov.overlay([l.rings(f) for f in polys], lambda fl: any(fl))
    out = []
    for poly in res:
        for hole in poly[1:]:
            h = l.features([[hole[::-1]]])[0]
            a = geodesy.area(h)
            if a >= min_area_m2:
                out.append(Issue(GAP, (), h.lat, h.lon, a))
    return out


def self_intersections(layer: Layer) -> List[Issue]:
    return [Issue(SELF_INTERSECTION, (f.id,), f.lat, f.lon) for f in layer.features
            if f.geom == POLYGON and f.parts and quality.polygon_self_intersects(f)]


def duplicate_geometries(layer: Layer) -> List[Issue]:
    seen, out = {}, []
    for f in layer.features:
        if not f.parts:
            continue
        key = tuple(sorted(tuple(sorted((round(x, 7), round(y, 7)) for x, y in p)) for p in f.parts))
        if key in seen:
            out.append(Issue(DUPLICATE, (seen[key], f.id), f.lat, f.lon))
        else:
            seen[key] = f.id
    return out


def report(layer: Layer, min_area_m2: float = 1.0) -> Report:
    return Report(overlaps(layer, min_area_m2) + gaps(layer, min_area_m2) + self_intersections(layer) + duplicate_geometries(layer))
