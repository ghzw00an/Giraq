"""النموذج: المعلم/العنصر (Feature) والطبقة (Layer). الإحداثيات WGS84 بترتيب (lon, lat)."""
from __future__ import annotations

import copy
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

POINT, LINE, POLYGON = 1, 3, 5
GEOM_NAMES = {POINT: "point", LINE: "line", POLYGON: "polygon"}
STATUS_NEW, STATUS_REVIEW, STATUS_VERIFIED = 0, 1, 2

Coord = Tuple[float, float]


@dataclass
class Feature:
    geom: int = POINT
    id: str = ""
    name: str = ""
    type: str = ""
    category: str = ""        # Gategory (القطاع)
    nahiya: str = ""          # Nahia
    qadaa: str = ""           # gathaa
    governorate: str = ""     # mohafadha
    name_en: str = ""
    description: str = ""
    notes: str = ""
    source: str = ""
    updated: str = ""
    accuracy: float = float("nan")
    status: int = STATUS_NEW
    photos: List[str] = field(default_factory=list)
    attrs: Dict[str, str] = field(default_factory=dict)
    parts: List[List[Coord]] = field(default_factory=list)
    holes: List[bool] = field(default_factory=list)
    lat: float = 0.0
    lon: float = 0.0

    @staticmethod
    def point(lat: float, lon: float, **kw) -> "Feature":
        f = Feature(geom=POINT, lat=lat, lon=lon, **kw)
        f.parts.append([(lon, lat)])
        f.holes.append(False)
        return f

    @staticmethod
    def new_id() -> str:
        return str(uuid.uuid4())

    def add_part(self, coords: List[Coord], hole: bool = False) -> None:
        self.parts.append([(float(x), float(y)) for x, y in coords])
        self.holes.append(hole)

    def is_hole(self, i: int) -> bool:
        return i < len(self.holes) and self.holes[i]

    def copy(self) -> "Feature":
        return copy.deepcopy(self)


@dataclass
class Layer:
    id: str
    label: str
    geom: int
    features: List[Feature] = field(default_factory=list)
    kind: str = "user"          # user | download | reference | import
    color: int = 0
    width: float = 0.0
    opacity: float = 1.0
    order: int = 0
    visible: bool = True
    source: str = ""
    source_date: str = ""
    accuracy_note: str = ""
    official: bool = False
    project_id: str = ""

    @staticmethod
    def geom_name(g: int) -> str:
        return GEOM_NAMES.get(g, "point")
