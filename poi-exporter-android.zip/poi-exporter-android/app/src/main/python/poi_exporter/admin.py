"""الحدود الإدارية المرجعية للعراق (18 محافظة + 101 قضاء)، غير رسمية ومُبسَّطة."""
from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass, field
from typing import List, Optional

from .geo import bbox, in_polygon, set_representative
from .model import POLYGON, Feature, Layer
from .sectors import norm_name

RESOURCE = os.path.join(os.path.dirname(__file__), "data", "iq_admin.json")


@dataclass
class Unit:
    level: int = 2
    name_en: str = ""
    name_ar: str = ""
    parent_en: str = ""
    parent_ar: str = ""
    poly: Feature = None
    extra: bool = False
    source: str = ""
    bbox: tuple = (1e9, 1e9, -1e9, -1e9)

    def name(self, ar: bool = True) -> str:
        return self.name_ar if ar and self.name_ar else self.name_en

    def parent(self, ar: bool = True) -> str:
        return self.parent_ar if ar and self.parent_ar else self.parent_en

    def covers(self, lat: float, lon: float) -> bool:
        b = self.bbox
        if lon < b[0] or lon > b[2] or lat < b[1] or lat > b[3]:
            return False
        return in_polygon(self.poly, lon, lat)

    def boundary_distance_m(self, lat: float, lon: float) -> float:
        """مسافة تقريبية بالمتر إلى حد الوحدة."""
        m_lat = 111320.0
        m_lon = 111320.0 * max(0.2, math.cos(math.radians(lat)))
        best = float("inf")
        for ring in self.poly.parts:
            for i in range(len(ring) - 1):
                ax, ay = (ring[i][0] - lon) * m_lon, (ring[i][1] - lat) * m_lat
                bx, by = (ring[i + 1][0] - lon) * m_lon, (ring[i + 1][1] - lat) * m_lat
                dx, dy = bx - ax, by - ay
                L = dx * dx + dy * dy
                t = 0.0 if L == 0 else max(0.0, min(1.0, -(ax * dx + ay * dy) / L))
                best = min(best, math.hypot(ax + t * dx, ay + t * dy))
        return best


@dataclass
class Hit:
    district: Optional[Unit] = None
    governorate: Optional[Unit] = None
    boundary_m: float = -1.0

    def qadaa(self, ar=True) -> str:
        return self.district.name(ar) if self.district else ""

    def governorate_name(self, ar=True) -> str:
        if self.district:
            return self.district.parent(ar)
        return self.governorate.name(ar) if self.governorate else ""

    def found(self) -> bool:
        return self.district is not None or self.governorate is not None


def _ar_key(s: str) -> str:
    t = norm_name(s)
    if t.startswith("قضاء"):
        t = t[4:]
    if t.startswith("ال") and len(t) > 3:
        t = t[2:]
    return t


def _en_key(s: str) -> str:
    import re
    t = re.sub(r"\b(district|qada|qadaa|qadha)\b", "", (s or "").lower())
    t = re.sub(r"[^a-z0-9]", "", t)
    if t.startswith("al") and len(t) > 4:
        t = t[2:]
    return t


class AdminRef:
    def __init__(self):
        self.adm1: List[Unit] = []
        self.adm2: List[Unit] = []
        self.notes = ""
        self.built = ""
        self.sources = ["", ""]
        self.licenses = ["", ""]
        self.years = ["", ""]

    _shared: Optional["AdminRef"] = None

    @classmethod
    def get(cls) -> Optional["AdminRef"]:
        if cls._shared is None:
            try:
                import pkgutil          # يعمل داخل أندرويد (Chaquopy) حيث لا تتوفر الملفات كمسارات حقيقية
                raw = pkgutil.get_data(__package__ or "poi_exporter", "data/iq_admin.json")
            except (OSError, ValueError):
                raw = None
            if raw is None and os.path.exists(RESOURCE):
                raw = open(RESOURCE, "rb").read()
            if raw is not None:
                cls._shared = cls.load(json.loads(raw.decode("utf-8")))
        return cls._shared

    @classmethod
    def load(cls, root: dict) -> "AdminRef":
        r = cls()
        m = root.get("meta", {})
        r.notes, r.built = m.get("notes", ""), m.get("built", "")
        for i in (1, 2):
            lm = m.get(f"adm{i}", {})
            r.sources[i - 1], r.licenses[i - 1], r.years[i - 1] = lm.get("source", ""), lm.get("license", ""), lm.get("year", "")
        r._read_features(root, False)
        r.adm1.sort(key=lambda u: u.name_en.lower())
        r.adm2.sort(key=lambda u: u.name_en.lower())
        return r

    def units(self, level: int) -> List[Unit]:
        return self.adm1 if level == 1 else self.adm2

    def source(self, level):
        return self.sources[level - 1]

    def license(self, level):
        return self.licenses[level - 1]

    def year(self, level):
        return self.years[level - 1]

    def _read_features(self, root: dict, extra: bool) -> None:
        for fm in root.get("features", []):
            pr = fm.get("properties", {})
            u = Unit(level=int(pr.get("level", 2)), name_en=pr.get("name_en", ""), name_ar=pr.get("name_ar", ""),
                     parent_en=pr.get("parent_en", ""), parent_ar=pr.get("parent_ar", ""), extra=extra,
                     source=pr.get("source", ""))
            f = Feature(geom=POLYGON, id=("adm1:" if u.level == 1 else "adm2:") + u.name_en + ("#osm" if extra else ""))
            g = fm.get("geometry", {})
            polys = g.get("coordinates", [])
            if g.get("type") == "Polygon":
                polys = [polys]
            for rings in polys:
                for ri, pts in enumerate(rings):
                    f.add_part([(p[0], p[1]) for p in pts], ri > 0)
            f.name = u.name_ar or u.name_en
            f.name_en = u.name_en
            f.type = "Governorate" if u.level == 1 else "District"
            set_representative(f)
            u.poly, u.bbox = f, bbox(f)
            (self.adm1 if u.level == 1 else self.adm2).append(u)

    # ------------------------------------------------------------------ بحث
    def find(self, level: int, lat: float, lon: float) -> Optional[Unit]:
        """الوحدة التي تحوي النقطة؛ عند التداخل يفوز أصغر صندوق."""
        best, best_a = None, float("inf")
        for u in self.units(level):
            if not u.covers(lat, lon):
                continue
            a = (u.bbox[2] - u.bbox[0]) * (u.bbox[3] - u.bbox[1])
            if a < best_a:
                best_a, best = a, u
        return best

    def locate(self, lat: float, lon: float) -> Hit:
        h = Hit(district=self.find(2, lat, lon))
        if h.district:
            h.governorate = next((g for g in self.adm1 if g.name_en == h.district.parent_en), None)
            try:
                h.boundary_m = h.district.boundary_distance_m(lat, lon)
            except Exception:  # noqa: BLE001
                h.boundary_m = -1.0
        else:
            h.governorate = self.find(1, lat, lon)
        return h

    def fill(self, f: Feature, ar: bool = True) -> bool:
        """يملأ gathaa وmohafadha إن كانا فارغين. يرجع True إن تغيّر شيء."""
        if f.qadaa and f.governorate:
            return False
        h = self.locate(f.lat, f.lon)
        changed = False
        if not f.qadaa and h.qadaa(ar):
            f.qadaa, changed = h.qadaa(ar), True
        if not f.governorate and h.governorate_name(ar):
            f.governorate, changed = h.governorate_name(ar), True
        return changed

    def knows_district(self, name_ar: str, name_en: str) -> bool:
        ka, ke = _ar_key(name_ar), _en_key(name_en)
        for u in self.adm2:
            if ka and ka == _ar_key(u.name_ar):
                return True
            if ke and ke == _en_key(u.name_en):
                return True
        return False

    def add_extra(self, name_en: str, name_ar: str, poly: Feature, source: str = "") -> Optional[Unit]:
        """يضيف قضاءً جلبه المستخدم من OSM (يستبدل المطابق بالاسم)."""
        if poly is None or not poly.parts or poly.geom != POLYGON:
            return None
        u = Unit(level=2, extra=True, name_en=(name_en or "").strip(), name_ar=(name_ar or "").strip(), source=source)
        if not u.name_en and not u.name_ar:
            return None
        u.name_en = u.name_en or u.name_ar
        f = poly.copy()
        f.id, f.name, f.name_en, f.type = f"adm2:{u.name_en}#osm", u.name_ar or u.name_en, u.name_en, "District"
        set_representative(f)
        u.poly, u.bbox = f, bbox(f)
        gov = self.find(1, f.lat, f.lon)
        if gov:
            u.parent_en, u.parent_ar = gov.name_en, gov.name_ar
        self.adm2 = [x for x in self.adm2 if not (x.extra and (norm_name(x.name_en) == norm_name(u.name_en)
                                                              or (u.name_ar and norm_name(x.name_ar) == norm_name(u.name_ar))))]
        self.adm2.append(u)
        self.adm2.sort(key=lambda x: x.name_en.lower())
        return u

    def accuracy_note(self, ar=True) -> str:
        return ("حدود غير رسمية ومُبسَّطة؛ قد تُخطئ النقطة القريبة من الحد. لا تصلح للمساحة أو الأعمال القانونية." if ar else
                "Unofficial, generalized boundaries; points near a border may be assigned wrongly. Not for surveying or legal use.")

    def layer(self, level: int, ar: bool = True, parent_en: Optional[str] = None) -> Layer:
        label = ("المحافظات (غير رسمي)" if ar else "Governorates (unofficial)") if level == 1 else \
                ("الأقضية (غير رسمي)" if ar else "Districts (unofficial)")
        if parent_en:
            label = f"{parent_en} — {label}"
        l = Layer(f"ref_adm{level}" + (f"_{parent_en}" if parent_en else ""), label, POLYGON, kind="reference")
        l.source = f"{self.source(level)} — {self.license(level)}"
        l.source_date = self.year(level)
        l.accuracy_note = self.accuracy_note(ar)
        for u in self.units(level):
            if parent_en and parent_en != u.parent_en:
                continue
            f = u.poly.copy()
            f.name, f.name_en = u.name(ar), u.name_en
            if level == 2:
                f.qadaa, f.governorate = u.name(ar), u.parent(ar)
            else:
                f.governorate = u.name(ar)
            l.features.append(f)
        return l


    # ------------------------------------------------------------------ أقضية إضافية جلبها المستخدم (تُحفظ خارج الملف المضمّن)
    def extras_json(self) -> str:
        feats = []
        for u in self.adm2:
            if not u.extra:
                continue
            coords = []
            outer = None
            for i, r in enumerate(u.poly.parts):
                if u.poly.is_hole(i) and outer is not None:
                    outer.append([list(p) for p in r])
                else:
                    outer = [[list(p) for p in r]]
                    coords.append(outer)
            feats.append({"type": "Feature", "properties": {"level": 2, "name_en": u.name_en, "name_ar": u.name_ar,
                                                             "parent_en": u.parent_en, "parent_ar": u.parent_ar, "source": u.source},
                          "geometry": {"type": "MultiPolygon", "coordinates": coords}})
        return json.dumps({"type": "FeatureCollection", "features": feats}, ensure_ascii=False)

    def load_extras(self, text: str) -> int:
        """يستعيد الأقضية الإضافية المحفوظة؛ يستبدل المطابق بالاسم. يرجع عدد ما أُضيف."""
        if not text or not text.strip():
            return 0
        before = len(self.adm2)
        tmp = AdminRef()
        tmp._read_features(json.loads(text), True)
        for u in tmp.adm2:
            self.adm2 = [x for x in self.adm2 if not (x.extra and norm_name(x.name_en) == norm_name(u.name_en))]
            self.adm2.append(u)
        self.adm2.sort(key=lambda x: x.name_en.lower())
        return len(tmp.adm2)
