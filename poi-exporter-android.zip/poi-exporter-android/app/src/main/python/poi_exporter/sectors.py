"""القطاعات الخمسة عشر (Gategory) وعناصرها، وألوانها، وقوالب الإدخال السريع. النصوص حرفية كما كتبها المستخدم."""
from __future__ import annotations

import json
import unicodedata
from dataclasses import dataclass, asdict
from typing import List, Optional

from .model import Feature


def norm_name(s: Optional[str]) -> str:
    """تطبيع عربي: يزيل التشكيل والتطويل ويوحّد الألف والياء والتاء المربوطة ويحوّل لأحرف صغيرة."""
    if not s:
        return ""
    t = unicodedata.normalize("NFKC", s)
    out = []
    for c in t:
        o = ord(c)
        if 0x064B <= o <= 0x065F or o in (0x0670, 0x0640) or 0x06D6 <= o <= 0x06ED:
            continue
        c = {"أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ى": "ي", "ی": "ي", "ئ": "ي",
             "ة": "ه", "ک": "ك", "ؤ": "و"}.get(c, c)
        if c.isalnum():
            out.append(c.lower())
    return "".join(out)


@dataclass(frozen=True)
class Sector:
    name: str
    items: tuple


ALL: List[Sector] = [
    Sector("قطاع المواصلات", ("تقاطع", "طريق رئيسي", "كراج", "سيطرة", "طريق فرعي", "محطة قطار", "مجسر", "طريق ثانوي", "نفق", "طريق نيسمي", "جسر مشاة", "سكة حديد")),
    Sector("القطاع السياسي", ("مقر حزب", "مكتب حزب", "سفارة", "قنصلية")),
    Sector("القطاع الإداري", ("دائرة", "وزارة", "نقابة", "مكتب", "محكمة", "بلدية", "مديرية", "قسم", "شعبة", "هيئة", "جمعية")),
    Sector("القطاع المدني", ("مؤسسة مجتمع مدني", "جمعية خيرية", "مؤسسة", "دار رعاية")),
    Sector("القطاع التجاري", ("شركة", "محل", "سوق", "مقهى", "مطعم", "مكتب تجاري", "فندق", "قاعة مناسبات", "علوة", "مول", "مجمع تجاري", "مخزن", "مشتل", "معرض", "محطة تعبئة وقود")),
    Sector("القطاع المالي", ("مصرف", "صيرفة", "شركة")),
    Sector("القطاع التربوي والتعليم", ("روضة", "مدرسة", "معهد", "جامعة", "مركز أبحاث", "أقسام داخلية", "حضانة", "كلية", "رئاسة جامعة", "عمادة")),
    Sector("القطاع الترفيهي", ("متنزه", "مدينة ألعاب", "حديقة حيوانات", "حديقة")),
    Sector("القطاع الرياضي", ("ملعب", "مسبح", "مركز شباب", "نادي", "قاعة")),
    Sector("القطاع الخدماتي", ("محطة صرف صحي",)),
    Sector("القطاع الديني", ("مسجد", "مصلى", "كنيسة", "مقام", "مرقد", "حسينية", "وقف", "مغتسل", "مقبرة", "معبد", "موكب")),
    Sector("القطاع الزراعي", ("سايلو", "حقل", "بستان", "مزرعة", "بحيرة أسماك", "محمية")),
    Sector("القطاع الصحي", ("مستشفى", "مستوصف", "صيدلية", "مركز صحي", "مختبر", "عيادة", "مذخر", "مجمع طبي", "مركز تجميل")),
    Sector("القطاع الصناعي", ("معمل", "مخزن", "مصنع")),
    Sector("القطاع الثقافي", ("متحف", "معرض", "مسرح", "سينما", "مكتبة", "اتحاد", "مركز ثقافي")),
]

# لون ثابت لكل قطاع (RGB) بنفس ترتيب ALL
COLORS = [0xE8590C, 0x862E9C, 0x495057, 0x0CA678, 0xF59F00, 0x2B8A3E, 0x1C7ED6, 0xE64980,
          0x74B816, 0x15AABF, 0x5F3DC4, 0x66A80F, 0xE03131, 0x7B5E57, 0xD6336C]


def find(text: str) -> Optional[Sector]:
    t = norm_name(text)
    if not t:
        return None
    for s in ALL:
        if norm_name(s.name) == t:
            return s
    return None


def of_item(item: str) -> Optional[Sector]:
    t = norm_name(item)
    if not t:
        return None
    for s in ALL:
        if any(norm_name(i) == t for i in s.items):
            return s
    return None


def all_of_item(item: str) -> List[Sector]:
    t = norm_name(item)
    if not t:
        return []
    return [s for s in ALL if any(norm_name(i) == t for i in s.items)]


def index_of(category: str) -> int:
    s = find(category)
    return ALL.index(s) if s else -1


def color_of(category: str) -> int:
    """لون RGB للقطاع، أو 0 إن لم يكن النص قطاعاً."""
    i = index_of(category)
    return COLORS[i] if i >= 0 else 0


def color_hex(category: str) -> str:
    c = color_of(category)
    return "#%06X" % c if c else ""


@dataclass
class Template:
    name: str = ""
    type: str = ""
    category: str = ""
    qadaa: str = ""
    nahiya: str = ""
    governorate: str = ""

    def apply_to(self, f: Feature) -> None:
        """يملأ الحقول غير الفارغة في القالب فقط."""
        if self.type:
            f.type = self.type
        if self.category:
            f.category = self.category
        if self.qadaa:
            f.qadaa = self.qadaa
        if self.nahiya:
            f.nahiya = self.nahiya
        if self.governorate:
            f.governorate = self.governorate


def templates_to_json(lst: List[Template]) -> str:
    return json.dumps([asdict(t) for t in lst], ensure_ascii=False)


def templates_from_json(text: str) -> List[Template]:
    out: List[Template] = []
    if not text or not text.strip():
        return out
    try:
        data = json.loads(text)
    except ValueError:
        return out
    if not isinstance(data, list):
        return out
    for e in data:
        if isinstance(e, dict) and e.get("name"):
            out.append(Template(**{k: str(e.get(k, "")) for k in Template.__dataclass_fields__}))
    return out
