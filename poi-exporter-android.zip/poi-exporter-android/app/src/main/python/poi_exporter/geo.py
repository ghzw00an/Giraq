"""دوال هندسية صغيرة (lon,lat بالدرجات) ومواصفة منطقة التنزيل AreaSpec."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

from .model import LINE, POINT, POLYGON, Feature

R = 6371008.8
Ring = Sequence[Tuple[float, float]]


def haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(min(1.0, math.sqrt(a)))


def rect_around(clat: float, clon: float, w_m: float, h_m: float):
    """(south, west, north, east) لمستطيل w×h متر حول نقطة."""
    d_lat = math.degrees(h_m / 2 / R)
    cos = max(0.01, math.cos(math.radians(clat)))
    d_lon = math.degrees(w_m / 2 / (R * cos))
    return clat - d_lat, clon - d_lon, clat + d_lat, clon + d_lon


def circle_ring(clat: float, clon: float, r_m: float, n: int = 64) -> List[Tuple[float, float]]:
    cos = max(0.01, math.cos(math.radians(clat)))
    out = []
    for i in range(n + 1):
        a = 2 * math.pi * (i % n) / n
        out.append((clon + math.degrees(r_m * math.sin(a) / (R * cos)),
                    clat + math.degrees(r_m * math.cos(a) / R)))
    return out


def signed_area(ring: Ring) -> float:
    """مساحة بدرجات مربعة؛ موجبة عكس عقارب الساعة."""
    n = len(ring)
    a = 0.0
    j = n - 1
    for i in range(n):
        a += ring[j][0] * ring[i][1] - ring[i][0] * ring[j][1]
        j = i
    return a / 2


def reversed_ring(ring: Ring) -> List[Tuple[float, float]]:
    return list(reversed(list(ring)))


def oriented(ring: Ring, clockwise: bool) -> List[Tuple[float, float]]:
    is_ccw = signed_area(ring) > 0
    return list(ring) if clockwise == (not is_ccw) else reversed_ring(ring)


def point_in_ring(x: float, y: float, ring: Ring) -> bool:
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i]
        xj, yj = ring[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


def in_polygon(f: Feature, lon: float, lat: float) -> bool:
    """اختبار الزوج/الفرد على كل حلقات المضلع (الثقوب مستبعدة)."""
    inside = False
    for ring in f.parts:
        n = len(ring)
        j = n - 1
        for i in range(n):
            xi, yi = ring[i]
            xj, yj = ring[j]
            if (yi > lat) != (yj > lat) and lon < (xj - xi) * (lat - yi) / (yj - yi) + xi:
                inside = not inside
            j = i
    return inside


def bbox(f: Feature):
    xs = [p[0] for part in f.parts for p in part]
    ys = [p[1] for part in f.parts for p in part]
    if not xs:
        return (1e9, 1e9, -1e9, -1e9)
    return (min(xs), min(ys), max(xs), max(ys))


def path_length(p: Ring) -> float:
    return sum(haversine(p[i - 1][1], p[i - 1][0], p[i][1], p[i][0]) for i in range(1, len(p)))


def ring_area_m2(ring: Ring) -> float:
    """مساحة تقريبية بالمتر المربع (إسقاط متساوي المساحة محلي مبسّط)."""
    if len(ring) < 3:
        return 0.0
    lat0 = sum(p[1] for p in ring) / len(ring)
    mx = math.radians(1) * R * math.cos(math.radians(lat0))
    my = math.radians(1) * R
    pts = [(p[0] * mx, p[1] * my) for p in ring]
    return abs(signed_area(pts))


def polygon_area_m2(f: Feature) -> float:
    a = 0.0
    for i, r in enumerate(f.parts):
        s = ring_area_m2(r)
        a += -s if f.is_hole(i) else s
    return max(0.0, a)


def set_representative(f: Feature) -> None:
    """يضبط lat/lon: النقطة نفسها، منتصف الخط، أو نقطة داخل المضلع."""
    if not f.parts:
        return
    if f.geom == POINT:
        f.lon, f.lat = f.parts[0][0]
    elif f.geom == LINE:
        total = sum(path_length(p) for p in f.parts)
        half, acc = total / 2, 0.0
        for p in f.parts:
            for i in range(1, len(p)):
                seg = haversine(p[i - 1][1], p[i - 1][0], p[i][1], p[i][0])
                if acc + seg >= half and seg > 0:
                    t = (half - acc) / seg
                    f.lon = p[i - 1][0] + (p[i][0] - p[i - 1][0]) * t
                    f.lat = p[i - 1][1] + (p[i][1] - p[i - 1][1]) * t
                    return
                acc += seg
        f.lon, f.lat = f.parts[0][0]
    else:
        best, best_a = 0, -1.0
        for i, r in enumerate(f.parts):
            if f.is_hole(i):
                continue
            a = abs(signed_area(r))
            if a > best_a:
                best_a, best = a, i
        r = f.parts[best]
        cx = cy = a2 = 0.0
        n = len(r)
        j = n - 1
        for i in range(n):
            cr = r[j][0] * r[i][1] - r[i][0] * r[j][1]
            a2 += cr
            cx += (r[j][0] + r[i][0]) * cr
            cy += (r[j][1] + r[i][1]) * cr
            j = i
        if abs(a2) > 1e-18:
            cx /= 3 * a2
            cy /= 3 * a2
            if in_polygon(f, cx, cy):
                f.lon, f.lat = cx, cy
                return
        # المركز خارج المضلع: أعرض مقطع أفقي عبر منتصف الصندوق
        bb = bbox(f)
        best_w, bx, by = -1.0, r[0][0], r[0][1]
        for pas in range(3):
            y = bb[1] + (bb[3] - bb[1]) * (0.5 + (pas - 1) * 0.2)
            xs = []
            for ring in f.parts:
                m = len(ring)
                j = m - 1
                for i in range(m):
                    yi, yj = ring[i][1], ring[j][1]
                    if (yi > y) != (yj > y):
                        xi, xj = ring[i][0], ring[j][0]
                        xs.append((xj - xi) * (y - yi) / (yj - yi) + xi)
                    j = i
            xs.sort()
            for k in range(0, len(xs) - 1, 2):
                w = xs[k + 1] - xs[k]
                if w > best_w:
                    best_w, bx, by = w, (xs[k] + xs[k + 1]) / 2, y
        f.lon, f.lat = bx, by


def decimate(p: Ring, maximum: int) -> List[Tuple[float, float]]:
    n = len(p)
    if n <= maximum or maximum < 2:
        return list(p)
    return [p[round(i * (n - 1) / (maximum - 1))] for i in range(maximum)]


def _same(a, b) -> bool:
    return abs(a[0] - b[0]) < 1e-9 and abs(a[1] - b[1]) < 1e-9


def build_rings(ways: Sequence[Ring]) -> List[List[Tuple[float, float]]]:
    """يربط أجزاء الطرق طرفاً بطرف في حلقات مغلقة؛ الأجزاء المفتوحة تُهمل."""
    rest = [list(w) for w in ways if w is not None and len(w) >= 2]
    rings = []
    while rest:
        cur = rest.pop(0)
        progress = True
        while progress and not _same(cur[0], cur[-1]):
            progress = False
            for k, w in enumerate(rest):
                add = None
                if _same(cur[-1], w[0]):
                    add = w
                elif _same(cur[-1], w[-1]):
                    add = w[::-1]
                if add is not None:
                    cur = cur + add[1:]
                    rest.pop(k)
                    progress = True
                    break
        if _same(cur[0], cur[-1]) and len(cur) >= 4:
            rings.append(cur)
    return rings


class AreaSpec:
    """منطقة التنزيل: مستطيل أو دائرة أو مستطيل مدوَّر."""

    def __init__(self, south, west, north, east, circle=False, clat=None, clon=None, radius=0.0):
        self.south, self.west, self.north, self.east = south, west, north, east
        self.circle = circle
        self.clat = (south + north) / 2 if clat is None else clat
        self.clon = (west + east) / 2 if clon is None else clon
        self.radius = radius
        self.rot = self.rw = self.rh = 0.0
        self.corners: Optional[List[Tuple[float, float]]] = None  # (lon,lat)x4 عند التدوير

    @staticmethod
    def rect(s, w, n, e) -> "AreaSpec":
        return AreaSpec(s, w, n, e)

    @staticmethod
    def make_circle(lat, lon, radius_m) -> "AreaSpec":
        s, w, n, e = rect_around(lat, lon, radius_m * 2, radius_m * 2)
        return AreaSpec(s, w, n, e, True, lat, lon, radius_m)

    @staticmethod
    def centered(lat, lon, w_m, h_m) -> "AreaSpec":
        return AreaSpec.rect(*rect_around(lat, lon, w_m, h_m))

    @staticmethod
    def rotated(lat, lon, w_m, h_m, deg) -> "AreaSpec":
        d = ((deg % 360) + 360) % 360
        if d < 1e-9:
            return AreaSpec.centered(lat, lon, w_m, h_m)
        m_lat = 111320.0
        m_lon = 111320.0 * max(0.05, math.cos(math.radians(lat)))
        c, s = math.cos(math.radians(d)), math.sin(math.radians(d))
        corners = []
        for x, y in [(-w_m / 2, h_m / 2), (w_m / 2, h_m / 2), (w_m / 2, -h_m / 2), (-w_m / 2, -h_m / 2)]:
            e, n = x * c + y * s, -x * s + y * c
            corners.append((lon + e / m_lon, lat + n / m_lat))
        a = AreaSpec(min(p[1] for p in corners), min(p[0] for p in corners),
                     max(p[1] for p in corners), max(p[0] for p in corners), False, lat, lon, 0.0)
        a.rot, a.rw, a.rh, a.corners = d, w_m, h_m, corners
        return a

    def is_rotated(self) -> bool:
        return self.corners is not None

    def width_m(self) -> float:
        if self.corners:
            return self.rw
        return self.radius * 2 if self.circle else haversine(self.clat, self.west, self.clat, self.east)

    def height_m(self) -> float:
        if self.corners:
            return self.rh
        return self.radius * 2 if self.circle else haversine(self.south, self.clon, self.north, self.clon)

    def area_km2(self) -> float:
        if self.circle:
            return math.pi * self.radius ** 2 / 1e6
        return self.width_m() * self.height_m() / 1e6

    def overpass(self) -> str:
        """فلتر منطقة Overpass."""
        if self.circle:
            return "(around:%.0f,%.6f,%.6f)" % (self.radius, self.clat, self.clon)
        if self.corners:
            return '(poly:"' + " ".join("%.6f %.6f" % (lat, lon) for lon, lat in self.corners) + '")'
        return "(%.6f,%.6f,%.6f,%.6f)" % (self.south, self.west, self.north, self.east)

    def contains(self, lat: float, lon: float) -> bool:
        if self.circle:
            return haversine(self.clat, self.clon, lat, lon) <= self.radius * 1.0005
        if self.corners:
            m_lat = 111320.0
            m_lon = 111320.0 * max(0.05, math.cos(math.radians(self.clat)))
            e, n = (lon - self.clon) * m_lon, (lat - self.clat) * m_lat
            c, s = math.cos(math.radians(self.rot)), math.sin(math.radians(self.rot))
            x, y = e * c - n * s, e * s + n * c
            return abs(x) <= self.rw / 2 * 1.0005 and abs(y) <= self.rh / 2 * 1.0005
        return self.south <= lat <= self.north and self.west <= lon <= self.east
