"""أدوات التحليل المكاني وتحرير الحقول (بايثون صرف؛ بعض الأدوات تستفيد من shapely/scipy إن وُجدا)."""
from __future__ import annotations

import math
import random
import re
from collections import Counter, OrderedDict, defaultdict
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from . import sectors
from .geo import (AreaSpec, R, circle_ring, haversine, in_polygon, path_length, polygon_area_m2, ring_area_m2,
                  set_representative)
from .model import LINE, POINT, POLYGON, Feature, Layer
from .sectors import norm_name

FIELD_NAMES = ["name", "type", "Gategory", "gathaa", "Nahia", "mohafadha"]


def field_value(f: Feature, idx: int) -> str:
    return [f.name, f.type, f.category, f.qadaa, f.nahiya, f.governorate][idx] or ""


def _set(f: Feature, idx: int, v: str) -> None:
    if idx == 0:
        f.name = v
    elif idx == 1:
        f.type = v
    elif idx == 2:
        f.category = v
    elif idx == 3:
        f.qadaa = v
    elif idx == 4:
        f.nahiya = v
    else:
        f.governorate = v


def _new_layer(src: Layer, label: str, geom: int, feats=None) -> Layer:
    return Layer(f"{src.id}_{abs(hash(label)) % 10**6}", label, geom, list(feats or []), kind="user")


def _points(src: Layer) -> List[Feature]:
    return [f for f in src.features if f.geom == POINT and f.parts]


class Plane:
    """إسقاط مستوٍ محلي (أمتار) حول مركز مجموعة نقاط، لحسابات المسافة السريعة."""

    def __init__(self, lat0: float, lon0: float):
        self.lat0, self.lon0 = lat0, lon0
        self.kx = math.radians(1) * R * math.cos(math.radians(lat0))
        self.ky = math.radians(1) * R

    @staticmethod
    def around(pts: Sequence[Feature]) -> "Plane":
        if not pts:
            return Plane(0, 0)
        return Plane(sum(p.lat for p in pts) / len(pts), sum(p.lon for p in pts) / len(pts))

    def x(self, lon):
        return (lon - self.lon0) * self.kx

    def y(self, lat):
        return (lat - self.lat0) * self.ky

    def lon(self, x):
        return self.lon0 + x / self.kx

    def lat(self, y):
        return self.lat0 + y / self.ky


# ---------------------------------------------------------------------------- تصفية وتلخيص
MATCH_CONTAINS, MATCH_EQUALS, MATCH_STARTS, MATCH_EMPTY, MATCH_NOT_EMPTY = "contains", "equals", "starts", "empty", "not_empty"


def filter_layer(src: Layer, field_idx: int, text: str = "", mode: str = MATCH_CONTAINS) -> Layer:
    t = norm_name(text)
    out = []
    for f in src.features:
        v = field_value(f, field_idx)
        nv = norm_name(v)
        ok = {MATCH_CONTAINS: t in nv, MATCH_EQUALS: nv == t, MATCH_STARTS: nv.startswith(t),
              MATCH_EMPTY: not v.strip(), MATCH_NOT_EMPTY: bool(v.strip())}[mode]
        if ok:
            out.append(f.copy())
    return _new_layer(src, f"{src.label} — {FIELD_NAMES[field_idx]}", src.geom, out)


def summarize(src: Layer, field_idx: int) -> "OrderedDict[str, int]":
    c = Counter((field_value(f, field_idx).strip() or "(فارغ)") for f in src.features)
    return OrderedDict(sorted(c.items(), key=lambda kv: (-kv[1], kv[0])))


def summary_text(src: Layer, field_idx: int) -> str:
    s = summarize(src, field_idx)
    return "\n".join(f"{k}: {v}" for k, v in s.items()) + f"\n— المجموع: {sum(s.values())}"


def within_radius(src: Layer, lat: float, lon: float, radius_m: float) -> Layer:
    out = []
    for f in src.features:
        d = haversine(lat, lon, f.lat, f.lon)
        if d <= radius_m:
            g = f.copy()
            g.attrs["distance_m"] = str(round(d))
            out.append(g)
    out.sort(key=lambda g: float(g.attrs["distance_m"]))
    return _new_layer(src, f"{src.label} — ضمن {int(radius_m)} م", src.geom, out)


def centroids(src: Layer) -> Layer:
    out = []
    for f in src.features:
        g = Feature.point(f.lat, f.lon, id=Feature.new_id(), name=f.name, type=f.type, category=f.category,
                          qadaa=f.qadaa, nahiya=f.nahiya, governorate=f.governorate)
        g.attrs.update(f.attrs)
        out.append(g)
    return _new_layer(src, f"{src.label} — مراكز", POINT, out)


def density_grid(src: Layer, cell_m: float, keep_empty: bool = False) -> Layer:
    pts = _points(src)
    if cell_m <= 0:
        raise ValueError("حجم الخلية يجب أن يكون موجباً")
    if not pts:
        return _new_layer(src, f"{src.label} — كثافة", POLYGON)
    pl = Plane.around(pts)
    cnt: Dict[Tuple[int, int], int] = Counter((math.floor(pl.x(p.lon) / cell_m), math.floor(pl.y(p.lat) / cell_m)) for p in pts)
    keys = list(cnt)
    if keep_empty:
        xs, ys = [k[0] for k in keys], [k[1] for k in keys]
        keys = [(i, j) for i in range(min(xs), max(xs) + 1) for j in range(min(ys), max(ys) + 1)]
        if len(keys) > 200000:
            raise ValueError("الشبكة كبيرة جداً")
    out = []
    for i, j in keys:
        x0, y0 = i * cell_m, j * cell_m
        ring = [(pl.lon(x0), pl.lat(y0)), (pl.lon(x0 + cell_m), pl.lat(y0)), (pl.lon(x0 + cell_m), pl.lat(y0 + cell_m)),
                (pl.lon(x0), pl.lat(y0 + cell_m)), (pl.lon(x0), pl.lat(y0))]
        f = Feature(geom=POLYGON, id=Feature.new_id(), name=str(cnt.get((i, j), 0)))
        f.add_part(ring)
        f.attrs["count"] = str(cnt.get((i, j), 0))
        set_representative(f)
        out.append(f)
    return _new_layer(src, f"{src.label} — شبكة كثافة {int(cell_m)} م", POLYGON, out)


# ---------------------------------------------------------------------------- DBSCAN
@dataclass
class Cluster:
    members: List[Feature] = field(default_factory=list)
    lat: float = 0.0
    lon: float = 0.0


def clusters(src: Layer, eps_m: float, min_pts: int) -> List[Cluster]:
    """DBSCAN: النقطة ذات min_pts جيران على الأقل (بما فيها نفسها) ضمن eps_m تُكوّن نواة تجمّع."""
    pts = _points(src)
    if not eps_m > 0:
        raise ValueError("المسافة يجب أن تكون موجبة")
    if min_pts < 2:
        raise ValueError("أقل عدد نقاط 2")
    if len(pts) > 50000:
        raise ValueError("أكثر من 50000 نقطة: صفّ الطبقة أولاً")
    pl = Plane.around(pts)
    xs = [pl.x(p.lon) for p in pts]
    ys = [pl.y(p.lat) for p in pts]
    grid: Dict[Tuple[int, int], List[int]] = defaultdict(list)
    for i in range(len(pts)):
        grid[(math.floor(xs[i] / eps_m), math.floor(ys[i] / eps_m))].append(i)

    def neigh(i):
        cx, cy = math.floor(xs[i] / eps_m), math.floor(ys[i] / eps_m)
        r = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for j in grid.get((cx + dx, cy + dy), ()):
                    if (xs[i] - xs[j]) ** 2 + (ys[i] - ys[j]) ** 2 <= eps_m * eps_m:
                        r.append(j)
        return r

    label = [0] * len(pts)    # 0 غير مزور، -1 ضجيج، >0 رقم التجمع
    cid = 0
    for i in range(len(pts)):
        if label[i] != 0:
            continue
        nb = neigh(i)
        if len(nb) < min_pts:
            label[i] = -1
            continue
        cid += 1
        label[i] = cid
        queue = list(nb)
        k = 0
        while k < len(queue):
            j = queue[k]
            k += 1
            if label[j] == -1:
                label[j] = cid
            if label[j] != 0:
                continue
            label[j] = cid
            nb2 = neigh(j)
            if len(nb2) >= min_pts:
                queue.extend(nb2)
    out = [Cluster() for _ in range(cid)]
    for i, l in enumerate(label):
        if l > 0:
            out[l - 1].members.append(pts[i])
    for c in out:
        c.lat = sum(m.lat for m in c.members) / len(c.members)
        c.lon = sum(m.lon for m in c.members) / len(c.members)
    out.sort(key=lambda c: -len(c.members))
    return out


def convex_hull(points: Sequence[Tuple[float, float]]) -> List[Tuple[float, float]]:
    pts = sorted(set(points))
    if len(pts) <= 2:
        return pts
    cross = lambda o, a, b: (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo, up = [], []
    for p in pts:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], p) <= 0:
            lo.pop()
        lo.append(p)
    for p in reversed(pts):
        while len(up) >= 2 and cross(up[-2], up[-1], p) <= 0:
            up.pop()
        up.append(p)
    return lo[:-1] + up[:-1]


def cluster_layers(src: Layer, eps_m: float, min_pts: int, hulls: bool = True) -> List[Layer]:
    cl = clusters(src, eps_m, min_pts)
    centres = []
    polys = []
    for k, c in enumerate(cl, 1):
        f = Feature.point(c.lat, c.lon, id=Feature.new_id(), name=f"تجمع {k} — {len(c.members)}")
        f.attrs["count"] = str(len(c.members))
        centres.append(f)
        if hulls and len(c.members) >= 3:
            h = convex_hull([(m.lon, m.lat) for m in c.members])
            if len(h) >= 3:
                p = Feature(geom=POLYGON, id=Feature.new_id(), name=f"تجمع {k}")
                p.add_part(h + [h[0]])
                p.attrs["count"] = str(len(c.members))
                set_representative(p)
                polys.append(p)
    out = [_new_layer(src, f"{src.label} — مراكز التجمعات", POINT, centres)]
    if hulls:
        out.append(_new_layer(src, f"{src.label} — حدود التجمعات", POLYGON, polys))
    return out


# ---------------------------------------------------------------------------- أقرب جار
@dataclass
class NN:
    n: int = 0
    mean_observed_m: float = 0.0
    mean_expected_m: float = 0.0
    ratio: float = 0.0
    z: float = 0.0
    pattern: str = ""


def nearest_neighbour(src: Layer) -> NN:
    """مؤشر أقرب جار (Clark–Evans): <1 متجمع، ≈1 عشوائي، >1 متباعد."""
    pts = _points(src)
    n = len(pts)
    if n < 3:
        raise ValueError("يلزم 3 نقاط على الأقل")
    pl = Plane.around(pts)
    xs = [pl.x(p.lon) for p in pts]
    ys = [pl.y(p.lat) for p in pts]
    try:
        import numpy as np
        from scipy.spatial import cKDTree  # type: ignore
        d, _ = cKDTree(np.column_stack([xs, ys])).query(np.column_stack([xs, ys]), k=2)
        obs = float(d[:, 1].mean())
    except ImportError:
        tot = 0.0
        for i in range(n):
            tot += min(math.hypot(xs[i] - xs[j], ys[i] - ys[j]) for j in range(n) if j != i)
        obs = tot / n
    hull = convex_hull(list(zip(xs, ys)))
    area = abs(sum(hull[i][0] * hull[(i + 1) % len(hull)][1] - hull[(i + 1) % len(hull)][0] * hull[i][1]
                   for i in range(len(hull)))) / 2 if len(hull) >= 3 else 0.0
    if area <= 0:
        raise ValueError("النقاط على خط واحد")
    exp = 0.5 / math.sqrt(n / area)
    se = 0.26136 / math.sqrt(n * n / area)
    z = (obs - exp) / se
    ratio = obs / exp
    pat = "متجمع" if ratio < 1 and z < -1.96 else "متباعد" if ratio > 1 and z > 1.96 else "عشوائي"
    return NN(n, obs, exp, ratio, z, pat)


# ---------------------------------------------------------------------------- هندسة مشتقة
def extent(layer: Layer):
    xs = [p[0] for f in layer.features for part in f.parts for p in part]
    ys = [p[1] for f in layer.features for part in f.parts for p in part]
    return (min(xs), min(ys), max(xs), max(ys)) if xs else None


def bounding_rectangles(src: Layer, per_feature: bool = False) -> Layer:
    def rect(b, name):
        f = Feature(geom=POLYGON, id=Feature.new_id(), name=name)
        f.add_part([(b[0], b[1]), (b[2], b[1]), (b[2], b[3]), (b[0], b[3]), (b[0], b[1])])
        set_representative(f)
        return f
    out = []
    if per_feature:
        for f in src.features:
            xs = [p[0] for part in f.parts for p in part]
            ys = [p[1] for part in f.parts for p in part]
            if xs:
                out.append(rect((min(xs), min(ys), max(xs), max(ys)), f.name))
    else:
        b = extent(src)
        if b:
            out.append(rect(b, src.label))
    return _new_layer(src, f"{src.label} — مستطيل محيط", POLYGON, out)


def point_path(src: Layer, polygon: bool = False, sort_by_name: bool = False) -> Layer:
    pts = _points(src)
    if sort_by_name:
        pts = sorted(pts, key=lambda p: norm_name(p.name))
    if len(pts) < (3 if polygon else 2):
        raise ValueError("عدد النقاط غير كافٍ")
    c = [(p.lon, p.lat) for p in pts]
    f = Feature(geom=POLYGON if polygon else LINE, id=Feature.new_id(), name=src.label)
    f.add_part(c + [c[0]] if polygon else c)
    set_representative(f)
    return _new_layer(src, f"{src.label} — {'مضلع' if polygon else 'خط'} من النقاط", f.geom, [f])


def _dp(pts: List[Tuple[float, float]], tol: float, pl: Plane) -> List[Tuple[float, float]]:
    """Douglas–Peucker (تكراري)."""
    if len(pts) < 3:
        return pts
    keep = [False] * len(pts)
    keep[0] = keep[-1] = True
    stack = [(0, len(pts) - 1)]
    xy = [(pl.x(p[0]), pl.y(p[1])) for p in pts]
    while stack:
        a, b = stack.pop()
        ax, ay = xy[a]
        bx, by = xy[b]
        dx, dy = bx - ax, by - ay
        L = dx * dx + dy * dy
        best, idx = -1.0, -1
        for i in range(a + 1, b):
            px, py = xy[i]
            if L == 0:
                d = math.hypot(px - ax, py - ay)
            else:
                t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / L))
                d = math.hypot(px - ax - t * dx, py - ay - t * dy)
            if d > best:
                best, idx = d, i
        if best > tol:
            keep[idx] = True
            stack += [(a, idx), (idx, b)]
    return [p for p, k in zip(pts, keep) if k]


def simplify_layer(src: Layer, tolerance_m: float) -> Layer:
    out = []
    for f in src.features:
        if f.geom == POINT:
            out.append(f.copy())
            continue
        g = f.copy()
        pl = Plane(f.lat, f.lon)
        for i, p in enumerate(g.parts):
            s = _dp(p, tolerance_m, pl)
            if f.geom == POLYGON and len(s) < 4:
                continue
            g.parts[i] = s
        set_representative(g)
        out.append(g)
    return _new_layer(src, f"{src.label} — مبسّط {tolerance_m:g} م", src.geom, out)


def merge(layers: Sequence[Layer], label: str) -> Layer:
    geoms = {l.geom for l in layers}
    if len(geoms) != 1:
        raise ValueError("يجب أن تكون الطبقات من نوع هندسة واحد")
    out = Layer("merged_" + str(abs(hash(label)) % 10**6), label, geoms.pop(), kind="user")
    for l in layers:
        for f in l.features:
            g = f.copy()
            g.id = Feature.new_id()
            out.features.append(g)
    return out


# ---------------------------------------------------------------------------- توليد
def multi_ring(src: Layer, distances_m: Sequence[float]) -> Layer:
    """حلقات (Buffer) متعددة حول النقاط."""
    out = []
    for f in _points(src):
        for d in sorted(distances_m, reverse=True):
            p = Feature(geom=POLYGON, id=Feature.new_id(), name=f"{f.name} — {d:g} م")
            p.add_part(circle_ring(f.lat, f.lon, d, 64))
            p.attrs["radius_m"] = f"{d:g}"
            set_representative(p)
            out.append(p)
    return _new_layer(src, f"{src.label} — حلقات", POLYGON, out)


def along_lines(src: Layer, interval_m: float, include_ends: bool = True) -> Layer:
    if interval_m <= 0:
        raise ValueError("المسافة يجب أن تكون موجبة")
    out = []
    for f in src.features:
        if f.geom != LINE:
            continue
        for p in f.parts:
            total, acc, nxt = path_length(p), 0.0, 0.0 if include_ends else interval_m
            pts = []
            for i in range(1, len(p)):
                seg = haversine(p[i - 1][1], p[i - 1][0], p[i][1], p[i][0])
                while nxt <= acc + seg + 1e-9 and seg > 0:
                    t = (nxt - acc) / seg
                    pts.append((p[i - 1][0] + (p[i][0] - p[i - 1][0]) * t, p[i - 1][1] + (p[i][1] - p[i - 1][1]) * t))
                    nxt += interval_m
                acc += seg
            if include_ends and total > 0 and (not pts or haversine(pts[-1][1], pts[-1][0], p[-1][1], p[-1][0]) > 0.5):
                pts.append(p[-1])
            for x, y in pts:
                q = Feature.point(y, x, id=Feature.new_id(), name=f.name)
                out.append(q)
    return _new_layer(src, f"{src.label} — نقاط على الخطوط", POINT, out)


def vertices(src: Layer) -> Layer:
    out = []
    for f in src.features:
        for p in f.parts:
            for x, y in (p[:-1] if f.geom == POLYGON else p):
                out.append(Feature.point(y, x, id=Feature.new_id(), name=f.name))
    return _new_layer(src, f"{src.label} — رؤوس", POINT, out)


def boundaries(src: Layer) -> Layer:
    out = []
    for f in src.features:
        if f.geom != POLYGON:
            continue
        g = Feature(geom=LINE, id=Feature.new_id(), name=f.name)
        for p in f.parts:
            g.add_part(p)
        set_representative(g)
        out.append(g)
    return _new_layer(src, f"{src.label} — حدود", LINE, out)


def explode(src: Layer) -> Layer:
    out = []
    for f in src.features:
        if f.geom == POINT or len(f.parts) <= 1:
            out.append(f.copy())
            continue
        if f.geom == LINE:
            for p in f.parts:
                g = f.copy()
                g.id = Feature.new_id()
                g.parts, g.holes = [p], [False]
                set_representative(g)
                out.append(g)
        else:
            cur = None
            for i, p in enumerate(f.parts):
                if f.is_hole(i) and cur is not None:
                    cur.add_part(p, True)
                else:
                    cur = f.copy()
                    cur.id = Feature.new_id()
                    cur.parts, cur.holes = [p], [False]
                    out.append(cur)
            for g in out[-len([1 for i in range(len(f.parts)) if not f.is_hole(i)]):]:
                set_representative(g)
    return _new_layer(src, f"{src.label} — مفكّك", src.geom, out)


def _pip_any(polys: Sequence[Feature], lon: float, lat: float) -> bool:
    return any(in_polygon(p, lon, lat) for p in polys)


def random_points(poly_layer: Layer, n: int, seed: int = 1) -> Layer:
    polys = [f for f in poly_layer.features if f.geom == POLYGON]
    b = extent(Layer("t", "t", POLYGON, polys))
    if not polys or not b:
        raise ValueError("لا توجد مضلعات")
    rnd = random.Random(seed)
    out, tries = [], 0
    while len(out) < n and tries < n * 200:
        tries += 1
        x, y = rnd.uniform(b[0], b[2]), rnd.uniform(b[1], b[3])
        if _pip_any(polys, x, y):
            out.append(Feature.point(y, x, id=Feature.new_id(), name=f"R-{len(out) + 1}"))
    return _new_layer(poly_layer, f"{poly_layer.label} — نقاط عشوائية", POINT, out)


def regular_points(poly_layer: Layer, spacing_m: float) -> Layer:
    polys = [f for f in poly_layer.features if f.geom == POLYGON]
    b = extent(Layer("t", "t", POLYGON, polys))
    if not polys or not b:
        raise ValueError("لا توجد مضلعات")
    pl = Plane((b[1] + b[3]) / 2, (b[0] + b[2]) / 2)
    x0, x1, y0, y1 = pl.x(b[0]), pl.x(b[2]), pl.y(b[1]), pl.y(b[3])
    if ((x1 - x0) / spacing_m + 1) * ((y1 - y0) / spacing_m + 1) > 500000:
        raise ValueError("الشبكة كبيرة جداً")
    out = []
    y = y0
    while y <= y1:
        x = x0
        while x <= x1:
            lon, lat = pl.lon(x), pl.lat(y)
            if _pip_any(polys, lon, lat):
                out.append(Feature.point(lat, lon, id=Feature.new_id(), name=f"G-{len(out) + 1}"))
            x += spacing_m
        y += spacing_m
    return _new_layer(poly_layer, f"{poly_layer.label} — نقاط منتظمة", POINT, out)


def dissolve_by(src: Layer, field_idx: int) -> Layer:
    """دمج حسب حقل: يجمع أجزاء الميزات ذات القيمة نفسها في ميزة واحدة متعددة الأجزاء."""
    groups: "OrderedDict[str, Feature]" = OrderedDict()
    for f in src.features:
        key = field_value(f, field_idx)
        g = groups.get(key)
        if g is None:
            g = f.copy()
            g.id = Feature.new_id()
            _set(g, field_idx, key)
            groups[key] = g
        else:
            for i, p in enumerate(f.parts):
                g.add_part(p, f.is_hole(i))
    for g in groups.values():
        set_representative(g)
    return _new_layer(src, f"{src.label} — دمج حسب {FIELD_NAMES[field_idx]}", src.geom, groups.values())


def hull_by(src: Layer, field_idx: int) -> Layer:
    groups: Dict[str, List[Tuple[float, float]]] = defaultdict(list)
    for f in src.features:
        for p in f.parts:
            groups[field_value(f, field_idx)].extend(p)
    out = []
    for k, pts in groups.items():
        h = convex_hull(pts)
        if len(h) >= 3:
            f = Feature(geom=POLYGON, id=Feature.new_id(), name=k)
            f.add_part(h + [h[0]])
            set_representative(f)
            out.append(f)
    return _new_layer(src, f"{src.label} — أغلفة حسب {FIELD_NAMES[field_idx]}", POLYGON, out)


def mean_centre(src: Layer) -> Feature:
    pts = _points(src) or list(src.features)
    if not pts:
        raise ValueError("طبقة فارغة")
    lat = sum(p.lat for p in pts) / len(pts)
    lon = sum(p.lon for p in pts) / len(pts)
    return Feature.point(lat, lon, id=Feature.new_id(), name="المركز الوسطي")


# ---------------------------------------------------------------------------- طبقتان
def count_in_polygons(points: Layer, polys: Layer) -> Layer:
    out = []
    pts = _points(points)
    for p in polys.features:
        if p.geom != POLYGON:
            continue
        g = p.copy()
        g.attrs["count"] = str(sum(1 for q in pts if in_polygon(p, q.lon, q.lat)))
        out.append(g)
    return _new_layer(polys, f"{polys.label} — عدّ", POLYGON, out)


def nearest_join(a: Layer, b: Layer) -> Layer:
    """يضيف لكل نقطة في a أقرب ميزة في b (الاسم والمسافة)."""
    out = []
    for f in _points(a):
        best, bd = None, float("inf")
        for g in b.features:
            d = haversine(f.lat, f.lon, g.lat, g.lon)
            if d < bd:
                best, bd = g, d
        h = f.copy()
        if best is not None:
            h.attrs["nearest_name"] = best.name
            h.attrs["nearest_m"] = str(round(bd))
        out.append(h)
    return _new_layer(a, f"{a.label} — أقرب", POINT, out)


def within_distance_of(a: Layer, b: Layer, radius_m: float) -> Layer:
    out = [f.copy() for f in a.features if any(haversine(f.lat, f.lon, g.lat, g.lon) <= radius_m for g in b.features)]
    return _new_layer(a, f"{a.label} — ضمن {radius_m:g} م من {b.label}", a.geom, out)


def erase_points(a: Layer, polys: Layer) -> Layer:
    pp = [f for f in polys.features if f.geom == POLYGON]
    return _new_layer(a, f"{a.label} — محو", a.geom, [f.copy() for f in a.features if not _pip_any(pp, f.lon, f.lat)])


def intersect_points(a: Layer, polys: Layer) -> Layer:
    pp = [f for f in polys.features if f.geom == POLYGON]
    return _new_layer(a, f"{a.label} — تقاطع", a.geom, [f.copy() for f in a.features if _pip_any(pp, f.lon, f.lat)])


def extract(src: Layer, area: AreaSpec, label: Optional[str] = None) -> Layer:
    """استخراج عناصر طبقة تقع نقطتها التمثيلية داخل منطقة (مستطيل/دائرة/مدور)."""
    return _new_layer(src, label or f"{src.label} — مستخرج", src.geom,
                      [f.copy() for f in src.features if area.contains(f.lat, f.lon)])


def thiessen(src: Layer) -> Layer:
    """مضلعات ثيسن (فورونوي) — تحتاج scipy، وتُقصّ بصندوق محيط موسّع."""
    try:
        import numpy as np
        from scipy.spatial import Voronoi  # type: ignore
    except ImportError as e:
        raise RuntimeError("مضلعات ثيسن تحتاج scipy") from e
    pts = _points(src)
    if len(pts) < 3:
        raise ValueError("يلزم 3 نقاط على الأقل")
    pl = Plane.around(pts)
    xy = np.array([[pl.x(p.lon), pl.y(p.lat)] for p in pts])
    # نقاط حارسة بعيدة تجعل كل الخلايا الداخلية محدودة
    span = max(np.ptp(xy[:, 0]), np.ptp(xy[:, 1]), 1.0) * 10
    cx, cy = xy.mean(axis=0)
    guards = np.array([[cx - span, cy - span], [cx + span, cy - span], [cx + span, cy + span], [cx - span, cy + span]])
    vor = Voronoi(np.vstack([xy, guards]))
    out = []
    for i, p in enumerate(pts):
        reg = vor.regions[vor.point_region[i]]
        if not reg or -1 in reg:
            continue
        ring = [(pl.lon(vor.vertices[v][0]), pl.lat(vor.vertices[v][1])) for v in reg]
        f = Feature(geom=POLYGON, id=Feature.new_id(), name=p.name)
        f.add_part(ring + [ring[0]])
        set_representative(f)
        out.append(f)
    return _new_layer(src, f"{src.label} — ثيسن", POLYGON, out)


# ---------------------------------------------------------------------------- تحرير جماعي (تُرجع أزواج (قبل، بعد))
@dataclass
class Edits:
    pairs: List[Tuple[Feature, Feature]] = field(default_factory=list)
    skipped: int = 0
    note: str = ""

    def apply_in_place(self, feats: Sequence[Feature]) -> int:
        """يطبّق التعديلات على القوائم الأصلية (المطابقة بالمعرّف). يرجع عدد ما تغيّر."""
        by = {a.id: a for _, a in self.pairs}
        n = 0
        for i, f in enumerate(feats):
            a = by.get(f.id)
            if a is not None:
                feats[i] = a
                n += 1
        return n


def auto_sector(fs: Sequence[Feature], overwrite: bool = False) -> Edits:
    """يضبط Gategory من type إذا انتمى النوع لقطاع واحد فقط؛ الغامض أو المجهول يُتخطى."""
    e, amb, unk = Edits(), 0, 0
    for f in fs:
        if f.geom != POINT or (not overwrite and f.category.strip()):
            continue
        s = sectors.all_of_item(f.type)
        if not s:
            unk += bool(f.type.strip())
            e.skipped += 1
            continue
        if len(s) > 1:
            amb += 1
            e.skipped += 1
            continue
        if s[0].name == f.category:
            continue
        a = f.copy()
        a.category = s[0].name
        e.pairs.append((f.copy(), a))
    e.note = f"غامض (يقع في أكثر من قطاع): {amb} — نوع غير معروف: {unk}"
    return e


def set_field(fs: Sequence[Feature], idx: int, value: str, only_empty: bool = False) -> Edits:
    if not 0 <= idx <= 5:
        raise ValueError("حقل غير صالح")
    e = Edits()
    for f in fs:
        cur = field_value(f, idx)
        if (only_empty and cur.strip()) or cur == value:
            continue
        a = f.copy()
        _set(a, idx, value)
        e.pairs.append((f.copy(), a))
    return e


def replace_text(fs: Sequence[Feature], idx: int, find: str, repl: str = "") -> Edits:
    if not 0 <= idx <= 5:
        raise ValueError("حقل غير صالح")
    if not find:
        raise ValueError("اكتب النص المراد استبداله")
    e = Edits()
    for f in fs:
        cur = field_value(f, idx)
        if find not in cur:
            continue
        a = f.copy()
        _set(a, idx, cur.replace(find, repl or ""))
        e.pairs.append((f.copy(), a))
    return e


def clean_string(s: Optional[str]) -> str:
    """يوحّد صيغ الحروف العربية (ى→ي، ک→ك)، يزيل التطويل والمسافات الصفرية ويضغط المسافات."""
    if not s:
        return ""
    out = []
    for c in s:
        if c in "ىی":
            c = "ي"
        elif c == "ک":
            c = "ك"
        elif c in "ـ\u200c\u200b":
            continue
        elif c == "\u00a0":
            c = " "
        out.append(c)
    return re.sub(r"\s+", " ", "".join(out).strip())


def clean_text(fs: Sequence[Feature]) -> Edits:
    e = Edits()
    for f in fs:
        a, ch = f.copy(), False
        for i in range(6):
            cur = field_value(f, i)
            cl = clean_string(cur)
            if cur != cl:
                _set(a, i, cl)
                ch = True
        if ch:
            e.pairs.append((f.copy(), a))
    return e


def feature_area_m2(f: Feature) -> float:
    return polygon_area_m2(f)


def feature_perimeter_m(f: Feature) -> float:
    return sum(path_length(p) for p in f.parts)


def feature_length_m(f: Feature) -> float:
    return sum(path_length(p) for p in f.parts)


def add_measures(fs: Sequence[Feature]) -> Edits:
    e = Edits()
    for f in fs:
        if f.geom == POINT:
            e.skipped += 1
            continue
        a = f.copy()
        if f.geom == POLYGON:
            a.attrs["area_m2"] = str(round(feature_area_m2(f)))
            a.attrs["perimeter_m"] = str(round(feature_perimeter_m(f)))
        else:
            a.attrs["length_m"] = str(round(feature_length_m(f)))
        e.pairs.append((f.copy(), a))
    return e


# ---------------------------------------------------------------------------- تنسيق قياسات
def _digits(s: str) -> str:
    t = {ord(str(i)): "٠١٢٣٤٥٦٧٨٩"[i] for i in range(10)}
    t[ord(".")], t[ord(",")] = "٫", "٬"
    return s.translate(t)


def format_area(m2: float, arabic_digits: bool = False) -> str:
    a = f"{m2:,.{0 if m2 >= 100 else 2}f} m²"
    h = f"{m2 / 10000:,.4f}".rstrip("0").rstrip(".") + " ha"
    k = f"{m2 / 1e6:,.{2 if m2 >= 1e8 else 6}f}".rstrip("0").rstrip(".") + " km²"
    s = f"{a} = {h} = {k}"
    return _digits(s) if arabic_digits else s


def format_length(m: float, arabic_digits: bool = False) -> str:
    if m >= 10000:
        s = f"{m / 1000:,.2f} km"
    elif m >= 1000:
        s = f"{m / 1000:,.3f} km"
    elif m >= 100:
        s = f"{m:,.1f} m"
    else:
        s = f"{m:,.2f} m"
    return _digits(s) if arabic_digits else s
