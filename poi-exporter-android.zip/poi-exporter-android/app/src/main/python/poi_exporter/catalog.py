"""ما يمكن تنزيله: فئات المعالم (POI) وطبقات الخرائط الإضافية، وتوليد جمل Overpass."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

from .model import LINE, POINT, POLYGON
from .geo import AreaSpec


@dataclass(frozen=True)
class Clause:
    key: str
    values: tuple = ()

    def selector(self) -> str:
        if not self.values:
            return f'["{self.key}"]'
        return f'["{self.key}"~"^(' + "|".join(self.values) + ')$"]'

    def matches(self, tags: Dict[str, str]) -> bool:
        v = tags.get(self.key)
        if not v:
            return False
        return not self.values or v in self.values


def C(key: str, *values: str) -> Clause:
    return Clause(key, tuple(values))


@dataclass(frozen=True)
class PoiCat:
    id: str
    ar: str
    en: str
    clauses: tuple

    def label(self, arabic: bool = True) -> str:
        return self.ar if arabic else self.en


@dataclass(frozen=True)
class LayerDef:
    id: str
    ar: str
    en: str
    geom: int
    extra: str
    clauses: tuple

    def label(self, arabic: bool = True) -> str:
        return self.ar if arabic else self.en


K_POI = "poi"
K_ROADS_MAIN, K_ROADS_SEC, K_RIVERS = "roads_main", "roads_secondary", "rivers"
K_LAKES, K_DAMS, K_TOURISM = "lakes", "dams", "tourism"
K_ADMIN_GOV, K_ADMIN_QADAA, K_ADMIN_NAHIYA = "admin_gov", "admin_qadaa", "admin_nahiya"
ADMIN_IDS = [K_ADMIN_GOV, K_ADMIN_QADAA, K_ADMIN_NAHIYA]

POI: List[PoiCat] = [
    PoiCat("school", "مدارس", "Schools", (C("amenity", "school", "kindergarten"),)),
    PoiCat("university", "جامعات وكليات", "Universities and colleges", (C("amenity", "university", "college"),)),
    PoiCat("hospital", "مستشفيات", "Hospitals", (C("amenity", "hospital"),)),
    PoiCat("clinic", "عيادات ومراكز صحية", "Clinics", (C("amenity", "clinic", "doctors", "dentist"),)),
    PoiCat("pharmacy", "صيدليات", "Pharmacies", (C("amenity", "pharmacy"),)),
    PoiCat("worship", "مساجد ودور عبادة", "Places of worship", (C("amenity", "place_of_worship"),)),
    PoiCat("food", "مطاعم ومقاهي", "Restaurants and cafes", (C("amenity", "restaurant", "cafe", "fast_food"),)),
    PoiCat("bank", "مصارف", "Banks", (C("amenity", "bank"),)),
    PoiCat("fuel", "محطات وقود", "Fuel stations", (C("amenity", "fuel"),)),
    PoiCat("hotel", "فنادق", "Hotels", (C("tourism", "hotel", "guest_house", "motel"),)),
    PoiCat("police", "شرطة وأمن", "Police", (C("amenity", "police"),)),
    PoiCat("gov", "دوائر حكومية", "Government offices", (C("amenity", "townhall", "courthouse"), C("office", "government"))),
    PoiCat("shop", "متاجر وأسواق", "Shops", (C("shop"),)),
    PoiCat("market", "أسواق شعبية", "Marketplaces", (C("amenity", "marketplace"),)),
    PoiCat("sport", "ملاعب ورياضة", "Sports", (C("leisure", "stadium", "sports_centre"),)),
    PoiCat("airport", "مطارات", "Airports", (C("aeroway", "aerodrome"),)),
]

_WATER_NOT_RIVER = '["water"!~"^(river|stream|canal|ditch|drain|oxbow)$"]'

LAYERS: List[LayerDef] = [
    LayerDef(K_ROADS_MAIN, "الطرق الرئيسية", "Main roads", LINE, "",
             (C("highway", "motorway", "trunk", "primary", "motorway_link", "trunk_link", "primary_link"),)),
    LayerDef(K_ROADS_SEC, "الطرق الثانوية والفرعية", "Secondary & minor roads", LINE, "",
             (C("highway", "secondary", "tertiary", "secondary_link", "tertiary_link", "unclassified", "residential", "living_street", "road"),)),
    LayerDef(K_RIVERS, "الأنهار", "Rivers", LINE, "", (C("waterway", "river", "canal"),)),
    LayerDef(K_LAKES, "البحيرات", "Lakes", POLYGON, _WATER_NOT_RIVER, (C("natural", "water"),)),
    LayerDef(K_DAMS, "السدود", "Dams", POINT, "", (C("waterway", "dam"), C("man_made", "dam"))),
    LayerDef(K_TOURISM, "المعالم السياحية", "Tourist sites", POINT, "",
             (C("tourism", "attraction", "museum", "viewpoint", "zoo", "theme_park", "gallery"), C("historic"))),
]


def admin_label(idx: int, arabic: bool = True) -> str:
    ar = ["حدود المحافظات", "حدود الأقضية", "حدود النواحي"]
    en = ["Governorate boundaries", "District (qadaa) boundaries", "Sub-district (nahiya) boundaries"]
    return (ar if arabic else en)[idx]


def poi(cat_id: str) -> Optional[PoiCat]:
    return next((c for c in POI if c.id == cat_id), None)


def layer(layer_id: str) -> Optional[LayerDef]:
    return next((d for d in LAYERS if d.id == layer_id), None)


_OK = re.compile(r"^[A-Za-z0-9_:\-|]+$")


def custom_selector(raw: Optional[str]) -> Optional[str]:
    """يقبل key=value أو key=a|b أو key؛ None إذا فارغ."""
    if raw is None or not raw.strip():
        return None
    raw = raw.strip()
    parts = raw.split("=", 1)
    if not _OK.match(parts[0]):
        raise ValueError(f"Invalid filter: {raw}")
    if len(parts) == 1 or not parts[1]:
        return f'["{parts[0]}"]'
    if not _OK.match(parts[1]):
        raise ValueError(f"Invalid filter: {raw}")
    if "|" in parts[1]:
        return f'["{parts[0]}"~"^({parts[1]})$"]'
    return f'["{parts[0]}"="{parts[1]}"]'


def poi_statements(ids: Sequence[str], custom: str, include_unnamed: bool, area: AreaSpec) -> List[str]:
    out = []
    named = "" if include_unnamed else '["name"]'
    for i in ids:
        c = poi(i)
        if not c:
            continue
        for cl in c.clauses:
            out.append("nwr" + cl.selector() + named + area.overpass() + ";")
    cs = custom_selector(custom)
    if cs:
        out.append("nwr" + cs + named + area.overpass() + ";")
    return out
