"""ترميز/فك WKB (Well-Known Binary) للنقاط والخطوط والمضلعات وتعدداتها."""
from __future__ import annotations

import struct
from typing import List, Tuple

from .model import LINE, POINT, POLYGON, Feature
from .geo import oriented, set_representative


def encode(f: Feature) -> bytes:
    """WKB (little endian) للميزة. المضلعات: الحلقة الخارجية عكس عقارب الساعة (معيار OGC)."""
    if not f.parts:
        raise ValueError("empty geometry")
    if f.geom == POINT:
        x, y = f.parts[0][0]
        return struct.pack("<BIdd", 1, 1, x, y)
    if f.geom == LINE:
        if len(f.parts) == 1:
            return struct.pack("<BII", 1, 2, len(f.parts[0])) + b"".join(struct.pack("<dd", *p) for p in f.parts[0])
        body = b"".join(struct.pack("<BII", 1, 2, len(p)) + b"".join(struct.pack("<dd", *c) for c in p) for p in f.parts)
        return struct.pack("<BII", 1, 5, len(f.parts)) + body
    polys: List[List[List[Tuple[float, float]]]] = []
    for i, r in enumerate(f.parts):
        if f.is_hole(i) and polys:
            polys[-1].append(oriented(r, True))     # ثقب: مع عقارب الساعة
        else:
            polys.append([oriented(r, False)])      # خارجي: عكس عقارب الساعة

    def poly(rings):
        return struct.pack("<BII", 1, 3, len(rings)) + b"".join(
            struct.pack("<I", len(r)) + b"".join(struct.pack("<dd", *c) for c in r) for r in rings)

    if len(polys) == 1:
        return poly(polys[0])
    return struct.pack("<BII", 1, 6, len(polys)) + b"".join(poly(p) for p in polys)


class _R:
    def __init__(self, b: bytes):
        self.b, self.o, self.le = b, 0, True

    def u8(self):
        v = self.b[self.o]
        self.o += 1
        return v

    def u32(self):
        v = struct.unpack_from("<I" if self.le else ">I", self.b, self.o)[0]
        self.o += 4
        return v

    def pt(self, dims):
        fmt = ("<" if self.le else ">") + "d" * dims
        v = struct.unpack_from(fmt, self.b, self.o)
        self.o += 8 * dims
        return (v[0], v[1])


def _read_geom(r: _R, out: List[tuple]) -> None:
    r.le = r.u8() == 1
    t = r.u32()
    dims = 2
    if t >= 3000:
        dims, t = 4, t - 3000
    elif t >= 2000:
        dims, t = 3, t - 2000
    elif t >= 1000:
        dims, t = 3, t - 1000
    if t == 1:
        out.append((POINT, [[r.pt(dims)]], [False]))
    elif t == 2:
        n = r.u32()
        out.append((LINE, [[r.pt(dims) for _ in range(n)]], [False]))
    elif t == 3:
        n = r.u32()
        parts, holes = [], []
        for i in range(n):
            m = r.u32()
            parts.append([r.pt(dims) for _ in range(m)])
            holes.append(i > 0)
        out.append((POLYGON, parts, holes))
    elif t in (4, 5, 6, 7):
        n = r.u32()
        for _ in range(n):
            _read_geom(r, out)
    else:
        raise ValueError(f"unsupported WKB type {t}")


def decode(blob: bytes) -> List[Feature]:
    """يفك WKB إلى ميزة واحدة أو أكثر (Multi* تُدمج في ميزة واحدة بأجزاء متعددة)."""
    items: List[tuple] = []
    _read_geom(_R(blob), items)
    if not items:
        return []
    g = items[0][0]
    f = Feature(geom=g)
    for geom, parts, holes in items:
        if geom != g:
            continue
        for p, h in zip(parts, holes):
            f.add_part(p, h)
    set_representative(f)
    return [f]
