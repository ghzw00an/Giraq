"""تشكيل الحروف العربية وترتيبها بصرياً (RTL) لرسمها في PDF/PNG دون مكتبات خارجية."""
from __future__ import annotations

import unicodedata
from typing import Dict, List

# base → {'iso','fin','ini','med'} من جداول Presentation Forms-B عبر unicodedata
_FORMS: Dict[str, Dict[str, str]] = {}
for _cp in range(0xFE70, 0xFEFF):
    _c = chr(_cp)
    _d = unicodedata.decomposition(_c)
    if not _d.startswith("<"):
        continue
    _tag, _, _base = _d.partition(" ")
    if len(_base.split()) != 1:
        continue
    _key = {"<isolated>": "iso", "<final>": "fin", "<initial>": "ini", "<medial>": "med"}.get(_tag)
    if _key:
        _FORMS.setdefault(chr(int(_base, 16)), {})[_key] = _c

# ligatures لام+ألف (isolated, final)
_LAM_ALEF = {"آ": ("\uFEF5", "\uFEF6"), "أ": ("\uFEF7", "\uFEF8"), "إ": ("\uFEF9", "\uFEFA"), "ا": ("\uFEFB", "\uFEFC")}
_DIACRITICS = set(chr(c) for c in list(range(0x064B, 0x0660)) + [0x0670])
_EXTRA = {"پ": "ب", "چ": "ج", "ژ": "ز", "گ": "ك", "ک": "ك", "ی": "ي"}   # حروف فارسية → أقرب عربي لها شكل


def _is_arabic(c: str) -> bool:
    o = ord(c)
    return 0x0600 <= o <= 0x06FF or 0xFB50 <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF


def _joins_next(c: str) -> bool:
    f = _FORMS.get(c)
    return bool(f and "ini" in f)


def _joins_prev(c: str) -> bool:
    f = _FORMS.get(c)
    return bool(f and "fin" in f)


def shape(text: str) -> str:
    """يستبدل الحروف بأشكالها السياقية (ما زالت بترتيب منطقي)."""
    chars = [_EXTRA.get(c, c) for c in text]
    out: List[str] = []
    i, n = 0, len(chars)
    prev_joins = False      # هل الحرف السابق (غير الشكلي) يصل بما بعده
    while i < n:
        c = chars[i]
        if c in _DIACRITICS:
            out.append(c)
            i += 1
            continue
        if c not in _FORMS:
            out.append(c)
            prev_joins = False
            i += 1
            continue
        # اللام + الألف
        if c == "ل":
            j = i + 1
            while j < n and chars[j] in _DIACRITICS:
                j += 1
            if j < n and chars[j] in _LAM_ALEF:
                iso, fin = _LAM_ALEF[chars[j]]
                out.append(fin if prev_joins else iso)
                prev_joins = False
                i = j + 1
                continue
        # التالي (متجاوزاً التشكيل)
        j = i + 1
        while j < n and chars[j] in _DIACRITICS:
            j += 1
        nxt_can = j < n and chars[j] in _FORMS and _joins_prev(chars[j])
        me_next = _joins_next(c) and nxt_can
        me_prev = prev_joins and _joins_prev(c)
        f = _FORMS[c]
        if me_prev and me_next:
            form = f.get("med", f.get("fin", f["iso"]))
        elif me_prev:
            form = f.get("fin", f["iso"])
        elif me_next:
            form = f.get("ini", f["iso"])
        else:
            form = f.get("iso", c)
        out.append(form)
        prev_joins = _joins_next(c)
        i += 1
    return "".join(out)


def _strong(c: str):
    if _is_arabic(c) and c not in "٠١٢٣٤٥٦٧٨٩":
        return "R"
    if c.isalpha() or c.isdigit() or c in "٠١٢٣٤٥٦٧٨٩":
        return "L"
    return None


def reorder(text: str) -> str:
    """ترتيب بصري لفقرة RTL: الأرقام واللاتيني تبقى LTR داخل السطر."""
    kinds = [_strong(c) for c in text]
    # الأحرف المحايدة تأخذ اتجاه المحيط (RTL ما لم يحاط باللاتيني من الجهتين)
    n = len(text)
    for i in range(n):
        if kinds[i] is None:
            l = next((kinds[k] for k in range(i - 1, -1, -1) if kinds[k]), "R")
            r = next((kinds[k] for k in range(i + 1, n) if kinds[k]), "R")
            kinds[i] = "L" if (l == "L" and r == "L") else "R"
    runs, cur, ck = [], "", None
    for c, k in zip(text, kinds):
        if k != ck and cur:
            runs.append((ck, cur))
            cur = ""
        cur += c
        ck = k
    if cur:
        runs.append((ck, cur))
    res = []
    for k, s in reversed(runs):
        if k == "R":
            mirror = {"(": ")", ")": "(", "[": "]", "]": "[", "<": ">", ">": "<"}
            s = "".join(mirror.get(ch, ch) for ch in reversed(s))
        res.append(s)
    return "".join(res)


def display(text: str) -> str:
    """نص جاهز للرسم بخط يدعم Presentation Forms (مثل DejaVu Sans). النص اللاتيني فقط يُعاد كما هو."""
    if not text or not any(_is_arabic(c) for c in text):
        return text
    return "\n".join(reorder(shape(line)) for line in text.split("\n"))
