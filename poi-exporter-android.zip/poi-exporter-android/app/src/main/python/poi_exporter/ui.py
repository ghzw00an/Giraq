"""واجهة بأسلوب تطبيقات الملاحة (Waze): خريطة بملء الشاشة، أزرار عائمة، ورقة سفلية، قائمة جانبية."""

PAGE = r"""<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<title>مصدّر المعالم</title>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
:root{--bg:#fff;--fg:#1b2733;--mut:#6b7a8a;--card:#fff;--line:#e3e8ee;--acc:#1e88ff;--acc2:#00c389;--chip:#eef3f8;--sh:0 4px 18px rgba(0,0,0,.22)}
[data-t=dark]{--bg:#12181f;--fg:#eaf0f6;--mut:#93a1b0;--card:#1a232d;--line:#2a3643;--chip:#242f3b;--sh:0 4px 18px rgba(0,0,0,.6)}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;height:100%;overflow:hidden;font-family:system-ui,"Segoe UI",Tahoma,sans-serif;background:var(--bg);color:var(--fg)}
#map{position:fixed;inset:0;z-index:0}
.leaflet-container{font-family:inherit}
button{font:inherit;border:0;cursor:pointer;color:inherit}
.fab{width:52px;height:52px;border-radius:50%;background:var(--card);box-shadow:var(--sh);font-size:22px;display:grid;place-items:center;transition:transform .12s,background .2s}
.fab:active{transform:scale(.88)}.fab.on{background:var(--acc);color:#fff}
/* شريط البحث العلوي */
#top{position:fixed;top:calc(env(safe-area-inset-top) + 12px);left:12px;right:12px;z-index:500;display:flex;gap:10px;align-items:center}
#bar{flex:1;display:flex;align-items:center;background:var(--card);box-shadow:var(--sh);border-radius:28px;padding:0 6px 0 16px;height:52px}
#bar input{flex:1;border:0;background:transparent;color:var(--fg);font:inherit;font-size:15px;outline:0;min-width:0;padding:0 8px}
#bar button{width:40px;height:40px;border-radius:50%;background:var(--acc);color:#fff;font-size:18px}
/* أزرار جانبية */
#fabs{position:fixed;left:12px;top:50%;transform:translateY(-50%);z-index:500;display:flex;flex-direction:column;gap:12px}
/* علامة + في المنتصف */
#cross{position:fixed;left:50%;top:50%;width:26px;height:26px;margin:-13px 0 0 -13px;z-index:400;pointer-events:none}
#cross:before,#cross:after{content:"";position:absolute;background:var(--acc);border-radius:2px}
#cross:before{left:12px;top:0;width:2px;height:26px}#cross:after{top:12px;left:0;height:2px;width:26px}
/* بطاقة الإحداثيات */
#info{position:fixed;right:12px;bottom:calc(env(safe-area-inset-bottom) + 96px);z-index:450;background:var(--card);box-shadow:var(--sh);border-radius:16px;padding:8px 14px;font-size:13px;max-width:62vw;direction:ltr;text-align:left;line-height:1.5}
#info b{display:block;font-size:11px;color:var(--mut);direction:rtl;text-align:right}
/* الورقة السفلية */
#sheet{position:fixed;left:0;right:0;bottom:0;z-index:600;background:var(--card);border-radius:24px 24px 0 0;box-shadow:0 -4px 24px rgba(0,0,0,.25);
 transform:translateY(calc(100% - 78px - env(safe-area-inset-bottom)));transition:transform .28s cubic-bezier(.2,.8,.2,1);max-height:78vh;display:flex;flex-direction:column}
#sheet.open{transform:none}
#grab{padding:10px 16px 8px;display:flex;flex-direction:column;align-items:center;gap:8px;cursor:pointer}
#grab i{width:42px;height:5px;border-radius:3px;background:var(--line)}
#go{width:100%;height:46px;border-radius:23px;background:var(--acc2);color:#fff;font-weight:700;font-size:16px;box-shadow:0 3px 10px rgba(0,195,137,.45)}
#go:active{transform:scale(.97)}#go[disabled]{opacity:.6}
#body{overflow:auto;padding:4px 16px calc(env(safe-area-inset-bottom) + 18px)}
h4{margin:14px 0 8px;font-size:13px;color:var(--mut);font-weight:600}
.chips{display:flex;flex-wrap:wrap;gap:8px}
.chip{background:var(--chip);border-radius:20px;padding:8px 14px;font-size:14px;transition:.15s}
.chip.on{background:var(--acc);color:#fff;transform:scale(1.03)}
.row{display:flex;align-items:center;gap:10px;margin:8px 0}.row label{width:84px;font-size:14px}
input[type=range]{flex:1;accent-color:var(--acc)}.row span{width:56px;text-align:center;font-size:13px;color:var(--mut)}
select{background:var(--chip);color:var(--fg);border:0;border-radius:12px;padding:10px 12px;font:inherit;font-size:14px}
.tg{display:flex;align-items:center;gap:10px;font-size:14px;margin:10px 0}
/* القائمة الجانبية */
#scrim{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:700;opacity:0;pointer-events:none;transition:.25s}
#drawer{position:fixed;top:0;bottom:0;right:0;width:82%;max-width:340px;background:var(--card);z-index:800;transform:translateX(100%);transition:transform .28s;padding:calc(env(safe-area-inset-top) + 18px) 18px 18px;overflow:auto;box-shadow:var(--sh)}
body.dr #drawer{transform:none}body.dr #scrim{opacity:1;pointer-events:auto}
#drawer h3{margin:0 0 6px;font-size:20px}
.res{margin:10px 0;padding:10px 12px;background:var(--chip);border-radius:14px;font-size:13px;direction:ltr;text-align:left;word-break:break-all;line-height:1.7}
.modal{position:fixed;inset:0;z-index:850;background:rgba(0,0,0,.45);display:none;align-items:flex-end}
.modal.show{display:flex}.panel{width:100%;max-height:88vh;overflow:auto;background:var(--card);border-radius:24px 24px 0 0;padding:18px 16px calc(env(safe-area-inset-bottom) + 18px);animation:up .25s}
@keyframes up{from{transform:translateY(40px);opacity:0}}
.panel h3{margin:0 0 8px}.in{width:100%;padding:12px;border-radius:12px;border:1px solid var(--line);background:var(--bg);color:var(--fg);font:inherit;margin:4px 0}
.btn{width:100%;height:46px;border-radius:23px;background:var(--acc2);color:#fff;font-weight:700;margin-top:12px}.btn.sec{background:var(--chip);color:var(--fg)}
.bars div{margin:6px 0;font-size:13px}.bars i{display:block;height:8px;border-radius:4px;background:var(--acc);margin-top:3px}
#prev{width:100%;border-radius:12px;border:1px solid var(--line);margin-top:8px;display:none}
.north{position:fixed;right:12px;top:calc(env(safe-area-inset-top) + 76px);z-index:450;width:46px;height:46px;border-radius:50%;background:var(--card);box-shadow:var(--sh);display:none;place-items:center;font-weight:800;line-height:1;text-align:center;font-size:12px}
.north b{display:block;font-size:18px;color:#e03131}
.ann{background:none!important;border:0!important}.ann div{white-space:pre;padding:2px 6px;border-radius:6px;background:rgba(255,255,255,.88);font-weight:600}
.li{display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--line);font-size:13px}.li span{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.li input[type=range]{width:90px;flex:none}.x{background:var(--chip);border-radius:50%;width:30px;height:30px}
.prog{height:8px;border-radius:4px;background:var(--chip);overflow:hidden;margin:8px 0}.prog i{display:block;height:100%;background:var(--acc2);width:0;transition:width .3s}
.sub{position:fixed;left:72px;bottom:0;z-index:520;display:none;flex-direction:column;gap:8px}.sub.show{display:flex}
.sub button{background:var(--card);box-shadow:var(--sh);border-radius:22px;padding:10px 16px;font-size:14px;white-space:nowrap}
.tbl{overflow:auto;border:1px solid var(--line);border-radius:12px;max-height:50vh}table{border-collapse:collapse;font-size:12px;direction:ltr;white-space:nowrap}
th,td{padding:6px 10px;border-bottom:1px solid var(--line);text-align:left}th{position:sticky;top:0;background:var(--chip)}
#toast{position:fixed;left:50%;bottom:110px;transform:translateX(-50%) translateY(20px);background:#1b2733;color:#fff;padding:10px 18px;border-radius:20px;z-index:900;opacity:0;transition:.25s;pointer-events:none;font-size:14px;max-width:86vw;text-align:center}
#toast.show{opacity:1;transform:translateX(-50%)}
</style></head><body data-t="light">
<div id="map"></div><div id="cross"></div>

<div id="top">
  <button class="fab" id="menu" aria-label="menu">☰</button>
  <div id="bar"><input id="q" data-ph="search" enterkeyhint="go" autocomplete="off"><button id="qgo">➤</button></div>
</div>

<div id="fabs">
  <button class="fab" id="loc" title="GPS">◎</button>
  <button class="fab on" id="rectb">▭</button>
  <button class="fab" id="lay">🗺</button>
  <button class="fab" id="flag">🚩</button>
</div>

<div class="north" id="north"><b>▲</b>N</div>
<div class="sub" id="sub2"><button id="f1"></button><button id="f2"></button><button id="f3"></button><button id="f4"></button></div>
<input type="file" id="aimg" accept="image/*" hidden>
<div class="sub" id="sub"><button id="s1"></button><button id="s2"></button><button id="s3"></button></div>
<div id="info"><b id="infoL"></b><span id="infoV">—</span><br><span id="infoA" style="direction:rtl;display:block;text-align:right"></span></div>

<div id="sheet">
  <div id="grab"><i></i><button id="go"></button></div>
  <div id="body">
    <h4 data-i="poi"></h4><div class="chips" id="poi"></div>
    <h4 data-i="layers"></h4><div class="chips" id="lyr"></div>
    <h4 data-i="area"></h4>
    <div class="row"><label data-i="w"></label><input type="range" id="rw" min="0.5" max="40" step="0.5" value="4"><span id="vw"></span></div>
    <div class="row"><label data-i="h"></label><input type="range" id="rh" min="0.5" max="40" step="0.5" value="4"><span id="vh"></span></div>
    <div class="row"><label data-i="shape"></label><select id="shape"><option value="rect" data-i="rect"></option><option value="circle" data-i="circle"></option></select></div>
    <label class="tg"><input type="checkbox" id="fill" checked> <span data-i="fill"></span></label>
    <div class="row"><label data-i="fmt"></label><select id="fmt">{% for f in fmts %}<option>{{f}}</option>{% endfor %}</select></div>
  </div>
</div>

<div class="modal" id="lm"><div class="panel">
  <h3 data-i="addlm"></h3>
  <div style="font-size:12px;color:var(--mut);direction:ltr;text-align:left" id="lmxy"></div>
  <input class="in" id="lname" data-ph="name">
  <h4 data-i="sector"></h4><div class="chips" id="lsec"></div>
  <h4 data-i="items"></h4><div class="chips" id="litems"></div>
  <input class="in" id="ltype" data-ph="type">
  <button class="btn" id="lsave"></button><button class="btn sec" id="lclose"></button>
</div></div>
<div class="modal" id="tb"><div class="panel">
  <h3 data-i="table"></h3><div class="tbl"><table id="tt"></table></div>
  <div class="row"><select id="efmt">{% for f in fmts %}<option>{{f}}</option>{% endfor %}</select><button class="btn" id="eexp" style="margin:0"></button></div>
  <button class="btn sec" id="tclose"></button>
</div></div>
<input type="file" id="imp" hidden>
<div class="modal" id="rp"><div class="panel">
  <h3 data-i="report"></h3>
  <input class="in" id="rtitle" data-ph="rtitle">
  <div class="row"><select id="rpaper"><option>A4</option><option>A3</option><option>A5</option></select>
   <select id="rfmt"><option value="pdf">PDF</option><option value="png">PNG</option></select></div>
  <img id="prev" alt="">
  <button class="btn sec" id="rprev"></button><button class="btn" id="rsave"></button>
  <button class="btn" id="ropen" style="background:var(--acc);display:none"></button>
  <button class="btn sec" id="rclose"></button>
</div></div>
<div class="modal" id="an"><div class="panel"><h3 data-i="analysis"></h3><div id="anb" class="bars"></div><button class="btn sec" id="aclose"></button></div></div>
<div class="modal" id="txt"><div class="panel"><h3 data-i="addtxt"></h3>
  <textarea class="in" id="ttext" rows="3"></textarea>
  <div class="row"><label data-i="size"></label><select id="tsize"><option>12</option><option selected>14</option><option>18</option><option>24</option><option>32</option></select>
  <input type="color" id="tcol" value="#000000" style="width:48px;height:40px;border:0;background:none"></div>
  <button class="btn" id="tsave"></button><button class="btn sec" id="tclose2"></button></div></div>
<div class="modal" id="rs"><div class="panel"><h3 data-i="rasters"></h3>
  <input type="file" id="rfile" class="in" accept=".tif,.tiff,.png,.jpg,.jpeg,.webp,.bmp,.gif">
  <h4 data-i="world"></h4><input class="in" id="rworld" type="file">
  <input class="in" id="rbounds" dir="ltr" placeholder="west,south,east,north (اختياري)">
  <button class="btn" id="radd"></button><div id="rlist"></div><button class="btn sec" id="rsclose"></button></div></div>
<div class="modal" id="tl"><div class="panel"><h3 data-i="tools"></h3>
  <div class="chips" id="tchips"></div><div id="tparams"></div>
  <button class="btn" id="trun"></button>
  <div id="tres" style="display:none"><div class="row"><select id="tfmt">{% for f in fmts %}<option>{{f}}</option>{% endfor %}</select><button class="btn" id="texp" style="margin:0"></button></div>
  <button class="btn sec" id="tclear"></button></div>
  <button class="btn sec" id="tlclose"></button></div></div>
<div class="modal" id="ad"><div class="panel"><h3 data-i="admin"></h3>
  <input class="in" id="aq" dir="ltr" placeholder="Abu Ghraib"><input class="in" id="aar" placeholder="الاسم بالعربي (اختياري)">
  <button class="btn" id="afetch"></button>
  <button class="btn sec" id="abulk"></button><div class="prog"><i id="apg"></i></div><div id="ast" style="font-size:13px"></div>
  <button class="btn sec" id="adclose"></button></div></div>
<div id="scrim"></div>
<aside id="drawer">
  <h3 data-i="title"></h3>
  <h4 data-i="conv"></h4>
  <div class="row"><input id="cin" style="flex:1;padding:10px;border-radius:12px;border:1px solid var(--line);background:var(--bg);color:var(--fg);direction:ltr" placeholder="33.3152, 44.3661 | 38S 440994 3686410"><button class="chip on" id="cgo">⇄</button></div>
  <div class="res" id="cout" hidden></div>
  <button class="btn sec" id="dtl"></button><button class="btn sec" id="drs"></button><button class="btn sec" id="dad"></button>
  <button class="btn sec" id="dimp"></button><button class="btn sec" id="drep"></button><button class="btn sec" id="dan"></button>
  <button class="btn" id="dlm" style="background:var(--acc)"></button><button class="btn sec" id="dtb"></button>
  <h4 data-i="coordtype"></h4>
  <div class="chips" id="ctype"></div>
  <h4 data-i="theme"></h4>
  <div class="chips" id="theme"></div>
  <h4 data-i="lang"></h4>
  <div class="chips" id="lang"></div>
</aside>
<div id="toast"></div>

<script>
const POI={{ cats|tojson }}, LYR={{ layers|tojson }};
const L10={ar:{search:"ابحث: إحداثيات UTM / MGRS / خط عرض وطول",go:"حدّد المنطقة ونزّل المعالم",dl:"تنزيل وتصدير",poi:"المعالم",layers:"الطبقات",area:"حجم المنطقة (كم)",w:"العرض",h:"الارتفاع",fill:"ملء القضاء والمحافظة من الحدود المضمّنة",fmt:"الصيغة",title:"مصدّر المعالم",conv:"محوّل الإحداثيات",coordtype:"نوع الإحداثيات",theme:"المظهر",lang:"اللغة",wait:"جارٍ التنزيل…",done:"تم الحفظ",pick:"اختر معلماً أو طبقة أولاً",noloc:"تعذّر تحديد الموقع",center:"مركز الخريطة",addlm:"إضافة معلم عند علامة +",sector:"القطاع (Gategory)",items:"العناصر",name:"الاسم (name)",type:"النوع (type)",save:"حفظ المعلم",close:"إغلاق",table:"جدول الخصائص",exp:"تصدير",addbtn:"إضافة معلم",lms:"المعالم المحفوظة",s1:"موقعي",s2:"إضافة معلم",s3:"إضافة عدة معالم",saved:"أُضيف المعلم",noname:"اكتب اسم المعلم",del:"حذف",empty:"لا توجد معالم",imp:"استيراد ملف (KML/KMZ/GeoJSON/GPX/CSV/Excel/SHP)",report:"تقرير الخريطة",analysis:"تحليل المعالم",rtitle:"عنوان التقرير",prev:"معاينة",rsave:"حفظ التقرير",ropen:"فتح",imported:"أُضيف",total:"المجموع",sector:"حسب القطاع",gathaa:"حسب القضاء",moh:"حسب المحافظة",centre:"المركز الوسطي",nn:"أقرب جار",cl:"التجمعات (500م)",addtxt:"إضافة نص",size:"الحجم",rasters:"صور جوية",tools:"أدوات المنطقة والتحليل",admin:"الأقضية من OSM",shape:"شكل المنطقة",rect:"مستطيل",circle:"دائرة",north:"سهم الشمال",scale:"مقياس الرسم",txt:"مربع نص",img:"صورة صغيرة",radd:"إضافة الصورة",run:"تشغيل",clear:"مسح الناتج",fetch:"جلب القضاء",bulk:"جلب كل الأقضية الناقصة",world:"World file (اختياري)",done2:"تم",notfound:"اختر أداة أولاً"},
 en:{search:"Search: UTM / MGRS / lat,lon",go:"Select area & download",dl:"Download & export",poi:"Landmarks",layers:"Layers",area:"Area size (km)",w:"Width",h:"Height",fill:"Fill district/governorate from built-in boundaries",fmt:"Format",title:"POI Exporter",conv:"Coordinate converter",coordtype:"Coordinate type",theme:"Theme",lang:"Language",wait:"Downloading…",done:"Saved",pick:"Pick a landmark or layer first",noloc:"Location unavailable",center:"Map centre",addlm:"Add landmark at + mark",sector:"Sector (Gategory)",items:"Items",name:"Name",type:"Type",save:"Save landmark",close:"Close",table:"Attribute table",exp:"Export",addbtn:"Add landmark",lms:"Saved landmarks",s1:"My location",s2:"Add landmark",s3:"Add several",saved:"Landmark added",noname:"Enter a name",del:"Delete",empty:"No landmarks",imp:"Import file (KML/KMZ/GeoJSON/GPX/CSV/Excel/SHP)",report:"Map report",analysis:"Landmark analysis",rtitle:"Report title",prev:"Preview",rsave:"Save report",ropen:"Open",imported:"Added",total:"Total",sector:"By sector",gathaa:"By district",moh:"By governorate",centre:"Mean centre",nn:"Nearest neighbour",cl:"Clusters (500 m)",addtxt:"Add text",size:"Size",rasters:"Aerial imagery",tools:"Area & analysis tools",admin:"Districts from OSM",shape:"Area shape",rect:"Rectangle",circle:"Circle",north:"North arrow",scale:"Scale bar",txt:"Text box",img:"Small image",radd:"Add image",run:"Run",clear:"Clear result",fetch:"Fetch district",bulk:"Fetch all missing districts",world:"World file (optional)",done2:"Done",notfound:"Pick a tool first"}};
const S={lang:"ar",theme:"light",ctype:"DD",...JSON.parse(localStorage.getItem("poi")||"{}")};
const save=()=>localStorage.setItem("poi",JSON.stringify(S));
const $=id=>document.getElementById(id), T=k=>L10[S.lang][k];
function toast(m){const t=$("toast");t.textContent=m;t.classList.add("show");clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove("show"),2600)}

/* خريطة */
const map=L.map("map",{zoomControl:false,attributionControl:false}).setView([33.3,44.4],11);
const osm=L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19});
const sat=L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",{maxZoom:19});
let base=osm.addTo(map);
L.control.attribution({prefix:false,position:"bottomleft"}).addAttribution("© OpenStreetMap · Esri").addTo(map);
$("lay").onclick=()=>{map.removeLayer(base);base=(base===osm?sat:osm).addTo(map);$("lay").classList.toggle("on",base===sat)};

/* المستطيل: يتبع منتصف الشاشة (علامة +) وحجمه من المنزلقين */
const sty={color:"#1e88ff",weight:2,fillOpacity:.12,dashArray:"6 4",interactive:false};const rectR=L.rectangle([[0,0],[0,0]],sty),rectC=L.circle([0,0],{...sty,radius:1});let rect=rectR;rect.addTo(map);
let rectOn=true;
function bounds(){const c=map.getCenter(),w=+$("rw").value,h=$("shape").value==="circle"?+$("rw").value:+$("rh").value,dLat=h/2/111.32,dLon=w/2/(111.32*Math.cos(c.lat*Math.PI/180));
 return [[c.lat-dLat,c.lng-dLon],[c.lat+dLat,c.lng+dLon]]}
function upRect(){$("vw").textContent=$("rw").value+" km";$("vh").textContent=$("rh").value+" km";const circ=$("shape").value==="circle";
 const want=circ?rectC:rectR;if(want!==rect){if(rectOn){map.removeLayer(rect);want.addTo(map)}rect=want}
 if(rectOn){if(circ){rectC.setLatLng(map.getCenter());rectC.setRadius(+$("rw").value*500)}else rectR.setBounds(bounds())}}
map.on("move",upRect);$("rw").oninput=$("rh").oninput=$("shape").onchange=upRect;
$("rectb").onclick=()=>{rectOn=!rectOn;$("rectb").classList.toggle("on",rectOn);if(rectOn){rect.addTo(map);upRect()}else map.removeLayer(rect)};

/* بطاقة المركز */
let tm;
async function upInfo(){const c=map.getCenter();$("infoL").textContent=T("center");
 try{const r=await (await fetch(`/api/coords?text=${c.lat.toFixed(6)},${c.lng.toFixed(6)}`)).json();$("infoV").textContent=r[S.ctype]||r.DD}catch(e){$("infoV").textContent=c.lat.toFixed(5)+", "+c.lng.toFixed(5)}
 try{const a=await (await fetch(`/api/locate?lat=${c.lat}&lon=${c.lng}`)).json();$("infoA").textContent=(a.qadaa||"")+(a.governorate?" / "+a.governorate:"")}catch(e){}}
map.on("moveend",()=>{clearTimeout(tm);tm=setTimeout(upInfo,350)});

/* GPS */
let me;
$("loc").onclick=()=>{if(!navigator.geolocation)return toast(T("noloc"));
 navigator.geolocation.getCurrentPosition(p=>{const ll=[p.coords.latitude,p.coords.longitude];map.flyTo(ll,16);
  if(me)map.removeLayer(me);me=L.circleMarker(ll,{radius:8,color:"#fff",weight:3,fillColor:"#1e88ff",fillOpacity:1}).addTo(map)},()=>toast(T("noloc")),{enableHighAccuracy:true,timeout:15000})};

/* بحث إحداثيات */
let pin;
async function search(){const t=$("q").value.trim();if(!t)return;
 const r=await fetch("/api/coords?text="+encodeURIComponent(t));const j=await r.json();if(!r.ok)return toast(j.error||"?");
 map.flyTo([j.lat,j.lon],15);if(pin)map.removeLayer(pin);pin=L.marker([j.lat,j.lon]).addTo(map).bindPopup(`<div style="direction:ltr">${j.UTM}<br>${j.MGRS}</div>`).openPopup()}
$("qgo").onclick=search;$("q").onkeydown=e=>{if(e.key==="Enter")search()};

/* الورقة السفلية */
const sheet=$("sheet");
$("grab").onclick=e=>{if(e.target===$("go")&&sheet.classList.contains("open"))return doDownload();sheet.classList.toggle("open")};
map.on("click",()=>sheet.classList.remove("open"));
function chips(el,items,store){items.forEach(x=>{const b=document.createElement("button");b.className="chip";b.textContent=S.lang==="ar"?x.ar:x.en;b.dataset.id=x.id;
 b.onclick=()=>{b.classList.toggle("on");if(navigator.vibrate)navigator.vibrate(8)};el.appendChild(b)})}
function sel(el){return [...el.querySelectorAll(".chip.on")].map(b=>b.dataset.id)}
async function saveBlob(bl,nm){
 if(window.Android){const b64=await new Promise(res=>{const fr=new FileReader();fr.onload=()=>res(fr.result.split(",")[1]);fr.readAsDataURL(bl)});return window.Android.save(nm,b64)}
 const a=document.createElement("a");a.href=URL.createObjectURL(bl);a.download=nm;a.click();return ""}
async function doDownload(){const poi=sel($("poi")),layers=sel($("lyr"));if(!poi.length&&!layers.length)return toast(T("pick"));
 const b=bounds(),go=$("go");go.disabled=true;go.textContent=T("wait");
 try{const r=await fetch("/api/download",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({bbox:[b[0][0],b[0][1],b[1][0],b[1][1]],poi,layers,format:$("fmt").value,fill_admin:$("fill").checked,shape:$("shape").value,radius_m:+$("rw").value*500})});
  if(!r.ok){toast((await r.json()).error||"error")}else{const bl=await r.blob();const nm="poi."+({shp:"zip"}[$("fmt").value]||$("fmt").value);await saveBlob(bl,nm);toast(T("done"))}
 }catch(e){toast(String(e))}finally{go.disabled=false;go.textContent=T("dl")}}
$("go").onclick=e=>{e.stopPropagation();if(!sheet.classList.contains("open")){sheet.classList.add("open");$("go").textContent=T("dl")}else doDownload()};

/* القائمة الجانبية */
$("menu").onclick=()=>document.body.classList.add("dr");$("scrim").onclick=()=>document.body.classList.remove("dr");
function opts(el,list,key,cb){el.innerHTML="";list.forEach(([v,t])=>{const b=document.createElement("button");b.className="chip"+(S[key]===v?" on":"");b.textContent=t;
 b.onclick=()=>{S[key]=v;save();[...el.children].forEach(c=>c.classList.remove("on"));b.classList.add("on");cb&&cb()};el.appendChild(b)})}
$("cgo").onclick=async()=>{const r=await fetch("/api/convert-coords?text="+encodeURIComponent($("cin").value));const j=await r.json();const o=$("cout");o.hidden=false;
 o.textContent=j.error?j.error:`DD: ${j.dd}\nDMS: ${j.dms}\nDDM: ${j.ddm}\nUTM: ${j.utm}\nMGRS: ${j.mgrs}`;o.style.whiteSpace="pre-wrap";if(!j.error)map.flyTo([j.lat,j.lon],15)};

function render(){document.documentElement.lang=S.lang;document.documentElement.dir=S.lang==="ar"?"rtl":"ltr";document.body.dataset.t=S.theme==="auto"?(matchMedia("(prefers-color-scheme:dark)").matches?"dark":"light"):S.theme;
 $("dlm").textContent=T("addbtn");$("dtl").textContent=T("tools");$("drs").textContent=T("rasters");$("dad").textContent=T("admin");$("f1").textContent="▲ "+T("north");$("f2").textContent="━ "+T("scale");$("f3").textContent="T "+T("txt");$("f4").textContent="🖼 "+T("img");$("tsave").textContent=T("save");$("tclose2").textContent=T("close");$("radd").textContent=T("radd");$("rsclose").textContent=T("close");$("trun").textContent=T("run");$("texp").textContent=T("exp");$("tclear").textContent=T("clear");$("tlclose").textContent=T("close");$("afetch").textContent=T("fetch");$("abulk").textContent=T("bulk");$("adclose").textContent=T("close");$("dimp").textContent=T("imp");$("drep").textContent=T("report");$("dan").textContent=T("analysis");$("rtitle").placeholder=T("rtitle");$("rprev").textContent=T("prev");$("rsave").textContent=T("rsave");$("ropen").textContent=T("ropen");$("rclose").textContent=T("close");$("aclose").textContent=T("close");$("dtb").textContent=T("table");$("lsave").textContent=T("save");$("lclose").textContent=T("close");$("tclose").textContent=T("close");$("eexp").textContent=T("exp");
 $("s1").textContent=T("s1");$("s2").textContent=T("s2");$("s3").textContent=T("s3");$("lname").placeholder=T("name");$("ltype").placeholder=T("type");
 document.querySelectorAll("[data-i]").forEach(e=>e.textContent=T(e.dataset.i));$("q").placeholder=T("search");$("go").textContent=sheet.classList.contains("open")?T("dl"):T("go");
 const keepP=sel($("poi")),keepL=sel($("lyr"));$("poi").innerHTML="";$("lyr").innerHTML="";chips($("poi"),POI);chips($("lyr"),LYR);
 keepP.forEach(i=>$("poi").querySelector(`[data-id="${i}"]`)?.classList.add("on"));keepL.forEach(i=>$("lyr").querySelector(`[data-id="${i}"]`)?.classList.add("on"));
 opts($("ctype"),[["DD","DD"],["DMS","DMS"],["UTM","UTM"],["MGRS","MGRS"]],"ctype",upInfo);
 opts($("theme"),[["light",S.lang==="ar"?"فاتح":"Light"],["dark",S.lang==="ar"?"داكن":"Dark"],["auto",S.lang==="ar"?"تلقائي":"Auto"]],"theme",render);
 opts($("lang"),[["ar","العربية"],["en","English"]],"lang",render);upRect();upInfo()}

/* ===== المعالم المحفوظة ===== */
let SEC=[],LM=[],lmLayer=L.layerGroup().addTo(map),multi=false,curSec="";
fetch("/api/sectors").then(r=>r.json()).then(j=>{SEC=j;loadLM()});
async function loadLM(){try{LM=await (await fetch("/api/landmarks")).json()}catch(e){LM=[]}
 lmLayer.clearLayers();LM.forEach(m=>{const col=(SEC.find(x=>x.name===m.Gategory)||{}).color||"#e03131";
  L.circleMarker([m.lat,m.lon],{radius:9,color:"#fff",weight:2,fillColor:col,fillOpacity:1}).addTo(lmLayer)
   .bindPopup(`<b>${m.name||"—"}</b><br>${m.type}<br><small>${m.Gategory}</small><br><a href="#" onclick="delLM('${m.id}');return false">${T("del")}</a>`)})}
async function delLM(id){await fetch("/api/landmarks/"+id,{method:"DELETE"});map.closePopup();loadLM()}
function drawSecs(){const el=$("lsec");el.innerHTML="";SEC.forEach(x=>{const b=document.createElement("button");b.className="chip"+(curSec===x.name?" on":"");b.textContent=x.name;
 b.onclick=()=>{curSec=x.name;drawSecs();drawItems()};el.appendChild(b)})}
function drawItems(){const el=$("litems");el.innerHTML="";const sc=SEC.find(x=>x.name===curSec);if(!sc)return;
 sc.items.forEach(i=>{const b=document.createElement("button");b.className="chip"+($("ltype").value===i?" on":"");b.textContent=i;
  b.onclick=()=>{$("ltype").value=i;drawItems()};el.appendChild(b)})}
function openLM(m){multi=m;const c=map.getCenter();$("lmxy").textContent=c.lat.toFixed(6)+", "+c.lng.toFixed(6);$("lname").value="";$("ltype").value="";curSec="";drawSecs();drawItems();$("lm").classList.add("show")}
$("lclose").onclick=()=>$("lm").classList.remove("show");
$("lsave").onclick=async()=>{const n=$("lname").value.trim();if(!n)return toast(T("noname"));const c=map.getCenter();
 const r=await fetch("/api/landmarks",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({lat:c.lat,lon:c.lng,name:n,type:$("ltype").value,Gategory:curSec})});
 if(!r.ok)return toast((await r.json()).error||"error");toast(T("saved"));
 if(multi){$("lname").value="";$("ltype").value="";drawItems()}else $("lm").classList.remove("show");
 await loadLM()};
$("ltype").oninput=drawItems;
$("dlm").onclick=()=>{document.body.classList.remove("dr");openLM(false)};
$("dtb").onclick=async()=>{document.body.classList.remove("dr");await loadLM();const cols=["name","type","Gategory","gathaa","Nahia","mohafadha","x","y","link"];
 $("tt").innerHTML="<tr>"+cols.map(c=>`<th>${c}</th>`).join("")+"</tr>"+(LM.length?LM.map(m=>"<tr>"+cols.map(c=>`<td>${m[c]??""}</td>`).join("")+"</tr>").join(""):`<tr><td colspan=9>${T("empty")}</td></tr>`);$("tb").classList.add("show")};
$("tclose").onclick=()=>$("tb").classList.remove("show");
$("eexp").onclick=async()=>{const f=$("efmt").value,r=await fetch("/api/landmarks/export?format="+f);if(!r.ok)return toast((await r.json()).error||"error");
 await saveBlob(await r.blob(),"landmarks."+({shp:"zip"}[f]||f));toast(T("done"))};
/* ضغطة مطوّلة على زر الموقع: قائمة صغيرة فوقه */
(function(){let t,long=false;const b=$("loc"),sub=$("sub");
 const open=()=>{const r=b.getBoundingClientRect();sub.style.bottom=(innerHeight-r.top+8)+"px";sub.style.left=r.left+"px";sub.classList.add("show");long=true};
 b.addEventListener("pointerdown",()=>{long=false;t=setTimeout(open,480)});
 ["pointerup","pointerleave","pointercancel"].forEach(e=>b.addEventListener(e,()=>clearTimeout(t)));
 b.addEventListener("click",e=>{if(long){e.stopImmediatePropagation();long=false}},true);
 $("s1").onclick=()=>{sub.classList.remove("show");long=false;$("loc").click()};
 $("s2").onclick=()=>{sub.classList.remove("show");openLM(false)};
 $("s3").onclick=()=>{sub.classList.remove("show");openLM(true)};
 document.addEventListener("pointerdown",e=>{if(!sub.contains(e.target)&&e.target!==b)sub.classList.remove("show")})})();

/* ===== استيراد ===== */
$("dimp").onclick=()=>{document.body.classList.remove("dr");$("imp").value="";$("imp").click()};
$("imp").onchange=async()=>{const f=$("imp").files[0];if(!f)return;const fd=new FormData();fd.append("file",f);
 const r=await fetch("/api/landmarks/import",{method:"POST",body:fd});const j=await r.json();if(!r.ok)return toast(j.error||"error");
 toast(T("imported")+": "+j.added);await loadLM();if(LM.length)map.fitBounds?map.fitBounds(LM.map(m=>[m.lat,m.lon])):0};
/* ===== تقرير: معاينة ثم حفظ ثم فتح ===== */
let lastPath="";
const rq=(f,inl)=>`/api/landmarks/report?format=${f}&paper=${$("rpaper").value}&title=${encodeURIComponent($("rtitle").value)}${inl?"&inline=1":""}`;
$("drep").onclick=()=>{document.body.classList.remove("dr");$("ropen").style.display="none";$("prev").style.display="none";$("rp").classList.add("show")};
$("rclose").onclick=()=>$("rp").classList.remove("show");
$("rprev").onclick=async()=>{$("rprev").disabled=true;try{const r=await fetch(rq("png",1));if(!r.ok)return toast((await r.json()).error||"error");
 $("prev").src=URL.createObjectURL(await r.blob());$("prev").style.display="block"}finally{$("rprev").disabled=false}};
$("rsave").onclick=async()=>{const f=$("rfmt").value,r=await fetch(rq(f,0));if(!r.ok)return toast((await r.json()).error||"error");
 lastPath=await saveBlob(await r.blob(),"report."+f);toast(T("done"));if(window.Android&&lastPath)$("ropen").style.display="block"};
$("ropen").onclick=()=>window.Android&&window.Android.open(lastPath);
/* ===== تحليل ===== */
function bars(t,o){const v=Object.entries(o),m=Math.max(...v.map(x=>x[1]),1);return `<h4>${t}</h4>`+v.map(([k,n])=>`<div>${k} — <b>${n}</b><i style="width:${Math.round(n/m*100)}%"></i></div>`).join("")}
$("dan").onclick=async()=>{document.body.classList.remove("dr");const r=await fetch("/api/landmarks/analysis");const j=await r.json();if(!r.ok)return toast(j.error||"error");
 let h=`<div class="res" style="direction:inherit;text-align:start">${T("total")}: <b>${j.total}</b><br>${T("centre")}: ${j.centre.utm}`;
 if(j.nn)h+=`<br>${T("nn")}: ${j.nn.mean_m} m — ${j.nn.pattern} (${j.nn.ratio})`;if(j.clusters)h+=`<br>${T("cl")}: ${j.clusters.count} [${j.clusters.sizes.join(", ")}]`;
 h+="</div>"+bars(T("sector"),j.by_sector)+bars(T("gathaa"),j.by_gathaa)+bars(T("moh"),j.by_mohafadha);$("anb").innerHTML=h;$("an").classList.add("show")};
$("aclose").onclick=()=>$("an").classList.remove("show");

/* ===== زر العلم: عناصر الخريطة ===== */
let scaleCtl=null,annLayer=L.layerGroup().addTo(map);
const sub2=$("sub2");
$("flag").onclick=e=>{e.stopPropagation();const r=$("flag").getBoundingClientRect();sub2.style.bottom=(innerHeight-r.bottom)+"px";sub2.style.left=(r.right+8)+"px";sub2.classList.toggle("show")};
document.addEventListener("pointerdown",e=>{if(!sub2.contains(e.target)&&e.target!==$("flag"))sub2.classList.remove("show")});
$("f1").onclick=()=>{sub2.classList.remove("show");const n=$("north");n.style.display=n.style.display==="grid"?"none":"grid"};
$("f2").onclick=()=>{sub2.classList.remove("show");if(scaleCtl){map.removeControl(scaleCtl);scaleCtl=null}else{scaleCtl=L.control.scale({metric:true,imperial:false,position:"bottomleft"}).addTo(map)}};
$("f3").onclick=()=>{sub2.classList.remove("show");$("ttext").value="";$("txt").classList.add("show")};
$("f4").onclick=()=>{sub2.classList.remove("show");$("aimg").value="";$("aimg").click()};
$("tclose2").onclick=()=>$("txt").classList.remove("show");
$("tsave").onclick=async()=>{const t=$("ttext").value.trim();if(!t)return;const c=map.getCenter();
 await fetch("/api/annotations",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({lat:c.lat,lon:c.lng,text:t,size:+$("tsize").value,color:$("tcol").value})});
 $("txt").classList.remove("show");loadAnn()};
$("aimg").onchange=async()=>{const f=$("aimg").files[0];if(!f)return;const c=map.getCenter(),fd=new FormData();fd.append("file",f);fd.append("lat",c.lat);fd.append("lon",c.lng);
 const r=await fetch("/api/annotations",{method:"POST",body:fd});if(!r.ok)return toast((await r.json()).error||"error");loadAnn()};
async function loadAnn(){let a=[];try{a=await (await fetch("/api/annotations")).json()}catch(e){}annLayer.clearLayers();
 a.forEach(i=>{const col="#"+(i.color&0xFFFFFF).toString(16).padStart(6,"0");
  const html=i.kind==="image"?`<img src="/api/annotations/${i.id}/file" width="${i.width}">`:`<div style="font-size:${i.size}px;color:${col}">${(i.text||"").replace(/</g,"&lt;")}</div>`;
  L.marker([i.lat,i.lon],{icon:L.divIcon({className:"ann",html,iconSize:null})}).addTo(annLayer)
   .bindPopup(`<a href="#" onclick="delAnn('${i.id}');return false">${T("del")}</a>`)})}
async function delAnn(id){await fetch("/api/annotations/"+id,{method:"DELETE"});map.closePopup();loadAnn()}
loadAnn();

/* ===== صور جوية ===== */
const rLayers={};
async function loadRasters(){let a=[];try{a=await (await fetch("/api/rasters")).json()}catch(e){}
 Object.values(rLayers).forEach(l=>map.removeLayer(l));for(const k in rLayers)delete rLayers[k];
 a.forEach(r=>{const l=L.imageOverlay(`/api/rasters/${r.id}.png`,[[r.bounds[1],r.bounds[0]],[r.bounds[3],r.bounds[2]]],{opacity:r.opacity});rLayers[r.id]=l;if(r.visible)l.addTo(map)});
 $("rlist").innerHTML="";a.forEach(r=>{const d=document.createElement("div");d.className="li";
  d.innerHTML=`<input type="checkbox" ${r.visible?"checked":""}><span>${r.name}</span><input type="range" min="0.1" max="1" step="0.1" value="${r.opacity}"><button class="x">✕</button>`;
  const [cb,,rg,x]=d.children;
  cb.onchange=async()=>{await fetch("/api/rasters/"+r.id,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({visible:cb.checked})});cb.checked?rLayers[r.id].addTo(map):map.removeLayer(rLayers[r.id])};
  rg.onchange=async()=>{rLayers[r.id].setOpacity(+rg.value);await fetch("/api/rasters/"+r.id,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({opacity:+rg.value})})};
  x.onclick=async()=>{await fetch("/api/rasters/"+r.id,{method:"DELETE"});loadRasters()};
  d.querySelector("span").onclick=()=>map.fitBounds([[r.bounds[1],r.bounds[0]],[r.bounds[3],r.bounds[2]]]);$("rlist").appendChild(d)})}
$("drs").onclick=()=>{document.body.classList.remove("dr");$("rs").classList.add("show");loadRasters()};
$("rsclose").onclick=()=>$("rs").classList.remove("show");
$("radd").onclick=async()=>{const f=$("rfile").files[0];if(!f)return;const fd=new FormData();fd.append("file",f);
 if($("rworld").files[0])fd.append("world",$("rworld").files[0]);if($("rbounds").value.trim())fd.append("bounds",$("rbounds").value.trim());
 toast("…");const r=await fetch("/api/rasters",{method:"POST",body:fd});const j=await r.json();if(!r.ok)return toast(j.error||"error");
 toast(T("done2")+(j.note?" — "+j.note:""));await loadRasters();map.fitBounds([[j.bounds[1],j.bounds[0]],[j.bounds[3],j.bounds[2]]])};

/* ===== أدوات المنطقة والتحليل ===== */
let TOOLS=[],curTool=null,resId=null,resLayer=null;
fetch("/api/tools").then(r=>r.json()).then(j=>{TOOLS=j});
function drawTools(){const el=$("tchips");el.innerHTML="";TOOLS.forEach(t=>{const b=document.createElement("button");b.className="chip"+(curTool===t.id?" on":"");b.textContent=t.ar;
 b.onclick=()=>{curTool=t.id;drawTools();const pe=$("tparams");pe.innerHTML="";t.params.forEach(([k,lab,d])=>{pe.insertAdjacentHTML("beforeend",`<h4>${lab}</h4><input class="in" data-k="${k}" value="${d}" dir="auto">`)})};el.appendChild(b)})}
$("dtl").onclick=()=>{document.body.classList.remove("dr");drawTools();$("tl").classList.add("show")};
$("tlclose").onclick=()=>$("tl").classList.remove("show");
$("trun").onclick=async()=>{if(!curTool)return toast(T("notfound"));const p={};document.querySelectorAll("#tparams [data-k]").forEach(i=>p[i.dataset.k]=i.value);const c=map.getCenter();
 const r=await fetch("/api/tools/run",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tool:curTool,params:p,lat:c.lat,lon:c.lng})});const j=await r.json();if(!r.ok)return toast(j.error||"error");
 if(resLayer)map.removeLayer(resLayer);resId=j.id;
 resLayer=L.geoJSON(j.geojson,{style:{color:"#e8590c",weight:2,fillOpacity:.2},pointToLayer:(f,ll)=>L.circleMarker(ll,{radius:7,color:"#fff",weight:2,fillColor:"#e8590c",fillOpacity:1})}).addTo(map);
 try{map.fitBounds(resLayer.getBounds())}catch(e){}toast(T("done2")+": "+j.count);$("tres").style.display="block";$("tl").classList.remove("show")};
$("tclear").onclick=()=>{if(resLayer)map.removeLayer(resLayer);resLayer=null;$("tres").style.display="none"};
$("texp").onclick=async()=>{if(!resId)return;const f=$("tfmt").value,r=await fetch(`/api/tools/${resId}/export?format=${f}`);if(!r.ok)return toast((await r.json()).error||"error");
 await saveBlob(await r.blob(),"result."+({shp:"zip"}[f]||f));toast(T("done"))};
$("tres").style.cssText="display:none;position:fixed;left:12px;right:12px;bottom:96px;z-index:640;background:var(--card);border-radius:18px;padding:10px;box-shadow:var(--sh)";document.body.appendChild($("tres"));

/* ===== الأقضية من OSM ===== */
$("dad").onclick=()=>{document.body.classList.remove("dr");$("ad").classList.add("show");pollAdmin()};
$("adclose").onclick=()=>$("ad").classList.remove("show");
$("afetch").onclick=async()=>{const q=$("aq").value.trim();if(!q)return;toast("…");const r=await fetch("/api/admin/fetch",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:q,name_en:q,name_ar:$("aar").value.trim()})});
 const j=await r.json();toast(r.ok?T("done2")+": "+j.name:(j.error||"error"));upInfo()};
let pt;async function pollAdmin(){try{const j=await (await fetch("/api/admin/status")).json();$("apg").style.width=(j.total?Math.round(j.done/j.total*100):0)+"%";
 $("ast").textContent=`${j.done}/${j.total} — ✔ ${j.added.length}  ✖ ${j.failed.length}  (Σ ${j.total_known})`;clearTimeout(pt);if(j.running&&$("ad").classList.contains("show"))pt=setTimeout(pollAdmin,2000)}catch(e){}}
$("abulk").onclick=async()=>{await fetch("/api/admin/bulk",{method:"POST"});pollAdmin();setTimeout(pollAdmin,1500)};
render();
</script></body></html>"""
