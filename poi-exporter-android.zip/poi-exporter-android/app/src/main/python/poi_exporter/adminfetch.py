"""جلب حدود قضاء من OSM (Nominatim بالاسم أو Overpass ضمن منطقة) وإضافته إلى المرجع المحلي مع حفظه في ملف."""
from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Callable, List, Optional

from . import overpass
from .admin import AdminRef
from .geo import AreaSpec, set_representative
from .model import POLYGON, Feature

CREDIT = "© OpenStreetMap contributors (ODbL)"
UA = "poi-exporter-py/3.6"


@dataclass
class Found:
    name_en: str = ""
    name_ar: str = ""
    detail: str = ""
    poly: Optional[Feature] = None


def from_geojson(g: dict) -> Optional[Feature]:
    co = g.get("coordinates")
    if not co:
        return None
    polys = co if g.get("type") == "MultiPolygon" else [co]
    f = Feature(geom=POLYGON, id=Feature.new_id())
    for rings in polys:
        for k, pts in enumerate(rings):
            if len(pts) >= 4:
                f.add_part([(p[0], p[1]) for p in pts], k > 0)
    if not f.parts:
        return None
    set_representative(f)
    return f


def parse_nominatim(data) -> List[Found]:
    arr = json.loads(data) if isinstance(data, (str, bytes)) else data
    out = []
    for o in arr:
        g = o.get("geojson")
        if not g or g.get("type") not in ("Polygon", "MultiPolygon"):
            continue          # نتيجة نقطية ليست حدّاً
        f = from_geojson(g)
        if f:
            nm = o.get("name", "")
            out.append(Found(nm, nm, f'{o.get("display_name", "")}  [{o.get("category", "")}/{o.get("type", "")}]', f))
    return out


def by_name(query: str, http: Optional[Callable[[str], bytes]] = None) -> List[Found]:
    url = ("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&polygon_geojson=1&polygon_threshold=0.0005"
           "&countrycodes=iq&accept-language=ar,en&q=" + urllib.parse.quote(query))
    if http is None:
        def http(u):
            with urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": UA}), timeout=30) as r:
                return r.read()
    return parse_nominatim(http(url))


def in_area(area: AreaSpec, level: int, fetcher: overpass.Fetcher) -> List[Found]:
    out = []
    for e in overpass.parse(fetcher(overpass.admin_query([level], area))):
        if overpass.admin_level(e.tags) != level:
            continue
        poly = overpass.polygon_from(e)
        if poly is None:
            continue
        ar = e.tag("name:ar") or e.tag("name")
        en = e.tag("name:en") or e.tag("int_name") or e.tag("name")
        if ar or en:
            out.append(Found(en, ar, f"admin_level={level}  OSM relation {e.id}", poly))
    return out


def add(ref: AdminRef, found: Found, path: Optional[str] = None):
    """يضيف القضاء المجلوب للمرجع (يستبدل المطابق بالاسم) ويحفظ الإضافات في path إن أُعطي."""
    u = ref.add_extra(found.name_en, found.name_ar, found.poly, CREDIT)
    if u is not None and path:
        save(ref, path)
    return u


def save(ref: AdminRef, path: str) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(ref.extras_json())


def restore(ref: AdminRef, path: str) -> int:
    if not os.path.isfile(path):
        return 0
    return ref.load_extras(open(path, encoding="utf-8").read())
