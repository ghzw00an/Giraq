"""إحصاءات منطقة: عدد المعالم لكل قطاع/نوع/محافظة داخل مضلع (أو كل الطبقات)."""
from __future__ import annotations

from collections import Counter, OrderedDict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from . import geodesy, geoops
from .model import POINT, POLYGON, Feature, Layer

BY_SECTOR, BY_TYPE, BY_GOVERNORATE, BY_QADAA, BY_LAYER = "sector", "type", "governorate", "qadaa", "layer"


@dataclass
class Result:
    total: int = 0
    by: Dict[str, int] = field(default_factory=dict)
    area_m2: float = 0.0
    density_per_km2: float = 0.0

    def table(self) -> List[List[str]]:
        rows = [["القيمة", "العدد", "النسبة %"]]
        for k, v in self.by.items():
            rows.append([k, str(v), "%.1f" % (100.0 * v / self.total if self.total else 0)])
        rows.append(["المجموع", str(self.total), "100.0"])
        return rows


def compute(layers: Sequence[Layer], area: Optional[Feature] = None, mode: str = geoops.INSIDE, by: str = BY_SECTOR) -> Result:
    feats: List = []
    for l in layers:
        for f in l.features:
            feats.append((l, f))
    if area is not None:
        chosen = {id(f) for f in geoops.select([f for _, f in feats], area, mode)}
        feats = [(l, f) for l, f in feats if id(f) in chosen]
    key = {BY_SECTOR: lambda l, f: f.category, BY_TYPE: lambda l, f: f.type, BY_GOVERNORATE: lambda l, f: f.governorate,
           BY_QADAA: lambda l, f: f.qadaa, BY_LAYER: lambda l, f: l.label}[by]
    c = Counter((key(l, f) or "(فارغ)") for l, f in feats)
    r = Result(total=len(feats), by=OrderedDict(sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))))
    if area is not None and area.geom == POLYGON:
        r.area_m2 = geodesy.area(area)
        r.density_per_km2 = r.total / (r.area_m2 / 1e6) if r.area_m2 > 0 else 0.0
    return r
