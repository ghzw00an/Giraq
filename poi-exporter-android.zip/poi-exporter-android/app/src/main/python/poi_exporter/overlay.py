"""محرك التراكب الهندسي (اتحاد/تقاطع/فرق/دمج) بلا مكتبات: يبني ترتيباً مستوياً (Arrangement) للقطع ثم يستخرج الوجوه
ويصنّفها حسب وقوعها في كل مُدخل. الإحداثيات مستوية (متر). كل مُدخل = قائمة حلقات تُفسَّر بقاعدة الزوجي/الفردي."""
from __future__ import annotations

import math
from collections import defaultdict
from typing import Callable, Dict, List, Optional, Sequence, Tuple

Pt = Tuple[float, float]
Ring = List[Pt]
SNAP = 1e-6


def _snap(p: Pt) -> Pt:
    return (round(p[0] / SNAP) * SNAP, round(p[1] / SNAP) * SNAP)


def _area2(r: Sequence[Pt]) -> float:
    a = 0.0
    j = len(r) - 1
    for i in range(len(r)):
        a += r[j][0] * r[i][1] - r[i][0] * r[j][1]
        j = i
    return a


def _in_rings(x: float, y: float, rings: Sequence[Sequence[Pt]]) -> bool:
    inside = False
    for r in rings:
        j = len(r) - 1
        for i in range(len(r)):
            xi, yi = r[i]
            xj, yj = r[j]
            if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
                inside = not inside
            j = i
    return inside


def _pip_ring(x: float, y: float, r: Sequence[Pt]) -> bool:
    return _in_rings(x, y, [r])


def _interior_point(rings: Sequence[Sequence[Pt]]) -> Pt:
    """نقطة داخل المنطقة المحددة بالحلقات (قشرة + ثقوب): منتصف أعرض مقطع أفقي."""
    ys = [p[1] for r in rings for p in r]
    y0, y1 = min(ys), max(ys)
    best_w, best = -1.0, None
    for frac in (0.5, 0.37, 0.63, 0.25, 0.75, 0.13, 0.87):
        y = y0 + (y1 - y0) * frac
        xs = []
        for r in rings:
            j = len(r) - 1
            for i in range(len(r)):
                if (r[i][1] > y) != (r[j][1] > y):
                    xs.append((r[j][0] - r[i][0]) * (y - r[i][1]) / (r[j][1] - r[i][1]) + r[i][0])
                j = i
        xs.sort()
        for k in range(0, len(xs) - 1, 2):
            w = xs[k + 1] - xs[k]
            if w > best_w:
                best_w, best = w, ((xs[k] + xs[k + 1]) / 2, y)
    return best or rings[0][0]


# ---------------------------------------------------------------------------- تنقيط القطع
def _segments(sets: Sequence[Sequence[Ring]]) -> List[Tuple[Pt, Pt]]:
    segs, seen = [], set()
    for rings in sets:
        for r in rings:
            pts = [_snap(p) for p in r]
            if pts and pts[0] != pts[-1]:
                pts.append(pts[0])
            for i in range(len(pts) - 1):
                a, b = pts[i], pts[i + 1]
                if a == b:
                    continue
                key = (a, b) if a < b else (b, a)
                if key not in seen:
                    seen.add(key)
                    segs.append(key)
    return segs


def _node(segs: List[Tuple[Pt, Pt]]) -> List[Tuple[Pt, Pt]]:
    n = len(segs)
    if n == 0:
        return []
    xs = [p[0] for s in segs for p in s]
    ys = [p[1] for s in segs for p in s]
    span = max(max(xs) - min(xs), max(ys) - min(ys), 1e-9)
    cell = max(span / max(1, int(math.sqrt(n))), 1e-9)
    x0, y0 = min(xs), min(ys)
    grid: Dict[Tuple[int, int], List[int]] = defaultdict(list)
    for i, (a, b) in enumerate(segs):
        for cx in range(int((min(a[0], b[0]) - x0) / cell), int((max(a[0], b[0]) - x0) / cell) + 1):
            for cy in range(int((min(a[1], b[1]) - y0) / cell), int((max(a[1], b[1]) - y0) / cell) + 1):
                grid[(cx, cy)].append(i)
    splits: List[List[Pt]] = [[] for _ in range(n)]
    done = set()
    for cell_list in grid.values():
        for ii in range(len(cell_list)):
            for jj in range(ii + 1, len(cell_list)):
                i, j = cell_list[ii], cell_list[jj]
                if (i, j) in done:
                    continue
                done.add((i, j))
                a, b = segs[i]
                c, d = segs[j]
                rx, ry, sx, sy = b[0] - a[0], b[1] - a[1], d[0] - c[0], d[1] - c[1]
                den = rx * sy - ry * sx
                qpx, qpy = c[0] - a[0], c[1] - a[1]
                if abs(den) > 1e-18:
                    t = (qpx * sy - qpy * sx) / den
                    u = (qpx * ry - qpy * rx) / den
                    if -1e-9 <= t <= 1 + 1e-9 and -1e-9 <= u <= 1 + 1e-9:
                        p = _snap((a[0] + t * rx, a[1] + t * ry))
                        splits[i].append(p)
                        splits[j].append(p)
                else:
                    if abs(qpx * ry - qpy * rx) > 1e-9 * max(1.0, math.hypot(rx, ry)):
                        continue        # متوازيان لا يتلاقيان
                    for p, k in ((c, i), (d, i), (a, j), (b, j)):   # تداخل على استقامة واحدة
                        s = segs[k]
                        lo = (min(s[0][0], s[1][0]), min(s[0][1], s[1][1]))
                        hi = (max(s[0][0], s[1][0]), max(s[0][1], s[1][1]))
                        if lo[0] - 1e-9 <= p[0] <= hi[0] + 1e-9 and lo[1] - 1e-9 <= p[1] <= hi[1] + 1e-9:
                            splits[k].append(p)
    out, seen = [], set()
    for i, (a, b) in enumerate(segs):
        pts = {a, b, *splits[i]}
        d0 = (b[0] - a[0], b[1] - a[1])
        ordered = sorted(pts, key=lambda p: (p[0] - a[0]) * d0[0] + (p[1] - a[1]) * d0[1])
        for k in range(len(ordered) - 1):
            p, q = ordered[k], ordered[k + 1]
            if p == q:
                continue
            key = (p, q) if p < q else (q, p)
            if key not in seen:
                seen.add(key)
                out.append(key)
    return out


# ---------------------------------------------------------------------------- الرسم المستوي
class _Graph:
    def __init__(self, edges: List[Tuple[Pt, Pt]]):
        self.out: Dict[Pt, List[Pt]] = defaultdict(list)
        for a, b in edges:
            self.out[a].append(b)
            self.out[b].append(a)
        for v, nb in self.out.items():
            nb.sort(key=lambda w: math.atan2(w[1] - v[1], w[0] - v[0]))

    def next_edge(self, u: Pt, v: Pt) -> Pt:
        """بعد الوصول إلى v قادماً من u: خذ الحافة التالية «أقصى اليسار» حتى يبقى الوجه على يسارنا."""
        nb = self.out[v]
        i = nb.index(u)
        return nb[(i - 1) % len(nb)]


def _prune(edges: List[Tuple[Pt, Pt]]) -> List[Tuple[Pt, Pt]]:
    """يحذف الحواف المتدلّية (عقدة بدرجة 1) لأنها لا تحيط بوجه."""
    deg: Dict[Pt, int] = defaultdict(int)
    adj: Dict[Pt, set] = defaultdict(set)
    for a, b in edges:
        adj[a].add(b)
        adj[b].add(a)
    stack = [v for v, s in adj.items() if len(s) == 1]
    while stack:
        v = stack.pop()
        if len(adj[v]) != 1:
            continue
        w = next(iter(adj[v]))
        adj[v].clear()
        adj[w].discard(v)
        if len(adj[w]) == 1:
            stack.append(w)
    return [(a, b) for a, b in edges if b in adj[a]]


def overlay(sets: Sequence[Sequence[Ring]], keep: Callable[[Sequence[bool]], bool], dissolve: bool = True) -> List[List[Ring]]:
    """يرجع مضلعات [قشرة، ثقوب…] للمناطق التي يُرجع keep(flags) صواباً عندها (flags[i] = داخل المُدخل i)."""
    edges = _prune(_node(_segments(sets)))
    if not edges:
        return []
    g = _Graph(edges)
    visited = set()
    cycles: List[Ring] = []
    cyc_of: Dict[Tuple[Pt, Pt], int] = {}
    for a, b in edges:
        for u, v in ((a, b), (b, a)):
            if (u, v) in visited:
                continue
            ring: Ring = []
            cu, cv = u, v
            while (cu, cv) not in visited:
                visited.add((cu, cv))
                cyc_of[(cu, cv)] = len(cycles)
                ring.append(cu)
                cu, cv = cv, g.next_edge(cu, cv)
            cycles.append(ring)
    # مركّبات متصلة
    comp: Dict[Pt, Pt] = {}

    def find(x):
        while comp.setdefault(x, x) != x:
            comp[x] = comp[comp[x]]
            x = comp[x]
        return x
    for a, b in edges:
        comp[find(a)] = find(b)
    areas = [_area2(r) for r in cycles]
    shells = [i for i, a in enumerate(areas) if a > 1e-12]
    negs = [i for i, a in enumerate(areas) if a < -1e-12]
    parent: Dict[int, Optional[int]] = {}
    for i in negs:
        v = cycles[i][0]
        best, best_a = None, float("inf")
        for s in shells:
            if find(cycles[s][0]) == find(v):
                continue
            if areas[s] < best_a and _pip_ring(v[0], v[1], cycles[s]):
                best, best_a = s, areas[s]
        parent[i] = best
    children: Dict[int, List[int]] = defaultdict(list)
    for i, p in parent.items():
        if p is not None:
            children[p].append(i)
    # تصنيف الوجوه
    inc: Dict[int, bool] = {}
    for s in shells:
        pt = _interior_point([cycles[s]] + [cycles[h] for h in children[s]])
        flags = [_in_rings(pt[0], pt[1], rings) for rings in sets]
        inc[s] = bool(keep(flags))
    if not dissolve:      # كل وجه مشمول مستقلاً (قشرة + ثقوبه) دون إذابة الحواف المشتركة
        return [[cycles[s]] + [cycles[h][::-1][::-1] for h in children[s]] for s in shells if inc[s]]
    left_face = {}
    for (u, v), ci in cyc_of.items():
        left_face[(u, v)] = ci if areas[ci] > 1e-12 else parent.get(ci)
    sel: Dict[Pt, List[Pt]] = defaultdict(list)
    for (u, v), lf in left_face.items():
        rf = left_face.get((v, u))
        if lf is not None and inc.get(lf, False) and not (rf is not None and inc.get(rf, False)):
            sel[u].append(v)
    # ربط الحواف المختارة في حلقات
    rings: List[Ring] = []
    used = set()
    for u0, vs in list(sel.items()):
        for v0 in vs:
            if (u0, v0) in used:
                continue
            ring, u, v = [], u0, v0
            while (u, v) not in used:
                used.add((u, v))
                ring.append(u)
                outs = sel[v]
                if len(outs) == 1:
                    nxt = outs[0]
                else:
                    nb = g.out[v]
                    k = nb.index(u)
                    order = [nb[(k - 1 - m) % len(nb)] for m in range(len(nb))]
                    nxt = next(w for w in order if w in outs and (v, w) not in used) if any(w in outs and (v, w) not in used for w in order) else outs[0]
                u, v = v, nxt
            if len(ring) >= 3:
                rings.append(ring)
    # حذف النقاط الخطية الزائدة
    clean = []
    for r in rings:
        out = []
        n = len(r)
        for i in range(n):
            a, b, c = r[i - 1], r[i], r[(i + 1) % n]
            if abs((b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])) > 1e-9:
                out.append(b)
        if len(out) >= 3 and abs(_area2(out)) > 1e-9:
            clean.append(out)
    shells_r = [r for r in clean if _area2(r) > 0]
    holes_r = [r for r in clean if _area2(r) < 0]
    polys = [[s] for s in shells_r]
    for h in holes_r:
        best, best_a = None, float("inf")
        for k, s in enumerate(shells_r):
            a = _area2(s)
            if a < best_a and all(_pip_ring(p[0], p[1], s) or p in s for p in h):
                best, best_a = k, a
        if best is not None:
            polys[best].append(h)
    return polys


# ---------------------------------------------------------------------------- واجهات مريحة
def union(*operands: Sequence[Ring]) -> List[List[Ring]]:
    return overlay(operands, lambda f: any(f))


def intersection(a: Sequence[Ring], b: Sequence[Ring]) -> List[List[Ring]]:
    return overlay([a, b], lambda f: f[0] and f[1])


def difference(a: Sequence[Ring], b: Sequence[Ring]) -> List[List[Ring]]:
    return overlay([a, b], lambda f: f[0] and not f[1])


def sym_difference(a: Sequence[Ring], b: Sequence[Ring]) -> List[List[Ring]]:
    return overlay([a, b], lambda f: f[0] != f[1])


def circle(cx: float, cy: float, r: float, n: int = 32) -> Ring:
    return [(cx + r * math.cos(2 * math.pi * i / n), cy + r * math.sin(2 * math.pi * i / n)) for i in range(n)]


def capsule(a: Pt, b: Pt, r: float, n: int = 16) -> Ring:
    """مستطيل مع نصفي دائرة (بيل الخط) حول القطعة a-b."""
    ang = math.atan2(b[1] - a[1], b[0] - a[0])
    pts: Ring = []
    for i in range(n + 1):                      # نصف دائرة عند b
        t = ang - math.pi / 2 + math.pi * i / n
        pts.append((b[0] + r * math.cos(t), b[1] + r * math.sin(t)))
    for i in range(n + 1):                      # نصف دائرة عند a
        t = ang + math.pi / 2 + math.pi * i / n
        pts.append((a[0] + r * math.cos(t), a[1] + r * math.sin(t)))
    return pts
