"""UTM وMGRS وتنسيق/تحليل الإحداثيات (DD, DMS, DDM, UTM, MGRS) ونظم الإسناد CRS."""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Callable, Optional, Tuple

# ----------------------------------------------------------------------------- UTM (Krüger / Karney 2011)
_A = 6378137.0
_F = 1.0 / 298.257223563
_K0 = 0.9996
_E0 = 500000.0
_N0_SOUTH = 10000000.0
_N = _F / (2.0 - _F)
_N2, _N3, _N4 = _N ** 2, _N ** 3, _N ** 4
_E = math.sqrt(_F * (2.0 - _F))
_AA = _A / (1 + _N) * (1 + _N2 / 4 + _N4 / 64)
_ALPHA = [_N / 2 - 2 * _N2 / 3 + 5 * _N3 / 16 + 41 * _N4 / 180,
          13 * _N2 / 48 - 3 * _N3 / 5 + 557 * _N4 / 1440,
          61 * _N3 / 240 - 103 * _N4 / 140,
          49561 * _N4 / 161280]
_BETA = [_N / 2 - 2 * _N2 / 3 + 37 * _N3 / 96 - _N4 / 360,
         _N2 / 48 + _N3 / 15 - 437 * _N4 / 1440,
         17 * _N3 / 480 - 37 * _N4 / 840,
         4397 * _N4 / 161280]
_DELTA = [2 * _N - 2 * _N2 / 3 - 2 * _N3 + 116 * _N4 / 45,
          7 * _N2 / 3 - 8 * _N3 / 5 - 227 * _N4 / 45,
          56 * _N3 / 15 - 136 * _N4 / 35,
          4279 * _N4 / 630]
_BANDS = "CDEFGHJKLMNPQRSTUVWX"


@dataclass
class UtmResult:
    zone: int
    north: bool
    easting: float
    northing: float
    band: str

    def zone_label(self) -> str:
        return f"{self.zone}{self.band}"


def band_letter(lat: float) -> str:
    i = int(math.floor((lat + 80.0) / 8.0))
    return _BANDS[max(0, min(19, i))]


def zone_for(lon: float) -> int:
    l = lon
    while l >= 180:
        l -= 360
    while l < -180:
        l += 360
    return max(1, min(60, int(math.floor((l + 180.0) / 6.0)) + 1))


def _atanh(x: float) -> float:
    return 0.5 * math.log((1 + x) / (1 - x))


def utm_from_latlon(lat: float, lon: float, zone: Optional[int] = None) -> UtmResult:
    if zone is None:
        zone = zone_for(lon)
    lon0 = math.radians((zone - 1) * 6 - 180 + 3)
    phi = math.radians(lat)
    lam = math.radians(lon) - lon0
    while lam > math.pi:
        lam -= 2 * math.pi
    while lam < -math.pi:
        lam += 2 * math.pi
    sp = math.sin(phi)
    t = math.sinh(_atanh(sp) - _E * _atanh(_E * sp))
    xi_p = math.atan2(t, math.cos(lam))
    eta_p = _atanh(math.sin(lam) / math.sqrt(1 + t * t))
    xi, eta = xi_p, eta_p
    for j in range(1, 5):
        xi += _ALPHA[j - 1] * math.sin(2 * j * xi_p) * math.cosh(2 * j * eta_p)
        eta += _ALPHA[j - 1] * math.cos(2 * j * xi_p) * math.sinh(2 * j * eta_p)
    north = lat >= 0
    return UtmResult(zone, north, _E0 + _K0 * _AA * eta,
                     _K0 * _AA * xi + (0.0 if north else _N0_SOUTH), band_letter(lat))


def utm_to_latlon(zone: int, north: bool, easting: float, northing: float) -> Tuple[float, float]:
    lon0 = math.radians((zone - 1) * 6 - 180 + 3)
    xi = (northing - (0.0 if north else _N0_SOUTH)) / (_K0 * _AA)
    eta = (easting - _E0) / (_K0 * _AA)
    xi_p, eta_p = xi, eta
    for j in range(1, 5):
        xi_p -= _BETA[j - 1] * math.sin(2 * j * xi) * math.cosh(2 * j * eta)
        eta_p -= _BETA[j - 1] * math.cos(2 * j * xi) * math.sinh(2 * j * eta)
    chi = math.asin(math.sin(xi_p) / math.cosh(eta_p))
    phi = chi
    for j in range(1, 5):
        phi += _DELTA[j - 1] * math.sin(2 * j * chi)
    lam = lon0 + math.atan2(math.sinh(eta_p), math.cos(xi_p))
    return math.degrees(phi), math.degrees(lam)


# ----------------------------------------------------------------------------- MGRS
_COLS = ["ABCDEFGH", "JKLMNPQR", "STUVWXYZ"]
_ROWS = "ABCDEFGHJKLMNPQRSTUV"
_MGRS_RE = re.compile(r"^(\d{1,2})([C-HJ-NP-X])([A-HJ-NP-Z])([A-HJ-NP-V])(\d{0,10})$")


def mgrs_looks(compact_upper: str) -> bool:
    m = _MGRS_RE.match(compact_upper)
    return bool(m) and len(m.group(5)) % 2 == 0


def mgrs_from_latlon(lat: float, lon: float, digits: int = 5) -> str:
    if lat < -80 or lat > 84:
        raise ValueError("MGRS covers 80S to 84N")
    u = utm_from_latlon(lat, lon)
    band = min(19, int(math.floor((lat + 80) / 8)))
    s = (u.zone - 1) % 3
    col = max(0, min(7, int(math.floor(u.easting / 100000)) - 1))
    row = (int(math.floor(u.northing / 100000)) + (5 if u.zone % 2 == 0 else 0)) % 20
    e = int(math.floor(u.easting + 1e-4)) % 100000
    n = int(math.floor(u.northing + 1e-4)) % 100000
    es, ns = "%05d" % e, "%05d" % n
    es, ns = es[:digits], ns[:digits]
    out = f"{u.zone}{_BANDS[band]} {_COLS[s][col]}{_ROWS[row]}"
    return out + (f" {es} {ns}" if digits > 0 else "")


def mgrs_to_latlon(text: str) -> Tuple[float, float]:
    """(lat, lon) للركن الجنوبي الغربي للمربع المشار إليه."""
    s = re.sub(r"[\s,;]+", "", text).upper()
    m = _MGRS_RE.match(s)
    if not m or len(m.group(5)) % 2:
        raise ValueError("bad MGRS")
    zone = int(m.group(1))
    if zone < 1 or zone > 60:
        raise ValueError("bad zone")
    band = _BANDS.index(m.group(2))
    st = (zone - 1) % 3
    col = _COLS[st].find(m.group(3))
    row = _ROWS.find(m.group(4))
    if col < 0:
        raise ValueError("bad column letter for zone")
    d = m.group(5)
    half = len(d) // 2
    pad = lambda x: float(x.ljust(5, "0"))
    e = 0.0 if half == 0 else pad(d[:half])
    n = 0.0 if half == 0 else pad(d[half:])
    easting = (col + 1) * 100000.0 + e
    n100 = ((row - (5 if zone % 2 == 0 else 0)) % 20) * 100000.0
    north = band >= 10
    band_lat = (band - 10) * 8 + (6 if band == 19 else 4)
    band_min = (band - 10) * 8
    band_max = band_min + (12 if band == 19 else 8)
    best, best_d = None, 1e9
    for k in range(10):
        northing = n100 + n + k * 2000000.0
        if northing > 10000000.0:
            break
        lat, lon = utm_to_latlon(zone, north, easting, northing)
        if band_min - 1e-4 <= lat <= band_max + 1e-4:
            d_ = abs(lat - band_lat)
            if d_ < best_d:
                best_d, best = d_, northing
    if best is None:
        raise ValueError("MGRS outside its latitude band")
    return utm_to_latlon(zone, north, easting, best)


# ----------------------------------------------------------------------------- تنسيق / تحليل
FMT_DD, FMT_DMS, FMT_UTM, FMT_MGRS, FMT_DDM = "DD", "DMS", "UTM", "MGRS", "DDM"


@dataclass
class Parsed:
    lat: float
    lon: float
    fmt: str


def fmt_dd(lat, lon) -> str:
    return "%.7f, %.7f" % (lat, lon)


def fmt_utm(lat, lon) -> str:
    u = utm_from_latlon(lat, lon)
    return "%s %.2f %.2f" % (u.zone_label(), u.easting, u.northing)


def _dms1(v: float, pos: str, neg: str) -> str:
    cs = int(round(abs(v) * 3600 * 100))
    deg, min_, sec = cs // 360000, (cs % 360000) // 6000, (cs % 6000) / 100.0
    return "%d°%02d'%05.2f\"%s" % (deg, min_, sec, neg if v < 0 else pos)


def _ddm1(v: float, pos: str, neg: str) -> str:
    tm = int(round(abs(v) * 60 * 100000))
    deg, minute = tm // 6000000, (tm % 6000000) / 100000.0
    return "%d°%08.5f'%s" % (deg, minute, neg if v < 0 else pos)


def fmt_dms(lat, lon) -> str:
    return _dms1(lat, "N", "S") + " " + _dms1(lon, "E", "W")


def fmt_ddm(lat, lon) -> str:
    return _ddm1(lat, "N", "S") + " " + _ddm1(lon, "E", "W")


def format_coord(fmt: str, lat: float, lon: float) -> str:
    if fmt == FMT_DMS:
        return fmt_dms(lat, lon)
    if fmt == FMT_DDM:
        return fmt_ddm(lat, lon)
    if fmt == FMT_UTM:
        return fmt_utm(lat, lon)
    if fmt == FMT_MGRS:
        return fmt_utm(lat, lon) if (lat < -80 or lat > 84) else mgrs_from_latlon(lat, lon, 5)
    return fmt_dd(lat, lon)


_UTM_RE = re.compile(r"^(\d{1,2})\s*([C-HJ-NP-X])?\s+(?:E\s*)?(\d+(?:\.\d+)?)\s*M?\s+(?:N\s*)?(\d+(?:\.\d+)?)\s*M?$")
_TOKEN_RE = re.compile(r"([NSEW])|([+-]?\d+(?:\.\d+)?|[+-]?\.\d+)")


def _normalize(raw: str) -> str:
    out = []
    for c in raw.strip():
        if "٠" <= c <= "٩":
            out.append(chr(ord("0") + ord(c) - ord("٠")))
        elif "۰" <= c <= "۹":
            out.append(chr(ord("0") + ord(c) - ord("۰")))
        elif c == "٫":
            out.append(".")
        elif c in "،؛":
            out.append(",")
        elif c in "−–":
            out.append("-")
        elif c in "′’‘`´":
            out.append("'")
        elif c in "″”“":
            out.append('"')
        else:
            out.append(c.upper())
    return "".join(out)


def parse_coord(raw: str) -> Parsed:
    """يكتشف الصيغة تلقائياً؛ يرفع ValueError عند عدم التعرف."""
    if raw is None or not raw.strip():
        raise ValueError("empty")
    t = _normalize(raw)
    compact = re.sub(r"[\s,;]+", "", t)
    if mgrs_looks(compact):
        lat, lon = mgrs_to_latlon(compact)
        return Parsed(lat, lon, FMT_MGRS)
    m = _UTM_RE.match(t.replace(",", " ").replace(";", " ").strip())
    if m:
        zone = int(m.group(1))
        e, n = float(m.group(3)), float(m.group(4))
        h = m.group(2)
        north = h is None or h in "NPQRSTUVWX"
        if 1 <= zone <= 60 and 100000 <= e <= 900000 and 0 <= n <= 10000000:
            lat, lon = utm_to_latlon(zone, north, e, n)
            return Parsed(lat, lon, FMT_UTM)
    return _parse_degrees(t)


def _parse_degrees(t: str) -> Parsed:
    s = re.sub(r"[°º'\":,;]", " ", t)
    toks = []
    letters = 0
    for m in _TOKEN_RE.finditer(s):
        if m.group(1):
            toks.append(("L", m.group(1)))
            letters += 1
        else:
            toks.append(("V", float(m.group(2)), m.group(2).startswith("-")))
    bad = ValueError("unrecognized coordinates")
    if letters not in (0, 2):
        raise bad
    chunks, chunk_letter = [], []
    if letters == 0:
        n = len(toks)
        if n not in (2, 4, 6):
            raise bad
        per = n // 2
        chunks = [toks[:per], toks[per:]]
    elif toks[0][0] == "L":
        cur = None
        for k in toks:
            if k[0] == "L":
                chunk_letter.append(k[1])
                cur = []
                chunks.append(cur)
            else:
                cur.append(k)
    else:
        cur = []
        for k in toks:
            if k[0] == "L":
                chunk_letter.append(k[1])
                chunks.append(cur)
                cur = []
            else:
                cur.append(k)
        if cur:
            raise bad
    if len(chunks) != 2:
        raise bad
    val, dms, max_chunk = [0.0, 0.0], False, 1
    for c in range(2):
        ch = chunks[c]
        if not ch or len(ch) > 3:
            raise bad
        d = abs(ch[0][1])
        mi = ch[1][1] if len(ch) > 1 else 0.0
        se = ch[2][1] if len(ch) > 2 else 0.0
        if len(ch) > 1:
            dms = True
        max_chunk = max(max_chunk, len(ch))
        if mi < 0 or mi >= 60 or se < 0 or se >= 60:
            raise ValueError("bad minutes or seconds")
        v = d + mi / 60 + se / 3600
        neg = (chunk_letter[c] in "SW") if letters == 2 else ch[0][2]
        val[c] = -v if neg else v
    if letters == 2:
        a0 = chunk_letter[0] in "NS"
        a1 = chunk_letter[1] in "NS"
        if a0 == a1:
            raise ValueError("need one latitude and one longitude")
        lat, lon = (val[0], val[1]) if a0 else (val[1], val[0])
    else:
        lat, lon = val
    if abs(lat) > 90 or abs(lon) > 180:
        raise ValueError("out of range")
    return Parsed(lat, lon, FMT_DD if not dms else (FMT_DDM if max_chunk == 2 else FMT_DMS))


# ----------------------------------------------------------------------------- CRS
class Crs:
    """نظام إحداثيات. يعمل بدون مكتبات خارجية لـ WGS84 وWeb Mercator وUTM (EPSG:326xx/327xx)،
    ولأي EPSG آخر إن توفرت مكتبة pyproj."""

    def __init__(self, epsg: int, name: str, geographic: bool):
        self.epsg, self.name, self.geographic = epsg, name, geographic

    def __repr__(self):
        return f"Crs(EPSG:{self.epsg}, {self.name})"

    @staticmethod
    def wgs84() -> "Crs":
        return Crs(4326, "WGS 84", True)

    @staticmethod
    def utm(zone: int, north: bool = True) -> "Crs":
        return Crs((32600 if north else 32700) + zone, f"WGS 84 / UTM zone {zone}{'N' if north else 'S'}", False)

    @staticmethod
    def of(code) -> "Crs":
        if isinstance(code, str):
            c = code.strip().upper().replace("EPSG:", "")
            if not c.isdigit():
                raise ValueError(f"unknown CRS: {code}")
            code = int(c)
        code = int(code)
        if code == 4326:
            return Crs.wgs84()
        if code == 3857:
            return Crs(3857, "WGS 84 / Pseudo-Mercator", False)
        if 32601 <= code <= 32660:
            return Crs.utm(code - 32600, True)
        if 32701 <= code <= 32760:
            return Crs.utm(code - 32700, False)
        from . import proj as _proj
        if _proj.supported(code):
            d = _proj.parse(code)
            return Crs(code, d.name, d.geographic)
        try:
            from pyproj import CRS as _P  # type: ignore
            p = _P.from_epsg(code)
            return Crs(code, p.name, p.is_geographic)
        except Exception as e:  # noqa: BLE001
            raise ValueError(f"EPSG:{code} غير مدعوم (إسقاط غير متوفر؛ ثبّت pyproj)") from e

    @staticmethod
    def search(text: str, limit: int = 30):
        """بحث في فهرس EPSG المضمّن بالرمز أو الاسم: [(code, name)]."""
        from . import proj as _proj
        return _proj.search(text, limit)

    def transformer_from_wgs84(self) -> Callable[[float, float], Tuple[float, float]]:
        """دالة (lon, lat) → (x, y) في هذا النظام."""
        if self.epsg == 4326:
            return lambda lon, lat: (lon, lat)
        if self.epsg == 3857:
            def merc(lon, lat):
                x = _A * math.radians(lon)
                y = _A * math.log(math.tan(math.pi / 4 + math.radians(max(-85.0511, min(85.0511, lat))) / 2))
                return x, y
            return merc
        if 32601 <= self.epsg <= 32760:
            zone = self.epsg % 100
            def u(lon, lat):
                r = utm_from_latlon(lat, lon, zone)
                return r.easting, r.northing
            return u
        from . import proj as _proj
        if _proj.supported(self.epsg):
            return _proj.from_wgs84_fn(self.epsg)
        from pyproj import Transformer  # type: ignore
        t = Transformer.from_crs(4326, self.epsg, always_xy=True)
        return lambda lon, lat: t.transform(lon, lat)

    def transformer_to_wgs84(self) -> Callable[[float, float], Tuple[float, float]]:
        if self.epsg == 4326:
            return lambda x, y: (x, y)
        if self.epsg == 3857:
            return lambda x, y: (math.degrees(x / _A),
                                 math.degrees(2 * math.atan(math.exp(y / _A)) - math.pi / 2))
        if 32601 <= self.epsg <= 32760:
            zone, north = self.epsg % 100, self.epsg < 32700
            def u(x, y):
                lat, lon = utm_to_latlon(zone, north, x, y)
                return lon, lat
            return u
        from . import proj as _proj
        if _proj.supported(self.epsg):
            return _proj.to_wgs84_fn(self.epsg)
        from pyproj import Transformer  # type: ignore
        t = Transformer.from_crs(self.epsg, 4326, always_xy=True)
        return lambda x, y: t.transform(x, y)

    def wkt(self) -> str:
        """WKT لملف .prj في Shapefile."""
        if self.epsg == 4326:
            return ('GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137.0,298.257223563]],'
                    'PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]')
        if 32601 <= self.epsg <= 32760:
            z, n = self.epsg % 100, self.epsg < 32700
            return ('PROJCS["WGS_1984_UTM_Zone_%d%s",GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",'
                    'SPHEROID["WGS_1984",6378137.0,298.257223563]],PRIMEM["Greenwich",0.0],'
                    'UNIT["Degree",0.0174532925199433]],PROJECTION["Transverse_Mercator"],'
                    'PARAMETER["False_Easting",500000.0],PARAMETER["False_Northing",%s],'
                    'PARAMETER["Central_Meridian",%d.0],PARAMETER["Scale_Factor",0.9996],'
                    'PARAMETER["Latitude_Of_Origin",0.0],UNIT["Meter",1.0]]'
                    % (z, "N" if n else "S", "0.0" if n else "10000000.0", (z - 1) * 6 - 180 + 3))
        from . import proj as _proj
        if _proj.supported(self.epsg):
            return _proj.wkt(self.epsg)
        try:
            from pyproj import CRS as _P  # type: ignore
            return _P.from_epsg(self.epsg).to_wkt(version="WKT1_ESRI")
        except Exception as e:  # noqa: BLE001
            raise ValueError(f"لا يمكن كتابة .prj للنظام EPSG:{self.epsg}") from e
