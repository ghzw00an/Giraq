"""كتابة وقراءة Shapefile بلغة بايثون الصرفة (shp/shx/dbf/prj/cpg) داخل ملف ZIP."""
from __future__ import annotations

import io
import math
import re
import struct
import zipfile
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from . import landmark
from .coords import Crs
from .geo import oriented, set_representative, signed_area
from .model import LINE, POINT, POLYGON, Feature, Layer
from .sectors import norm_name

SHP_NULL, SHP_POINT, SHP_POLYLINE, SHP_POLYGON = 0, 1, 3, 5
_SHAPE_OF = {POINT: SHP_POINT, LINE: SHP_POLYLINE, POLYGON: SHP_POLYGON}


def safe_name(s: str, fallback: str = "layer") -> str:
    t = re.sub(r"[^A-Za-z0-9_\-]+", "_", s or "").strip("_")
    return t or re.sub(r"[^A-Za-z0-9_\-]+", "_", fallback or "").strip("_") or "layer"


def dbf_name(raw: str, used: set) -> str:
    """اسم حقل DBF: ASCII فقط وحتى 10 أحرف وفريد."""
    base = re.sub(r"[^A-Za-z0-9_]", "_", raw)[:10] or "f"
    if base[0].isdigit():
        base = "f" + base[:9]
    name, i = base, 1
    while name.lower() in used:
        suffix = str(i)
        name = base[:10 - len(suffix)] + suffix
        i += 1
    used.add(name.lower())
    return name


def _cut_utf8(s: str, n: int) -> bytes:
    b = s.encode("utf-8")
    if len(b) <= n:
        return b
    b = b[:n]
    while b:
        try:
            b.decode("utf-8")
            break
        except UnicodeDecodeError:
            b = b[:-1]
    return b


def _shape_records(feats: Sequence[Feature], geom: int, tx: Optional[Callable]):
    """يرجع قائمة (content_bytes, bbox) لكل ميزة بعد تحويل الإحداثيات."""
    recs = []
    for f in feats:
        parts = [[(tx(x, y) if tx else (x, y)) for x, y in p] for p in f.parts]
        if geom == POINT:
            x, y = parts[0][0]
            content = struct.pack("<idd", SHP_POINT, x, y)
            bb = (x, y, x, y)
        else:
            rings = []
            for i, p in enumerate(parts):
                if geom == POLYGON:
                    p = oriented(p, clockwise=not f.is_hole(i))
                rings.append(p)
            pts = [c for r in rings for c in r]
            xs, ys = [c[0] for c in pts], [c[1] for c in pts]
            bb = (min(xs), min(ys), max(xs), max(ys))
            idx, k = [], 0
            for r in rings:
                idx.append(k)
                k += len(r)
            content = (struct.pack("<i4dii", _SHAPE_OF[geom], *bb, len(rings), len(pts))
                       + struct.pack("<%di" % len(idx), *idx)
                       + b"".join(struct.pack("<dd", *c) for c in pts))
        recs.append((content, bb))
    return recs


def build(feats: Sequence[Feature], geom: int, target: Optional[Crs] = None, attributes: bool = True,
          xy_target: Optional[Crs] = None) -> Dict[str, bytes]:
    """يبني ملفات الشيب {ext: bytes}. الهندسة بنظام target (الافتراضي WGS84)
    وحقلا x,y بـ UTM (أو بنظام xy_target إن حُدد)."""
    target = target or Crs.wgs84()
    feats = [f for f in feats if f.parts]
    tx = None if target.epsg == 4326 else target.transformer_from_wgs84()
    recs = _shape_records(feats, geom, tx)
    # ---- shp / shx
    allbb = [r[1] for r in recs] or [(0, 0, 0, 0)]
    bb = (min(b[0] for b in allbb), min(b[1] for b in allbb), max(b[2] for b in allbb), max(b[3] for b in allbb))
    body_shp = io.BytesIO()
    body_shx = io.BytesIO()
    offset = 50
    for i, (content, _) in enumerate(recs, 1):
        words = len(content) // 2
        body_shp.write(struct.pack(">ii", i, words) + content)
        body_shx.write(struct.pack(">ii", offset, words))
        offset += 4 + words

    def header(length_words):
        return (struct.pack(">i5ii", 9994, 0, 0, 0, 0, 0, length_words)
                + struct.pack("<ii4d4d", 1000, _SHAPE_OF[geom], *bb, 0, 0, 0, 0))

    shp = header(50 + len(body_shp.getvalue()) // 2) + body_shp.getvalue()
    shx = header(50 + len(body_shx.getvalue()) // 2) + body_shx.getvalue()
    # ---- dbf
    xy_tx = None if xy_target is None or xy_target.epsg == 4326 else xy_target.transformer_from_wgs84()
    dec = 2 if xy_target is None else (9 if xy_target.geographic else 3)
    fields = [("name", "C", 254, 0), ("type", "C", 254, 0), ("Gategory", "C", 254, 0), ("gathaa", "C", 254, 0),
              ("Nahia", "C", 254, 0), ("mohafadha", "C", 254, 0), ("x", "N", 20, dec), ("y", "N", 20, dec),
              ("link", "C", 254, 0)]
    used = {f[0].lower() for f in fields}
    extra: List[Tuple[str, str]] = []   # (اسم الحقل الأصلي، اسم DBF)
    if attributes:
        keys: List[str] = []
        for f in feats:
            for k in f.attrs:
                if not landmark.is_std(k) and k not in keys:
                    keys.append(k)
            if len(keys) > 100:
                break
        for k in keys:
            n = dbf_name(k, used)
            extra.append((k, n))
            fields.append((n, "C", 254, 0))
    rec_len = 1 + sum(f[2] for f in fields)
    out = io.BytesIO()
    hdr_len = 32 + 32 * len(fields) + 1
    out.write(struct.pack("<BBBBIHH20x", 3, 126, 1, 1, len(feats), hdr_len, rec_len))
    for name, typ, ln, dc in fields:
        out.write(name.encode("ascii").ljust(11, b"\0") + typ.encode() + b"\0" * 4 + struct.pack("<BB", ln, dc) + b"\0" * 14)
    out.write(b"\r")
    for f in feats:
        out.write(b" ")
        text = landmark.text(f)
        vals = list(text)
        if xy_target is None:
            x, y = landmark.xy(f, None)                      # UTM تلقائي
        elif xy_tx is None:
            x, y = f.lon, f.lat                              # WGS84
        else:
            x, y = landmark.xy(f, xy_tx)
        vals += [landmark.num(x, dec), landmark.num(y, dec), landmark.link(f)]
        vals += [f.attrs.get(k, "") for k, _ in extra]
        for (name, typ, ln, dc), v in zip(fields, vals):
            if typ == "N":
                out.write(v.encode("ascii").rjust(ln, b" ")[:ln])
            else:
                out.write(_cut_utf8(v or "", ln).ljust(ln, b" "))
    out.write(b"\x1a")
    return {"shp": shp, "shx": shx, "dbf": out.getvalue(), "prj": target.wkt().encode("utf-8"), "cpg": b"UTF-8"}


def write_zip(layers: Sequence[Layer], os_, target: Optional[Crs] = None, attributes: bool = True,
              xy_target: Optional[Crs] = None) -> List[str]:
    """يكتب ZIP فيه شيب لكل (طبقة × نوع هندسة). يرجع أسماء الملفات الأساسية."""
    names, used = [], set()
    with zipfile.ZipFile(os_, "w", zipfile.ZIP_DEFLATED) as z:
        for l in layers:
            by = {POINT: [], LINE: [], POLYGON: []}
            for f in l.features:
                if f.parts:
                    by[f.geom].append(f)
            for g, fs in by.items():
                if not fs:
                    continue
                base = safe_name(l.label, l.id)
                if len([1 for x in by.values() if x]) > 1:
                    base += {POINT: "_points", LINE: "_lines", POLYGON: "_polygons"}[g]
                b0, i = base, 2
                while base.lower() in used:
                    base = f"{b0}_{i}"
                    i += 1
                used.add(base.lower())
                for ext, data in build(fs, g, target, attributes, xy_target).items():
                    z.writestr(f"{base}.{ext}", data)
                names.append(base)
    return names


# ---------------------------------------------------------------------------- قراءة
def _read_dbf(data: bytes, encoding: str):
    nrec, hdr_len, rec_len = struct.unpack_from("<IHH", data, 4)
    fields, o = [], 32
    while o < hdr_len - 1 and data[o] != 0x0D:
        name = data[o:o + 11].split(b"\0")[0].decode("ascii", "replace")
        typ, ln, dc = chr(data[o + 11]), data[o + 16], data[o + 17]
        fields.append((name, typ, ln, dc))
        o += 32
    rows, o = [], hdr_len
    for _ in range(nrec):
        rec = data[o:o + rec_len]
        o += rec_len
        deleted = rec[:1] == b"*"
        pos, row = 1, {}
        for name, typ, ln, dc in fields:
            raw = rec[pos:pos + ln]
            pos += ln
            try:
                s = raw.decode(encoding).strip().strip("\0")
            except UnicodeDecodeError:
                s = raw.decode("cp1256", "replace").strip().strip("\0")
            row[name] = s
        rows.append((deleted, row))
    return [f[0] for f in fields], rows


def _read_shp(data: bytes):
    """يرجع قائمة بـ (نوع_الشكل، أجزاء) لكل سجل؛ الأجزاء قوائم نقاط (x,y)."""
    out, o, n = [], 100, len(data)
    while o + 8 <= n:
        _, words = struct.unpack_from(">ii", data, o)
        o += 8
        end = o + words * 2
        t = struct.unpack_from("<i", data, o)[0]
        base = t % 10 if t < 30 else t
        kind = {1: 1, 11: 1, 21: 1, 3: 3, 13: 3, 23: 3, 5: 5, 15: 5, 25: 5, 8: 8, 18: 8, 28: 8}.get(t, 0)
        if kind == 0:
            out.append((0, []))
        elif kind == 1:
            x, y = struct.unpack_from("<dd", data, o + 4)
            out.append((1, [[(x, y)]]))
        elif kind == 8:
            npts = struct.unpack_from("<i", data, o + 36)[0]
            pts = [struct.unpack_from("<dd", data, o + 40 + 16 * i) for i in range(npts)]
            out.append((8, [[p] for p in pts]))
        else:
            nparts, npts = struct.unpack_from("<ii", data, o + 36)
            idx = list(struct.unpack_from("<%di" % nparts, data, o + 44))
            p0 = o + 44 + 4 * nparts
            pts = [struct.unpack_from("<dd", data, p0 + 16 * i) for i in range(npts)]
            idx.append(npts)
            out.append((kind, [pts[idx[i]:idx[i + 1]] for i in range(nparts)]))
        o = end
    return out


def detect_crs(prj_text: str) -> Optional[Crs]:
    """يتعرف على النظام من نص .prj: WGS84/UTM مباشرة، ثم بالاسم في فهرس EPSG المضمّن، ثم pyproj إن توفر."""
    if not prj_text:
        return None
    t = prj_text.strip()
    up = t.upper()
    m = re.search(r'(?:PROJCS|GEOGCS)\["([^"]+)"', t)
    name = m.group(1) if m else ""
    if "TOWGS84" not in up:
        m2 = re.search(r"UTM[_ ]zone[_ ](\d{1,2})\s*([NS])?", t, re.I)
        if m2 and "WGS_1984" in up.replace(" ", "_"):
            return Crs.utm(int(m2.group(1)), (m2.group(2) or "N").upper() == "N")
        if up.startswith("GEOGCS") and ("WGS_1984" in up or "WGS 84" in up) and "PROJCS" not in up:
            return Crs.wgs84()
    if "PSEUDO" in up or "WEB_MERCATOR" in up or "3857" in t:
        return Crs.of(3857)
    from . import proj as _proj
    code = _proj.by_name(name)
    if code and _proj.supported(code):
        return Crs.of(code)
    try:
        from pyproj import CRS as _P  # type: ignore
        e = _P.from_wkt(t).to_epsg()
        return Crs.of(e) if e else None
    except Exception:  # noqa: BLE001
        return None


def read_zip(path_or_file, label: str = "shapefile"):
    """يقرأ كل الشيبات داخل ZIP. يرجع (قائمة طبقات، قائمة تحذيرات)."""
    layers, warns = [], []
    from . import mapper
    with zipfile.ZipFile(path_or_file) as z:
        names = {n.lower(): n for n in z.namelist()}
        bases = sorted({n[:-4] for n in names if n.endswith(".shp")})
        for b in bases:
            shp = z.read(names[b + ".shp"])
            dbf = z.read(names[b + ".dbf"]) if b + ".dbf" in names else None
            cpg = z.read(names[b + ".cpg"]).decode("ascii", "ignore").strip().lower() if b + ".cpg" in names else ""
            enc = "utf-8" if (not cpg or "utf" in cpg) else ("cp1256" if "1256" in cpg else cpg)
            crs = detect_crs(z.read(names[b + ".prj"]).decode("utf-8", "ignore")) if b + ".prj" in names else None
            if crs is None:
                warns.append(f"{b}: لا يوجد .prj معروف؛ افتُرض WGS84")
                crs = Crs.wgs84()
            to_wgs = crs.transformer_to_wgs84() if crs.epsg != 4326 else None
            header, rows = _read_dbf(dbf, enc) if dbf else ([], [])
            recs = _read_shp(shp)
            by_geom: Dict[int, Layer] = {}
            for i, (kind, parts) in enumerate(recs):
                if kind == 0 or not parts:
                    continue
                if rows and i < len(rows) and rows[i][0]:
                    continue
                geom = {1: POINT, 8: POINT, 3: LINE, 5: POLYGON}[kind]
                if kind == 8:
                    feats_parts = [[p[0]] for p in parts]
                else:
                    feats_parts = [parts]
                for fp in feats_parts:
                    f = Feature(geom=geom, id=Feature.new_id())
                    for k, p in enumerate(fp):
                        if to_wgs:
                            p = [to_wgs(x, y) for x, y in p]
                        hole = geom == POLYGON and signed_area(p) > 0 and k > 0
                        if geom == POLYGON and signed_area(p) > 0 and k == 0:
                            hole = False
                        f.add_part(p, hole)
                    if geom == POLYGON:   # الحلقة الأولى خارجية؛ والبقية: ثقب إن كانت عكس عقارب الساعة
                        f.holes = [False if (j == 0 or signed_area(r) < 0) else True for j, r in enumerate(f.parts)]
                    props = rows[i][1] if rows and i < len(rows) else {}
                    mapper.apply(f, props)
                    set_representative(f)
                    l = by_geom.setdefault(geom, Layer(f"imp_{b}_{geom}", b, geom, kind="import", source=b))
                    l.features.append(f)
            layers.extend(by_geom.values())
    return layers, warns
