"""واجهة ويب خفيفة (Flask + Leaflet) بديلة لواجهة الأندرويد: خريطة، تنزيل، تحويل إحداثيات، تحويل ملفات."""
from __future__ import annotations

import io
import os
import tempfile

from flask import Flask, jsonify, render_template_string, request, send_file

from . import catalog, convert as convmod, dashboard, formats, overpass, proj, report as reportmod
from .admin import AdminRef
from .coords import FMT_DD, Crs, format_coord, parse_coord
from .geo import AreaSpec

from .ui import PAGE


def create_app(fetcher=None) -> Flask:
    app = Flask(__name__)
    app.config["JSON_AS_ASCII"] = False
    get_fetcher = lambda: fetcher or overpass.http_fetcher()

    @app.get("/")
    def index():
        return render_template_string(PAGE, cats=catalog.POI, layers=catalog.LAYERS, fmts=formats.FORMATS)

    @app.get("/api/coords")
    def coords():
        try:
            p = parse_coord(request.args.get("text", ""))
        except ValueError as e:
            return jsonify(error=str(e)), 400
        return jsonify(detected=p.fmt, lat=p.lat, lon=p.lon, **{f: format_coord(f, p.lat, p.lon) for f in ("DD", "DMS", "DDM", "UTM", "MGRS")})

    @app.get("/api/locate")
    def locate():
        h = AdminRef.get().locate(float(request.args["lat"]), float(request.args["lon"]))
        return jsonify(qadaa=h.qadaa(), governorate=h.governorate_name(), boundary_m=h.boundary_m)

    @app.post("/api/download")
    def download():
        j = request.get_json(force=True)
        fmt = j.get("format", "geojson")
        if fmt not in formats.FORMATS:
            return jsonify(error="صيغة غير مدعومة"), 400
        s, w, n, e = j["bbox"]
        p = overpass.Params(area=AreaSpec.rect(s, w, n, e), poi_cats=j.get("poi", []), layer_ids=set(j.get("layers", [])),
                            custom=j.get("custom", ""), include_unnamed=bool(j.get("unnamed")))
        if AreaSpec.rect(s, w, n, e).area_km2() > 2500:
            return jsonify(error="المنطقة كبيرة جداً؛ قرّب الخريطة"), 400
        res = overpass.run(p, get_fetcher())
        if j.get("fill_admin"):
            adm = AdminRef.get()
            for l in res.layers:
                for f in l.features:
                    adm.fill(f, True)
        if not res.layers:
            return jsonify(error="; ".join(res.warnings) or "لا نتائج"), 502
        path = os.path.join(tempfile.mkdtemp(), "poi" + formats.EXT[fmt])
        formats.export_layers(res.layers, fmt, path)
        return send_file(path, as_attachment=True, download_name="poi" + formats.EXT[fmt])

    @app.post("/api/convert")
    def convert():
        up = request.files["file"]
        fmt = request.form.get("format", "geojson")
        d = tempfile.mkdtemp()
        src = os.path.join(d, os.path.basename(up.filename))
        up.save(src)
        crs = Crs.of(request.form["crs"]) if request.form.get("crs") else None
        try:
            res = formats.import_file(src, src_crs=crs)
            out = os.path.join(d, "out" + formats.EXT[fmt])
            formats.export_layers(res.layers, fmt, out)
        except (ValueError, KeyError) as e:
            return jsonify(error=str(e)), 400
        return send_file(out, as_attachment=True, download_name="converted" + formats.EXT[fmt])

    def _save_upload(field="file"):
        up = request.files[field]
        d = tempfile.mkdtemp()
        path = os.path.join(d, os.path.basename(up.filename))
        up.save(path)
        return d, path

    @app.get("/api/crs")
    def crs_search():
        return jsonify([{"code": c, "name": n} for c, n in proj.search(request.args.get("q", ""), 30)])

    @app.get("/api/convert-coords")
    def convert_coords():
        try:
            src = Crs.of(request.args["src"]) if request.args.get("src") else None
            tgt = Crs.of(request.args["target"]) if request.args.get("target") else None
            r = convmod.convert(request.args.get("text", ""), src, request.args.get("lonfirst") != "1", tgt)
        except ValueError as e:
            return jsonify(error=str(e)), 400
        return jsonify(lat=r.lat, lon=r.lon, dd=r.dd, dms=r.dms, ddm=r.ddm, utm=r.utm, mgrs=r.mgrs, target=r.target_text,
                       detected=r.detected_format, precision=r.precision_note, warnings=r.warnings)

    @app.post("/api/batch-coords")
    def batch_coords():
        d, src = _save_upload()
        out = os.path.join(d, "converted.csv")
        try:
            rep = convmod.batch_convert(src, out, request.form.get("column") or None, request.form.get("x") or None,
                                        request.form.get("y") or None, Crs.of(request.form["src"]) if request.form.get("src") else None,
                                        Crs.of(request.form["target"]) if request.form.get("target") else None)
        except ValueError as e:
            return jsonify(error=str(e)), 400
        resp = send_file(out, as_attachment=True, download_name="converted.csv")
        resp.headers["X-Rows"], resp.headers["X-Errors"] = str(rep.rows), str(len(rep.errors))
        return resp

    @app.post("/api/dashboard")
    def dash():
        d, src = _save_upload()
        res = formats.import_file(src)
        data = dashboard.compute(res.layers, os.path.basename(src))
        return app.response_class(dashboard.to_html(data), mimetype="text/html")

    @app.post("/api/report")
    def make_report():
        d, src = _save_upload()
        res = formats.import_file(src)
        fmt = request.form.get("format", "pdf")
        out = os.path.join(d, "report." + fmt)
        reportmod.make_report(res.layers, out, title=request.form.get("title", ""), paper=request.form.get("paper", "A4"),
                              landscape=request.form.get("portrait") != "1", color_by_sector=request.form.get("by_sector") == "1",
                              grid=int(request.form.get("grid", 0)), dpi=int(request.form.get("dpi", 150)))
        return send_file(out, as_attachment=True, download_name="report." + fmt)

    return app
