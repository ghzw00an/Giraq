"""يربط أسماء الحقول المعروفة في الملفات المستوردة بنموذج المعلم؛ الباقي يذهب إلى attrs."""
from __future__ import annotations

from typing import Dict

from .model import STATUS_NEW, STATUS_REVIEW, STATUS_VERIFIED, Feature

_NAME_KEYS = {"name", "name:ar", "name_ar", "الاسم", "اسم", "اسم_المعلم"}


def _norm(k: str) -> str:
    return k.strip().lower().replace(" ", "_")


def parse_status(v: str) -> int:
    s = v.strip().lower()
    if s == "1" or s.startswith("review") or "مراجعة" in s:
        return STATUS_REVIEW
    if s == "2" or s.startswith("verif") or "موثق" in s or "موثّق" in s:
        return STATUS_VERIFIED
    return STATUS_NEW


def status_text(s: int) -> str:
    return "review" if s == STATUS_REVIEW else "verified" if s == STATUS_VERIFIED else "new"


def apply(f: Feature, props: Dict[str, str]) -> None:
    fallback = None
    for k, v in props.items():
        v = "" if v is None else str(v)
        n = _norm(k)
        if n in _NAME_KEYS:
            if v and (not f.name or n in ("name", "name:ar")):
                f.name = v
        elif n in ("title", "label"):
            if fallback is None and v:
                fallback = v
            else:
                f.attrs[k] = v
        elif n in ("name_en", "name:en", "name_eng"):
            f.name_en = v
        elif n == "type":
            f.type = v
        elif n in ("category", "gategory", "cat"):
            f.category = v
        elif n in ("nahiya", "nahia"):
            f.nahiya = v
        elif n in ("qadaa", "gathaa"):
            f.qadaa = v
        elif n in ("governorat", "mohafadha", "governorate"):
            f.governorate = v
        elif n == "status":
            f.status = parse_status(v)
        elif n == "source":
            f.source = v
        elif n == "updated":
            f.updated = v
        elif n in ("acc_m", "accuracy"):
            try:
                f.accuracy = float("nan") if not v else float(v)
            except ValueError:
                f.attrs[k] = v
        elif n in ("descr", "description"):
            f.description = v
        elif n == "notes":
            f.notes = v
        elif n in ("x", "y"):
            pass
        elif n == "link":
            if v:
                f.attrs["link"] = v
        elif n in ("id", "uid"):
            f.id = v
        else:
            f.attrs[k] = v
    if not f.name and fallback:
        f.name = fallback
