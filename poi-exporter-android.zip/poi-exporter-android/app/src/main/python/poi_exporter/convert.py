"""محوّل الإحداثيات الدقيق: يحترم دقة الإدخال فلا يخترع خانات، ويحوّل بين أي نظامين (DD/DMS/DDM/UTM/MGRS/EPSG)،
ومحوّل دفعي للجداول (CSV/Excel) مع ملف أخطاء."""
from __future__ import annotations

import csv
import math
import re
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

from . import coords, formats, proj
from .coords import (FMT_DD, FMT_DDM, FMT_DMS, FMT_MGRS, FMT_UTM, Crs, Parsed, mgrs_from_latlon, parse_coord,
                     utm_from_latlon)

M_PER_DEG = 111320.0


# ---------------------------------------------------------------------------- الدقة
def _normalize(s: str) -> str:
    return coords._normalize(s)


def decimals(text: str) -> int:
    """أكبر عدد خانات عشرية في الأرقام المكتوبة (آخر رمز رقمي فيه فاصلة)."""
    best = 0
    for m in re.finditer(r"\d*\.(\d+)", _normalize(text).replace(",", " ")):
        best = max(best, len(m.group(1)))
    return best


def resolution_metres(text: str, fmt: str) -> float:
    d = decimals(text)
    if fmt == FMT_DMS:
        r = 10 ** -d / 3600.0 * M_PER_DEG
    elif fmt == FMT_DDM:
        r = 10 ** -d / 60.0 * M_PER_DEG
    elif fmt == FMT_MGRS:
        compact = re.sub(r"[\s,;]+", "", _normalize(text))
        digits = len(re.search(r"(\d*)$", compact).group(1))
        digits = min(digits, 10) // 2 if len(compact) > 5 else 0
        if re.match(r"^\d{1,2}[A-Z]", compact):
            digits = max(0, len(re.search(r"[A-Z]+(\d*)$", compact).group(1)) // 2)
        r = 10 ** (5 - digits)
    elif fmt == FMT_UTM:
        r = 10 ** -d
    else:
        r = 10 ** -d * M_PER_DEG
    return max(r, 0.001)


def projected_resolution(text: str) -> float:
    return max(10 ** -decimals(text), 0.001)


def projected_decimals(res: float) -> int:
    return max(0, min(3, round(-math.log10(res))))


def degree_decimals(res: float) -> int:
    return max(2, min(9, round(-math.log10(res / M_PER_DEG))))


def output_decimals(res: float, geographic: bool, lat: float) -> int:
    return degree_decimals(res / max(0.2, math.cos(math.radians(lat)))) if geographic else projected_decimals(res)


def dms_second_decimals(res: float) -> int:
    return max(0, min(5, round(math.log10(30.9 / res))))


def ddm_minute_decimals(res: float) -> int:
    return max(0, min(7, round(math.log10(1855.0 / res))))


def mgrs_digits(res: float) -> int:
    return max(1, min(5, round(5 - math.log10(res))))


def describe(res: float, ar: bool = True) -> str:
    if res >= 1000:
        v = "%.0f %s" % (res / 1000, "كم" if ar else "km")
    elif res >= 1:
        v = "%.0f %s" % (res, "م" if ar else "m")
    elif res >= 0.01:
        v = "%.0f %s" % (res * 100, "سم" if ar else "cm")
    else:
        v = "%.0f %s" % (res * 1000, "مم" if ar else "mm")
    return ("دقة الإدخال ≈ " if ar else "Input precision ≈ ") + v


def fixed(v: float, dec: int) -> str:
    s = "%.*f" % (max(0, dec), v)
    return "0" + s[1:] if s.startswith("-0") and float(s) == 0 else s


# ---------------------------------------------------------------------------- تنسيق بحسب الدقة
def fmt_dms_p(lat, lon, res):
    dd = dms_second_decimals(res)

    def one(v, pos, neg):
        scale = 10 ** dd
        cs = round(abs(v) * 3600 * scale)
        deg, rem = divmod(cs, 3600 * scale)
        mi, sec = divmod(rem, 60 * scale)
        return "%d°%02d'%s\"%s" % (deg, mi, ("%0*.*f" % (3 + dd if dd else 2, dd, sec / scale)), neg if v < 0 else pos)
    return one(lat, "N", "S") + " " + one(lon, "E", "W")


def fmt_ddm_p(lat, lon, res):
    dd = ddm_minute_decimals(res)

    def one(v, pos, neg):
        scale = 10 ** dd
        tm = round(abs(v) * 60 * scale)
        deg, mn = divmod(tm, 60 * scale)
        return "%d°%0*.*f'%s" % (deg, 3 + dd if dd else 2, dd, mn / scale, neg if v < 0 else pos)
    return one(lat, "N", "S") + " " + one(lon, "E", "W")


@dataclass
class Result:
    lat: float = 0.0
    lon: float = 0.0
    dd: str = ""
    dms: str = ""
    ddm: str = ""
    utm: str = ""
    utm_zone: str = ""
    utm_easting: str = ""
    utm_northing: str = ""
    mgrs: Optional[str] = None
    target: Optional[Crs] = None
    target_x: str = ""
    target_y: str = ""
    target_text: str = ""
    detected_format: str = ""
    resolution_m: float = 0.0
    precision_note: str = ""
    warnings: List[str] = field(default_factory=list)

    def copy_text(self) -> str:
        b = [f"WGS84 DD:   {self.dd}", f"WGS84 DMS:  {self.dms}", f"WGS84 DDM:  {self.ddm}", f"UTM:        {self.utm}"]
        if self.mgrs:
            b.append(f"MGRS:       {self.mgrs}")
        if self.target and self.target.epsg != 4326:
            b.append(f"EPSG:{self.target.epsg}:  {self.target_text}")
        b.append(self.precision_note)
        return "\n".join(b)


def _two_numbers(text: str) -> Tuple[float, float]:
    t = _normalize(text).replace(";", " ")
    t = re.sub(r"\s+", " ", t.replace(",", " ")).strip()
    nums = [formats.parse_num(x) for x in t.split(" ") if x]
    if len(nums) != 2 or any(math.isnan(n) for n in nums):
        raise ValueError("اكتب رقمين: X وY")
    return nums[0], nums[1]


def shift_warning(c: Crs) -> str:
    return (f"تحويل من EPSG:{c.epsg} يمر بإزاحة مرجعية تقريبية (Helmert)؛ قد يبلغ الخطأ عدة أمتار."
            f" Conversion from EPSG:{c.epsg} uses an approximate datum shift (several metres).")


def convert(text: str, src: Optional[Crs] = None, lat_first: bool = True, target: Optional[Crs] = None) -> Result:
    """يحوّل نصاً مكتوباً إلى كل التمثيلات. src=None: اكتشاف تلقائي لصيغ WGS84؛ وإلا نظام الإدخال."""
    if not text or not text.strip():
        raise ValueError("أدخل إحداثيات")
    wgs = Crs.wgs84()
    target = target or wgs
    r = Result(target=target)
    if src is None or src.epsg == 4326 or src.geographic:
        p = _parse_geographic(text, lat_first, r)
        lat, lon = p.lat, p.lon
        if src is not None and src.epsg != 4326:
            lon, lat = src.transformer_to_wgs84()(lon, lat)
            if proj.approximate_shift(src.epsg, 4326):
                r.warnings.append(shift_warning(src))
    else:
        x, y = _two_numbers(text)
        r.detected_format = f"EPSG:{src.epsg}"
        r.resolution_m = projected_resolution(text)
        try:
            lon, lat = src.transformer_to_wgs84()(x, y)
        except (ValueError, ArithmeticError):
            raise ValueError(f"الإحداثيات خارج مجال النظام EPSG:{src.epsg}. تحقق من ترتيب X وY.")
        if abs(lat) > 90 or abs(lon) > 180:
            raise ValueError("النتيجة خارج المدى الجغرافي؛ تحقق من النظام")
        if proj.approximate_shift(src.epsg, 4326):
            r.warnings.append(shift_warning(src))
    r.lat, r.lon = lat, lon
    res = r.resolution_m
    dd_dec = degree_decimals(res)
    r.dd = "%s, %s" % (fixed(lat, dd_dec), fixed(lon, dd_dec))
    r.dms, r.ddm = fmt_dms_p(lat, lon, res), fmt_ddm_p(lat, lon, res)
    u = utm_from_latlon(lat, lon)
    ud = projected_decimals(res)
    r.utm_zone, r.utm_easting, r.utm_northing = u.zone_label(), fixed(u.easting, ud), fixed(u.northing, ud)
    r.utm = f"{r.utm_zone} {r.utm_easting} {r.utm_northing}"
    if -80 <= lat <= 84:
        r.mgrs = mgrs_from_latlon(lat, lon, mgrs_digits(res))
    if target.epsg != 4326:
        tx, ty = target.transformer_from_wgs84()(lon, lat)
        dec = output_decimals(res, target.geographic, lat)
        r.target_x, r.target_y = fixed(tx, dec), fixed(ty, dec)
        r.target_text = f"{r.target_x} {r.target_y}"
        if proj.approximate_shift(4326, target.epsg):
            r.warnings.append(shift_warning(target))
    r.precision_note = describe(res)
    return r


def _parse_geographic(text: str, lat_first: bool, r: Result) -> Parsed:
    """DD/DMS/DDM/UTM/MGRS تلقائياً؛ رقمان بلا حرف جهة يتبعان lat_first."""
    t = _normalize(text)
    p = parse_coord(text if lat_first else _swap_plain(text, t))
    r.detected_format = p.fmt
    r.resolution_m = resolution_metres(text, p.fmt)
    return p


def _swap_plain(original: str, norm: str) -> str:
    if re.search(r"[NSEW°'\"]", norm) or re.search(r"[A-Z]", norm):
        return original
    nums = [x for x in re.split(r"[\s,;]+", norm.strip()) if x]
    return f"{nums[1]}, {nums[0]}" if len(nums) == 2 else original


# ---------------------------------------------------------------------------- الدفعي
FORMATS_OUT = ("DD", "DMS", "DDM", "UTM", "MGRS", "TARGET")


@dataclass
class BatchReport:
    rows: int = 0
    ok: int = 0
    errors: List[Tuple[int, str, str]] = field(default_factory=list)      # (رقم الصف، النص، السبب)
    warnings: List[str] = field(default_factory=list)


def batch_convert(in_path: str, out_path: str, column: Optional[str] = None, x_column: Optional[str] = None,
                  y_column: Optional[str] = None, src: Optional[Crs] = None, target: Optional[Crs] = None,
                  lat_first: bool = True, errors_path: Optional[str] = None) -> BatchReport:
    """يقرأ جدول CSV/Excel ويكتب CSV بأعمدة إضافية: lat, lon, DD, DMS, DDM, UTM, MGRS (+ x_target,y_target)."""
    header, rows = formats.read_table(in_path)
    if not header:
        raise ValueError("الملف فارغ")
    idx = {h.lower(): i for i, h in enumerate(header)}
    if column:
        ci = idx.get(column.lower())
        if ci is None:
            raise ValueError(f"العمود {column!r} غير موجود")
    elif x_column and y_column:
        ci = None
        xi, yi = idx.get(x_column.lower()), idx.get(y_column.lower())
        if xi is None or yi is None:
            raise ValueError("عمودا X/Y غير موجودين")
    else:
        m = formats.guess_columns(header)
        if m.combined >= 0:
            ci = m.combined
        elif m.x >= 0 and m.y >= 0:
            ci, xi, yi = None, m.x, m.y
        else:
            raise ValueError("حدّد عمود الإحداثيات أو عمودي X وY")
    extra = ["lat", "lon", "DD", "DMS", "DDM", "UTM", "MGRS"] + (["x_target", "y_target"] if target and target.epsg != 4326 else [])
    rep = BatchReport()
    out_rows = []
    for rn, row in enumerate(rows, 2):
        rep.rows += 1
        cell = lambda i: row[i] if i < len(row) else ""
        txt = cell(ci) if ci is not None else f"{cell(xi)} {cell(yi)}"
        try:
            r = convert(txt, src, lat_first, target)
        except (ValueError, ArithmeticError) as e:
            rep.errors.append((rn, txt, str(e)))
            out_rows.append(list(row) + [""] * len(extra))
            continue
        vals = ["%.9f" % r.lat, "%.9f" % r.lon, r.dd, r.dms, r.ddm, r.utm, r.mgrs or ""]
        if target and target.epsg != 4326:
            vals += [r.target_x, r.target_y]
        out_rows.append(list(row) + vals)
        rep.ok += 1
        for w in r.warnings:
            if w not in rep.warnings:
                rep.warnings.append(w)
    with open(out_path, "w", encoding="utf-8", newline="") as fh:
        fh.write("\ufeff")
        w = csv.writer(fh, lineterminator="\r\n")
        w.writerow(list(header) + extra)
        w.writerows(out_rows)
    if errors_path and rep.errors:
        with open(errors_path, "w", encoding="utf-8", newline="") as fh:
            fh.write("\ufeff")
            w = csv.writer(fh, lineterminator="\r\n")
            w.writerow(["row", "input", "error"])
            w.writerows(rep.errors)
    return rep
