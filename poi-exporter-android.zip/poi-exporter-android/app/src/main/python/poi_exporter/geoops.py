"""عمليات مكانية على المعالم: حاجز (Buffer)، اتحاد، تقاطع، فرق، تقسيم، قصّ، تحديد بمضلع، أقرب، شبكات. تُحسب القياسات في مستوى
محلي بالمتر حول مركز البيانات (دقة جيدة لمناطق حتى ~100 كم)."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

from . import overlay as ov
from .analysis import Plane, convex_hull
from .geo import haversine, in_polygon, set_representative
from .model import LINE, POINT, POLYGON, Feature, Layer

INSIDE, BOUNDARY_INCLUDED, INTERSECTS = "inside", "boundary_included", "intersects"


class Local:
    def __init__(self, feats: Sequence[Feature]):
        pts = [p for f in feats for part in f.parts for p in part]
        if not pts:
            self.pl = Plane(0, 0)
        else:
            self.pl = Plane(sum(p[1] for p in pts) / len(pts), sum(p[0] for p in pts) / len(pts))

    def to(self, p):
        return (self.pl.x(p[0]), self.pl.y(p[1]))

    def back(self, p):
        return (self.pl.lon(p[0]), self.pl.lat(p[1]))

    def rings(self, f: Feature):
        return [[self.to(p) for p in r[:-1] if True] if (r and r[0] == r[-1]) else [self.to(p) for p in r] for r in f.parts]

    def features(self, polys, template: Optional[Feature] = None) -> List[Feature]:
        out = []
        for poly in polys:
            f = template.copy() if template is not None else Feature()
            f.geom, f.id = POLYGON, Feature.new_id()
            f.parts, f.holes = [], []
            for k, ring in enumerate(poly):
                pts = [self.back(p) for p in ring]
                f.add_part(pts + [pts[0]], k > 0)
            set_representative(f)
            out.append(f)
        return out


def _polygon_rings(l: Local, f: Feature):
    if f.geom != POLYGON:
        raise ValueError("المطلوب مضلع")
    return l.rings(f)


def _need(f: Optional[Feature], what: str) -> Feature:
    if f is None or not f.parts:
        raise ValueError(f"هندسة غير موجودة: {what}")
    return f


# ---------------------------------------------------------------------------- Overlay
def buffer(f: Feature, meters: float, segments_per_quarter: int = 16) -> Optional[Feature]:
    """حاجز بالمتر. القيمة السالبة تُصغّر المضلعات. يرجع None إن كانت النتيجة فارغة."""
    _need(f, "buffer")
    if meters == 0:
        return f.copy()
    l = Local([f])
    n = max(8, min(64, segments_per_quarter)) * 4
    r = abs(meters)
    pieces = []
    if f.geom == POINT:
        x, y = l.to(f.parts[0][0])
        polys = [[ov.circle(x, y, r, n)]] if meters > 0 else []
    else:
        rings = _polygon_rings(l, f) if f.geom == POLYGON else [[l.to(p) for p in part] for part in f.parts]
        for ring in rings:
            pts = ring + ([ring[0]] if f.geom == POLYGON else [])
            for a, b in zip(pts, pts[1:]):
                if a != b:
                    pieces.append(ov.capsule(a, b, r, max(4, n // 4)))
        if f.geom == LINE:
            polys = ov.overlay([[p] for p in pieces], lambda fl: any(fl)) if meters > 0 else []
        elif meters > 0:
            polys = ov.overlay([rings] + [[p] for p in pieces], lambda fl: any(fl))
        else:
            polys = ov.overlay([rings] + [[p] for p in pieces], lambda fl: fl[0] and not any(fl[1:]))
    if not polys:
        return None
    feats = l.features(polys, _template(f))
    return _merge(feats) if len(feats) > 1 else feats[0]


def _template(f: Optional[Feature]) -> Optional[Feature]:
    if f is None:
        return None
    t = f.copy()
    t.id = ""
    return t


def _merge(fs: List[Feature]) -> Feature:
    out = fs[0].copy()
    for g in fs[1:]:
        for i, p in enumerate(g.parts):
            out.add_part(p, g.is_hole(i))
    set_representative(out)
    return out


def union(fs: Sequence[Feature]) -> Optional[Feature]:
    fs = [f for f in fs if f.geom == POLYGON and f.parts]
    if not fs:
        raise ValueError("لا توجد مضلعات")
    l = Local(fs)
    polys = ov.overlay([l.rings(f) for f in fs], lambda fl: any(fl))
    out = l.features(polys, _template(fs[0]))
    return _merge(out) if out else None


@dataclass
class Overlap:
    feature: Optional[Feature]
    area_m2: float


def intersection(a: Feature, b: Feature) -> Optional[Overlap]:
    _need(a, "A"), _need(b, "B")
    l = Local([a, b])
    polys = ov.intersection(_polygon_rings(l, a), _polygon_rings(l, b))
    out = l.features(polys, _template(a))
    if not out:
        return None
    m = _merge(out)
    from .geodesy import area
    return Overlap(m, area(m))


def difference(a: Feature, b: Feature) -> Optional[Feature]:
    _need(a, "A"), _need(b, "B")
    l = Local([a, b])
    out = l.features(ov.difference(_polygon_rings(l, a), _polygon_rings(l, b)), _template(a))
    return _merge(out) if out else None


def split(polygon: Feature, line: Feature) -> List[Feature]:
    """يقسم مضلعاً بخط يقطعه من طرف لطرف؛ يرجع الأجزاء (≥1)."""
    _need(polygon, "polygon"), _need(line, "line")
    if line.geom != LINE:
        raise ValueError("المطلوب خط")
    l = Local([polygon, line])
    rings = _polygon_rings(l, polygon)
    ring_sets = [rings, [[l.to(p) for p in part] for part in line.parts]]
    faces = ov.overlay(ring_sets, lambda fl: fl[0], dissolve=False)
    return l.features(faces, _template(polygon))


def convex_hull_feature(fs: Sequence[Feature]) -> Optional[Feature]:
    pts = [p for f in fs for part in f.parts for p in part]
    h = convex_hull(pts)
    if len(h) < 3:
        return None
    out = Feature(geom=POLYGON, id=Feature.new_id())
    out.add_part(h + [h[0]])
    set_representative(out)
    return out


# ---------------------------------------------------------------------------- اختيار وقصّ
def _point_mode(polygon: Feature, f: Feature, mode: str) -> bool:
    return in_polygon(polygon, f.lon, f.lat)


def select(feats: Sequence[Feature], polygon: Feature, mode: str = INSIDE) -> List[Feature]:
    """المعالم التي تقع ضمن المضلع بحسب النمط: INSIDE (داخل بحت) | BOUNDARY_INCLUDED | INTERSECTS."""
    _need(polygon, "polygon")
    l = Local([polygon] + list(feats[:200]))
    prings = _polygon_rings(l, polygon)
    out = []
    for f in feats:
        if not f.parts:
            continue
        if f.geom == POINT:
            x, y = l.to(f.parts[0][0])
            ins = ov._in_rings(x, y, prings)
            on = ins or _near_boundary(x, y, prings)
            ok = (ins and not _near_boundary(x, y, prings)) if mode == INSIDE else on
        else:
            frings = [[l.to(p) for p in part] for part in f.parts]
            inter = _geometry_intersects(frings, f.geom, prings)
            if mode == INTERSECTS:
                ok = inter
            else:
                allin = all(ov._in_rings(x, y, prings) for part in frings for x, y in part)
                crosses = _edges_cross(frings, f.geom, prings)
                ok = allin and not crosses
                if mode == INSIDE and ok:
                    ok = not any(_near_boundary(x, y, prings) for part in frings for x, y in part)
        if ok:
            out.append(f)
    return out


def _near_boundary(x, y, rings, tol=1e-6) -> bool:
    for r in rings:
        for i in range(len(r)):
            a, b = r[i - 1], r[i]
            dx, dy = b[0] - a[0], b[1] - a[1]
            L = dx * dx + dy * dy
            t = 0.0 if L == 0 else max(0.0, min(1.0, ((x - a[0]) * dx + (y - a[1]) * dy) / L))
            if math.hypot(a[0] + t * dx - x, a[1] + t * dy - y) <= tol:
                return True
    return False


def _edges_cross(frings, geom, prings) -> bool:
    from .quality import _seg_cross
    for part in frings:
        pts = part + ([part[0]] if geom == POLYGON else [])
        for a, b in zip(pts, pts[1:]):
            for r in prings:
                for i in range(len(r)):
                    c, d = r[i - 1], r[i]
                    if _seg_cross(a, b, c, d) and not (ov._in_rings(*a, prings) and ov._in_rings(*b, prings) and _proper_only_touch(a, b, c, d)):
                        # عبور فعلي: نقطتا القطعة على جانبين مختلفين للحد
                        if ov._in_rings(*a, prings) != ov._in_rings(*b, prings):
                            return True
    return False


def _proper_only_touch(a, b, c, d) -> bool:
    return True


def _geometry_intersects(frings, geom, prings) -> bool:
    from .quality import _seg_cross
    for part in frings:
        if any(ov._in_rings(x, y, prings) for x, y in part):
            return True
        pts = part + ([part[0]] if geom == POLYGON else [])
        for a, b in zip(pts, pts[1:]):
            for r in prings:
                for i in range(len(r)):
                    if _seg_cross(a, b, r[i - 1], r[i]):
                        return True
    if geom == POLYGON:       # المضلع يحتوي المضلع الآخر؟
        return any(ov._in_rings(r[0][0], r[0][1], frings) for r in prings)
    return False


def clip(layer: Layer, polygon: Feature, include_boundary: bool = True) -> Layer:
    """قصّ الطبقة بمضلع: النقاط تُختار، والخطوط والمضلعات تُقصّ هندسياً."""
    _need(polygon, "polygon")
    out = Layer(layer.id + "_clip", layer.label + " — مقصوص", layer.geom, kind="user")
    l = Local([polygon] + layer.features[:500])
    prings = _polygon_rings(l, polygon)
    for f in layer.features:
        if not f.parts:
            continue
        if f.geom == POINT:
            if select([f], polygon, BOUNDARY_INCLUDED if include_boundary else INSIDE):
                out.features.append(f.copy())
        elif f.geom == POLYGON:
            polys = ov.intersection(l.rings(f), prings)
            for g in l.features(polys, _template(f)):
                out.features.append(g)
        else:
            out.features.extend(_clip_line(f, l, prings))
    return out


def _clip_line(f: Feature, l: Local, prings) -> List[Feature]:
    res = []
    for part in f.parts:
        pts = [l.to(p) for p in part]
        cur: List[Tuple[float, float]] = []
        for a, b in zip(pts, pts[1:]):
            # نقاط التقاطع مع الحد مرتبة على القطعة
            ts = [0.0, 1.0]
            for r in prings:
                for i in range(len(r)):
                    c, d = r[i - 1], r[i]
                    rx, ry, sx, sy = b[0] - a[0], b[1] - a[1], d[0] - c[0], d[1] - c[1]
                    den = rx * sy - ry * sx
                    if abs(den) < 1e-15:
                        continue
                    t = ((c[0] - a[0]) * sy - (c[1] - a[1]) * sx) / den
                    u = ((c[0] - a[0]) * ry - (c[1] - a[1]) * rx) / den
                    if 0 < t < 1 and 0 <= u <= 1:
                        ts.append(t)
            ts.sort()
            for t0, t1 in zip(ts, ts[1:]):
                m = (a[0] + (b[0] - a[0]) * (t0 + t1) / 2, a[1] + (b[1] - a[1]) * (t0 + t1) / 2)
                p0 = (a[0] + (b[0] - a[0]) * t0, a[1] + (b[1] - a[1]) * t0)
                p1 = (a[0] + (b[0] - a[0]) * t1, a[1] + (b[1] - a[1]) * t1)
                if ov._in_rings(m[0], m[1], prings):
                    if not cur:
                        cur = [p0]
                    cur.append(p1)
                elif cur:
                    res.append(cur)
                    cur = []
        if cur:
            res.append(cur)
    out = []
    for seg in res:
        if len(seg) >= 2:
            g = f.copy()
            g.id = Feature.new_id()
            g.parts, g.holes = [[l.back(p) for p in seg]], [False]
            set_representative(g)
            out.append(g)
    return out


# ---------------------------------------------------------------------------- الأقرب والشبكات
@dataclass
class Hit:
    feature: Feature
    distance_m: float


def nearest(layer: Layer, lat: float, lon: float, k: int = 1) -> List[Hit]:
    hits = [Hit(f, haversine(lat, lon, f.lat, f.lon)) for f in layer.features if f.parts]
    hits.sort(key=lambda h: h.distance_m)
    return hits[:max(1, k)]


def point_grid(polygon: Feature, spacing_m: float) -> List[Feature]:
    from .analysis import regular_points
    return regular_points(Layer("t", "t", POLYGON, [polygon]), spacing_m).features


def square_grid(polygon: Feature, cell_m: float, clip_to_polygon: bool = False) -> List[Feature]:
    if cell_m <= 0:
        raise ValueError("حجم الخلية يجب أن يكون موجباً")
    l = Local([polygon])
    rings = _polygon_rings(l, polygon)
    xs = [x for r in rings for x, _ in r]
    ys = [y for r in rings for _, y in r]
    nx, ny = int((max(xs) - min(xs)) / cell_m) + 1, int((max(ys) - min(ys)) / cell_m) + 1
    if nx * ny > 100000:
        raise ValueError("الشبكة كبيرة جداً")
    out = []
    for i in range(nx):
        for j in range(ny):
            x0, y0 = min(xs) + i * cell_m, min(ys) + j * cell_m
            cell = [(x0, y0), (x0 + cell_m, y0), (x0 + cell_m, y0 + cell_m), (x0, y0 + cell_m)]
            if clip_to_polygon:
                polys = ov.intersection(rings, [cell])
                out.extend(l.features(polys))
            else:
                cx, cy = x0 + cell_m / 2, y0 + cell_m / 2
                if ov._in_rings(cx, cy, rings) or any(ov._in_rings(px, py, rings) for px, py in cell):
                    out.extend(l.features([[cell]]))
    return out


def centroid(f: Feature) -> Tuple[float, float]:
    """(lon, lat) لمركز الثقل (للمضلع مركز المساحة، وللخط منتصف الطول، وللنقطة نفسها)."""
    g = f.copy()
    set_representative(g)
    return g.lon, g.lat


def vertices(f: Feature):
    out = []
    for pi, part in enumerate(f.parts):
        for vi, (x, y) in enumerate(part[:-1] if f.geom == POLYGON else part):
            out.append((pi, vi, x, y))
    return out
