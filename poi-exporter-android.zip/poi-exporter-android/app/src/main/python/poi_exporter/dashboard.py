"""لوحة المعلومات: مجاميع، حلقة القطاعات بألوانها، تنبيه الأسماء الفارغة، وآخر 5 معالم. تُرسم HTML/SVG أو نصاً."""
from __future__ import annotations

import html
import math
from dataclasses import dataclass, field
from typing import List, Sequence, Tuple

from . import sectors
from .model import LINE, POINT, POLYGON, Feature, Layer


@dataclass
class Data:
    project: str = ""
    layers: int = 0
    total: int = 0
    points: int = 0
    lines: int = 0
    polygons: int = 0
    no_name: int = 0
    sector_counts: List[Tuple[str, int, str]] = field(default_factory=list)    # (الاسم، العدد، اللون)
    recent: List[Feature] = field(default_factory=list)


def compute(layers: Sequence[Layer], project: str = "") -> Data:
    d = Data(project=project, layers=len(layers))
    cnt = [0] * (len(sectors.ALL) + 1)
    recent: List[Feature] = []
    for l in layers:
        for f in l.features:
            d.total += 1
            if f.geom == POINT:
                d.points += 1
            elif f.geom == LINE:
                d.lines += 1
            else:
                d.polygons += 1
            if not (f.name or "").strip():
                d.no_name += 1
            i = sectors.index_of(f.category)
            cnt[i if i >= 0 else len(sectors.ALL)] += 1
            recent.append(f)
            recent = recent[-5:]
    for k, n in enumerate(cnt):
        if n:
            if k < len(sectors.ALL):
                d.sector_counts.append((sectors.ALL[k].name, n, "#%06X" % sectors.COLORS[k]))
            else:
                d.sector_counts.append(("بلا قطاع", n, "#888888"))
    d.recent = list(reversed(recent))
    return d


def donut_svg(d: Data, size: int = 160) -> str:
    r, cx, cy, sw = size * 0.36, size / 2, size / 2, size * 0.17
    parts = [f'<svg viewBox="0 0 {size} {size}" width="{size}" height="{size}">']
    if d.total == 0:
        parts.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="#ddd" stroke-width="{sw}"/>')
    else:
        circ = 2 * math.pi * r
        off = 0.0
        for name, n, col in d.sector_counts:
            ln = circ * n / d.total
            parts.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="{col}" stroke-width="{sw}" '
                         f'stroke-dasharray="{max(0.5, ln - 1.5):.2f} {circ:.2f}" stroke-dashoffset="{-off:.2f}" '
                         f'transform="rotate(-90 {cx} {cy})"><title>{html.escape(name)}: {n}</title></circle>')
            off += ln
    parts.append(f'<text x="{cx}" y="{cy + size * 0.05}" text-anchor="middle" font-size="{size * 0.2}" font-weight="bold">{d.total}</text>')
    parts.append(f'<text x="{cx}" y="{cy + size * 0.17}" text-anchor="middle" font-size="{size * 0.075}" fill="#666">معلم</text></svg>')
    return "".join(parts)


def to_html(d: Data) -> str:
    rows = "".join(f'<li><span style="background:{c};display:inline-block;width:10px;height:10px;border-radius:5px"></span> '
                   f'{html.escape(n)} <b>{k}</b></li>' for n, k, c in d.sector_counts)
    rec = "".join(f"<li>{html.escape(f.name or '(بلا اسم)')} — {html.escape(f.type)} <small>{html.escape(f.category)}</small></li>" for f in d.recent)
    warn = f'<p style="color:#c0392b"><b>⚠ {d.no_name} معلم بلا اسم</b></p>' if d.no_name else ""
    return (f'<div dir="rtl" style="font-family:sans-serif"><h2>لوحة المعلومات</h2><p>المشروع: {html.escape(d.project)}</p>'
            f'<p>طبقات <b>{d.layers}</b> • نقاط <b>{d.points}</b> • خطوط/مضلعات <b>{d.lines}/{d.polygons}</b></p>'
            f'{donut_svg(d)}<ul>{rows}</ul>{warn}<h3>آخر المعالم</h3><ul>{rec}</ul></div>')


def to_text(d: Data) -> str:
    out = [f"المشروع: {d.project}", f"طبقات {d.layers} • نقاط {d.points} • خطوط/مضلعات {d.lines}/{d.polygons} • المجموع {d.total}"]
    out += [f"  {n}: {k}" for n, k, _ in d.sector_counts]
    if d.no_name:
        out.append(f"⚠ {d.no_name} معلم بلا اسم")
    return "\n".join(out)
