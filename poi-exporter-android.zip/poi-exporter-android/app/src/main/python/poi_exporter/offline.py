"""الخرائط دون اتصال: مصادر بلاطات (MBTiles/ZIP/SQLite/GEMF)، ذاكرة بلاطات على القرص، تعريف الخرائط الأساسية، ولقطة خريطة
(Mosaic) تُدرج في تقارير PDF/PNG. لا ينزّل البرنامج مناطق كبيرة تلقائياً (سياسة OSM)؛ بل يخزّن ما تعرضه فقط."""
from __future__ import annotations

import io
import math
import os
import re
import sqlite3
import struct
import urllib.request
import zipfile
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Sequence, Tuple

UA = "poi-exporter-py/3.6 (tile viewer)"
EXTS = (".mbtiles", ".zip", ".sqlite", ".gemf")


# ---------------------------------------------------------------------------- رياضيات البلاطات
def lonlat_to_tile(lon: float, lat: float, z: int) -> Tuple[float, float]:
    n = 2 ** z
    lat = max(-85.0511, min(85.0511, lat))
    x = (lon + 180.0) / 360.0 * n
    y = (1 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2 * n
    return x, y


def tile_to_lonlat(x: float, y: float, z: int) -> Tuple[float, float]:
    n = 2 ** z
    return x / n * 360.0 - 180.0, math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))


def meters_per_pixel(lat: float, z: int) -> float:
    return 156543.03392 * math.cos(math.radians(lat)) / (2 ** z)


# ---------------------------------------------------------------------------- المصادر
class TileSource:
    name = "tiles"
    min_zoom, max_zoom = 0, 19

    def get(self, z: int, x: int, y: int) -> Optional[bytes]:
        raise NotImplementedError

    def close(self) -> None:
        pass


class MBTiles(TileSource):
    """MBTiles (جدول tiles بنظام TMS: y مقلوب)."""

    def __init__(self, path: str):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.name = os.path.basename(path)
        meta = dict(self.db.execute("SELECT name, value FROM metadata").fetchall()) if self._has("metadata") else {}
        self.meta = meta
        self.min_zoom = int(meta.get("minzoom", 0) or 0)
        self.max_zoom = int(meta.get("maxzoom", 19) or 19)

    def _has(self, t: str) -> bool:
        return self.db.execute("SELECT 1 FROM sqlite_master WHERE name=?", (t,)).fetchone() is not None

    def get(self, z, x, y):
        r = self.db.execute("SELECT tile_data FROM tiles WHERE zoom_level=? AND tile_column=? AND tile_row=?", (z, x, (1 << z) - 1 - y)).fetchone()
        return bytes(r[0]) if r else None

    def close(self):
        self.db.close()


class OsmdroidSqlite(TileSource):
    """قاعدة osmdroid: جدول tiles(key,provider,tile) حيث key = ((z<<z)+x<<z)+y."""

    def __init__(self, path: str):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.name = os.path.basename(path)

    def get(self, z, x, y):
        key = ((z << z) + x << z) + y
        r = self.db.execute("SELECT tile FROM tiles WHERE key=?", (key,)).fetchone()
        return bytes(r[0]) if r else None

    def close(self):
        self.db.close()


class ZipTiles(TileSource):
    """أرشيف ZIP بمسارات z/x/y.png (أو z/x/y.jpg)."""

    def __init__(self, path: str):
        self.z = zipfile.ZipFile(path)
        self.names = {n.lower().rsplit(".", 1)[0]: n for n in self.z.namelist() if re.match(r"^\d+/\d+/\d+\.\w+$", n.lower())}
        self.name = os.path.basename(path)
        zs = [int(k.split("/")[0]) for k in self.names] or [0]
        self.min_zoom, self.max_zoom = min(zs), max(zs)

    def get(self, z, x, y):
        n = self.names.get(f"{z}/{x}/{y}")
        return self.z.read(n) if n else None

    def close(self):
        self.z.close()


class Gemf(TileSource):
    """GEMF (Generic Map File): فهرس نطاقات (z, xmin..xmax, ymin..ymax, offset)."""

    def __init__(self, path: str):
        self.path = path
        self.name = os.path.basename(path)
        self.f = open(path, "rb")
        ver, tsize, nsrc = struct.unpack(">iii", self.f.read(12))
        if ver != 4:
            raise ValueError("إصدار GEMF غير مدعوم")
        for _ in range(nsrc):
            idx, ln = struct.unpack(">ii", self.f.read(8))
            self.f.read(ln)
        nr = struct.unpack(">i", self.f.read(4))[0]
        self.ranges = []
        for _ in range(nr):
            z, x0, x1, y0, y1, src, off = struct.unpack(">iiiiiiQ", self.f.read(32))
            self.ranges.append((z, x0, x1, y0, y1, off))
        self.min_zoom = min(r[0] for r in self.ranges)
        self.max_zoom = max(r[0] for r in self.ranges)
        self._offs: Dict[int, Tuple] = {}

    def get(self, z, x, y):
        pos = None
        for rz, x0, x1, y0, y1, off in self.ranges:
            if rz == z and x0 <= x <= x1 and y0 <= y <= y1:
                idx = (x - x0) * (y1 - y0 + 1) + (y - y0)
                # بعد الجداول: لكل بلاطة سجل (offset:8, size:4) وفق ترتيب الكتابة؛ نحسب موضعه ضمن هذا النطاق
                base = off
                pos = base + idx * 12
                break
        if pos is None:
            return None
        self.f.seek(pos)
        data = self.f.read(12)
        if len(data) < 12:
            return None
        o, sz = struct.unpack(">Qi", data)
        self.f.seek(o)
        return self.f.read(sz)

    def close(self):
        self.f.close()


def open_source(path: str) -> TileSource:
    low = path.lower()
    if low.endswith(".mbtiles"):
        return MBTiles(path)
    if low.endswith(".zip"):
        return ZipTiles(path)
    if low.endswith(".gemf"):
        return Gemf(path)
    if low.endswith(".sqlite"):
        db = sqlite3.connect(path)
        cols = {r[1] for r in db.execute("PRAGMA table_info(tiles)")}
        db.close()
        return MBTiles(path) if "zoom_level" in cols else OsmdroidSqlite(path)
    raise ValueError("صيغة غير مدعومة: mbtiles أو zip أو sqlite أو gemf")


# ---------------------------------------------------------------------------- الخرائط الأساسية والذاكرة
@dataclass(frozen=True)
class BaseMap:
    id: str
    ar: str
    en: str
    url: str          # قالب {z}/{x}/{y}
    ext: str
    max_zoom: int
    credit: str


BASEMAPS = [
    BaseMap("osm", "OpenStreetMap", "OpenStreetMap", "https://tile.openstreetmap.org/{z}/{x}/{y}.png", "png", 19,
            "© OpenStreetMap contributors"),
    BaseMap("esri", "Esri Imagery", "Esri Imagery",
            "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", "jpg", 19,
            "Tiles © Esri"),
]


def custom_basemap(template: str, name: str = "custom", ext: str = "png", max_zoom: int = 19, credit: str = "") -> BaseMap:
    """خريطة أساسية بقالب URL يحدّده المستخدم (يجب أن يحوي {z} و{x} و{y}). التزم بشروط مزوّد البلاطات."""
    if not all(k in template for k in ("{z}", "{x}", "{y}")):
        raise ValueError("القالب يجب أن يحوي {z} و{x} و{y}")
    return BaseMap(name, name, name, template, ext, max_zoom, credit)


class TileCache:
    """ذاكرة بلاطات على القرص: مجلد/مزوّد/z/x/y.ext مع قياس الحجم والمسح."""

    def __init__(self, folder: str):
        self.folder = folder
        os.makedirs(folder, exist_ok=True)

    def _path(self, bm: BaseMap, z, x, y) -> str:
        return os.path.join(self.folder, bm.id, str(z), str(x), f"{y}.{bm.ext}")

    def get(self, bm, z, x, y) -> Optional[bytes]:
        p = self._path(bm, z, x, y)
        return open(p, "rb").read() if os.path.isfile(p) else None

    def put(self, bm, z, x, y, data: bytes) -> None:
        p = self._path(bm, z, x, y)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "wb") as fh:
            fh.write(data)

    def size(self) -> int:
        return tree_size(self.folder)

    def clear(self) -> None:
        import shutil
        shutil.rmtree(self.folder, ignore_errors=True)
        os.makedirs(self.folder, exist_ok=True)


def tree_size(path: str) -> int:
    if os.path.isfile(path):
        return os.path.getsize(path)
    return sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(path) for f in fs)


def human(b: float) -> str:
    if b < 1024:
        return f"{int(b)} B"
    for unit, d in (("KB", 1024), ("MB", 1024 ** 2), ("GB", 1024 ** 3)):
        if b < d * 1024 or unit == "GB":
            return f"{b / d:.1f} {unit}" if unit != "GB" else f"{b / d:.2f} GB"
    return str(b)


class OfflineStore:
    """مجلد الملفات المحلية (ملف واحد نشط) + وضع «الذاكرة فقط»."""

    def __init__(self, folder: str, prefs=None):
        self.folder = folder
        os.makedirs(folder, exist_ok=True)
        self.prefs = prefs

    def import_file(self, path: str) -> str:
        name = os.path.basename(path)
        if not name.lower().endswith(EXTS):
            raise ValueError("صيغة غير مدعومة. استخدم mbtiles أو zip أو sqlite أو gemf.")
        safe = re.sub(r"[^A-Za-z0-9._-]", "_", name)
        dst = os.path.join(self.folder, safe)
        import shutil
        shutil.copyfile(path, dst)
        prev = self.active_name()
        if prev and prev != safe:
            try:
                os.remove(os.path.join(self.folder, prev))
            except OSError:
                pass
        if self.prefs:
            self.prefs.put("offline_file", safe)
        return dst

    def active_name(self) -> str:
        return self.prefs.get("offline_file", "") if self.prefs else ""

    def active_source(self) -> Optional[TileSource]:
        n = self.active_name()
        p = os.path.join(self.folder, n) if n else ""
        return open_source(p) if n and os.path.isfile(p) else None

    def clear_active(self) -> None:
        n = self.active_name()
        if n:
            try:
                os.remove(os.path.join(self.folder, n))
            except OSError:
                pass
        if self.prefs:
            self.prefs.put("offline_file", "")


# ---------------------------------------------------------------------------- لقطة خريطة
def snapshot(bbox: Sequence[float], width_px: int, source: Optional[TileSource] = None, basemap: Optional[BaseMap] = None,
             cache: Optional[TileCache] = None, cache_only: bool = False, fetch: Optional[Callable[[str], bytes]] = None,
             max_tiles: int = 120, zoom: Optional[int] = None):
    """يرسم لقطة للصندوق (west,south,east,north) من ملف دون اتصال أو من الإنترنت (مع الذاكرة). يرجع (PIL.Image, m/px, الاعتماد).
    إن خلا المستوى المختار من البلاطات في الملف يُجرَّب ما دونه تلقائياً."""
    if zoom is not None or source is None:
        return _snapshot_impl(bbox, width_px, source, basemap, cache, cache_only, fetch, max_tiles, zoom)
    first = _snapshot_impl(bbox, width_px, source, basemap, cache, cache_only, fetch, max_tiles, None, probe=True)
    z = first
    last = None
    while z >= 0:
        try:
            return _snapshot_impl(bbox, width_px, source, basemap, cache, cache_only, fetch, max_tiles, z)
        except IOError as e:
            last = e
            z -= 1
    raise last or IOError("لا توجد بلاطات")


def _snapshot_impl(bbox, width_px, source, basemap, cache, cache_only, fetch, max_tiles, zoom, probe=False):
    from PIL import Image
    west, south, east, north = bbox
    lat0 = (south + north) / 2
    if zoom is None:
        zoom = 0
        top = (source.max_zoom if source else (basemap.max_zoom if basemap else 19))
        for z in range(0, top + 1):
            x0, y0 = lonlat_to_tile(west, north, z)
            x1, y1 = lonlat_to_tile(east, south, z)
            if (x1 - x0) * 256 > width_px * 1.2:
                break
            zoom = z
            if int(x1) - int(x0) + 1 > 0 and (int(x1) - int(x0) + 1) * (int(y1) - int(y0) + 1) > max_tiles:
                zoom = max(0, z - 1)
                break
    if probe:
        return zoom
    x0f, y0f = lonlat_to_tile(west, north, zoom)
    x1f, y1f = lonlat_to_tile(east, south, zoom)
    tx0, ty0, tx1, ty1 = int(x0f), int(y0f), int(x1f), int(y1f)
    if (tx1 - tx0 + 1) * (ty1 - ty0 + 1) > max_tiles:
        raise ValueError("المنطقة كبيرة لهذه اللقطة؛ قرّب الخريطة")
    mosaic = Image.new("RGB", ((tx1 - tx0 + 1) * 256, (ty1 - ty0 + 1) * 256), (230, 230, 230))
    ok = 0
    for tx in range(tx0, tx1 + 1):
        for ty in range(ty0, ty1 + 1):
            data = None
            if source:
                data = source.get(zoom, tx, ty)
            elif basemap:
                data = cache.get(basemap, zoom, tx, ty) if cache else None
                if data is None and not cache_only:
                    url = basemap.url.format(z=zoom, x=tx, y=ty)
                    try:
                        data = fetch(url) if fetch else urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA}), timeout=20).read()
                        if cache and data:
                            cache.put(basemap, zoom, tx, ty, data)
                    except Exception:  # noqa: BLE001
                        data = None
            if data:
                try:
                    mosaic.paste(Image.open(io.BytesIO(data)).convert("RGB"), ((tx - tx0) * 256, (ty - ty0) * 256))
                    ok += 1
                except Exception:  # noqa: BLE001
                    pass
    if ok == 0:
        raise IOError("لا توجد بلاطات متاحة لهذه المنطقة")
    crop = mosaic.crop((round((x0f - tx0) * 256), round((y0f - ty0) * 256), round((x1f - tx0) * 256), round((y1f - ty0) * 256)))
    mpp = (east - west) * math.pi / 180 * 6378137.0 * math.cos(math.radians(lat0)) / max(1, crop.width)
    credit = basemap.credit if basemap else (source.name if source else "")
    return crop, mpp, credit
