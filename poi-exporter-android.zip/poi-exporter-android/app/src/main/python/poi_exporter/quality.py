"""فحص الهندسة، كشف المكررات، وتقرير جودة الطبقة. لا يغيّر شيئاً من تلقاء نفسه."""
from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .admin import AdminRef
from .geo import haversine, oriented, set_representative, signed_area
from .model import LINE, POINT, POLYGON, Feature, Layer
from .sectors import norm_name

EMPTY, TOO_FEW_POINTS, NOT_CLOSED = "EMPTY", "TOO_FEW_POINTS", "NOT_CLOSED"
SELF_INTERSECTION, RING_ORIENTATION, DUPLICATE_VERTEX = "SELF_INTERSECTION", "RING_ORIENTATION", "DUPLICATE_VERTEX"
OUT_OF_RANGE, TYPE_MISMATCH = "OUT_OF_RANGE", "TYPE_MISMATCH"
IRAQ_BBOX = (38.6, 28.9, 48.9, 37.5)   # lon_min, lat_min, lon_max, lat_max (للتنبيه فقط وليس حدّاً)

MESSAGES = {
    EMPTY: ("لا توجد إحداثيات. احذف السجل أو أعد رسمه.", "No coordinates. Delete or redraw the feature."),
    TOO_FEW_POINTS: ("عدد النقاط قليل (الخط يحتاج نقطتين والمضلع 3 رؤوس). أضف رؤوساً أو احذفه.",
                     "Too few points (line needs 2, polygon 3 vertices). Add vertices or delete it."),
    NOT_CLOSED: ("المضلع غير مغلق؛ يمكن إغلاقه تلقائياً.", "Polygon is not closed; it can be closed automatically."),
    SELF_INTERSECTION: ("المضلع يتقاطع مع نفسه. عدّل الرؤوس أو استخدم «إصلاح الهندسة».",
                        'The polygon crosses itself. Edit the vertices or use "Repair geometry".'),
    RING_ORIENTATION: ("اتجاه الحلقة غير قياسي؛ يُصحَّح تلقائياً.", "Ring orientation is non-standard; fixed automatically."),
    DUPLICATE_VERTEX: ("نقاط متتالية مكررة؛ تُحذف تلقائياً.", "Consecutive duplicate vertices; removed automatically."),
    OUT_OF_RANGE: ("إحداثيات خارج النطاق (خط العرض ±90، خط الطول ±180). تحقق من نظام الإحداثيات أو من ترتيب X وY.",
                   "Coordinates out of range (lat ±90, lon ±180). Check the CRS or the X/Y order."),
    TYPE_MISMATCH: ("نوع الهندسة لا يطابق نوع الطبقة.", "Geometry type does not match the layer type."),
}


def message(code: str, ar: bool = True) -> str:
    m = MESSAGES.get(code)
    return (m[0] if ar else m[1]) if m else code


def is_blocking(code: str) -> bool:
    return code in (EMPTY, TOO_FEW_POINTS, OUT_OF_RANGE, SELF_INTERSECTION, TYPE_MISMATCH)


# ---------------------------------------------------------------------------- تقاطع القطع
def _orient(ax, ay, bx, by, cx, cy):
    v = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
    return 0 if v == 0 else (1 if v > 0 else -1)


def _on_seg(ax, ay, bx, by, cx, cy):
    return min(ax, bx) <= cx <= max(ax, bx) and min(ay, by) <= cy <= max(ay, by)


def _seg_cross(a, b, c, d) -> bool:
    o1, o2 = _orient(*a, *b, *c), _orient(*a, *b, *d)
    o3, o4 = _orient(*c, *d, *a), _orient(*c, *d, *b)
    if o1 != o2 and o3 != o4:
        return True
    if o1 == 0 and _on_seg(*a, *b, *c):
        return True
    if o2 == 0 and _on_seg(*a, *b, *d):
        return True
    if o3 == 0 and _on_seg(*c, *d, *a):
        return True
    return o4 == 0 and _on_seg(*c, *d, *b)


def polygon_self_intersects(f: Feature) -> bool:
    """يكتشف تقاطع حدود المضلع مع نفسها (بين قطع غير متجاورة) باستخدام شبكة تجزئة."""
    segs = []  # (ring_index, k, a, b)
    for ri, ring in enumerate(f.parts):
        for k in range(len(ring) - 1):
            segs.append((ri, k, len(ring) - 1, ring[k], ring[k + 1]))
    if len(segs) < 4:
        return False
    xs = [p[0] for s in segs for p in (s[3], s[4])]
    ys = [p[1] for s in segs for p in (s[3], s[4])]
    w, h = max(xs) - min(xs), max(ys) - min(ys)
    n = max(1, int(math.sqrt(len(segs))))
    cx, cy = (w / n) or 1e-12, (h / n) or 1e-12
    x0, y0 = min(xs), min(ys)
    grid: Dict[tuple, list] = defaultdict(list)
    for idx, s in enumerate(segs):
        a, b = s[3], s[4]
        i0, i1 = sorted((int((a[0] - x0) / cx), int((b[0] - x0) / cx)))
        j0, j1 = sorted((int((a[1] - y0) / cy), int((b[1] - y0) / cy)))
        for i in range(i0, i1 + 1):
            for j in range(j0, j1 + 1):
                grid[(i, j)].append(idx)
    seen = set()
    for cell in grid.values():
        for ii in range(len(cell)):
            for jj in range(ii + 1, len(cell)):
                i, j = cell[ii], cell[jj]
                if (i, j) in seen:
                    continue
                seen.add((i, j))
                r1, k1, last1, a, b = segs[i]
                r2, k2, last2, c, d = segs[j]
                if r1 == r2:
                    gap = abs(k1 - k2)
                    if gap == 1 or gap == last1 - 1:   # قطع متجاورة (بما فيها الإغلاق)
                        continue
                if _seg_cross(a, b, c, d):
                    return True
    return False


# ---------------------------------------------------------------------------- فحص الميزة
def check(f: Feature, layer_geom: int = 0) -> List[str]:
    r: List[str] = []
    if not f.parts:
        return [EMPTY]
    if layer_geom and f.geom != layer_geom:
        r.append(TYPE_MISMATCH)
    rng = dup = open_ = few = orient = False
    for i, p in enumerate(f.parts):
        n = len(p)
        if n == 0:
            few = True
            continue
        for k, (x, y) in enumerate(p):
            if x != x or y != y or abs(x) > 180 or abs(y) > 90:
                rng = True
            if k > 0 and (x, y) == p[k - 1]:
                dup = True
        if f.geom == LINE and n < 2:
            few = True
        if f.geom == POLYGON:
            closed = p[0] == p[-1]
            if not closed:
                open_ = True
            distinct = n - (1 if closed else 0)
            if distinct < 3:
                few = True
            elif (signed_area(p) < 0) == f.is_hole(i):
                orient = True
    if rng:
        r.append(OUT_OF_RANGE)
    if few:
        r.append(TOO_FEW_POINTS)
    if open_:
        r.append(NOT_CLOSED)
    if dup:
        r.append(DUPLICATE_VERTEX)
    if orient:
        r.append(RING_ORIENTATION)
    if f.geom == POLYGON and not rng and not few:
        try:
            if polygon_self_intersects(f):
                r.append(SELF_INTERSECTION)
        except Exception:  # noqa: BLE001
            r.append(SELF_INTERSECTION)
    return r


def describe(codes: List[str], ar: bool = True) -> str:
    return " • ".join(message(c, ar) for c in codes)


def fix(f: Feature) -> bool:
    """يغلق الحلقات ويضبط اتجاهها ويزيل التكرار المتتالي. يرجع True إن تغيّر شيء."""
    changed = False
    for i, p in enumerate(f.parts):
        q = []
        for pt in p:
            if q and q[-1] == pt:
                continue
            q.append(pt)
        if len(q) != len(p):
            changed = True
        p = q
        if f.geom == POLYGON and len(p) >= 3:
            if p[0] != p[-1]:
                p = p + [p[0]]
                changed = True
            if len(p) >= 4 and (signed_area(p) < 0) == f.is_hole(i):
                p = p[::-1]
                changed = True
        f.parts[i] = p
    if changed:
        set_representative(f)
    return changed


def make_valid(f: Feature) -> Optional[Feature]:
    """يُصلح التقاطعات الذاتية؛ يحتاج مكتبة shapely (اختيارية). يرجع None إن تعذّر."""
    try:
        from shapely.geometry import Polygon  # type: ignore
        from shapely.validation import make_valid as mv  # type: ignore
    except ImportError:
        return None
    try:
        outers = [p for i, p in enumerate(f.parts) if not f.is_hole(i)]
        holes = [p for i, p in enumerate(f.parts) if f.is_hole(i)]
        g = mv(Polygon(outers[0], holes))
        polys = [g] if g.geom_type == "Polygon" else [x for x in getattr(g, "geoms", []) if x.geom_type == "Polygon"]
        if not polys:
            return None
        best = max(polys, key=lambda x: x.area)
        out = f.copy()
        out.parts, out.holes = [], []
        out.add_part(list(best.exterior.coords), False)
        for h in best.interiors:
            out.add_part(list(h.coords), True)
        fix(out)
        return out
    except Exception:  # noqa: BLE001
        return None


# ---------------------------------------------------------------------------- المكررات
@dataclass
class DupGroup:
    members: List[Feature] = field(default_factory=list)
    max_distance: float = 0.0
    same_name: bool = False
    same_coords: bool = False


def find_duplicates(feats: List[Feature], meters: float = 30.0, use_name: bool = True) -> List[DupGroup]:
    """مواقع متطابقة (≤0.1م) أو الاسم نفسه ضمن مسافة. تجزئة شبكية O(n)."""
    cell = max(meters, 1) / 111320.0 * 1.5
    grid: Dict[tuple, List[int]] = defaultdict(list)
    for i, f in enumerate(feats):
        grid[(math.floor(f.lon / cell), math.floor(f.lat / cell))].append(i)
    names = [norm_name(f.name) if use_name else "" for f in feats]
    used = [False] * len(feats)
    out: List[DupGroup] = []
    for i, a in enumerate(feats):
        if used[i]:
            continue
        cx, cy = math.floor(a.lon / cell), math.floor(a.lat / cell)
        g: Optional[DupGroup] = None
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for j in grid.get((cx + dx, cy + dy), ()):
                    if j <= i or used[j]:
                        continue
                    b = feats[j]
                    d = haversine(a.lat, a.lon, b.lat, b.lon)
                    same = d <= 0.1
                    nm = use_name and names[i] != "" and names[i] == names[j] and d <= meters
                    if not same and not nm:
                        continue
                    if g is None:
                        g = DupGroup(members=[a])
                        used[i] = True
                    g.members.append(b)
                    used[j] = True
                    g.max_distance = max(g.max_distance, d)
                    g.same_coords |= same
                    g.same_name |= nm or (names[i] != "" and names[i] == names[j])
        if g:
            out.append(g)
    return out


# ---------------------------------------------------------------------------- تقرير الجودة
def _empty(s) -> bool:
    return s is None or not str(s).strip()


@dataclass
class Report:
    total: int = 0
    empty_name: int = 0
    empty_type: int = 0
    empty_category: int = 0
    empty_gathaa: int = 0
    empty_nahia: int = 0
    empty_mohafadha: int = 0
    invalid_geometry: List[Feature] = field(default_factory=list)
    geometry_codes: Dict[str, int] = field(default_factory=dict)
    outside_iraq: List[Feature] = field(default_factory=list)
    duplicates: List[DupGroup] = field(default_factory=list)
    duplicate_extra: int = 0
    missing_admin: List[Feature] = field(default_factory=list)

    def problems(self) -> int:
        return len(self.invalid_geometry) + len(self.outside_iraq) + self.duplicate_extra

    def to_text(self, ar: bool = True) -> str:
        b = [("عدد العناصر: " if ar else "Features: ") + str(self.total),
             ("حقول فارغة — " if ar else "Empty fields — ") +
             f"name {self.empty_name} • type {self.empty_type} • Gategory {self.empty_category} • "
             f"gathaa {self.empty_gathaa} • Nahia {self.empty_nahia} • mohafadha {self.empty_mohafadha}",
             ("هندسة غير صالحة: " if ar else "Invalid geometry: ") + str(len(self.invalid_geometry))]
        for c, n in self.geometry_codes.items():
            b.append(f"   • {message(c, ar)} ({n})")
        b.append(("خارج نطاق العراق التقريبي: " if ar else "Outside Iraq's rough extent: ") + str(len(self.outside_iraq)))
        b.append(("مجموعات مكررة: " if ar else "Duplicate groups: ") + f"{len(self.duplicates)} "
                 + (f"(يمكن حذف {self.duplicate_extra} عنصراً مكرراً)" if ar else f"({self.duplicate_extra} removable)"))
        b.append(("بلا قضاء/محافظة وقابلة للملء: " if ar else "Missing qadaa/governorate, fillable: ") + str(len(self.missing_admin)))
        return "\n".join(b)


def analyze(layer: Layer, dup_meters: float = 30.0, admin: Optional[AdminRef] = None) -> Report:
    r = Report(total=len(layer.features))
    points = []
    for f in layer.features:
        r.empty_name += _empty(f.name)
        r.empty_type += _empty(f.type)
        r.empty_category += _empty(f.category)
        r.empty_gathaa += _empty(f.qadaa)
        r.empty_nahia += _empty(f.nahiya)
        r.empty_mohafadha += _empty(f.governorate)
        codes = check(f, 0)
        if codes:
            r.invalid_geometry.append(f)
            for c in codes:
                r.geometry_codes[c] = r.geometry_codes.get(c, 0) + 1
        bad = OUT_OF_RANGE in codes or EMPTY in codes
        if not bad and not (IRAQ_BBOX[0] <= f.lon <= IRAQ_BBOX[2] and IRAQ_BBOX[1] <= f.lat <= IRAQ_BBOX[3]):
            r.outside_iraq.append(f)
        if f.geom == POINT and not bad:
            points.append(f)
        if admin and not bad and (_empty(f.qadaa) or _empty(f.governorate)):
            if admin.locate(f.lat, f.lon).found():
                r.missing_admin.append(f)
    if len(points) > 1:
        r.duplicates = find_duplicates(points, dup_meters, True)
        r.duplicate_extra = sum(len(g.members) - 1 for g in r.duplicates)
    return r


def repair_geometry(bad: List[Feature], make_valid_too: bool = False):
    """قائمة أزواج (الأصل، المُصلَح) للميزات التي تغيّرت."""
    out = []
    for f in bad:
        a = f.copy()
        changed = fix(a)
        if make_valid_too and f.geom == POLYGON and SELF_INTERSECTION in check(a, 0):
            v = make_valid(a)
            if v is not None:
                v.id, v.name, v.type, v.category = f.id, f.name, f.type, f.category
                v.qadaa, v.nahiya, v.governorate = f.qadaa, f.nahiya, f.governorate
                v.attrs.update(f.attrs)
                a, changed = v, True
        if changed:
            out.append((f.copy(), a))
    return out


def duplicate_ids_to_remove(groups: List[DupGroup]) -> List[str]:
    return [m.id for g in groups for m in g.members[1:]]


def fill_admin_for(features: List[Feature], admin: AdminRef):
    out = []
    for f in features:
        a = f.copy()
        if admin.fill(a, True):
            out.append((f.copy(), a))
    return out
