"""عناصر الخريطة (نصوص وصور صغيرة مثبّتة جغرافياً). تُحفظ منفصلة عن الطبقات فلا تدخل في التصدير، وتظهر في PDF/PNG."""
from __future__ import annotations

import json
import math
import uuid
from dataclasses import asdict, dataclass, field
from typing import List, Optional

TEXT, IMAGE = "text", "image"


@dataclass
class Item:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    kind: str = TEXT
    lat: float = 0.0
    lon: float = 0.0
    text: str = ""
    size: float = 14.0                 # sp
    color: int = 0xFF000000            # ARGB
    background: int = 0xE6FFFFFF
    file: str = ""
    width: int = 96                    # dp (للصور)

    def copy(self) -> "Item":
        return Item(**asdict(self))


class Annotations:
    def __init__(self):
        self.items: List[Item] = []

    def add(self, item: Item) -> Item:
        self.items.append(item)
        return item

    def find(self, item_id: str) -> Optional[Item]:
        return next((i for i in self.items if i.id == item_id), None)

    def remove(self, item_id: str) -> bool:
        for k, i in enumerate(self.items):
            if i.id == item_id:
                del self.items[k]
                return True
        return False

    def nearest(self, lat: float, lon: float, max_m: float) -> Optional[Item]:
        best, bd = None, max_m
        for i in self.items:
            dy = (i.lat - lat) * 111320.0
            dx = (i.lon - lon) * 111320.0 * math.cos(math.radians(lat))
            d = math.hypot(dx, dy)
            if d <= bd:
                bd, best = d, i
        return best

    def to_json(self) -> str:
        return json.dumps({"items": [asdict(i) for i in self.items]}, ensure_ascii=False)

    @staticmethod
    def from_json(text: str) -> "Annotations":
        a = Annotations()
        if not text or not text.strip():
            return a
        try:
            for m in json.loads(text).get("items", []):
                i = Item(id=str(m.get("id") or uuid.uuid4()), kind=IMAGE if m.get("kind") == IMAGE else TEXT,
                         lat=float(m.get("lat", 0)), lon=float(m.get("lon", 0)), text=str(m.get("text", "")),
                         size=max(6.0, min(72.0, float(m.get("size", 14)))), color=int(m.get("color", 0xFF000000)),
                         background=int(m.get("background", m.get("bg", 0xE6FFFFFF))), file=str(m.get("file", "")),
                         width=int(max(24, min(400, float(m.get("width", m.get("w", 96)))))))
                if abs(i.lat) <= 90 and abs(i.lon) <= 180:
                    a.items.append(i)
        except (ValueError, TypeError, AttributeError):
            return Annotations()
        return a
