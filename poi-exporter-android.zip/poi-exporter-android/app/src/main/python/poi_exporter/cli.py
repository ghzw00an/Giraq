"""واجهة سطر الأوامر: python -m poi_exporter <أمر> ..."""
from __future__ import annotations

import argparse
import csv
import json
import sys

from . import analysis, catalog, formats, overpass, quality, sectors, convert as convmod, offline, proj, raster, report as reportmod, topology, appstate, dashboard, adminfetch, geoops
from .admin import AdminRef
from .coords import FMT_DD, Crs, format_coord, parse_coord
from .geo import AreaSpec
from .model import POINT, Feature, Layer


def _crs(v):
    return Crs.of(v) if v else None


def _merge_layers(layers):
    return layers


def cmd_download(a):
    if a.circle:
        lat, lon, r = (float(x) for x in a.circle.split(","))
        area = AreaSpec.make_circle(lat, lon, r)
    else:
        s, w, n, e = (float(x) for x in a.bbox.split(","))
        area = AreaSpec.rect(s, w, n, e)
    p = overpass.Params(area=area, poi_cats=a.poi or [], custom=a.custom or "", include_unnamed=a.unnamed,
                        layer_ids=set(a.layers or []), fill_admin=a.fill_admin)
    res = overpass.run(p, overpass.http_fetcher(),
                       lambda m, i, n: print(f"[{i}/{n}] {m}", file=sys.stderr))
    for w_ in res.warnings:
        print("تحذير:", w_, file=sys.stderr)
    adm = AdminRef.get()
    if a.offline_admin and adm:
        for l in res.layers:
            for f in l.features:
                adm.fill(f, True)
    warns = formats.export_layers(res.layers, a.format, a.out, formats.ExportOptions(_crs(a.target)))
    for w_ in warns:
        print("تنبيه:", w_, file=sys.stderr)
    print(f"{res.feature_count()} عنصر → {a.out}")


def cmd_convert(a):
    res = formats.import_file(a.input, mapping=None, src_crs=_crs(a.crs), skip_duplicates=a.skip_dup, repair=a.repair)
    for w_ in res.warnings:
        print("تنبيه:", w_, file=sys.stderr)
    if a.fill_admin:
        adm = AdminRef.get()
        for l in res.layers:
            for f in l.features:
                adm.fill(f, True)
    fmt = a.format or a.out.rsplit(".", 1)[-1].lower().replace("zip", "shp").replace("geojson", "geojson")
    for w_ in formats.export_layers(res.layers, fmt, a.out, formats.ExportOptions(_crs(a.target), not a.no_attrs)):
        print("تنبيه:", w_, file=sys.stderr)
    print(f"{res.feature_count()} عنصر → {a.out}")


def cmd_coords(a):
    for text in a.text:
        try:
            p = parse_coord(text)
        except ValueError as e:
            print(f"{text!r}: خطأ — {e}")
            continue
        print(f"[{p.fmt}]")
        for f in ("DD", "DMS", "DDM", "UTM", "MGRS"):
            print(f"  {f:5} {format_coord(f, p.lat, p.lon)}")


def cmd_locate(a):
    adm = AdminRef.get()
    h = adm.locate(a.lat, a.lon)
    print("القضاء:", h.qadaa() or "-", "| المحافظة:", h.governorate_name() or "-",
          "| المسافة إلى الحد (م):", round(h.boundary_m) if h.boundary_m >= 0 else "-")


def cmd_quality(a):
    res = formats.import_file(a.input)
    for l in res.layers:
        print(f"== {l.label}")
        print(quality.analyze(l, a.dup_meters, AdminRef.get()).to_text())


def cmd_analyze(a):
    res = formats.import_file(a.input)
    pts = [l for l in res.layers if l.geom == POINT]
    if not pts:
        sys.exit("لا توجد طبقة نقاط")
    l = pts[0]
    if a.tool == "summary":
        print(analysis.summary_text(l, a.field))
    elif a.tool == "nn":
        print(analysis.nearest_neighbour(l))
    elif a.tool == "clusters":
        for i, c in enumerate(analysis.clusters(l, a.eps, a.min_pts), 1):
            print(f"تجمع {i}: {len(c.members)} نقطة عند {c.lat:.5f},{c.lon:.5f}")
    elif a.tool == "auto-sector":
        e = analysis.auto_sector(l.features)
        print(f"{len(e.pairs)} تعديل — {e.note}")
        if a.out:
            e.apply_in_place(l.features)
            formats.export_layers([l], a.out.rsplit(".", 1)[-1], a.out)


def cmd_sectors(a):
    for s in sectors.ALL:
        print(f"{s.name}: {'، '.join(s.items)}")



def _load_layers(paths):
    layers = []
    for p in paths:
        r = formats.import_file(p)
        for w_ in r.warnings:
            print("تنبيه:", w_, file=sys.stderr)
        layers += r.layers
    return layers


def cmd_report(a):
    layers = _load_layers(a.input)
    kw = dict(title=a.title or "", subtitle=a.subtitle or "", landscape=not a.portrait, paper=a.paper, grid={"none": 0, "deg": 1, "utm": 2}[a.grid],
              fixed_scale=a.scale, color_by_sector=a.by_sector, table=not a.no_table, legend=not a.no_legend, map_rotation=0.0, dpi=a.dpi)
    if a.bbox:
        kw["bbox"] = [float(x) for x in a.bbox.split(",")]
    items = []
    if a.raster:
        store = raster.RasterStore(a.raster_dir)
        for it in store.items:
            items.append((it, store.image(it)))
        kw["rasters"] = items
    if a.basemap or a.tiles:
        bb = kw.get("bbox") or reportmod.pad_bbox(reportmod.layers_extent(layers), 0.05)
        if a.tiles:
            img, mpp, credit = offline.snapshot(bb, a.dpi * 8, source=offline.open_source(a.tiles))
        else:
            bm = next(b for b in offline.BASEMAPS if b.id == a.basemap)
            img, mpp, credit = offline.snapshot(bb, a.dpi * 8, basemap=bm, cache=offline.TileCache(a.cache_dir))
        kw.update(snapshot=img, snapshot_bbox=bb, snap_credit=credit)
    r = reportmod.make_report(layers, a.out, **kw)
    print(f"{r.page_count()} صفحة → {a.out}")


def cmd_raster(a):
    store = raster.RasterStore(a.store)
    if a.action == "add":
        b = tuple(float(x) for x in a.bounds.split(",")) if a.bounds else None
        it = store.import_file(a.file, bounds=b, epsg=a.epsg)
        print(f"أُضيفت {it.id}: {it.name} {it.w}x{it.h}", it.note)
    elif a.action == "list":
        for it in store.items:
            print(it.id, it.name, "%dx%d" % (it.w, it.h), it.bounds())
    elif a.action == "remove":
        store.remove(a.file)


def cmd_batch(a):
    rep = convmod.batch_convert(a.input, a.out, a.column, a.x, a.y, _crs(a.src), _crs(a.target), not a.lon_first, a.errors)
    print(f"{rep.ok}/{rep.rows} صف نجح" + (f" • {len(rep.errors)} خطأ" if rep.errors else ""))
    for w_ in rep.warnings:
        print("تنبيه:", w_, file=sys.stderr)


def cmd_crs(a):
    if a.query.isdigit():
        try:
            c = Crs.of(int(a.query))
            print(c)
            return
        except ValueError as e:
            print(e)
    for code, name in proj.search(a.query, 40):
        print(code, name)


def cmd_topology(a):
    for l in _load_layers([a.input]):
        if l.geom == 5:
            print("==", l.label)
            rep = topology.report(l, a.min_area)
            print(rep.to_text())
            for i in rep.issues[:50]:
                print(f"  {i.kind} {i.ids} ({i.lat:.5f},{i.lon:.5f}) {i.area_m2:.0f} م²")


def cmd_dashboard(a):
    layers = _load_layers([a.input])
    print(dashboard.to_text(dashboard.compute(layers, a.input)))


def cmd_admin_fetch(a):
    found = adminfetch.by_name(a.query)
    ref = AdminRef.get()
    for i, f in enumerate(found, 1):
        print(i, f.name_ar, "—", f.detail)
    if found and a.add:
        u = adminfetch.add(ref, found[a.add - 1], a.save)
        print("أُضيف:", u.name_en if u else "فشل")


def cmd_backup(a):
    from .workspace import Workspace
    ws = Workspace(a.db)
    prefs = appstate.Prefs(a.base + "/prefs.json")
    n = appstate.run_backup(ws, a.base, prefs)
    print(f"{n} نسخة →", a.base + "/backups")


def cmd_geoop(a):
    l = _load_layers([a.input])[0]
    if a.op == "buffer":
        out = [geoops.buffer(f, a.meters) for f in l.features]
        out = [f for f in out if f]
        res = Layer("buf", f"{l.label} — حاجز {a.meters:g} م", 5, out)
    elif a.op == "union":
        u = geoops.union([f for f in l.features if f.geom == 5])
        res = Layer("union", l.label + " — اتحاد", 5, [u] if u else [])
    elif a.op == "hull":
        h = geoops.convex_hull_feature(l.features)
        res = Layer("hull", l.label + " — غلاف", 5, [h] if h else [])
    formats.export_layers([res], a.out.rsplit(".", 1)[-1] if "." in a.out else "geojson", a.out)
    print(f"{len(res.features)} عنصر → {a.out}")


def cmd_serve(a):
    from .webapp import create_app
    create_app().run(host=a.host, port=a.port)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="poi_exporter", description="مصدّر المعالم (POI Exporter) — بايثون")
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("download", help="تنزيل معالم/طبقات من OSM (Overpass) وتصديرها")
    g = d.add_mutually_exclusive_group(required=True)
    g.add_argument("--bbox", help="south,west,north,east")
    g.add_argument("--circle", help="lat,lon,radius_m")
    d.add_argument("--poi", nargs="*", choices=[c.id for c in catalog.POI])
    d.add_argument("--custom", help="مرشح مخصص مثل amenity=cafe")
    d.add_argument("--layers", nargs="*", choices=[x.id for x in catalog.LAYERS] + catalog.ADMIN_IDS)
    d.add_argument("--unnamed", action="store_true")
    d.add_argument("--fill-admin", action="store_true", help="ملء gathaa/mohafadha من حدود OSM")
    d.add_argument("--offline-admin", action="store_true", help="ملء gathaa/mohafadha من الحدود المضمّنة")
    d.add_argument("--format", default="geojson", choices=formats.FORMATS)
    d.add_argument("--target", help="نظام الإحداثيات للتصدير (EPSG)")
    d.add_argument("-o", "--out", required=True)
    d.set_defaults(fn=cmd_download)
    c = sub.add_parser("convert", help="تحويل ملف بين الصيغ")
    c.add_argument("input")
    c.add_argument("-o", "--out", required=True)
    c.add_argument("--format", choices=formats.FORMATS)
    c.add_argument("--crs", help="نظام إحداثيات المصدر لملفات CSV/Excel (EPSG)")
    c.add_argument("--target", help="نظام التصدير (EPSG)")
    c.add_argument("--skip-dup", action="store_true")
    c.add_argument("--repair", action="store_true")
    c.add_argument("--fill-admin", action="store_true")
    c.add_argument("--no-attrs", action="store_true")
    c.set_defaults(fn=cmd_convert)
    k = sub.add_parser("coords", help="تحويل إحداثيات (DD/DMS/DDM/UTM/MGRS)")
    k.add_argument("text", nargs="+")
    k.set_defaults(fn=cmd_coords)
    l = sub.add_parser("locate", help="القضاء والمحافظة لنقطة")
    l.add_argument("lat", type=float)
    l.add_argument("lon", type=float)
    l.set_defaults(fn=cmd_locate)
    q = sub.add_parser("quality", help="تقرير جودة البيانات")
    q.add_argument("input")
    q.add_argument("--dup-meters", type=float, default=30)
    q.set_defaults(fn=cmd_quality)
    an = sub.add_parser("analyze", help="أدوات تحليل")
    an.add_argument("tool", choices=["summary", "nn", "clusters", "auto-sector"])
    an.add_argument("input")
    an.add_argument("--field", type=int, default=2)
    an.add_argument("--eps", type=float, default=300)
    an.add_argument("--min-pts", type=int, default=4)
    an.add_argument("-o", "--out")
    an.set_defaults(fn=cmd_analyze)
    s = sub.add_parser("sectors", help="عرض القطاعات وعناصرها")
    s.set_defaults(fn=cmd_sectors)
    rp = sub.add_parser("report", help="تقرير خريطة PDF/PNG (مع جدول الخصائص)")
    rp.add_argument("input", nargs="+")
    rp.add_argument("-o", "--out", required=True)
    rp.add_argument("--title")
    rp.add_argument("--subtitle")
    rp.add_argument("--paper", default="A4", choices=["A5", "A4", "A3"])
    rp.add_argument("--portrait", action="store_true")
    rp.add_argument("--grid", default="none", choices=["none", "deg", "utm"])
    rp.add_argument("--scale", type=float, default=0, help="مقياس ثابت 1:N")
    rp.add_argument("--bbox", help="west,south,east,north")
    rp.add_argument("--by-sector", action="store_true", help="تلوين النقاط حسب القطاع")
    rp.add_argument("--no-table", action="store_true")
    rp.add_argument("--no-legend", action="store_true")
    rp.add_argument("--dpi", type=int, default=150)
    rp.add_argument("--raster", action="store_true", help="إدراج صور المخزن (--raster-dir)")
    rp.add_argument("--raster-dir", default="rasters")
    rp.add_argument("--basemap", choices=[b.id for b in offline.BASEMAPS], help="لقطة خريطة أساسية من الإنترنت (مع ذاكرة)")
    rp.add_argument("--tiles", help="ملف بلاطات دون اتصال (mbtiles/zip/sqlite/gemf)")
    rp.add_argument("--cache-dir", default="tilecache")
    rp.set_defaults(fn=cmd_report)
    rs = sub.add_parser("raster", help="إدارة الصور الجوية (TIFF/GeoTIFF/JPG/PNG)")
    rs.add_argument("action", choices=["add", "list", "remove"])
    rs.add_argument("file", nargs="?")
    rs.add_argument("--store", default="rasters")
    rs.add_argument("--bounds", help="west,south,east,north للصور بلا مرجع جغرافي")
    rs.add_argument("--epsg", type=int)
    rs.set_defaults(fn=cmd_raster)
    bc = sub.add_parser("batch-coords", help="تحويل إحداثيات جدول CSV/Excel دفعةً")
    bc.add_argument("input")
    bc.add_argument("-o", "--out", required=True)
    bc.add_argument("--column", help="عمود فيه الإحداثيات كاملة")
    bc.add_argument("--x")
    bc.add_argument("--y")
    bc.add_argument("--src", help="نظام الإدخال (EPSG) أو اتركه للاكتشاف التلقائي")
    bc.add_argument("--target", help="نظام إضافي للإخراج (EPSG)")
    bc.add_argument("--lon-first", action="store_true")
    bc.add_argument("--errors", help="ملف CSV للصفوف المرفوضة")
    bc.set_defaults(fn=cmd_batch)
    cr = sub.add_parser("crs", help="بحث في فهرس EPSG المضمّن (رمز أو اسم)")
    cr.add_argument("query")
    cr.set_defaults(fn=cmd_crs)
    tp = sub.add_parser("topology", help="فحص طوبولوجيا المضلعات (تداخل/فجوة/تقاطع ذاتي/مكرر)")
    tp.add_argument("input")
    tp.add_argument("--min-area", type=float, default=1.0)
    tp.set_defaults(fn=cmd_topology)
    ds = sub.add_parser("dashboard", help="ملخص لوحة المعلومات لملف")
    ds.add_argument("input")
    ds.set_defaults(fn=cmd_dashboard)
    af = sub.add_parser("admin-fetch", help="جلب حدود قضاء من OSM بالاسم (Nominatim)")
    af.add_argument("query")
    af.add_argument("--add", type=int, help="رقم النتيجة المراد إضافتها")
    af.add_argument("--save", help="ملف حفظ الأقضية الإضافية")
    af.set_defaults(fn=cmd_admin_fetch)
    bk = sub.add_parser("backup", help="نسخ احتياطي لكل مشاريع قاعدة بيانات المشروع")
    bk.add_argument("--db", required=True)
    bk.add_argument("--base", default=".")
    bk.set_defaults(fn=cmd_backup)
    go = sub.add_parser("geoop", help="عمليات مكانية: buffer / union / hull")
    go.add_argument("op", choices=["buffer", "union", "hull"])
    go.add_argument("input")
    go.add_argument("-o", "--out", required=True)
    go.add_argument("--meters", type=float, default=100)
    go.set_defaults(fn=cmd_geoop)
    sv = sub.add_parser("serve", help="تشغيل الواجهة الرسومية في المتصفح")
    sv.add_argument("--host", default="127.0.0.1")
    sv.add_argument("--port", type=int, default=8000)
    sv.set_defaults(fn=cmd_serve)
    a = ap.parse_args(argv)
    try:
        a.fn(a)
    except (ValueError, IOError, KeyError) as e:
        sys.exit(f"خطأ: {e}")


if __name__ == "__main__":
    main()
