/* ===== اقتراحات المناطق أثناء الكتابة (من أول حرف) + إظهارها على الخريطة ===== */
(function () {
  const q = $("#q"); if (!q) return;
  const box = document.createElement("div"); box.id = "sug"; box.style.display = "none"; document.body.appendChild(box);
  let items = [], sel = -1, ab = null, tm = null, ready = false;
  const AR = /[\u0600-\u06FF]/, DIG = /[0-9\u0660-\u0669]/;
  const wantPlaces = v => v.length > 0 && (AR.test(v) || (!DIG.test(v) && /[A-Za-z]{2,}/.test(v)));
  const ZOOM = { "محافظة": 8, "قضاء": 10, "ناحية": 12, "مدينة": 12, "بلدة": 13, "حي": 14, "قرية": 14 };

  function ensureLayers() {
    if (ready || !map || !map.getSource) return ready;
    if (!map.getSource("area")) return false;               // الخريطة لم تُحمَّل بعد
    const empty = { type: "FeatureCollection", features: [] };
    map.addSource("place-hl", { type: "geojson", data: empty });
    map.addLayer({ id: "place-hl-f", type: "fill", source: "place-hl", paint: { "fill-color": "#d6336c", "fill-opacity": .14 } });
    map.addLayer({ id: "place-hl-l", type: "line", source: "place-hl", paint: { "line-color": "#d6336c", "line-width": 2.6 } });
    map.addSource("place-pv", { type: "geojson", data: empty });
    map.addLayer({ id: "place-pv-c", type: "circle", source: "place-pv", paint: { "circle-radius": 6, "circle-color": "#d6336c", "circle-stroke-width": 2, "circle-stroke-color": "#fff" } });
    ready = true; return true;
  }
  const setHL = f => { if (ensureLayers()) map.getSource("place-hl").setData({ type: "FeatureCollection", features: f ? [f] : [] }); };
  const setPV = list => { if (ensureLayers()) map.getSource("place-pv").setData({ type: "FeatureCollection", features: list.map(p => ({ type: "Feature", properties: { id: p.id }, geometry: { type: "Point", coordinates: [p.lon, p.lat] } })) }); };

  function hide() { box.style.display = "none"; sel = -1; }
  function mark(s, qv) {                                    // تظليل الحروف المطابقة في بداية الاسم
    const n = qv.replace(/^\s+/, ""); if (!n) return esc(s);
    const strip = x => x.replace(/[\u064B-\u065F\u0670\u0640]/g, "");
    const a = strip(s), b = strip(n);
    if (a.startsWith(b) || (a.startsWith("ال") && a.slice(2).startsWith(b))) {
      const off = a.startsWith(b) ? 0 : 2, len = Math.min(s.length, off + n.length);
      return esc(s.slice(0, off)) + "<mark>" + esc(s.slice(off, len)) + "</mark>" + esc(s.slice(len));
    }
    return esc(s);
  }
  function render() {
    if (!items.length) { hide(); return; }
    const v = q.value;
    box.innerHTML = items.map((p, i) => `<div class="sg${i === sel ? " on" : ""}" data-i="${i}"><div class="sn">${mark(p.name, v)}${p.en && p.en !== p.name ? `<small>${esc(p.en)}</small>` : ""}</div><div class="st"><span class="tp">${esc(p.type)}</span>${p.parent ? `<span>${esc(p.parent)}</span>` : ""}</div></div>`).join("");
    box.style.display = "block";
    box.querySelectorAll(".sg").forEach(e => { e.onpointerdown = ev => { ev.preventDefault(); pick(items[+e.dataset.i]); }; });
  }
  async function fetchSug() {
    const v = q.value.trim();
    if (!wantPlaces(v)) { items = []; setPV([]); hide(); return; }
    if (ab) ab.abort(); ab = new AbortController();
    try {
      const r = await (await fetch("/api/places/suggest?limit=12&q=" + encodeURIComponent(v), { signal: ab.signal })).json();
      if (q.value.trim() !== v) return;                      // نتيجة قديمة
      items = r.items || []; sel = -1; render(); setPV(items);
    } catch (e) { }
  }
  async function pick(p) {
    if (!p) return;
    hide(); q.blur(); q.value = p.name; setPV([]); setHL(null);
    let hasPoly = false;
    if (p.poly) {
      try { const r = await api("/api/places/geom?id=" + p.id); if (r.feature) { setHL(r.feature); hasPoly = true; } } catch (e) { }
    }
    if (p.bbox && p.bbox[2] > p.bbox[0] && p.bbox[3] > p.bbox[1]) {
      map.fitBounds([[p.bbox[0], p.bbox[1]], [p.bbox[2], p.bbox[3]]], { padding: { top: 120, bottom: 140, left: 40, right: 40 }, maxZoom: 15, duration: 900 });
    } else {
      map.flyTo({ center: [p.lon, p.lat], zoom: ZOOM[p.type] || 13, duration: 900 });
    }
    marker("sr", p.lon, p.lat);
    popupAt([p.lon, p.lat], `<b>${esc(p.name)}</b><div class="hint">${esc(p.type)}${p.parent ? " — " + esc(p.parent) : ""}${p.en ? "<br><span style=\"direction:ltr;display:inline-block\">" + esc(p.en) + "</span>" : ""}</div><div class="hint" style="direction:ltr;text-align:start">${p.lat.toFixed(5)}, ${p.lon.toFixed(5)}</div><button class="btn blk" id="pa">${I("plus")}${t("addhere")}</button>`,
      d => { $("#pa", d).onclick = () => { openAdd(); ADD.at = [p.lat, p.lon]; }; });
  }
  q.addEventListener("input", () => {
    clearTimeout(tm);
    if (!q.value.trim()) { items = []; hide(); setPV([]); setHL(null); return; }
    tm = setTimeout(fetchSug, 60);
  });
  q.addEventListener("focus", () => { if (items.length && wantPlaces(q.value.trim())) render(); else if (wantPlaces(q.value.trim())) fetchSug(); });
  q.addEventListener("blur", () => setTimeout(hide, 150));
  q.addEventListener("keydown", e => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") { if (!items.length) return; e.preventDefault(); sel = (sel + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length; render(); return; }
    if (e.key === "Escape") { hide(); return; }
    if (e.key === "Enter" && wantPlaces(q.value.trim())) {
      const p = items[sel >= 0 ? sel : 0];
      if (p) { e.preventDefault(); e.stopImmediatePropagation(); pick(p); }
    }
  }, true);
  $("#qgo").addEventListener("click", e => {                 // زر السهم: أول نتيجة إن كان النص اسماً
    if (wantPlaces(q.value.trim()) && items.length) { e.stopImmediatePropagation(); e.preventDefault(); pick(items[sel >= 0 ? sel : 0]); }
  }, true);
})();
