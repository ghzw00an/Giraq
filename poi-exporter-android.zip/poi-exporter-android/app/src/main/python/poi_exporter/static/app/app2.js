"use strict";
/* ===== الإعدادات والمظهر ===== */
async function setSet(k, v) { S.set[k] = v; try { await post("/api/settings", { [k]: v }); } catch (e) { fail(e); } }
function applyTheme() { const m = S.set.theme === "auto" ? (matchMedia("(prefers-color-scheme:dark)").matches ? "dark" : "light") : S.set.theme; document.documentElement.dataset.theme = m; }
function applyLang() { const h = document.documentElement; h.lang = S.set.lang; h.dir = S.set.lang === "ar" ? "rtl" : "ltr"; $("#q").placeholder = t("search"); buildDock(); buildDrawer(); renderShown(); $("#dh h1").textContent = t("app"); $$("[data-i]").forEach(e => e.textContent = t(e.dataset.i)); }
function buildDock() {
  const d = $("#dock"); d.innerHTML = "";
  [["plus", "add", openAdd], ["area", "area", openArea], ["fetch", "fetch", openFetch, 1], ["table", "table", () => openTable()], ["tool", "tools", openTools]].forEach(([i, k, f, m]) => { const b = el(`<button class="${m ? "main" : ""}">${I(i)}<span>${t(k)}</span></button>`, d); b.onclick = f; });
}
function buildDrawer() {
  const g = $("#dgrid"); g.innerHTML = "";
  [["imp", "import", openImport], ["save", "saved", openSaved], ["report", "report", openReport], ["chart", "analysis", openAnalysis], ["tool", "tools", openTools], ["img", "aerial", openAerial],
  ["conv", "conv", openConv], ["pin", "dist", openDist], ["tag", "ann", openAnn], ["layers", "base", openBase], ["table", "table", () => openTable()], ["settings", "settings", openSettings]]
    .forEach(([i, k, f]) => { const b = el(`<button class="tile">${I(i)}<span>${t(k)}</span></button>`, g); b.onclick = f; });
  $("#sec-shown").textContent = t("shown");
}
/* ===== المعروضة ===== */
const sw = (on, fn) => { const s = el(`<label class="sw"><input type="checkbox" ${on ? "checked" : ""}><i></i></label>`); $("input", s).onchange = e => fn(e.target.checked); return s; };
function renderShown() {
  const c = $("#shown"); if (!c) return; c.innerHTML = "";
  const add = (dot, name, sub, on, fn, click) => { const r = el(`<div class="row"><i class="dot" style="background:${dot}"></i><div class="t"><b>${esc(name)}</b>${sub ? `<small>${esc(sub)}</small>` : ""}</div></div>`, c); if (click) $(".t", r).onclick = click; r.appendChild(sw(on, fn)); };
  add("#1e7bff", t("s_area"), "", A.show, v => { A.show = v; if (v) { const c = map.getCenter(); A.lat = c.lat; A.lon = c.lng; } drawArea(); });
  add("#868e96", t("s_g1"), "", !!S.on.g1, v => toggleAdmin(1, v)); add("#adb5bd", t("s_g2"), "", !!S.on.g2, v => toggleAdmin(2, v));
  S.ds.forEach(d => add(d.color, d.label, d.count + " " + t("rows"), d.visible, v => setDsVis(d, v), () => openTable(d.id)));
  if (S.ras.length) add("#7048e8", t("s_ras"), S.ras.length, S.on.ras !== false, v => { S.on.ras = v; S.ras.forEach(r => map.getLayer("r-" + r.id) && map.setLayoutProperty("r-" + r.id, "visibility", v && r.visible ? "visible" : "none")); });
  if (S.ann.length) add("#f59f00", t("s_ann"), S.ann.length, S.on.ann !== false, v => { S.on.ann = v; drawAnn(); });
  if (S.toolRid) add("#e8590c", t("s_tool"), "", S.on.tool !== false, v => { S.on.tool = v; ["tool-f", "tool-l", "tool-c"].forEach(l => map.setLayoutProperty(l, "visibility", v ? "visible" : "none")); });
}
async function toggleAdmin(lv, v) {
  S.on["g" + lv] = v; const id = "adm" + lv;
  if (v && !map.getSource(id)) { try { map.addSource(id, { type: "geojson", data: await api("/api/admin/geojson?level=" + lv) }); map.addLayer({ id: id + "-f", type: "fill", source: id, paint: { "fill-color": "#868e96", "fill-opacity": .04 } }, "area-f"); map.addLayer({ id: id + "-l", type: "line", source: id, paint: { "line-color": lv === 1 ? "#495057" : "#868e96", "line-width": lv === 1 ? 2.2 : 1.2, "line-dasharray": lv === 1 ? [1] : [3, 2] } }, "area-f"); } catch (e) { S.on["g" + lv] = false; renderShown(); return fail(e); } }
  [id + "-f", id + "-l"].forEach(l => map.getLayer(l) && map.setLayoutProperty(l, "visibility", v ? "visible" : "none"));
}
/* ===== عناصر الخريطة والصور ===== */
let ANNM = [];
async function loadAnn() { try { S.ann = await api("/api/annotations"); } catch (e) { S.ann = []; } drawAnn(); }
function drawAnn() {
  ANNM.forEach(m => m.remove()); ANNM = []; if (S.on.ann === false) return;
  S.ann.forEach(a => { const e = document.createElement("div"); if (a.kind === "image") e.innerHTML = `<img src="/api/annotations/${a.id}/file" width="${a.width}">`; else { e.className = "ann"; e.textContent = a.text; e.style.cssText = `font-size:${a.size}px;color:#${(a.color & 0xFFFFFF).toString(16).padStart(6, "0")}`; } ANNM.push(new maplibregl.Marker({ element: e }).setLngLat([a.lon, a.lat]).addTo(map)); });
}
async function loadRas() {
  try { S.ras = await api("/api/rasters"); } catch (e) { S.ras = []; }
  S.ras.forEach(r => { const id = "r-" + r.id, [w, s, e, n] = r.bounds; if (!map.getSource(id)) { map.addSource(id, { type: "image", url: `/api/rasters/${r.id}.png`, coordinates: [[w, n], [e, n], [e, s], [w, s]] }); map.addLayer({ id, type: "raster", source: id, paint: { "raster-opacity": r.opacity } }, firstOverlay()); } map.setLayoutProperty(id, "visibility", r.visible && S.on.ras !== false ? "visible" : "none"); map.setPaintProperty(id, "raster-opacity", r.opacity); });
  map.getStyle().layers.filter(l => l.id.startsWith("r-") && !S.ras.find(r => "r-" + r.id === l.id)).forEach(l => { map.removeLayer(l.id); map.removeSource(l.id); });
  renderShown();
}
/* ===== جلب البيانات ===== */
const F = { poi: new Set(), layers: new Set(), custom: "", unnamed: false, fill: true, fmt: "" };
function openFetch() {
  F.fmt = F.fmt || S.set.export_fmt || "xlsx";
  openSheet("fetch", t("fetch"), b => {
    const bb = areaBBox();
    b.innerHTML = `<div class="card"><div class="row"><div class="t"><b>${t(A.shape)}${A.shape === "circle" ? " — " + Math.round(A.r) + " m" : " — " + Math.round(A.w) + "×" + Math.round(A.h) + " m"}${A.deg ? " ↻" + Math.round(A.deg) + "°" : ""}</b><small>${bb[0].toFixed(4)}, ${bb[1].toFixed(4)} → ${bb[2].toFixed(4)}, ${bb[3].toFixed(4)}</small></div><button class="ib" id="f_a">${I("area")}</button></div></div>
    <div class="sec">${t("poi")}</div><div class="chips" id="f_p"></div><div class="sec">${t("layers")}</div><div class="chips" id="f_l"></div>
    ${fieldRow(t("custom"), "f_cu", F.custom)}
    <div class="card" style="margin-top:12px"><div class="row"><div class="t">${t("unnamed")}</div><span id="s1"></span></div><div class="row"><div class="t">${t("fill")}</div><span id="s2"></span></div><div class="row"><div class="t">${t("autosave")}</div><span id="s3"></span></div><div class="row"><div class="t">${t("autoexp")}</div><span id="s4"></span></div></div>
    <div id="f_fw"><label class="f">${t("fmt")}</label><select class="in" id="f_fmt">${S.boot.fmts.map(x => `<option ${x === F.fmt ? "selected" : ""}>${x}</option>`).join("")}</select></div>
    <div class="bar" id="f_bar" style="display:none;margin-top:12px"><i style="width:0"></i></div><div class="hint" id="f_st"></div>
    <div class="btns"><button class="btn blk" id="f_go">${I("fetch")}${t("start")}</button></div>`;
    const chips = (id, arr, set) => arr.forEach(x => { const c = el(`<span class="chip ${set.has(x.id) ? "on" : ""}">${esc(S.set.lang === "ar" ? x.ar : x.en)}</span>`, $(id, b)); c.onclick = () => { set.has(x.id) ? set.delete(x.id) : set.add(x.id); c.classList.toggle("on"); }; });
    chips("#f_p", S.boot.cats, F.poi); chips("#f_l", S.boot.layers, F.layers);
    $("#s1", b).appendChild(sw(F.unnamed, v => F.unnamed = v)); $("#s2", b).appendChild(sw(F.fill, v => F.fill = v)); $("#s3", b).appendChild(sw(S.set.autosave, v => setSet("autosave", v))); $("#s4", b).appendChild(sw(S.set.autoexport, v => { setSet("autoexport", v); $("#f_fw", b).style.display = v ? "" : "none"; }));
    $("#f_fw", b).style.display = S.set.autoexport ? "" : "none"; $("#f_a", b).onclick = openArea;
    $("#f_go", b).onclick = () => runFetch(b);
  });
}
async function runFetch(b) {
  F.custom = $("#f_cu", b).value; F.fmt = $("#f_fmt", b).value;
  if (!F.poi.size && !F.layers.size && !F.custom.trim()) return toast(t("poi") + " / " + t("layers"));
  const body = { bbox: areaBBox(), shape: A.shape === "circle" ? "circle" : (A.deg % 360 ? "rotated" : "rect"), lat: A.lat, lon: A.lon, w_m: A.w, h_m: A.h, deg: A.deg, radius_m: A.r, poi: [...F.poi], layers: [...F.layers], custom: F.custom, unnamed: F.unnamed, fill_admin: F.fill, format: F.fmt, autosave: S.set.autosave !== false, export: !!S.set.autoexport };
  const go = $("#f_go", b); go.disabled = true; const bar = $("#f_bar", b), st = $("#f_st", b); bar.style.display = "";
  try {
    const { id } = await post("/api/download/start", body); let s;
    for (; ;) { s = await api("/api/download/status/" + id); st.textContent = t("pstep") + ": " + s.step + (s.total ? ` ${s.done}/${s.total}` : ""); $("i", bar).style.width = (s.total ? Math.round(s.done / s.total * 100) : 15) + "%"; if (s.state !== "running") break; await new Promise(r => setTimeout(r, 500)); }
    if (s.state === "error") throw new Error(s.error);
    st.textContent = t("fetched") + ": " + s.count; $("i", bar).style.width = "100%";
    if (s.datasets && s.datasets.length) await refreshDs(s.datasets); else if (!S.set.autosave) { const g = await api("/api/download/geojson/" + id); map.getSource("tool").setData(g); }
    if (s.name) await getFile("/api/download/result/" + id, {}, s.name);
    map.fitBounds([[areaBBox()[1], areaBBox()[0]], [areaBBox()[3], areaBBox()[2]]], { padding: 40, duration: 600 });
    if (s.datasets && s.datasets.length) { const big = [...s.datasets].sort((a, b) => (S.ds.find(d => d.id === b) || {}).count - (S.ds.find(d => d.id === a) || {}).count)[0]; openTable(big); }
  } catch (e) { fail(e); } finally { go.disabled = false; }
}
/* ===== جدول البيانات (Attribute table) ===== */
const TB = { id: "", q: "", sort: "", dir: "asc", rows: [], total: 0, sel: new Set() };
async function openTable(id) {
  if (!S.ds.length) await refreshDs();
  const real = S.ds.filter(d => d.kind !== "reference"); if (!real.length) return toast(t("nol"));
  if (id && id !== TB.id) { TB.id = id; TB.sel = new Set(); TB.q = ""; TB.sort = ""; }
  if (!real.find(d => d.id === TB.id)) { TB.id = real[0].id; TB.sel = new Set(); }
  openSheet("table", t("table"), b => {
    b.innerHTML = `<div class="tools"><select class="in" id="t_ds" style="flex:1;min-width:150px">${real.map(d => `<option value="${d.id}" ${d.id === TB.id ? "selected" : ""}>${esc(d.label)} (${d.count})</option>`).join("")}</select></div>
    <div class="tools"><input class="in" id="t_q" placeholder="${t("search2")}" value="${esc(TB.q)}" style="flex:1;min-width:120px"><select class="in" id="t_fmt" style="width:auto">${S.boot.fmts.map(x => `<option ${x === (S.set.export_fmt || "xlsx") ? "selected" : ""}>${x}</option>`).join("")}</select></div>
    <div class="tools"><button class="btn sec2" id="t_ex">${I("fetch")}${t("export")}</button><button class="ib" id="t_op" title="${t("open")}">${I("open")}</button><button class="ib" id="t_sh" title="${t("share")}">${I("share")}</button><button class="ib er" id="t_dl" title="${t("delsel")}">${I("trash")}</button><span class="hint" id="t_n" style="flex:1;text-align:end"></span></div>
    <div class="tw"><table class="t"><thead></thead><tbody></tbody></table></div><div class="btns"><button class="btn sec2 blk" id="t_more" style="display:none">${t("more")}</button></div>`;
    const head = $("thead", b); head.innerHTML = `<tr><th><input type="checkbox" id="t_all"></th><th></th>${FIELDS.map(k => `<th data-k="${k}">${t(k)}${TB.sort === k ? (TB.dir === "asc" ? " ▲" : " ▼") : ""}</th>`).join("")}</tr>`;
    $$("th[data-k]", head).forEach(h => h.onclick = () => { TB.dir = TB.sort === h.dataset.k && TB.dir === "asc" ? "desc" : "asc"; TB.sort = h.dataset.k; openTable(); });
    $("#t_ds", b).onchange = e => { TB.id = e.target.value; TB.sel = new Set(); TB.q = ""; openTable(); };
    let tm; $("#t_q", b).oninput = e => { clearTimeout(tm); tm = setTimeout(() => { TB.q = e.target.value; loadRows(b, true); }, 300); };
    const ex = m => exportDs({ layers: [TB.id], ids: [...TB.sel], format: $("#t_fmt", b).value, name: (S.ds.find(d => d.id === TB.id) || {}).label }, m);
    $("#t_ex", b).onclick = () => ex(); $("#t_op", b).onclick = () => ex("open"); $("#t_sh", b).onclick = () => ex("share");
    $("#t_dl", b).onclick = async () => { if (!TB.sel.size) return toast(t("sel")); if (!confirm(t("confirm"))) return; await post("/api/features/delete", { ids: [...TB.sel] }).catch(fail); TB.sel = new Set(); await refreshDs(dsIds()); openTable(); };
    $("#t_all", b).onchange = e => { TB.rows.forEach(r => e.target.checked ? TB.sel.add(r.id) : TB.sel.delete(r.id)); loadRows(b, false, true); };
    $("#t_more", b).onclick = () => loadRows(b);
    loadRows(b, true);
  }, { full: true });
}
async function loadRows(b, reset, norefetch) {
  if (reset) TB.rows = [];
  if (!norefetch) { const q = new URLSearchParams({ offset: TB.rows.length, limit: 100, q: TB.q, sort: TB.sort, dir: TB.dir }); try { const r = await api(`/api/datasets/${TB.id}/rows?` + q); TB.total = r.total; TB.rows = TB.rows.concat(r.rows); } catch (e) { return fail(e); } }
  const tb = $("tbody", b); tb.innerHTML = "";
  TB.rows.forEach(r => {
    const tr = el(`<tr class="${TB.sel.has(r.id) ? "sel" : ""}"><td><input type="checkbox" ${TB.sel.has(r.id) ? "checked" : ""}></td><td class="act"><button class="ib sm" data-a="z">${I("zoom")}</button><button class="ib sm" data-a="e">${I("edit")}</button><button class="ib sm er" data-a="d">${I("trash")}</button></td>${FIELDS.map(k => `<td class="${k === "x" || k === "y" ? "num" : ""}">${esc(r[k])}</td>`).join("")}</tr>`.replace("<tr", "<table><tr").replace("</tr>", "</tr></table>")).querySelector("tr");
    tb.appendChild(tr);
    $("input", tr).onchange = e => { e.target.checked ? TB.sel.add(r.id) : TB.sel.delete(r.id); tr.classList.toggle("sel", e.target.checked); $("#t_n", b).textContent = status(); };
    $("[data-a=z]", tr).onclick = () => { closeSheet(); map.flyTo({ center: [r.lon, r.lat], zoom: Math.max(map.getZoom(), 17) }); marker("z", r.lon, r.lat); };
    $("[data-a=e]", tr).onclick = () => editRow(r, async () => { await refreshDs(dsIds()); const o = TB.rows.length; TB.rows = []; loadRows(b, true); });
    $("[data-a=d]", tr).onclick = async () => { if (!confirm(t("confirm"))) return; await post("/api/features/delete", { ids: [r.id] }).catch(fail); TB.sel.delete(r.id); await refreshDs(dsIds()); openTable(); };
  });
  const status = () => `${TB.total} ${t("rows")}${TB.sel.size ? " · " + TB.sel.size + " " + t("sel") : ""}`; $("#t_n", b).textContent = status(); $("#t_more", b).style.display = TB.rows.length < TB.total ? "" : "none";
}
/* ===== المعالم المحفوظة ===== */
function openSaved() {
  const draw = b => {
    b.innerHTML = ""; if (!S.ds.length) { b.innerHTML = `<div class="hint">${t("nol")}</div>`; return; }
    const c = el(`<div class="card"></div>`, b);
    S.ds.forEach(d => {
      const r = el(`<div style="padding:10px 12px;border-bottom:1px solid var(--br)"><div class="row" style="padding:0;border:0"><i class="dot" style="background:${d.color}"></i><div class="t"><b>${esc(d.label)}</b><small>${d.count} ${t("rows")}${d.source ? " · " + esc(d.source) : ""}</small></div></div><div class="btns" style="margin:8px 0 0"></div></div>`, c); const bt = $(".btns", r);
      $(".row", r).appendChild(sw(d.visible, v => setDsVis(d, v)));
      [["table", () => openTable(d.id)], ["zoom", async () => { const g = await api(`/api/datasets/${d.id}/geojson`); const pts = JSON.stringify(g).match(/-?\d+\.\d+,-?\d+\.\d+/g) || []; const xs = pts.map(p => p.split(",").map(Number)).filter(p => p[0] > 20 && p[0] < 70); if (xs.length) { const bb = new maplibregl.LngLatBounds(); xs.forEach(p => bb.extend(p)); closeSheet(); map.fitBounds(bb, { padding: 60, maxZoom: 17 }); } }], ["edit", () => { const m = prompt(t("rename"), d.label); if (m) post("/api/datasets/" + d.id, { label: m }).then(() => refreshDs()); }],
      ["open", () => exportDs({ layers: [d.id], format: S.set.export_fmt || "xlsx", name: d.label }, "open")], ["share", () => exportDs({ layers: [d.id], format: S.set.export_fmt || "xlsx", name: d.label }, "share")], ["trash", async () => { if (confirm(t("confirm"))) { await del("/api/datasets/" + d.id).catch(fail); await refreshDs(); } }, "er"]]
        .forEach(([i, f, cl]) => { const x = el(`<button class="ib ${cl || ""}">${I(i)}</button>`, bt); x.style.flex = "1"; x.style.borderRadius = "12px"; x.onclick = f; });
    });
  };
  openSheet("saved", t("saved"), b => { draw(b); S.onDs = () => { if (SHEET === "saved") draw($("#sh-b")); }; }, { full: true });
}
/* ===== المنطقة ===== */
function syncAreaUI() { const b = $("#sh-b"); if (SHEET !== "area" || !b) return; const set = (id, v) => { const e = $("#" + id, b); if (e && document.activeElement !== e) e.value = Math.round(v); }; ["w", "h", "r", "deg"].forEach(k => { set("ar_" + k, A[k]); set("an_" + k, A[k]); }); const f = $("#ar_f", b); if (f) f.checked = A.follow; }
function openArea() {
  openSheet("area", t("area"), b => {
    b.innerHTML = `<div class="seg" id="ar_s">${["rect", "circle"].map(k => `<button data-k="${k}" class="${A.shape === k ? "on" : ""}">${t(k)}</button>`).join("")}</div>
    <div id="ar_rect"><label class="f">${t("w")}</label><div class="two"><input type="range" id="ar_w" min="50" max="20000" step="10"><input class="in" id="an_w" type="number"></div>
    <label class="f">${t("h")}</label><div class="two"><input type="range" id="ar_h" min="50" max="20000" step="10"><input class="in" id="an_h" type="number"></div>
    <label class="f">${t("deg")}</label><div class="two"><input type="range" id="ar_deg" min="0" max="359" step="1"><input class="in" id="an_deg" type="number"></div></div>
    <div id="ar_circ"><label class="f">${t("r")}</label><div class="two"><input type="range" id="ar_r" min="30" max="10000" step="10"><input class="in" id="an_r" type="number"></div></div>
    <div class="card" style="margin-top:12px"><div class="row"><div class="t">${t("follow")}</div><span id="ar_fw"></span></div><div class="row"><div class="t">${t("s_area")}</div><span id="ar_sw"></span></div></div>
    <div class="btns"><button class="btn sec2" id="ar_here">${I("locate")}${t("here")}</button><button class="btn sec2" id="ar_v">${I("area")}${t("fitv")}</button><button class="btn sec2" id="ar_fit">${I("zoom")}${t("fit")}</button></div>`;
    const lim = () => { $("#ar_rect", b).style.display = A.shape === "circle" ? "none" : ""; $("#ar_circ", b).style.display = A.shape === "circle" ? "" : "none"; };
    lim(); syncAreaUI();
    $$("#ar_s button", b).forEach(x => x.onclick = () => { A.shape = x.dataset.k; $$("#ar_s button", b).forEach(y => y.classList.toggle("on", y === x)); lim(); drawArea(); setSet("shape", A.shape); });
    ["w", "h", "r", "deg"].forEach(k => { const s = $("#ar_" + k, b), n = $("#an_" + k, b); s.oninput = () => { A[k] = +s.value; drawArea(true); n.value = Math.round(A[k]); }; n.onchange = () => { A[k] = Math.max(k === "deg" ? 0 : 20, +n.value); if (k === "deg") A.deg %= 360; drawArea(); }; });
    $("#ar_fw", b).appendChild(el(`<label class="sw"><input type="checkbox" id="ar_f"><i></i></label>`)); $("#ar_f", b).checked = A.follow; $("#ar_f", b).onchange = e => { A.follow = e.target.checked; if (A.follow) { const c = map.getCenter(); A.lat = c.lat; A.lon = c.lng; drawArea(); } };
    $("#ar_sw", b).appendChild(sw(A.show, v => { A.show = v; if (v) { const c = map.getCenter(); A.lat = c.lat; A.lon = c.lng; } drawArea(); renderShown(); }));
    $("#ar_here", b).onclick = () => { const c = map.getCenter(); A.lat = c.lat; A.lon = c.lng; drawArea(); };
    $("#ar_v", b).onclick = () => { sizeFromView(); drawArea(); };
    $("#ar_fit", b).onclick = () => { const bb = areaBBox(); closeSheet(); map.fitBounds([[bb[1], bb[0]], [bb[3], bb[2]]], { padding: 50 }); };
  });
}
/* ===== الأدوات ===== */
let TOOLS = [], TSEL = null;
async function openTools() {
  if (!TOOLS.length) try { TOOLS = await api("/api/tools"); } catch (e) { return fail(e); }
  openSheet("tools", t("tools"), b => {
    b.innerHTML = `<div class="chips" id="tl"></div><div id="tp"></div><div class="btns"><button class="btn blk" id="tr">${I("tool")}${t("run")}</button></div><div id="tres"></div>`;
    TOOLS.forEach(x => { const c = el(`<span class="chip ${TSEL === x.id ? "on" : ""}">${esc(x.ar)}</span>`, $("#tl", b)); c.onclick = () => { TSEL = x.id; openTools(); }; });
    const tool = TOOLS.find(x => x.id === TSEL); $("#tr", b).style.display = tool ? "" : "none";
    if (tool) $("#tp", b).innerHTML = tool.params.map(p => fieldRow(p[1], "tp_" + p[0], p[2])).join("");
    $("#tr", b).onclick = async () => {
      const params = {}; tool.params.forEach(p => params[p[0]] = $("#tp_" + p[0], b).value); const c = map.getCenter();
      try { const r = await post("/api/tools/run", { tool: tool.id, params, lat: c.lat, lon: c.lng }); S.toolRid = r.id; S.on.tool = true; map.getSource("tool").setData(r.geojson); ["tool-f", "tool-l", "tool-c"].forEach(l => map.setLayoutProperty(l, "visibility", "visible")); renderShown();
        $("#tres", b).innerHTML = `<div class="sec">${t("result")}: ${r.count}</div><div class="btns"><select class="in" id="te_f" style="flex:1">${S.boot.fmts.map(x => `<option>${x}</option>`).join("")}</select><button class="btn sec2" id="te_e">${I("fetch")}${t("exres")}</button><button class="btn sec2" id="te_c">${I("x")}${t("clear")}</button></div>`;
        $("#te_e", b).onclick = () => { const f = $("#te_f", b).value; getFile(`/api/tools/${r.id}/export?format=${f}`, {}, "result" + (EXT[f] || "")).catch(fail); };
        $("#te_c", b).onclick = () => { map.getSource("tool").setData({ type: "FeatureCollection", features: [] }); S.toolRid = null; renderShown(); $("#tres", b).innerHTML = ""; };
      } catch (e) { fail(e); }
    };
  });
}
/* ===== التقرير ===== */
const R = { title: "", paper: "A4", portrait: false, by_sector: true, legend: true, table: true, grid: 0, dpi: 150, fmt: "pdf" };
async function openReport() {
  let RT = {}; try { RT = await api("/api/report-templates"); } catch (e) { }
  openSheet("report", t("report"), b => {
    b.innerHTML = `${fieldRow(t("title"), "r_t", R.title)}<div class="two"><div><label class="f">${t("paper")}</label><select class="in" id="r_p">${["A4", "A3", "A5"].map(x => `<option ${x === R.paper ? "selected" : ""}>${x}</option>`).join("")}</select></div><div><label class="f">${t("dpi")}</label><select class="in" id="r_d">${[100, 150, 200, 300].map(x => `<option ${x === R.dpi ? "selected" : ""}>${x}</option>`).join("")}</select></div></div>
    <div class="chips" style="margin:12px 0" id="r_c"></div><div class="two"><div><label class="f">${t("grid")}</label><select class="in" id="r_g">${[0, 2, 3, 4, 5].map(x => `<option ${x === R.grid ? "selected" : ""}>${x}</option>`).join("")}</select></div><div><label class="f">${t("fmt")}</label><select class="in" id="r_f">${["pdf", "png"].map(x => `<option ${x === R.fmt ? "selected" : ""}>${x}</option>`).join("")}</select></div></div>
    <div class="sec">${t("rtpl")}</div><div class="chips" id="r_tp"></div>
    <div class="btns"><button class="btn sec2" id="r_pv">${I("eye")}${t("preview")}</button><button class="btn" id="r_sv">${I("fetch")}${t("repsave")}</button><button class="btn sec2" id="r_st">${I("save")}${t("rtsave")}</button></div><div id="r_im"></div>`;
    [["portrait", "port"], ["by_sector", "sectorc"], ["legend", "legend"], ["table", "tbl"]].forEach(([k, l]) => { const c = el(`<span class="chip ${R[k] ? "on" : ""}">${t(l)}</span>`, $("#r_c", b)); c.onclick = () => { R[k] = !R[k]; c.classList.toggle("on"); }; });
    const rd = () => { R.title = $("#r_t", b).value; R.paper = $("#r_p", b).value; R.dpi = +$("#r_d", b).value; R.grid = +$("#r_g", b).value; R.fmt = $("#r_f", b).value; };
    const qs = f => new URLSearchParams({ format: f, title: R.title, paper: R.paper, portrait: R.portrait ? 1 : 0, by_sector: R.by_sector ? 1 : 0, legend: R.legend ? 1 : 0, table: R.table ? 1 : 0, grid: R.grid, dpi: f === "png" ? Math.min(R.dpi, 110) : R.dpi }).toString();
    $("#r_pv", b).onclick = async () => { rd(); $("#r_im", b).innerHTML = `<div class="hint">${t("wait")}</div>`; try { const r = await fetch("/api/landmarks/report?inline=1&" + qs("png")); if (!r.ok) throw new Error((await r.json()).error); $("#r_im", b).innerHTML = `<img style="width:100%;border-radius:12px;margin-top:10px;border:1px solid var(--br)" src="${URL.createObjectURL(await r.blob())}">`; } catch (e) { $("#r_im", b).innerHTML = ""; fail(e); } };
    $("#r_sv", b).onclick = () => { rd(); getFile("/api/landmarks/report?" + qs(R.fmt), {}, "report." + R.fmt).catch(fail); };
    $("#r_st", b).onclick = async () => { rd(); const n = prompt(t("rtsave")); if (n) { await post("/api/report-templates", { name: n, title: R.title, paper: R.paper, fmt: R.fmt, portrait: R.portrait, grid: R.grid, legend: R.legend, table: R.table, by_sector: R.by_sector, dpi: R.dpi }); openReport(); } };
    Object.keys(RT).forEach(n => { const c = el(`<span class="chip">${esc(n)}<i style="opacity:.5">✕</i></span>`, $("#r_tp", b)); c.onclick = () => { const o = RT[n]; Object.keys(o).forEach(k => { if (o[k] != null) R[k === "fmt" ? "fmt" : k] = o[k]; }); openReport(); }; c.lastChild.onclick = async e => { e.stopPropagation(); await del("/api/report-templates/" + encodeURIComponent(n)); openReport(); }; });
  }, { full: true });
}
async function openAnalysis() {
  let j; try { j = await api("/api/landmarks/analysis"); } catch (e) { return fail(e); }
  openSheet("analysis", t("analysis"), b => {
    const bars = (title, o) => { const mx = Math.max(1, ...Object.values(o)); return `<div class="sec">${title}</div><div class="card">${Object.entries(o).slice(0, 15).map(([k, v]) => `<div class="row"><div class="t" style="flex:.8"><small>${esc(k)}</small></div><div class="bar" style="flex:1"><i style="width:${v / mx * 100}%"></i></div><b>${v}</b></div>`).join("")}</div>`; };
    b.innerHTML = `<div class="card"><div class="row"><div class="t"><b>${j.total}</b><small>${t("poiset")}</small></div></div>${j.centre ? `<div class="row"><div class="t"><small>${esc(j.centre.utm)}</small></div></div>` : ""}${j.nn ? `<div class="row"><div class="t"><small>NN ${j.nn.mean_m} m · R=${j.nn.ratio} · ${esc(j.nn.pattern)}</small></div></div>` : ""}${j.clusters ? `<div class="row"><div class="t"><small>DBSCAN ${j.clusters.eps_m} m: ${j.clusters.count} (${j.clusters.sizes.join(", ")})</small></div></div>` : ""}</div>${bars(t("Gategory"), j.by_sector)}${bars(t("gathaa"), j.by_gathaa)}${bars(t("mohafadha"), j.by_mohafadha)}`;
  }, { full: true });
}
/* ===== الاستيراد / المحوّل ===== */
function openImport() {
  openSheet("import", t("import"), b => {
    b.innerHTML = `<input class="in" type="file" id="i_f"><label class="f">${t("crs")}</label><input class="in" id="i_c" list="crsl" placeholder="EPSG:32638"><datalist id="crsl"></datalist>
    <div class="card" style="margin-top:12px"><div class="row"><div class="t">${t("skipdup")}</div><span id="i_s"></span></div></div><div class="hint">KML · KMZ · GeoJSON · GPX · SHP(zip) · CSV · XLSX</div>
    <div class="btns"><button class="btn blk" id="i_go">${I("imp")}${t("import")}</button></div>`;
    let sk = false; $("#i_s", b).appendChild(sw(false, v => sk = v)); crsHook($("#i_c", b), $("#crsl", b));
    $("#i_go", b).onclick = async () => { const f = $("#i_f", b).files[0]; if (!f) return toast(t("pick")); const fd = new FormData(); fd.append("file", f); fd.append("skip_dup", sk ? "1" : "0"); if ($("#i_c", b).value) fd.append("crs", $("#i_c", b).value.split(/\s/)[0]); toast(t("wait")); try { const r = await api("/api/landmarks/import", { method: "POST", body: fd }); toast(t("impdone") + " " + r.added); await refreshDs(dsIds()); const l = S.ds.find(d => d.label === "المعالم"); l && openTable(l.id); } catch (e) { fail(e); } };
  });
}
function crsHook(inp, dl) { let tm; inp.oninput = () => { clearTimeout(tm); tm = setTimeout(async () => { if (inp.value.length < 2) return; try { const r = await api("/api/crs?q=" + encodeURIComponent(inp.value)); dl.innerHTML = r.map(x => `<option value="${esc(x.code)} ${esc(x.name)}">`).join(""); } catch (e) { } }, 300); }; }
function openConv() {
  openSheet("conv", t("conv"), b => {
    b.innerHTML = `${fieldRow(t("conv1"), "c_t", "")}<div class="two"><div><label class="f">${t("srcc")}</label><input class="in" id="c_s" list="cl1"></div><div><label class="f">${t("tgtc")}</label><input class="in" id="c_g" list="cl1"></div></div><datalist id="cl1"></datalist>
    <div class="btns"><button class="btn blk" id="c_go">${I("conv")}${t("conv2")}</button></div><div id="c_r"></div>
    <div class="sec">${t("batch")}</div><input class="in" type="file" id="c_bf"><div class="btns"><button class="btn sec2 blk" id="c_bg">${I("conv")}${t("conv2")}</button></div>
    <div class="sec">${t("fconv")}</div><input class="in" type="file" id="c_ff"><select class="in" id="c_fo" style="margin-top:8px">${S.boot.fmts.map(x => `<option>${x}</option>`).join("")}</select><div class="btns"><button class="btn sec2 blk" id="c_fg">${I("conv")}${t("conv2")}</button></div>`;
    crsHook($("#c_s", b), $("#cl1", b)); crsHook($("#c_g", b), $("#cl1", b)); const cc = v => (v || "").split(/\s/)[0];
    $("#c_go", b).onclick = async () => { try { const r = await api("/api/convert-coords?" + new URLSearchParams({ text: $("#c_t", b).value, src: cc($("#c_s", b).value), target: cc($("#c_g", b).value) })); $("#c_r", b).innerHTML = `<div class="card" style="margin-top:12px">${[["DD", r.dd], ["DMS", r.dms], ["DDM", r.ddm], ["UTM", r.utm], ["MGRS", r.mgrs], ["→", r.target]].filter(x => x[1]).map(([k, v]) => `<div class="row"><div class="t"><small>${k}</small><b style="direction:ltr;text-align:start">${esc(v)}</b></div><button class="ib sm" data-v="${esc(v)}">${I("share")}</button></div>`).join("")}</div>${(r.warnings || []).map(w => `<div class="hint">⚠ ${esc(w)}</div>`).join("")}<div class="btns"><button class="btn sec2" id="c_m">${I("pin")}${t("zoomto")}</button><button class="btn sec2" id="c_a">${I("plus")}${t("addhere")}</button></div>`;
      $$("[data-v]", b).forEach(x => x.onclick = () => { navigator.clipboard && navigator.clipboard.writeText(x.dataset.v).catch(() => { }); toast(x.dataset.v); });
      $("#c_m", b).onclick = () => { closeSheet(); map.flyTo({ center: [r.lon, r.lat], zoom: 16 }); marker("sr", r.lon, r.lat); }; $("#c_a", b).onclick = () => { ADD.at = [r.lat, r.lon]; openAdd(); }; } catch (e) { fail(e); } };
    $("#c_bg", b).onclick = () => { const f = $("#c_bf", b).files[0]; if (!f) return toast(t("pick")); const fd = new FormData(); fd.append("file", f); if ($("#c_s", b).value) fd.append("src", cc($("#c_s", b).value)); if ($("#c_g", b).value) fd.append("target", cc($("#c_g", b).value)); getFile("/api/batch-coords", { method: "POST", body: fd }, "converted.csv").catch(fail); };
    $("#c_fg", b).onclick = () => { const f = $("#c_ff", b).files[0]; if (!f) return toast(t("pick")); const fd = new FormData(); fd.append("file", f); fd.append("format", $("#c_fo", b).value); getFile("/api/convert", { method: "POST", body: fd }, "converted" + EXT[$("#c_fo", b).value]).catch(fail); };
  }, { full: true });
}
/* ===== صور جوية ===== */
async function openAerial() {
  await loadRas();
  openSheet("aerial", t("aerial"), b => {
    b.innerHTML = `<input class="in" type="file" id="ae_f" accept=".tif,.tiff,.png,.jpg,.jpeg,.webp"><label class="f">${t("world")}</label><input class="in" type="file" id="ae_w"><label class="f">${t("bounds")}</label><input class="in" id="ae_b" dir="ltr">
    <div class="btns"><button class="btn blk" id="ae_go">${I("img")}${t("addraster")}</button></div><div class="card" id="ae_l"></div>`;
    S.ras.forEach(r => { const row = el(`<div class="row"><div class="t"><b>${esc(r.name)}</b><input type="range" min="0.1" max="1" step="0.05" value="${r.opacity}"></div><button class="ib sm" data-z>${I("zoom")}</button><button class="ib sm er" data-d>${I("trash")}</button></div>`, $("#ae_l", b)); row.insertBefore(sw(r.visible, async v => { await post("/api/rasters/" + r.id, { visible: v }); loadRas(); }), $("[data-z]", row));
      $("input[type=range]", row).onchange = async e => { await post("/api/rasters/" + r.id, { opacity: +e.target.value }); loadRas(); }; $("[data-z]", row).onclick = () => { closeSheet(); map.fitBounds([[r.bounds[0], r.bounds[1]], [r.bounds[2], r.bounds[3]]], { padding: 40 }); }; $("[data-d]", row).onclick = async () => { await del("/api/rasters/" + r.id); await loadRas(); openAerial(); }; });
    $("#ae_go", b).onclick = async () => { const f = $("#ae_f", b).files[0]; if (!f) return toast(t("pick")); const fd = new FormData(); fd.append("file", f); const w = $("#ae_w", b).files[0]; if (w) fd.append("world", w); if ($("#ae_b", b).value) fd.append("bounds", $("#ae_b", b).value); toast(t("wait")); try { const r = await api("/api/rasters", { method: "POST", body: fd }); await loadRas(); map.fitBounds([[r.bounds[0], r.bounds[1]], [r.bounds[2], r.bounds[3]]], { padding: 40 }); closeSheet(); toast(t("done") + (r.note ? " — " + r.note : "")); } catch (e) { fail(e); } };
  }, { full: true });
}
/* ===== الأقضية ===== */
function openDist() {
  openSheet("dist", t("dist"), b => {
    b.innerHTML = `${fieldRow(t("dname"), "d_q", "")}<div class="btns"><button class="btn" id="d_f">${I("pin")}${t("dfetch")}</button><button class="btn sec2" id="d_b">${I("cloud")}${t("dbulk")}</button></div><div class="bar" id="d_bar" style="display:none"><i style="width:0"></i></div><div class="hint" id="d_s"></div>
    <div class="sec">${t("dexp")}</div><div class="two"><select class="in" id="d_l"><option value="1">${t("gov")}</option><option value="2" selected>${t("dis")}</option></select><select class="in" id="d_fm">${S.boot.fmts.map(x => `<option>${x}</option>`).join("")}</select></div><div class="btns"><button class="btn sec2 blk" id="d_e">${I("fetch")}${t("export")}</button></div>`;
    $("#d_f", b).onclick = async () => { try { const r = await post("/api/admin/fetch", { query: $("#d_q", b).value }); toast((r.added ? t("added") : t("done")) + ": " + r.name); S.on.g2 = false; if (map.getSource("adm2")) { map.getSource("adm2").setData(await api("/api/admin/geojson?level=2")); } } catch (e) { fail(e); } };
    const poll = async () => { try { const j = await api("/api/admin/status"); $("#d_bar", b).style.display = ""; $("#d_bar i", b).style.width = (j.total ? j.done / j.total * 100 : 0) + "%"; $("#d_s", b).textContent = `${j.done}/${j.total} · ${j.total_known}`; if (j.running && SHEET === "dist") setTimeout(poll, 1500); } catch (e) { } };
    $("#d_b", b).onclick = async () => { await post("/api/admin/bulk", {}).catch(fail); poll(); }; poll();
    $("#d_e", b).onclick = () => getFile(`/api/admin/export?level=${$("#d_l", b).value}&format=${$("#d_fm", b).value}`, {}, "admin").catch(fail);
  });
}
/* ===== عناصر الخريطة ===== */
function openAnn() {
  openSheet("ann", t("ann"), b => {
    b.innerHTML = `${fieldRow(t("txt"), "n_t", "")}<div class="two"><div><label class="f">${t("size")}</label><input class="in" type="number" id="n_s" value="16"></div><div><label class="f">${t("color")}</label><input class="in" type="color" id="n_c" value="#000000" style="padding:2px;height:44px"></div></div>
    <div class="btns"><button class="btn" id="n_a">${I("tag")}${t("addtext")}</button></div><div class="sec">${t("addimg")}</div><input class="in" type="file" id="n_f" accept="image/*"><label class="f">${t("width")}</label><input class="in" type="number" id="n_w" value="96"><div class="btns"><button class="btn sec2 blk" id="n_i">${I("img")}${t("addimg")}</button></div><div class="card" id="n_l"></div>`;
    const list = () => { const l = $("#n_l", b); l.innerHTML = ""; S.ann.forEach(a => { const r = el(`<div class="row"><div class="t"><b>${esc(a.kind === "image" ? "🖼" : a.text)}</b></div><button class="ib sm" data-z>${I("zoom")}</button><button class="ib sm er" data-d>${I("trash")}</button></div>`, l); $("[data-z]", r).onclick = () => { closeSheet(); map.flyTo({ center: [a.lon, a.lat] }); }; $("[data-d]", r).onclick = async () => { await del("/api/annotations/" + a.id); await loadAnn(); list(); renderShown(); }; }); }; list();
    $("#n_a", b).onclick = async () => { const c = map.getCenter(); if (!$("#n_t", b).value) return; try { await post("/api/annotations", { lat: c.lat, lon: c.lng, text: $("#n_t", b).value, size: +$("#n_s", b).value, color: $("#n_c", b).value }); await loadAnn(); list(); renderShown(); } catch (e) { fail(e); } };
    $("#n_i", b).onclick = async () => { const f = $("#n_f", b).files[0]; if (!f) return toast(t("pick")); const c = map.getCenter(), fd = new FormData(); fd.append("file", f); fd.append("lat", c.lat); fd.append("lon", c.lng); fd.append("width", $("#n_w", b).value); try { await api("/api/annotations", { method: "POST", body: fd }); await loadAnn(); list(); renderShown(); } catch (e) { fail(e); } };
  }, { full: true });
}
/* ===== الخرائط والإعدادات ===== */
function openBase() {
  openSheet("base", t("base"), b => {
    b.innerHTML = `<div class="grid" id="bg"></div><div class="hint">${t("tip_g")}</div>${fieldRow(t("curl"), "b_u", S.set.custom_url || "", 'dir="ltr" placeholder="https://…/{z}/{x}/{y}.png"')}`;
    ["osm", "sat", "hybrid", "roads", "custom"].forEach(k => { const x = el(`<button class="tile" style="${S.base === k ? "border-color:var(--pr);border-width:2px" : ""}">${I("layers")}<span>${t(k === "cust" ? "cust" : k === "custom" ? "cust" : k)}</span></button>`, $("#bg", b)); x.onclick = async () => { if (k === "custom") await setSet("custom_url", $("#b_u", b).value.trim()); setBase(k); setSet("base", k); openBase(); }; });
  });
}
function openSettings() {
  openSheet("set", t("settings"), async b => {
    const seg = (id, opts, cur) => `<div class="seg" id="${id}">${opts.map(([v, l]) => `<button data-v="${v}" class="${cur === v ? "on" : ""}">${l}</button>`).join("")}</div>`;
    b.innerHTML = `<label class="f">${t("theme")}</label>${seg("st_t", [["auto", t("auto")], ["light", t("light")], ["dark", t("dark")]], S.set.theme)}<label class="f">${t("lang")}</label>${seg("st_l", [["ar", "العربية"], ["en", "English"]], S.set.lang)}
    <label class="f">${t("ctype")}</label>${seg("st_c", ["DD", "DMS", "DDM", "UTM", "MGRS"].map(x => [x, x]), S.set.ctype)}${fieldRow(t("folder"), "st_f", S.set.folder)}
    <label class="f">${t("fmt")}</label><select class="in" id="st_x">${S.boot.fmts.map(x => `<option ${x === S.set.export_fmt ? "selected" : ""}>${x}</option>`).join("")}</select>
    <label class="f">${t("basem")}</label>${seg("st_b", ["osm", "sat", "hybrid", "roads"].map(x => [x, t(x)]), S.set.base)}
    <div class="card" style="margin-top:12px"><div class="row"><div class="t">${t("autosave")}</div><span id="so1"></span></div><div class="row"><div class="t">${t("autoexp")}</div><span id="so2"></span></div><div class="row"><div class="t">${t("scale")}</div><span id="so3"></span></div><div class="row"><div class="t">${t("tilt")}</div><span id="so4"></span></div></div>
    <div class="row card" style="margin-top:12px"><div class="t"><b>${t("cache")}</b><small id="st_cs">…</small></div><button class="ib er" id="st_cc">${I("trash")}</button></div>`;
    const sg = (id, fn) => $$("#" + id + " button", b).forEach(x => x.onclick = () => { $$("#" + id + " button", b).forEach(y => y.classList.toggle("on", y === x)); fn(x.dataset.v); });
    sg("st_t", async v => { await setSet("theme", v); applyTheme(); }); sg("st_l", async v => { await setSet("lang", v); applyLang(); openSettings(); }); sg("st_c", async v => { await setSet("ctype", v); infoSoon(); }); sg("st_b", async v => { await setSet("base", v); setBase(v); });
    $("#st_f", b).onchange = e => setSet("folder", e.target.value.trim() || "POIExporter"); $("#st_x", b).onchange = e => setSet("export_fmt", e.target.value);
    $("#so1", b).appendChild(sw(S.set.autosave, v => setSet("autosave", v))); $("#so2", b).appendChild(sw(S.set.autoexport, v => setSet("autoexport", v))); $("#so3", b).appendChild(sw(S.set.scale, async v => { await setSet("scale", v); applyScale(); })); $("#so4", b).appendChild(sw(S.set.pitch, async v => { await setSet("pitch", v); applyPitch(); }));
    const cs = async () => { try { const j = await api("/api/tiles/size"); $("#st_cs", b).textContent = j.files + " · " + j.mb + " MB"; } catch (e) { } }; cs(); $("#st_cc", b).onclick = async () => { await del("/api/tiles"); cs(); };
  }, { full: true });
}
/* ===== الإقلاع ===== */
function bindUI() {
  $("#menu").onclick = () => { document.body.classList.add("dr"); renderShown(); }; $("#scrim").onclick = () => { document.body.classList.remove("dr"); closeSheet(); }; $("#sh-x").onclick = closeSheet; $("#dh-x").onclick = () => document.body.classList.remove("dr");
  $("#q").onkeydown = e => { if (e.key === "Enter") doSearch(); }; $("#qgo").onclick = doSearch;
  $("#compass").onclick = () => map.easeTo({ bearing: 0, pitch: 0 }); $("#lay").onclick = openBase;
  const lc = $("#locate"), lp = $("#lpm"); let tm, long = false;
  lc.onpointerdown = () => { long = false; tm = setTimeout(() => { long = true; lp.style.display = "block"; const r = lc.getBoundingClientRect(); lp.style.top = (r.top - 8 - lp.offsetHeight) + "px"; lp.style[document.dir === "rtl" ? "left" : "right"] = ""; lp.style.left = Math.max(8, r.right - lp.offsetWidth) + "px"; }, 450); };
  lc.onpointerup = lc.onpointerleave = () => clearTimeout(tm); lc.onclick = () => { if (!long) locate(false); };
  document.addEventListener("pointerdown", e => { if (!lp.contains(e.target) && !lc.contains(e.target)) lp.style.display = "none"; });
  $("#lp1", lp).onclick = () => { lp.style.display = "none"; locate(false); }; $("#lp2", lp).onclick = () => { lp.style.display = "none"; locate(true); }; $("#lp3", lp).onclick = () => { lp.style.display = "none"; startTouch("multi"); };
}
async function boot2() {
  try { S.sectors = await api("/api/sectors"); } catch (e) { }
  await Promise.all([loadTpls(), loadAnn(), loadRas()]); try { await refreshDs(); } catch (e) { }
  infoSoon(); const sp = $("#splash"); if (sp) { sp.style.opacity = 0; setTimeout(() => sp.remove(), 400); }
}
window.addEventListener("DOMContentLoaded", () => {
  S.set = Object.assign({}, S.boot.settings || {}); A.shape = S.set.shape || "rect"; applyTheme(); bindUI(); applyLang(); initMap();
});
