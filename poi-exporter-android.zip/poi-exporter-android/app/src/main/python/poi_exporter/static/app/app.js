"use strict";
/* ===== أدوات عامة ===== */
const $ = (s, e = document) => e.querySelector(s);
const $$ = (s, e = document) => [...e.querySelectorAll(s)];
const api = async (u, o = {}) => { const r = await fetch(u, o); let j = null; try { j = await r.json(); } catch (e) { } if (!r.ok) throw new Error((j && j.error) || ("HTTP " + r.status)); return j; };
const post = (u, b) => api(u, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b) });
const del = u => api(u, { method: "DELETE" });
const esc = s => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const el = (h, p) => { const d = document.createElement("div"); d.innerHTML = h.trim(); const e = d.firstChild; if (p) p.appendChild(e); return e; };
const ICONS = {
  menu: "M4 6h16M4 12h16M4 18h16", search: "M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3", plus: "M12 5v14M5 12h14",
  fetch: "M12 3v12m0 0l-4-4m4 4l4-4M4 17v3h16v-3", table: "M3 5h18v14H3zM3 10h18M9 5v14", locate: "M12 8a4 4 0 100 8 4 4 0 000-8zM12 2v3M12 19v3M2 12h3M19 12h3",
  compass: "M12 2l4 10-4 10-4-10z", layers: "M12 3l9 5-9 5-9-5zM3 13l9 5 9-5", tool: "M14.7 6.3a4 4 0 005 5L21 13l-8 8-3-3 8-8zM3 21l5-5", settings: "M12 15a3 3 0 100-6 3 3 0 000 6zM19 12l2-1-2-4-2 1-2-1-1-2h-4l-1 2-2 1-2-1-2 4 2 1v2l-2 1 2 4 2-1 2 1 1 2h4l1-2 2-1 2 1 2-4-2-1z",
  imp: "M12 21V9m0 0l-4 4m4-4l4 4M4 7V4h16v3", save: "M6 3h12v18l-6-4-6 4z", report: "M7 3h8l4 4v14H7zM15 3v4h4M10 12h6M10 16h6", chart: "M4 20V10m6 10V4m6 16v-7m4 7H2",
  img: "M3 5h18v14H3zM8 11a2 2 0 100-4 2 2 0 000 4zM21 16l-5-5-8 8", conv: "M7 7h13l-3-3m3 3l-3 3M17 17H4l3-3m-3 3l3 3", pin: "M12 21s7-6 7-12a7 7 0 10-14 0c0 6 7 12 7 12zM12 11a2 2 0 100-4 2 2 0 000 4z",
  tag: "M3 12V3h9l9 9-9 9zM7.5 7.5h.01", x: "M6 6l12 12M18 6L6 18", trash: "M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3", edit: "M4 20h4L19 9l-4-4L4 16zM14 6l4 4",
  share: "M18 8a3 3 0 100-6 3 3 0 000 6zM6 15a3 3 0 100-6 3 3 0 000 6zM18 22a3 3 0 100-6 3 3 0 000 6zM8.6 13.5l6.8 4M15.4 6.5l-6.8 4", open: "M14 3h7v7M21 3l-9 9M19 14v7H3V5h7",
  eye: "M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 15a3 3 0 100-6 3 3 0 000 6z", check: "M5 12l5 5L20 7", zoom: "M12 3v4M12 17v4M3 12h4M17 12h4M12 9a3 3 0 100 6 3 3 0 000-6z",
  area: "M5 5h14v14H5z", rot: "M20 12a8 8 0 11-3-6.2M20 4v5h-5", cloud: "M7 18a4 4 0 010-8 5 5 0 019.6-1A4 4 0 0117 18z", more: "M5 12h.01M12 12h.01M19 12h.01", tilt: "M3 18l9-12 9 12zM12 6v12"
};
const ic = n => `<svg class="i" viewBox="0 0 24 24"><path d="${ICONS[n] || ""}"/></svg>`;
const I = ic;

/* ===== الترجمة ===== */
const TX = {
  ar: {
    app: "مصدّر المعالم", search: "ابحث: إحداثيات UTM / MGRS / خط عرض وطول", add: "إضافة", fetch: "جلب", table: "الجدول", area: "المنطقة", tools: "أدوات", menu: "القائمة",
    import: "استيراد", saved: "المحفوظة", report: "تقرير", analysis: "تحليل", aerial: "صور جوية", conv: "محوّل", dist: "الأقضية", ann: "عناصر الخريطة", base: "الخرائط", settings: "الإعدادات",
    shown: "المعروضة على الخريطة", s_area: "مربع المنطقة", s_g1: "حدود المحافظات", s_g2: "حدود الأقضية", s_ann: "عناصر الخريطة", s_tool: "نتيجة الأداة", s_ras: "الصور الجوية",
    close: "إغلاق", cancel: "إلغاء", ok: "موافق", save2: "حفظ", del: "حذف", edit: "تعديل", open: "فتح", share: "مشاركة", export: "تصدير", loc: "موقعي", addhere: "إضافة معلم هنا", addmany: "إضافة عدة معالم",
    name: "الاسم", type: "النوع", Gategory: "القطاع", gathaa: "القضاء", Nahia: "الناحية", mohafadha: "المحافظة", x: "X", y: "Y", link: "الرابط",
    sector: "القطاع", items: "عناصر القطاع", tpl: "قوالب جاهزة", tplsave: "حفظ كقالب", center: "في المركز (+)", touch: "باللمس", gps: "موقعي الحالي", addb: "إضافة", pend: "معلم بانتظار الحفظ", savall: "حفظ الكل", tapmap: "اضغط على الخريطة لتحديد الموقع",
    added: "تمت الإضافة", nodata: "لا توجد بيانات", done: "تم", err: "خطأ", wait: "جارٍ…", typehere: "أو اكتب النوع", nameph: "اسم المعلم",
    poi: "المعالم", layers: "الطبقات", custom: "استعلام مخصص (OSM)", unnamed: "تضمين بلا اسم", fill: "ملء القضاء/المحافظة", fmt: "الصيغة", autosave: "حفظ تلقائي داخل التطبيق", autoexp: "تصدير ملف أيضاً", start: "ابدأ الجلب", fetched: "تم الجلب",
    rows: "سجل", search2: "بحث في الجدول", sel: "محدد", delsel: "حذف المحدد", zoomto: "عرض على الخريطة", confirm: "تأكيد الحذف؟", rename: "إعادة تسمية", more: "تحميل المزيد", nol: "لا توجد مجموعات محفوظة بعد",
    shape: "الشكل", rect: "مستطيل", circle: "دائرة", rotated: "مائل", w: "العرض (م)", h: "الارتفاع (م)", r: "نصف القطر (م)", deg: "الدوران (°)", follow: "يتبع المركز (+)", pinned: "مثبّت", show: "إظهار", hide: "إخفاء", fitv: "من حجم الشاشة", here: "ضعه هنا", fit: "اعرض المنطقة",
    run: "تشغيل", result: "النتيجة", clear: "مسح", exres: "تصدير النتيجة", preview: "معاينة", title: "العنوان", paper: "الورق", port: "طولي", sectorc: "ألوان القطاعات", legend: "مفتاح", tbl: "جدول", grid: "شبكة", dpi: "الدقة", repsave: "حفظ التقرير", rtpl: "قوالب التقرير", rtsave: "حفظ كقالب",
    pick: "اختر ملفاً", skipdup: "تجاوز المكرر", crs: "نظام الإحداثيات (اختياري)", impdone: "تم استيراد", world: "ملف الإحداثيات (اختياري)", bounds: "الحدود: غرب,جنوب,شرق,شمال", opac: "الشفافية", addraster: "إضافة صورة",
    conv1: "أدخل إحداثياً", conv2: "تحويل", srcc: "المصدر", tgtc: "الهدف", batch: "تحويل ملف دفعة واحدة", fconv: "تحويل ملف إلى صيغة",
    dname: "اسم القضاء", dfetch: "جلب حدود", dbulk: "جلب كل الأقضية الناقصة", dexp: "تصدير الحدود", lvl: "المستوى", gov: "محافظات", dis: "أقضية",
    txt: "نص", size: "الحجم", color: "اللون", addtext: "إضافة نص", addimg: "إضافة صورة صغيرة", width: "العرض",
    theme: "المظهر", auto: "تلقائي", light: "فاتح", dark: "داكن", lang: "اللغة", ctype: "نوع الإحداثيات", folder: "مجلد الحفظ", basem: "الخريطة الافتراضية", curl: "رابط خريطة مخصص ({z}/{x}/{y})", scale: "مقياس الرسم", tilt: "إمالة الخريطة", cache: "ذاكرة الخرائط",
    osm: "شوارع", sat: "قمر صناعي", hybrid: "هجين", roads: "طرق", cust: "مخصص", tpls: "القوالب", saved2: "تم الحفظ في", loading: "جارٍ التحميل…", pstep: "الخطوة", poiset: "المعالم المرئية",
    tip_g: "خرائط جوجل غير مضمّنة بسبب شروط الاستخدام؛ الهجين من Esri والطرق من Carto، ويمكنك لصق رابط خريطتك."
  },
  en: {
    app: "POI Exporter", search: "Search: UTM / MGRS / lat,lon", add: "Add", fetch: "Fetch", table: "Table", area: "Area", tools: "Tools", menu: "Menu",
    import: "Import", saved: "Saved", report: "Report", analysis: "Analysis", aerial: "Aerial", conv: "Converter", dist: "Districts", ann: "Map items", base: "Maps", settings: "Settings",
    shown: "Shown on map", s_area: "Area box", s_g1: "Governorate borders", s_g2: "District borders", s_ann: "Map items", s_tool: "Tool result", s_ras: "Aerial images",
    close: "Close", cancel: "Cancel", ok: "OK", save2: "Save", del: "Delete", edit: "Edit", open: "Open", share: "Share", export: "Export", loc: "My location", addhere: "Add landmark here", addmany: "Add several",
    name: "Name", type: "Type", Gategory: "Sector", gathaa: "District", Nahia: "Sub-district", mohafadha: "Governorate", x: "X", y: "Y", link: "Link",
    sector: "Sector", items: "Sector items", tpl: "Templates", tplsave: "Save as template", center: "At centre (+)", touch: "By touch", gps: "My location", addb: "Add", pend: "pending", savall: "Save all", tapmap: "Tap the map to place",
    added: "Added", nodata: "No data", done: "Done", err: "Error", wait: "Working…", typehere: "or type the type", nameph: "Landmark name",
    poi: "Landmarks", layers: "Layers", custom: "Custom query (OSM)", unnamed: "Include unnamed", fill: "Fill district/governorate", fmt: "Format", autosave: "Auto-save in app", autoexp: "Also export a file", start: "Start fetching", fetched: "Fetched",
    rows: "rows", search2: "Search table", sel: "selected", delsel: "Delete selected", zoomto: "Show on map", confirm: "Confirm delete?", rename: "Rename", more: "Load more", nol: "No saved datasets yet",
    shape: "Shape", rect: "Rectangle", circle: "Circle", rotated: "Rotated", w: "Width (m)", h: "Height (m)", r: "Radius (m)", deg: "Rotation (°)", follow: "Follow centre (+)", pinned: "Pinned", show: "Show", hide: "Hide", fitv: "From screen size", here: "Place here", fit: "Zoom to area",
    run: "Run", result: "Result", clear: "Clear", exres: "Export result", preview: "Preview", title: "Title", paper: "Paper", port: "Portrait", sectorc: "Sector colours", legend: "Legend", tbl: "Table", grid: "Grid", dpi: "DPI", repsave: "Save report", rtpl: "Report templates", rtsave: "Save as template",
    pick: "Choose file", skipdup: "Skip duplicates", crs: "Coordinate system (optional)", impdone: "Imported", world: "World file (optional)", bounds: "Bounds: west,south,east,north", opac: "Opacity", addraster: "Add image",
    conv1: "Enter a coordinate", conv2: "Convert", srcc: "Source", tgtc: "Target", batch: "Batch-convert a file", fconv: "Convert file to format",
    dname: "District name", dfetch: "Fetch borders", dbulk: "Fetch all missing districts", dexp: "Export borders", lvl: "Level", gov: "Governorates", dis: "Districts",
    txt: "Text", size: "Size", color: "Colour", addtext: "Add text", addimg: "Add small image", width: "Width",
    theme: "Theme", auto: "Auto", light: "Light", dark: "Dark", lang: "Language", ctype: "Coordinate type", folder: "Save folder", basem: "Default map", curl: "Custom tiles URL ({z}/{x}/{y})", scale: "Scale bar", tilt: "Tilt map", cache: "Map cache",
    osm: "Streets", sat: "Satellite", hybrid: "Hybrid", roads: "Roads", cust: "Custom", tpls: "Templates", saved2: "Saved to", loading: "Loading…", pstep: "Step", poiset: "Visible landmarks",
    tip_g: "Google tiles are not embedded (terms of use). Hybrid is Esri, roads are Carto; you can paste your own tile URL."
  }
};
const S = { set: {}, sectors: [], tpls: [], ds: [], on: {}, ann: [], ras: [], boot: window.BOOT || { cats: [], layers: [], fmts: [] } };
const t = k => (TX[S.set.lang] || TX.ar)[k] || k;
const FIELDS = ["name", "type", "Gategory", "gathaa", "Nahia", "mohafadha", "x", "y", "link"];

/* ===== رسائل وحفظ ومشاركة ===== */
let toastT;
function toast(msg, btns) {
  $$(".toast").forEach(e => e.remove());
  const d = el(`<div class="toast"><span>${esc(msg)}</span></div>`, document.body);
  (btns || []).forEach(b => { const x = el(`<button>${esc(b[0])}</button>`, d); x.onclick = () => { b[1](); d.remove(); }; });
  clearTimeout(toastT); toastT = setTimeout(() => d.remove(), btns && btns.length ? 9000 : 3200);
}
const fail = e => toast("⚠ " + (e && e.message || e));
const blobB64 = b => new Promise(r => { const f = new FileReader(); f.onload = () => r(String(f.result).split(",")[1]); f.readAsDataURL(b); });
async function saveBlob(blob, name, mode) {
  if (window.Android && Android.save) {
    const p = Android.save(name, await blobB64(blob), S.set.folder || "POIExporter");
    if (!p) return "";
    if (mode === "open") Android.open(p); else if (mode === "share") Android.share(p);
    else toast(t("saved2") + " " + p, [[t("open"), () => Android.open(p)], [t("share"), () => Android.share(p)]]);
    return p;
  }
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
  toast(t("done") + " — " + name); return "";
}
function fname(r, d) { const m = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/.exec(r.headers.get("Content-Disposition") || ""); return m ? decodeURIComponent(m[1]) : d; }
async function getFile(url, init, dflt, mode) {
  const r = await fetch(url, init); if (!r.ok) { let m = r.status; try { m = (await r.json()).error || m; } catch (e) { } throw new Error(m); }
  return saveBlob(await r.blob(), fname(r, dflt), mode);
}
const EXT = { geojson: ".geojson", kml: ".kml", kmz: ".kmz", gpx: ".gpx", shp: ".zip", csv: ".csv", xlsx: ".xlsx", gpkg: ".gpkg" };
function exportDs(o, mode) { return getFile("/api/datasets/export", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(o) }, "poi" + (EXT[o.format] || ""), mode).catch(fail); }

/* ===== الخريطة ===== */
let map, me, A = { shape: "rect", lat: 33.3, lon: 44.4, w: 2000, h: 2000, r: 1000, deg: 0, follow: true, show: true };
const ORIGIN = location.origin;
const BASES = { osm: ["osm"], sat: ["sat"], hybrid: ["sat", "trans", "ref"], roads: ["roads"], custom: ["custom"] };
function tileUrl(s) { return ORIGIN + "/tiles/" + s + "/{z}/{x}/{y}" + (s === "custom" ? "?u=" + encodeURIComponent(S.set.custom_url || "") : ""); }
function addRasterSrc(id) { if (map.getSource("b-" + id)) return; map.addSource("b-" + id, { type: "raster", tiles: [tileUrl(id)], tileSize: 256, maxzoom: id === "ref" || id === "trans" ? 17 : 19 }); map.addLayer({ id: "b-" + id, type: "raster", source: "b-" + id, layout: { visibility: "none" } }, firstOverlay()); }
function firstOverlay() { const l = map.getStyle().layers.find(l => !l.id.startsWith("b-")); return l && l.id; }
function setBase(m) {
  if (m === "custom") { if (!S.set.custom_url) { toast(t("curl")); m = "osm"; } else if (map.getLayer("b-custom") && map._cu !== S.set.custom_url) { map.removeLayer("b-custom"); map.removeSource("b-custom"); } }
  if (m === "custom") { addRasterSrc("custom"); map._cu = S.set.custom_url; }
  S.base = m; const on = BASES[m] || BASES.osm;
  ["osm", "sat", "ref", "trans", "roads", "custom"].forEach(id => { if (map.getLayer("b-" + id)) map.setLayoutProperty("b-" + id, "visibility", on.includes(id) ? "visible" : "none"); });
}
function initMap() {
  map = new maplibregl.Map({ container: "map", style: { version: 8, sources: {}, layers: [{ id: "bg", type: "background", paint: { "background-color": "#dfe6ee" } }] }, center: [44.4, 33.3], zoom: 11, maxPitch: 60, attributionControl: false, dragRotate: true, pitchWithRotate: true, fadeDuration: 0 });
  map.addControl(new maplibregl.AttributionControl({ compact: true, customAttribution: "OSM · Esri · Carto" }), "bottom-left");
  map.on("load", () => {
    ["osm", "sat", "ref", "trans", "roads"].forEach(addRasterSrc);
    map.addSource("area", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
    map.addLayer({ id: "area-f", type: "fill", source: "area", paint: { "fill-color": "#1e7bff", "fill-opacity": .1 } });
    map.addLayer({ id: "area-l", type: "line", source: "area", paint: { "line-color": "#1e7bff", "line-width": 3 } });
    map.addSource("tool", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
    map.addLayer({ id: "tool-f", type: "fill", source: "tool", filter: ["==", "$type", "Polygon"], paint: { "fill-color": "#e8590c", "fill-opacity": .25 } });
    map.addLayer({ id: "tool-l", type: "line", source: "tool", paint: { "line-color": "#e8590c", "line-width": 2 } });
    map.addLayer({ id: "tool-c", type: "circle", source: "tool", filter: ["==", "$type", "Point"], paint: { "circle-radius": 6, "circle-color": "#e8590c", "circle-stroke-width": 2, "circle-stroke-color": "#fff" } });
    setBase(S.set.base || "osm"); applyScale(); applyPitch();
    sizeFromView(); drawArea(); boot2();
  });
  map.on("rotate", updCompass); map.on("pitch", updCompass);
  map.on("move", () => { if (A.follow && A.show) { const c = map.getCenter(); A.lat = c.lat; A.lon = c.lng; drawArea(true); } });
  map.on("moveend", infoSoon);
  map.on("click", mapClick);
}
function applyScale() { if (S._sc) { map.removeControl(S._sc); S._sc = null; } if (S.set.scale) { S._sc = new maplibregl.ScaleControl({ unit: "metric" }); map.addControl(S._sc, "bottom-left"); } }
function applyPitch() { map.setMaxPitch(S.set.pitch ? 60 : 0); if (!S.set.pitch) map.easeTo({ pitch: 0 }); }
function updCompass() { const c = $("#compass svg"); if (c) c.style.transform = `rotate(${-map.getBearing()}deg)`; }
/* ===== مربع المنطقة ===== */
const MX = 111320;
function offs(lat, lon, e, n) { return [lon + e / (MX * Math.cos(lat * Math.PI / 180)), lat + n / 110574]; }
function rotL(x, y, d) { const a = d * Math.PI / 180, c = Math.cos(a), s = Math.sin(a); return [x * c + y * s, -x * s + y * c]; }
function areaPoly() {
  const pts = []; if (A.shape === "circle") { for (let i = 0; i <= 72; i++) { const a = i / 72 * 2 * Math.PI; pts.push(offs(A.lat, A.lon, A.r * Math.sin(a), A.r * Math.cos(a))); } return pts; }
  [[-1, 1], [1, 1], [1, -1], [-1, -1], [-1, 1]].forEach(([sx, sy]) => { const [e, n] = rotL(sx * A.w / 2, sy * A.h / 2, A.deg); pts.push(offs(A.lat, A.lon, e, n)); }); return pts;
}
function areaBBox() { const p = areaPoly(), la = p.map(x => x[1]), lo = p.map(x => x[0]); return [Math.min(...la), Math.min(...lo), Math.max(...la), Math.max(...lo)]; }
const hd = {};
function mkHandle(k, cls, fn) {
  const e = document.createElement("div"); e.className = "hd " + cls;
  const m = new maplibregl.Marker({ element: e, draggable: true }).setLngLat([0, 0]).addTo(map); m.on("drag", () => fn(m.getLngLat())); m.on("dragend", () => { drawArea(); syncAreaUI(); }); hd[k] = m;
}
function vec(ll) { return [(ll.lng - A.lon) * MX * Math.cos(A.lat * Math.PI / 180), (ll.lat - A.lat) * 110574]; }
function drawArea(light) {
  if (!map.getSource("area")) return;
  const vis = A.show; map.setLayoutProperty("area-f", "visibility", vis ? "visible" : "none"); map.setLayoutProperty("area-l", "visibility", vis ? "visible" : "none");
  map.getSource("area").setData({ type: "FeatureCollection", features: [{ type: "Feature", properties: {}, geometry: { type: "Polygon", coordinates: [areaPoly()] } }] });
  if (!hd.mv) {
    mkHandle("mv", "mv", ll => { A.follow = false; A.lat = ll.lat; A.lon = ll.lng; drawArea(true); });
    mkHandle("rot", "rot", ll => { const [e, n] = vec(ll); A.deg = (Math.atan2(e, n) * 180 / Math.PI + 360) % 360; A.shape === "circle" || drawArea(true); });
    mkHandle("sz", "", ll => { const [e, n] = vec(ll); if (A.shape === "circle") A.r = Math.max(20, Math.hypot(e, n)); else { const a = A.deg * Math.PI / 180, x = e * Math.cos(a) - n * Math.sin(a), y = e * Math.sin(a) + n * Math.cos(a); A.w = Math.max(40, Math.round(2 * Math.abs(x))); A.h = Math.max(40, Math.round(2 * Math.abs(y))); } drawArea(true); });
  }
  Object.values(hd).forEach(m => m.getElement().style.display = vis ? "" : "none");
  hd.mv.setLngLat([A.lon, A.lat]);
  if (A.shape === "circle") { hd.sz.setLngLat(offs(A.lat, A.lon, A.r, 0)); hd.rot.getElement().style.display = "none"; }
  else { const [e, n] = rotL(A.w / 2, -A.h / 2, A.deg); hd.sz.setLngLat(offs(A.lat, A.lon, e, n)); const k = Math.max(A.w, A.h) * .12 + A.h / 2, [re, rn] = rotL(0, k, A.deg); hd.rot.setLngLat(offs(A.lat, A.lon, re, rn)); hd.rot.getElement().style.display = vis ? "" : "none"; }
  if (!light) syncAreaUI();
}
function sizeFromView() { const b = map.getBounds(), c = map.getCenter(); const wm = (b.getEast() - b.getWest()) * MX * Math.cos(c.lat * Math.PI / 180); A.w = A.h = Math.max(100, Math.round(wm * .45 / 50) * 50); A.r = A.w / 2; A.lat = c.lat; A.lon = c.lng; }
/* ===== معلومات المركز + البحث ===== */
let infoAb, infoTm;
function infoSoon() { clearTimeout(infoTm); infoTm = setTimeout(async () => { const c = map.getCenter(); if (infoAb) infoAb.abort(); infoAb = new AbortController(); try { const r = await (await fetch(`/api/center?lat=${c.lat.toFixed(6)}&lon=${c.lng.toFixed(6)}`, { signal: infoAb.signal })).json(); $("#info").innerHTML = `<b>${esc(r[S.set.ctype] || r.DD)}</b><span>${esc((r.qadaa || "") + (r.governorate ? " / " + r.governorate : ""))}</span>`; } catch (e) { } }, 250); }
async function doSearch() {
  const q = $("#q").value.trim(); if (!q) return;
  try { const r = await api("/api/coords?text=" + encodeURIComponent(q)); map.flyTo({ center: [r.lon, r.lat], zoom: Math.max(map.getZoom(), 15) }); marker("sr", r.lon, r.lat);
    popupAt([r.lon, r.lat], `<b>${esc(r[S.set.ctype] || r.DD)}</b><div class="hint">${esc(r.UTM)}<br>${esc(r.MGRS)}</div><button class="btn blk" id="pa">${I("plus")}${t("addhere")}</button>`, p => $("#pa", p).onclick = () => { openAdd(); ADD.at = [r.lat, r.lon]; }); } catch (e) { fail(e); }
}
const MK = {};
function marker(k, lon, lat, cls) { if (MK[k]) MK[k].remove(); const e = document.createElement("div"); e.className = "mk " + (cls || ""); MK[k] = new maplibregl.Marker({ element: e }).setLngLat([lon, lat]).addTo(map); return MK[k]; }
let POP;
function popupAt(ll, html, init) { if (POP) POP.remove(); const d = document.createElement("div"); d.style.cssText = "min-width:180px;color:#16202b"; d.innerHTML = html; POP = new maplibregl.Popup({ offset: 14, maxWidth: "300px" }).setLngLat(ll).setDOMContent(d).addTo(map); init && init(d); return POP; }
function locate(add) {
  if (!navigator.geolocation) return toast("GPS ✕");
  toast(t("wait")); navigator.geolocation.getCurrentPosition(p => { const ll = [p.coords.longitude, p.coords.latitude]; map.flyTo({ center: ll, zoom: 16 }); marker("me", ll[0], ll[1]); if (add) { ADD.at = [ll[1], ll[0]]; openAdd(); } }, e => toast("GPS: " + e.message), { enableHighAccuracy: true, timeout: 15000 });
}
/* ===== مجموعات البيانات على الخريطة ===== */
const dsIds = () => S.ds.map(d => d.id);
function dsLayers(id) { return ["f", "l", "c"].map(k => `d-${id}-${k}`); }
async function ensureDs(d, force) {
  const sid = "d-" + d.id;
  if (!map.getSource(sid) || force) {
    const g = await api(`/api/datasets/${d.id}/geojson`);
    if (map.getSource(sid)) map.getSource(sid).setData(g); else {
      map.addSource(sid, { type: "geojson", data: g });
      const col = ["coalesce", ["get", "color"], d.color];
      map.addLayer({ id: sid + "-f", type: "fill", source: sid, filter: ["==", "$type", "Polygon"], paint: { "fill-color": col, "fill-opacity": .22 } }, "area-f");
      map.addLayer({ id: sid + "-l", type: "line", source: sid, filter: ["!=", "$type", "Point"], paint: { "line-color": col, "line-width": 2.2 } }, "area-f");
      map.addLayer({ id: sid + "-c", type: "circle", source: sid, filter: ["==", "$type", "Point"], paint: { "circle-radius": ["interpolate", ["linear"], ["zoom"], 8, 3, 14, 6, 18, 9], "circle-color": col, "circle-stroke-width": 2, "circle-stroke-color": "#fff" } }, "area-f");
      dsLayers(d.id).forEach(l => { map.on("click", l, e => featClick(e)); map.on("mouseenter", l, () => map.getCanvas().style.cursor = "pointer"); map.on("mouseleave", l, () => map.getCanvas().style.cursor = ""); });
    }
  }
  dsLayers(d.id).forEach(l => map.getLayer(l) && map.setLayoutProperty(l, "visibility", d.visible ? "visible" : "none"));
}
async function refreshDs(forceIds) {
  S.ds = await api("/api/datasets");
  for (const id of Object.keys(S.dsLoaded || {})) if (!dsIds().includes(id)) { dsLayers(id).forEach(l => map.getLayer(l) && map.removeLayer(l)); map.getSource("d-" + id) && map.removeSource("d-" + id); delete S.dsLoaded[id]; }
  S.dsLoaded = S.dsLoaded || {};
  await Promise.all(S.ds.map(d => ensureDs(d, (forceIds || []).includes(d.id)).then(() => S.dsLoaded[d.id] = 1).catch(() => { })));
  renderShown(); if (S.onDs) S.onDs();
}
function featClick(e) {
  if (ADD.mode) return; const f = e.features[0]; if (!f) return; const p = f.properties; e._fc = 1;
  const rows = ["type", "Gategory", "gathaa", "Nahia", "mohafadha"].filter(k => p[k]).map(k => `<div class="hint"><b>${t(k)}:</b> ${esc(p[k])}</div>`).join("");
  popupAt(e.lngLat, `<b>${esc(p.name || "—")}</b>${rows}<div class="btns"><button class="ib sm" id="pe">${I("edit")}</button><button class="ib sm er" id="pd">${I("trash")}</button><button class="ib sm" id="pc">${I("share")}</button></div>`, d => {
    $("#pe", d).onclick = () => editRow(p, () => refreshDs(dsIds())); $("#pd", d).onclick = async () => { if (confirm(t("confirm"))) { await post("/api/features/delete", { ids: [p.id] }).catch(fail); POP.remove(); refreshDs(dsIds()); } };
    $("#pc", d).onclick = () => { const s = `${p.name}\n${p.lat},${p.lon}`; navigator.share ? navigator.share({ text: s }).catch(() => { }) : toast(s); };
  });
}
function mapClick(e) {
  if (ADD.mode === "touch" || ADD.mode === "multi") { addAt(e.lngLat.lat, e.lngLat.lng); return; }
  if (e._fc) return;
}
async function setDsVis(d, v) { d.visible = v; await post("/api/datasets/" + d.id, { visible: v }).catch(fail); await ensureDs(d); }
/* ===== نافذة سفلية ===== */
let SHEET = null;
function openSheet(id, title, render, o = {}) {
  SHEET = id; const s = $("#sheet"); s.classList.toggle("full", !!o.full); $("#sh-t").textContent = title; const b = $("#sh-b"); b.innerHTML = ""; render(b);
  document.body.classList.remove("dr"); document.body.classList.add("sh");
}
function closeSheet() { SHEET = null; S.onDs = null; document.body.classList.remove("sh"); }
function modal(title, body, onOk, okText) {
  const m = el(`<div class="modal"><div class="p"><h3>${esc(title)}</h3><div id="mb"></div><div class="btns"><button class="btn sec2" id="mc">${t("cancel")}</button><button class="btn" id="mo">${esc(okText || t("save2"))}</button></div></div></div>`, document.body);
  $("#mb", m).appendChild(body); $("#mc", m).onclick = () => m.remove(); $("#mo", m).onclick = async () => { try { if (await onOk() !== false) m.remove(); } catch (e) { fail(e); } }; return m;
}
function fieldRow(label, id, val, extra) { return `<label class="f">${esc(label)}</label><input class="in" id="${id}" value="${esc(val)}" ${extra || ""}>`; }
function editRow(r, done) {
  const b = el(`<div>${["name", "type", "gathaa", "Nahia", "mohafadha", "link"].map(k => fieldRow(t(k), "e_" + k, r[k] || "")).join("")}
   <label class="f">${t("Gategory")}</label><select class="in" id="e_Gategory"><option value=""></option>${S.sectors.map(s => `<option ${s.name === r.Gategory ? "selected" : ""}>${esc(s.name)}</option>`).join("")}</select>
   <div class="two">${fieldRow("lat", "e_lat", r.lat)}${fieldRow("lon", "e_lon", r.lon)}</div></div>`);
  modal(t("edit"), b, async () => { const j = {}; ["name", "type", "gathaa", "Nahia", "mohafadha", "link", "Gategory"].forEach(k => j[k] = $("#e_" + k, b).value); const la = +$("#e_lat", b).value, lo = +$("#e_lon", b).value; if (la !== +r.lat || lo !== +r.lon) { j.lat = la; j.lon = lo; j.refill_admin = true; } await post("/api/landmarks/" + r.id, j); toast(t("done")); done && done(); });
}
/* ===== الإضافة ===== */
const ADD = { sector: null, name: "", type: "", mode: "", pending: [], at: null };
function secColor(n) { const s = S.sectors.find(x => x.name === n); return s ? s.color : "#1e7bff"; }
function openAdd() {
  openSheet("add", t("add"), b => {
    b.innerHTML = `<div class="hint">${t("sector")}</div><div class="chips" id="sc"></div><div id="itw"></div>
    ${fieldRow(t("name"), "a_name", ADD.name, `placeholder="${t("nameph")}"`)}${fieldRow(t("type"), "a_type", ADD.type, `placeholder="${t("typehere")}"`)}
    <div class="sec">${t("tpl")}</div><div class="chips" id="tp"></div>
    <div class="btns"><button class="btn" id="a_c">${I("plus")}${t("center")}</button><button class="btn sec2" id="a_t">${I("pin")}${t("touch")}</button><button class="btn sec2" id="a_g">${I("locate")}${t("gps")}</button></div>
    <div class="btns"><button class="btn sec2" id="a_m">${I("layers")}${t("addmany")}</button><button class="btn sec2" id="a_s">${I("save")}${t("tplsave")}</button></div>`;
    const sc = $("#sc", b); S.sectors.forEach(s => { const c = el(`<span class="chip ${ADD.sector === s.name ? "on" : ""}"><i class="dot" style="background:${s.color}"></i>${esc(s.name.replace(/^القطاع |^قطاع /, ""))}</span>`, sc); c.onclick = () => { ADD.sector = ADD.sector === s.name ? null : s.name; ADD.name = $("#a_name", b).value; ADD.type = $("#a_type", b).value; openAdd(); }; });
    const sec = S.sectors.find(s => s.name === ADD.sector);
    if (sec) { const w = $("#itw", b); w.innerHTML = `<div class="sec">${t("items")}</div><div class="chips"></div>`; const cc = $(".chips", w); sec.items.forEach(it => { const c = el(`<span class="chip ${ADD.type === it ? "on" : ""}">${esc(it)}</span>`, cc); c.onclick = () => { $("#a_type", b).value = it; ADD.type = it; $$(".chip", cc).forEach(x => x.classList.remove("on")); c.classList.add("on"); }; }); }
    const tp = $("#tp", b); S.tpls.forEach(x => { const c = el(`<span class="chip">${esc(x.name)}<i style="opacity:.5">✕</i></span>`, tp); c.onclick = () => { $("#a_name", b).value = x.name; $("#a_type", b).value = x.type || ""; ADD.sector = x.category || null; ADD.name = x.name; ADD.type = x.type || ""; openAdd(); }; c.lastChild.onclick = async ev => { ev.stopPropagation(); await del("/api/templates/" + encodeURIComponent(x.name)); await loadTpls(); openAdd(); }; });
    const rd = () => { ADD.name = $("#a_name", b).value.trim(); ADD.type = $("#a_type", b).value.trim(); };
    $("#a_c", b).onclick = () => { rd(); const c = ADD.at ? { lat: ADD.at[0], lng: ADD.at[1] } : map.getCenter(); ADD.at = null; addAt(c.lat, c.lng, true); };
    $("#a_t", b).onclick = () => { rd(); startTouch("touch"); }; $("#a_m", b).onclick = () => { rd(); startTouch("multi"); };
    $("#a_g", b).onclick = () => { rd(); locate(true); };
    $("#a_s", b).onclick = async () => { rd(); if (!ADD.name) return toast(t("nameph")); await post("/api/templates", { name: ADD.name, type: ADD.type, category: ADD.sector || "" }).catch(fail); await loadTpls(); openAdd(); };
  });
}
async function loadTpls() { try { S.tpls = await api("/api/templates"); } catch (e) { S.tpls = []; } }
function startTouch(mode) {
  ADD.mode = mode; ADD.pending = []; closeSheet(); const bn = $("#banner"); bn.style.display = "flex"; updBanner(); map.getCanvas().style.cursor = "crosshair";
}
function updBanner() { const bn = $("#banner"); if (!ADD.mode) { bn.style.display = "none"; return; } bn.innerHTML = `<span style="flex:1">${ADD.mode === "multi" ? ADD.pending.length + " " + t("pend") : t("tapmap")}</span>${ADD.mode === "multi" ? `<button class="btn" id="bs">${t("savall")}</button>` : ""}<button class="btn sec2" id="bc">${t("cancel")}</button>`; $("#bc").onclick = stopTouch; if (ADD.mode === "multi") $("#bs").onclick = saveMany; }
function stopTouch() { ADD.mode = ""; Object.keys(MK).filter(k => k.startsWith("p")).forEach(k => { MK[k].remove(); delete MK[k]; }); ADD.pending = []; $("#banner").style.display = "none"; map.getCanvas().style.cursor = ""; }
async function addAt(lat, lon, open) {
  if (ADD.mode === "multi") { ADD.pending.push({ lat, lon, name: ADD.name ? (ADD.pending.length ? ADD.name + " " + (ADD.pending.length + 1) : ADD.name) : "", type: ADD.type, Gategory: ADD.sector || "" }); marker("p" + ADD.pending.length, lon, lat, "pend"); updBanner(); return; }
  try { const r = await post("/api/landmarks", { lat, lon, name: ADD.name, type: ADD.type, Gategory: ADD.sector || "" }); if (ADD.mode === "touch") stopTouch(); toast(t("added") + (r.gathaa ? " — " + r.gathaa : ""));
    await refreshDs(dsIds()); marker("new", lon, lat); setTimeout(() => MK.new && MK.new.remove(), 2500); if (open) closeSheet(); } catch (e) { fail(e); }
}
async function saveMany() { if (!ADD.pending.length) return stopTouch(); try { const r = await post("/api/features/add-many", { items: ADD.pending }); stopTouch(); toast(t("added") + " " + r.added); await refreshDs(dsIds()); } catch (e) { fail(e); } }
