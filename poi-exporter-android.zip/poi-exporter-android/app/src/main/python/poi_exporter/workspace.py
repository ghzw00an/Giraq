"""مشاريع SQLite: طبقات وعناصر، حفظ تلقائي، تراجع/إعادة (آخر 200 خطوة)، بحث محلي، ونسخ احتياطي (.poiproj.zip)."""
from __future__ import annotations

import json
import math
import os
import shutil
import sqlite3
import struct
import tempfile
import time
import zipfile
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from .geo import bbox, set_representative
from .model import LINE, POINT, POLYGON, Feature, Layer
from .sectors import norm_name

DDL = [
    "CREATE TABLE IF NOT EXISTS project (id TEXT PRIMARY KEY, name TEXT NOT NULL, created TEXT, updated TEXT, note TEXT DEFAULT '')",
    "CREATE TABLE IF NOT EXISTS layer (id TEXT PRIMARY KEY, project TEXT NOT NULL, name TEXT NOT NULL, geom INTEGER NOT NULL, "
    "kind TEXT DEFAULT 'user', color INTEGER DEFAULT 0, width REAL DEFAULT 0, opacity REAL DEFAULT 1, ord INTEGER DEFAULT 0, "
    "visible INTEGER DEFAULT 1, source TEXT DEFAULT '', source_date TEXT DEFAULT '', accuracy_note TEXT DEFAULT '', "
    "official INTEGER DEFAULT 0, deleted INTEGER DEFAULT 0)",
    "CREATE INDEX IF NOT EXISTS layer_project ON layer(project, deleted)",
    "CREATE TABLE IF NOT EXISTS feature (id TEXT PRIMARY KEY, layer TEXT NOT NULL, geom INTEGER NOT NULL, shape TEXT NOT NULL, "
    "minx REAL, miny REAL, maxx REAL, maxy REAL, lat REAL, lon REAL, name TEXT DEFAULT '', name_en TEXT DEFAULT '', "
    "type TEXT DEFAULT '', category TEXT DEFAULT '', governorate TEXT DEFAULT '', qadaa TEXT DEFAULT '', nahiya TEXT DEFAULT '', "
    "descr TEXT DEFAULT '', notes TEXT DEFAULT '', source TEXT DEFAULT '', updated TEXT DEFAULT '', accuracy REAL, "
    "status INTEGER DEFAULT 0, photos TEXT DEFAULT '', attrs TEXT DEFAULT '', deleted INTEGER DEFAULT 0)",
    "CREATE INDEX IF NOT EXISTS feature_layer ON feature(layer, deleted)",
    "CREATE INDEX IF NOT EXISTS feature_minx ON feature(minx, maxx)",
    "CREATE INDEX IF NOT EXISTS feature_miny ON feature(miny, maxy)",
    "CREATE INDEX IF NOT EXISTS feature_name ON feature(name)",
    "CREATE TABLE IF NOT EXISTS history (seq INTEGER PRIMARY KEY AUTOINCREMENT, project TEXT NOT NULL, ts TEXT, label TEXT, "
    "json TEXT NOT NULL, undone INTEGER DEFAULT 0)",
    "CREATE INDEX IF NOT EXISTS history_project ON history(project, seq)",
    "CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)",
]
DEFAULT_PROJECT = "مشروعي"


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def _shape(f: Feature) -> str:
    return json.dumps({"p": f.parts, "h": f.holes}, separators=(",", ":"))


def _unshape(s: str, f: Feature) -> None:
    d = json.loads(s)
    f.parts = [[(c[0], c[1]) for c in p] for p in d["p"]]
    f.holes = list(d["h"])


@dataclass
class ProjectInfo:
    id: str
    name: str
    created: str = ""
    updated: str = ""


class Workspace:
    """يحفظ كل تعديل فوراً في SQLite ويسجله كخطوة تراجع واحدة."""

    def __init__(self, path: str = ":memory:", max_history: int = 200):
        self.path = path
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        for s in DDL:
            self.db.execute(s)
        self.max_history = max_history
        self.project: Optional[ProjectInfo] = None
        self.db.commit()

    def close(self) -> None:
        self.db.commit()
        self.db.close()

    # ------------------------------------------------------------------ المشاريع
    def projects(self) -> List[ProjectInfo]:
        return [ProjectInfo(r["id"], r["name"], r["created"], r["updated"])
                for r in self.db.execute("SELECT * FROM project ORDER BY updated DESC")]

    def create_project(self, name: str) -> ProjectInfo:
        p = ProjectInfo(Feature.new_id(), name, _now(), _now())
        self.db.execute("INSERT INTO project(id,name,created,updated) VALUES(?,?,?,?)", (p.id, p.name, p.created, p.updated))
        self.db.commit()
        return p

    def open(self, project_id: str) -> ProjectInfo:
        r = self.db.execute("SELECT * FROM project WHERE id=?", (project_id,)).fetchone()
        if not r:
            raise KeyError("مشروع غير موجود")
        self.project = ProjectInfo(r["id"], r["name"], r["created"], r["updated"])
        return self.project

    def open_default(self, name: str = DEFAULT_PROJECT) -> ProjectInfo:
        ps = self.projects()
        return self.open(ps[0].id) if ps else self.open(self.create_project(name).id)

    def rename_project(self, name: str) -> None:
        self.db.execute("UPDATE project SET name=?, updated=? WHERE id=?", (name, _now(), self._pid()))
        self.project.name = name
        self.db.commit()

    def delete_project(self, project_id: str) -> None:
        ids = [r["id"] for r in self.db.execute("SELECT id FROM layer WHERE project=?", (project_id,))]
        for lid in ids:
            self.db.execute("DELETE FROM feature WHERE layer=?", (lid,))
        self.db.execute("DELETE FROM layer WHERE project=?", (project_id,))
        self.db.execute("DELETE FROM history WHERE project=?", (project_id,))
        self.db.execute("DELETE FROM project WHERE id=?", (project_id,))
        self.db.commit()
        if self.project and self.project.id == project_id:
            self.project = None

    def _pid(self) -> str:
        if not self.project:
            raise RuntimeError("لا يوجد مشروع مفتوح")
        return self.project.id

    # ------------------------------------------------------------------ قراءة
    def layers(self, include_hidden: bool = True) -> List[Layer]:
        out = []
        for r in self.db.execute("SELECT * FROM layer WHERE project=? AND deleted=0 ORDER BY ord, rowid", (self._pid(),)):
            l = Layer(r["id"], r["name"], r["geom"], kind=r["kind"], color=r["color"], width=r["width"], opacity=r["opacity"],
                      order=r["ord"], visible=bool(r["visible"]), source=r["source"], source_date=r["source_date"],
                      accuracy_note=r["accuracy_note"], official=bool(r["official"]), project_id=r["project"])
            if include_hidden or l.visible:
                l.features = self._features(l.id)
                out.append(l)
        return out

    def layer(self, layer_id: str) -> Optional[Layer]:
        return next((l for l in self.layers() if l.id == layer_id), None)

    def _row_feature(self, r) -> Feature:
        f = Feature(geom=r["geom"], id=r["id"], name=r["name"], name_en=r["name_en"], type=r["type"], category=r["category"],
                    governorate=r["governorate"], qadaa=r["qadaa"], nahiya=r["nahiya"], description=r["descr"],
                    notes=r["notes"], source=r["source"], updated=r["updated"],
                    accuracy=float("nan") if r["accuracy"] is None else r["accuracy"], status=r["status"],
                    lat=r["lat"], lon=r["lon"])
        f.photos = [p for p in (r["photos"] or "").split("\n") if p]
        f.attrs = json.loads(r["attrs"]) if r["attrs"] else {}
        _unshape(r["shape"], f)
        return f

    def _features(self, layer_id: str) -> List[Feature]:
        return [self._row_feature(r) for r in self.db.execute("SELECT * FROM feature WHERE layer=? AND deleted=0 ORDER BY rowid", (layer_id,))]

    def feature(self, fid: str) -> Optional[Feature]:
        r = self.db.execute("SELECT * FROM feature WHERE id=? AND deleted=0", (fid,)).fetchone()
        return self._row_feature(r) if r else None

    def feature_count(self) -> int:
        return self.db.execute("SELECT COUNT(*) FROM feature f JOIN layer l ON l.id=f.layer WHERE l.project=? AND l.deleted=0 AND f.deleted=0",
                               (self._pid(),)).fetchone()[0]

    def bbox_query(self, layer_id: str, west: float, south: float, east: float, north: float) -> List[str]:
        return [r["id"] for r in self.db.execute(
            "SELECT id FROM feature WHERE layer=? AND deleted=0 AND maxx>=? AND minx<=? AND maxy>=? AND miny<=?",
            (layer_id, west, east, south, north))]

    def search(self, text: str, limit: int = 100) -> List[Feature]:
        """بحث محلي في الاسم والنوع والقطاع والمنطقة (يدعم العربية دون الاعتماد على الإنترنت)."""
        like = f"%{text}%"
        out, seen = [], set()
        for r in self.db.execute(
                "SELECT f.* FROM feature f JOIN layer l ON l.id=f.layer WHERE l.project=? AND l.deleted=0 AND f.deleted=0 AND "
                "(f.name LIKE ? OR f.name_en LIKE ? OR f.type LIKE ? OR f.category LIKE ? OR f.id=? OR f.governorate LIKE ? "
                "OR f.qadaa LIKE ? OR f.nahiya LIKE ?) LIMIT ?",
                (self._pid(), like, like, like, like, text, like, like, like, limit)):
            out.append(self._row_feature(r))
            seen.add(r["id"])
        n = norm_name(text)
        if n and len(out) < limit:      # مطابقة عربية مُطبَّعة (ألف/ياء/تشكيل)
            for r in self.db.execute("SELECT f.* FROM feature f JOIN layer l ON l.id=f.layer WHERE l.project=? AND l.deleted=0 AND f.deleted=0", (self._pid(),)):
                if r["id"] in seen:
                    continue
                if n in norm_name(r["name"]) or n in norm_name(r["type"]) or n in norm_name(r["category"]):
                    out.append(self._row_feature(r))
                    if len(out) >= limit:
                        break
        return out

    # ------------------------------------------------------------------ كتابة منخفضة المستوى
    def _put_feature(self, layer_id: str, f: Feature) -> None:
        if not f.id:
            f.id = Feature.new_id()
        if f.parts and not (f.lat or f.lon):
            set_representative(f)
        b = bbox(f) if f.parts else (None,) * 4
        self.db.execute(
            "INSERT OR REPLACE INTO feature (id,layer,geom,shape,minx,miny,maxx,maxy,lat,lon,name,name_en,type,category,governorate,"
            "qadaa,nahiya,descr,notes,source,updated,accuracy,status,photos,attrs,deleted) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)",
            (f.id, layer_id, f.geom, _shape(f), *b, f.lat, f.lon, f.name, f.name_en, f.type, f.category, f.governorate, f.qadaa,
             f.nahiya, f.description, f.notes, f.source, f.updated, None if math.isnan(f.accuracy) else f.accuracy, f.status,
             "\n".join(f.photos), json.dumps(f.attrs, ensure_ascii=False) if f.attrs else ""))

    def _layer_of(self, fid: str) -> Optional[str]:
        r = self.db.execute("SELECT layer FROM feature WHERE id=?", (fid,)).fetchone()
        return r["layer"] if r else None

    # ------------------------------------------------------------------ التاريخ (تراجع/إعادة)
    # كل خطوة: قائمة عمليات {op:'add'|'del'|'upd', layer, before, after}
    def _record(self, label: str, ops: List[dict]) -> None:
        if not ops:
            return
        self.db.execute("DELETE FROM history WHERE project=? AND undone=1", (self._pid(),))
        self.db.execute("INSERT INTO history(project,ts,label,json) VALUES(?,?,?,?)",
                        (self._pid(), _now(), label, json.dumps(ops, ensure_ascii=False)))
        extra = self.db.execute("SELECT COUNT(*) FROM history WHERE project=?", (self._pid(),)).fetchone()[0] - self.max_history
        if extra > 0:
            self.db.execute("DELETE FROM history WHERE seq IN (SELECT seq FROM history WHERE project=? ORDER BY seq LIMIT ?)",
                            (self._pid(), extra))
        self.db.execute("UPDATE project SET updated=? WHERE id=?", (_now(), self._pid()))
        self.db.commit()

    @staticmethod
    def _dump(f: Optional[Feature]) -> Optional[dict]:
        if f is None:
            return None
        d = {k: getattr(f, k) for k in ("geom", "id", "name", "type", "category", "nahiya", "qadaa", "governorate", "name_en",
                                         "description", "notes", "source", "updated", "status", "photos", "attrs", "lat", "lon")}
        d["accuracy"] = None if math.isnan(f.accuracy) else f.accuracy
        d["parts"], d["holes"] = f.parts, f.holes
        return d

    @staticmethod
    def _load(d: dict) -> Feature:
        f = Feature(**{k: v for k, v in d.items() if k not in ("parts", "holes", "accuracy")})
        f.accuracy = float("nan") if d.get("accuracy") is None else d["accuracy"]
        f.parts = [[(c[0], c[1]) for c in p] for p in d["parts"]]
        f.holes = list(d["holes"])
        return f

    def can_undo(self) -> bool:
        return self.db.execute("SELECT 1 FROM history WHERE project=? AND undone=0 LIMIT 1", (self._pid(),)).fetchone() is not None

    def can_redo(self) -> bool:
        return self.db.execute("SELECT 1 FROM history WHERE project=? AND undone=1 LIMIT 1", (self._pid(),)).fetchone() is not None

    def undo_label(self) -> str:
        r = self.db.execute("SELECT label FROM history WHERE project=? AND undone=0 ORDER BY seq DESC LIMIT 1", (self._pid(),)).fetchone()
        return r["label"] if r else ""

    def history(self) -> List[Tuple[int, str, str, bool]]:
        return [(r["seq"], r["ts"], r["label"], bool(r["undone"])) for r in
                self.db.execute("SELECT * FROM history WHERE project=? ORDER BY seq DESC", (self._pid(),))]

    def undo(self) -> Optional[str]:
        r = self.db.execute("SELECT * FROM history WHERE project=? AND undone=0 ORDER BY seq DESC LIMIT 1", (self._pid(),)).fetchone()
        if not r:
            return None
        for op in reversed(json.loads(r["json"])):
            self._apply(op, reverse=True)
        self.db.execute("UPDATE history SET undone=1 WHERE seq=?", (r["seq"],))
        self.db.commit()
        return r["label"]

    def redo(self) -> Optional[str]:
        r = self.db.execute("SELECT * FROM history WHERE project=? AND undone=1 ORDER BY seq ASC LIMIT 1", (self._pid(),)).fetchone()
        if not r:
            return None
        for op in json.loads(r["json"]):
            self._apply(op, reverse=False)
        self.db.execute("UPDATE history SET undone=0 WHERE seq=?", (r["seq"],))
        self.db.commit()
        return r["label"]

    def clear_history(self) -> None:
        self.db.execute("DELETE FROM history WHERE project=?", (self._pid(),))
        self.db.commit()

    def _apply(self, op: dict, reverse: bool) -> None:
        kind = op["op"]
        if reverse:
            kind = {"add": "del", "del": "add", "upd": "upd"}[kind]
            before, after = op.get("after"), op.get("before")
        else:
            before, after = op.get("before"), op.get("after")
        if kind == "add":
            self._put_feature(op["layer"], self._load(after or before))
        elif kind == "del":
            self.db.execute("UPDATE feature SET deleted=1 WHERE id=?", ((before or after)["id"],))
        elif kind == "upd":
            self._put_feature(op["layer"], self._load(after))
        elif kind == "layer_add":
            self.db.execute("UPDATE layer SET deleted=0 WHERE id=?", (op["layer"],))
        elif kind == "layer_del":
            self.db.execute("UPDATE layer SET deleted=1 WHERE id=?", (op["layer"],))

    # ------------------------------------------------------------------ تعديلات عامة (كل منها خطوة تراجع)
    def add_layer(self, label: str, geom: int, kind: str = "user") -> Layer:
        l = Layer(Feature.new_id(), label, geom, kind=kind, project_id=self._pid())
        n = self.db.execute("SELECT COALESCE(MAX(ord),0)+1 FROM layer WHERE project=?", (self._pid(),)).fetchone()[0]
        self.db.execute("INSERT INTO layer(id,project,name,geom,kind,ord) VALUES(?,?,?,?,?,?)", (l.id, l.project_id, label, geom, kind, n))
        self._record("إضافة طبقة", [{"op": "layer_add", "layer": l.id}])
        return l

    def add_layer_with_features(self, src: Layer) -> Layer:
        l = self.add_layer(src.label, src.geom, src.kind if src.kind != "download" else "download")
        self.db.execute("UPDATE layer SET source=?, source_date=?, accuracy_note=?, official=?, color=? WHERE id=?",
                        (src.source, src.source_date, src.accuracy_note, int(src.official), src.color, l.id))
        l.features = [f.copy() for f in src.features]
        self.add_features(l.id, l.features, "استيراد طبقة")
        return l

    def rename_layer(self, layer_id: str, label: str) -> None:
        self.db.execute("UPDATE layer SET name=? WHERE id=?", (label, layer_id))
        self.db.commit()

    def update_layer_style(self, layer_id: str, color: Optional[int] = None, width: Optional[float] = None,
                           opacity: Optional[float] = None, order: Optional[int] = None) -> None:
        for col, v in (("color", color), ("width", width), ("opacity", opacity), ("ord", order)):
            if v is not None:
                self.db.execute(f"UPDATE layer SET {col}=? WHERE id=?", (v, layer_id))
        self.db.commit()

    def set_visible(self, layer_id: str, v: bool) -> None:
        self.db.execute("UPDATE layer SET visible=? WHERE id=?", (int(v), layer_id))
        self.db.commit()

    def delete_layer(self, layer_id: str) -> None:
        self.db.execute("UPDATE layer SET deleted=1 WHERE id=?", (layer_id,))
        self._record("حذف طبقة", [{"op": "layer_del", "layer": layer_id}])

    def add_features(self, layer_id: str, fs: Sequence[Feature], label: str = "إضافة معالم") -> None:
        ops = []
        for f in fs:
            self._put_feature(layer_id, f)
            ops.append({"op": "add", "layer": layer_id, "after": self._dump(f)})
        self._record(label, ops)

    def add_feature(self, layer_id: str, f: Feature) -> None:
        self.add_features(layer_id, [f], "إضافة معلم")

    def delete_features(self, layer_id: str, ids: Sequence[str], label: str = "حذف") -> None:
        ops = []
        for fid in ids:
            f = self.feature(fid)
            if f:
                ops.append({"op": "del", "layer": layer_id, "before": self._dump(f)})
                self.db.execute("UPDATE feature SET deleted=1 WHERE id=?", (fid,))
        self._record(label, ops)

    def delete_anywhere(self, ids: Sequence[str], label: str = "حذف") -> None:
        ops = []
        for fid in ids:
            lid, f = self._layer_of(fid), self.feature(fid)
            if f and lid:
                ops.append({"op": "del", "layer": lid, "before": self._dump(f)})
                self.db.execute("UPDATE feature SET deleted=1 WHERE id=?", (fid,))
        self._record(label, ops)

    def update_features(self, pairs: Sequence[Tuple[Feature, Feature]], label: str = "تعديل") -> None:
        """pairs: (قبل، بعد). المعرّف يؤخذ من «قبل»."""
        ops = []
        for before, after in pairs:
            lid = self._layer_of(before.id)
            if not lid:
                continue
            after.id = before.id
            self._put_feature(lid, after)
            ops.append({"op": "upd", "layer": lid, "before": self._dump(before), "after": self._dump(after)})
        self._record(label, ops)

    def update_feature(self, before: Feature, after: Feature, label: str = "تعديل معلم") -> None:
        self.update_features([(before, after)], label)

    def move_features(self, ids: Sequence[str], to_layer: str, label: str = "نقل") -> None:
        ops = []
        for fid in ids:
            f, lid = self.feature(fid), self._layer_of(fid)
            if f and lid and lid != to_layer:
                ops.append({"op": "del", "layer": lid, "before": self._dump(f)})
                ops.append({"op": "add", "layer": to_layer, "after": self._dump(f)})
                self.db.execute("UPDATE feature SET layer=? WHERE id=?", (to_layer, fid))
        self._record(label, ops)

    # ------------------------------------------------------------------ نسخ احتياطي
    def backup(self, dest_zip: str) -> None:
        """ينسخ المشروع المفتوح كاملاً إلى ملف .poiproj.zip (JSON داخل ZIP)."""
        data = {"version": 1, "project": {"name": self.project.name},
                "layers": [{"id": l.id, "name": l.label, "geom": l.geom, "kind": l.kind, "color": l.color, "width": l.width,
                            "opacity": l.opacity, "order": l.order, "visible": l.visible, "source": l.source,
                            "source_date": l.source_date, "accuracy_note": l.accuracy_note, "official": l.official,
                            "features": [self._dump(f) for f in l.features]} for l in self.layers()]}
        with zipfile.ZipFile(dest_zip, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("manifest.json", json.dumps(data, ensure_ascii=False))

    def restore(self, src_zip: str, name: Optional[str] = None) -> ProjectInfo:
        """يستعيد نسخة احتياطية كمشروع جديد (لا يستبدل مشروعاً قائماً)."""
        with zipfile.ZipFile(src_zip) as z:
            data = json.loads(z.read("manifest.json").decode("utf-8"))
        p = self.create_project(name or data["project"]["name"] + " (مستعاد)")
        self.open(p.id)
        for L in data["layers"]:
            lid = Feature.new_id()
            self.db.execute(
                "INSERT INTO layer(id,project,name,geom,kind,color,width,opacity,ord,visible,source,source_date,accuracy_note,official) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (lid, p.id, L["name"], L["geom"], L["kind"], L["color"], L["width"], L["opacity"], L["order"], int(L["visible"]),
                 L["source"], L["source_date"], L["accuracy_note"], int(L["official"])))
            for d in L["features"]:
                f = self._load(d)
                f.id = Feature.new_id()
                self._put_feature(lid, f)
        self.db.commit()
        return p
