"""جيوديسيا على مجسّم WGS84: مسافة واتجاه ووجهة (Vincenty) ومساحة ومحيط دقيقان (إسقاط أسطواني متساوي المساحة)."""
from __future__ import annotations

import math
from typing import List, Sequence, Tuple

from .geo import haversine
from .model import LINE, POINT, POLYGON, Feature

A = 6378137.0
F = 1 / 298.257223563
B = A * (1 - F)
E2 = F * (2 - F)


def inverse(lat1: float, lon1: float, lat2: float, lon2: float):
    """(المسافة م، الاتجاه الابتدائي°، الاتجاه النهائي°) بين نقطتين؛ Vincenty مع احتياطي كروي للنقاط شبه المتقابلة."""
    if lat1 == lat2 and lon1 == lon2:
        return 0.0, 0.0, 0.0
    L = math.radians(lon2 - lon1)
    U1 = math.atan((1 - F) * math.tan(math.radians(lat1)))
    U2 = math.atan((1 - F) * math.tan(math.radians(lat2)))
    sU1, cU1, sU2, cU2 = math.sin(U1), math.cos(U1), math.sin(U2), math.cos(U2)
    lam = L
    for _ in range(200):
        sl, cl = math.sin(lam), math.cos(lam)
        ss = math.hypot(cU2 * sl, cU1 * sU2 - sU1 * cU2 * cl)
        if ss == 0:
            return 0.0, 0.0, 0.0
        cs = sU1 * sU2 + cU1 * cU2 * cl
        sigma = math.atan2(ss, cs)
        sa = cU1 * cU2 * sl / ss
        c2a = 1 - sa * sa
        c2sm = cs - 2 * sU1 * sU2 / c2a if c2a else 0.0
        C = F / 16 * c2a * (4 + F * (4 - 3 * c2a))
        prev = lam
        lam = L + (1 - C) * F * sa * (sigma + C * ss * (c2sm + C * cs * (-1 + 2 * c2sm * c2sm)))
        if abs(lam - prev) < 1e-12:
            break
    else:       # لم يتقارب (شبه متقابلتين)
        d = haversine(lat1, lon1, lat2, lon2)
        return d, bearing_sphere(lat1, lon1, lat2, lon2), bearing_sphere(lat2, lon2, lat1, lon1)
    u2 = c2a * (A * A - B * B) / (B * B)
    k1 = (math.sqrt(1 + u2) - 1) / (math.sqrt(1 + u2) + 1)
    AA = (1 + k1 * k1 / 4) / (1 - k1)
    BB = k1 * (1 - 3 * k1 * k1 / 8)
    dsig = BB * ss * (c2sm + BB / 4 * (cs * (-1 + 2 * c2sm * c2sm) - BB / 6 * c2sm * (-3 + 4 * ss * ss) * (-3 + 4 * c2sm * c2sm)))
    s = B * AA * (sigma - dsig)
    a1 = math.degrees(math.atan2(cU2 * math.sin(lam), cU1 * sU2 - sU1 * cU2 * math.cos(lam))) % 360
    a2 = math.degrees(math.atan2(cU1 * math.sin(lam), -sU1 * cU2 + cU1 * sU2 * math.cos(lam))) % 360
    return s, a1, a2


def bearing_sphere(lat1, lon1, lat2, lon2) -> float:
    p1, p2, dl = math.radians(lat1), math.radians(lat2), math.radians(lon2 - lon1)
    return math.degrees(math.atan2(math.sin(dl) * math.cos(p2), math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl))) % 360


def distance(lat1, lon1, lat2, lon2) -> float:
    return inverse(lat1, lon1, lat2, lon2)[0]


def bearing(lat1, lon1, lat2, lon2) -> float:
    return inverse(lat1, lon1, lat2, lon2)[1]


def destination(lat1: float, lon1: float, bearing_deg: float, dist: float) -> Tuple[float, float]:
    """(lat, lon) بعد السير dist متراً بالاتجاه المعطى (Vincenty المباشرة)."""
    a1 = math.radians(bearing_deg)
    sa1, ca1 = math.sin(a1), math.cos(a1)
    tU1 = (1 - F) * math.tan(math.radians(lat1))
    cU1 = 1 / math.sqrt(1 + tU1 * tU1)
    sU1 = tU1 * cU1
    sig1 = math.atan2(tU1, ca1)
    sa = cU1 * sa1
    c2a = 1 - sa * sa
    u2 = c2a * (A * A - B * B) / (B * B)
    k1 = (math.sqrt(1 + u2) - 1) / (math.sqrt(1 + u2) + 1)
    AA = (1 + k1 * k1 / 4) / (1 - k1)
    BB = k1 * (1 - 3 * k1 * k1 / 8)
    sigma = dist / (B * AA)
    for _ in range(200):
        c2sm = math.cos(2 * sig1 + sigma)
        ss, cs = math.sin(sigma), math.cos(sigma)
        dsig = BB * ss * (c2sm + BB / 4 * (cs * (-1 + 2 * c2sm * c2sm) - BB / 6 * c2sm * (-3 + 4 * ss * ss) * (-3 + 4 * c2sm * c2sm)))
        new = dist / (B * AA) + dsig
        if abs(new - sigma) < 1e-12:
            sigma = new
            break
        sigma = new
    ss, cs = math.sin(sigma), math.cos(sigma)
    c2sm = math.cos(2 * sig1 + sigma)
    x = sU1 * ss - cU1 * cs * ca1
    lat2 = math.atan2(sU1 * cs + cU1 * ss * ca1, (1 - F) * math.hypot(sa, x))
    lam = math.atan2(ss * sa1, cU1 * cs - sU1 * ss * ca1)
    C = F / 16 * c2a * (4 + F * (4 - 3 * c2a))
    L = lam - (1 - C) * F * sa * (sigma + C * ss * (c2sm + C * cs * (-1 + 2 * c2sm * c2sm)))
    return math.degrees(lat2), (lon1 + math.degrees(L) + 540) % 360 - 180


def path_length(pts: Sequence[Tuple[float, float]]) -> float:
    return sum(distance(pts[i - 1][1], pts[i - 1][0], pts[i][1], pts[i][0]) for i in range(1, len(pts)))


def side_lengths(ring: Sequence[Tuple[float, float]]) -> List[float]:
    return [distance(ring[i][1], ring[i][0], ring[i + 1][1], ring[i + 1][0]) for i in range(len(ring) - 1)]


def _q(lat: float) -> float:
    e = math.sqrt(E2)
    s = math.sin(lat)
    return (1 - E2) * (s / (1 - E2 * s * s) - (1 / (2 * e)) * math.log((1 - e * s) / (1 + e * s)))


def ring_area(ring: Sequence[Tuple[float, float]]) -> float:
    """المساحة (م²) على المجسّم عبر إسقاط أسطواني متساوي المساحة (دقيق لأضلاع بطول عشرات الكيلومترات)."""
    if len(ring) < 3:
        return 0.0
    lon0 = ring[0][0]
    pts = []
    for lon, lat in ring:
        dl = (lon - lon0 + 180) % 360 - 180
        pts.append((A * math.radians(dl), A * _q(math.radians(lat)) / 2))
    a, j = 0.0, len(pts) - 1
    for i in range(len(pts)):
        a += pts[j][0] * pts[i][1] - pts[i][0] * pts[j][1]
        j = i
    return abs(a) / 2


def area(f: Feature) -> float:
    if f.geom != POLYGON:
        return 0.0
    t = 0.0
    for i, r in enumerate(f.parts):
        a = ring_area(r)
        t += -a if f.is_hole(i) else a
    return max(0.0, t)


def perimeter(f: Feature) -> float:
    return sum(path_length(r) for r in f.parts) if f.geom == POLYGON else 0.0


def length(f: Feature) -> float:
    return sum(path_length(p) for p in f.parts) if f.geom == LINE else 0.0
