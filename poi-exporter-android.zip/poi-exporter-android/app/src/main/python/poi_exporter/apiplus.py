"""واجهات إضافية: صور جوية، عناصر الخريطة، أقضية OSM، وأدوات التحليل والمنطقة."""
from __future__ import annotations

import json
import os
import urllib.request
import tempfile
import threading
import time
import uuid

from flask import jsonify, request, send_file

from . import adminfetch, analysis as an, formats, geoops
from .admin import AdminRef
from .annotations import IMAGE, TEXT, Annotations, Item
from .model import POINT, POLYGON, Feature, Layer
from .raster import RasterStore


def _home() -> str:
    d = os.path.join(os.path.expanduser("~"), "poi_data")
    os.makedirs(d, exist_ok=True)
    return d


def raster_store() -> RasterStore:
    return RasterStore(os.path.join(_home(), "rasters"))


def _ann_path() -> str:
    return os.path.join(_home(), "annotations.json")


def load_annotations() -> Annotations:
    p = _ann_path()
    return Annotations.from_json(open(p, encoding="utf-8").read()) if os.path.exists(p) else Annotations()


def save_annotations(a: Annotations) -> None:
    open(_ann_path(), "w", encoding="utf-8").write(a.to_json())


def ann_images():
    """دالة تعيد صورة PIL من اسم الملف المحفوظ (لتقرير PDF/PNG)."""
    from PIL import Image

    def f(name):
        p = os.path.join(_home(), "ann_files", os.path.basename(name))
        return Image.open(p).convert("RGBA") if os.path.exists(p) else None
    return f


# ---------------------------------------------------------------- قائمة الأقضية الناقصة (إنجليزي، عربي)
EXTRA_DISTRICTS = [
    ("Abu Ghraib", "أبو غريب"), ("Al-Taji", "التاجي"), ("Al-Tarmiyah", "الطارمية"), ("Al-Shaab", "الشعب"),
    ("Sadr City", "مدينة الصدر"), ("Al-Rashid", "الرشيد"), ("Al-Karrada", "الكرادة"), ("Al-Mansour", "المنصور"),
    ("Al-Karmah", "الكرمة"), ("Habbaniyah", "الحبانية"), ("Amiriyat al-Fallujah", "عامرية الفلوجة"),
    ("Al-Khalidiyah", "الخالدية"), ("Rawa", "راوة"), ("Al-Saqlawiyah", "الصقلاوية"), ("Al-Baghdadi", "البغدادي"),
    ("Al-Walid", "الوليد"), ("Al-Qasim", "القاسم"), ("Iskandariya", "الإسكندرية"), ("Jurf al-Sakhar", "جرف الصخر"),
    ("Al-Mashroo", "المشروع"), ("Al-Kifl", "الكفل"), ("Al-Husainiya", "الحسينية"), ("Al-Khairat", "الخيرات"),
    ("Al-Jadwal al-Gharbi", "الجدول الغربي"), ("Al-Haidariya", "الحيدرية"), ("Al-Hirah", "الحيرة"),
    ("Al-Abbasiyah", "العباسية"), ("Al-Shabakah", "الشبكة"), ("Al-Daghghara", "الدغارة"), ("Al-Shanafiyah", "الشنافية"),
    ("Ghammas", "غماس"), ("Al-Sunniyah", "السنية"), ("Al-Aziziyah", "العزيزية"), ("Al-Zubaidiyah", "الزبيدية"),
    ("Jassan", "جصان"), ("Al-Shuhaimiyah", "الشحيمية"), ("Al-Ahrar", "الأحرار"), ("Al-Hartha", "الهارثة"),
    ("Al-Deir", "الدير"), ("Umm Qasr", "أم قصر"), ("Safwan", "صفوان"), ("Al-Seba", "السيبة"),
    ("Kan'an", "كنعان"), ("Abu Saida", "أبو صيدا"), ("Al-Saadiya", "السعدية"), ("Jalawla", "جلولاء"),
    ("Al-Mansouriya", "المنصورية"), ("Hibhib", "هبهب"), ("Qara Tapa", "قره تبة"), ("Al-Udhaim", "العظيم"),
    ("Al-Dujail", "الدجيل"), ("Al-Ishaqi", "الإسحاقي"), ("Yathrib", "يثرب"), ("Al-Alam", "العلم"),
    ("Al-Dhuluiya", "الضلوعية"), ("Amerli", "آمرلي"), ("Al-Shura", "الشورة"), ("Al-Qayyarah", "القيارة"),
    ("Rabia", "ربيعة"), ("Zummar", "زمار"), ("Bashiqa", "بعشيقة"), ("Bartella", "برطلة"), ("Al-Qahtaniya", "القحطانية"),
    ("Al-Riyadh", "الرياض"), ("Al-Rashad", "الرشاد"), ("Altun Kupri", "ألتون كوبري"), ("Al-Fajr", "الفجر"),
    ("Sayyid Dakhil", "سيد دخيل"), ("Al-Islah", "الإصلاح"), ("Qalat Sukkar", "قلعة سكر"), ("Al-Nasr", "النصر"),
    ("Al-Dawaya", "الدواية"), ("Al-Gharraf", "الغراف"), ("Kumait", "كميت"), ("Al-Salam", "السلام"),
    ("Al-Adl", "العدل"), ("Al-Uzair", "العزير"), ("Al-Warka", "الوركاء"), ("Al-Suwair", "السوير"),
    ("Al-Hilal", "الهلال"), ("Busayyah", "بصية"), ("Mergasur", "ميركسور"), ("Soran", "سوران"),
    ("Said Sadiq", "سيد صادق"), ("Qaradagh", "قره داغ"),
]

_BULK = {"running": False, "done": 0, "total": 0, "added": [], "failed": []}


def _extras_path() -> str:
    return os.path.join(_home(), "admin_extra.json")


def _fetch_one(en: str, ar: str) -> bool:
    ref = AdminRef.get()
    if ref.knows_district(ar, en):
        return True
    found = adminfetch.by_name(f"{en}, Iraq")
    for f in found:
        f.name_en, f.name_ar = en, ar
        if adminfetch.add(ref, f, _extras_path()) is not None:
            return True
    return False


def _bulk_job():
    _BULK.update(running=True, done=0, total=len(EXTRA_DISTRICTS), added=[], failed=[])
    for en, ar in EXTRA_DISTRICTS:
        try:
            ok = _fetch_one(en, ar)
        except Exception:  # noqa: BLE001
            ok = False
        (_BULK["added"] if ok else _BULK["failed"]).append(ar)
        _BULK["done"] += 1
        time.sleep(1.2)      # سياسة Nominatim: طلب واحد في الثانية
    _BULK["running"] = False


# ---------------------------------------------------------------- أدوات التحليل
def _wrap(src, label, geom, feats):
    return an._new_layer(src, label, geom, feats)


def _tool_defs():
    return [
        {"id": "buffer", "ar": "حرم (Buffer) حول المعالم", "params": [["dist", "المسافة (م)", 200]]},
        {"id": "rings", "ar": "حلقات متعددة", "params": [["dists", "المسافات (م) مفصولة بفواصل", "100,300,500"]]},
        {"id": "density", "ar": "شبكة كثافة", "params": [["cell", "حجم الخلية (م)", 500]]},
        {"id": "clusters", "ar": "تجمعات (DBSCAN)", "params": [["eps", "المسافة (م)", 500], ["min", "أقل عدد", 3]]},
        {"id": "thiessen", "ar": "مضلعات ثيسن", "params": []},
        {"id": "hull", "ar": "الغلاف المحدّب لكل المعالم", "params": []},
        {"id": "hull_sector", "ar": "غلاف محدّب لكل قطاع", "params": []},
        {"id": "bbox", "ar": "المستطيل المحيط", "params": []},
        {"id": "path", "ar": "مسار يصل المعالم", "params": [["closed", "إغلاق المسار (1/0)", 0], ["byname", "ترتيب بالاسم (1/0)", 0]]},
        {"id": "radius", "ar": "المعالم ضمن نصف قطر من مركز الشاشة", "params": [["r", "نصف القطر (م)", 1000]]},
        {"id": "filter", "ar": "تصفية بحقل ونص", "params": [["field", "الحقل (name/type/Gategory/gathaa/Nahia/mohafadha)", "Gategory"], ["text", "النص", ""]]},
        {"id": "centre", "ar": "المركز الوسطي", "params": []},
        {"id": "ring_area", "ar": "دائرة بنصف قطر حول مركز الشاشة", "params": [["r", "نصف القطر (م)", 1000]]},
    ]


FIELDS = {n.lower(): i for i, n in enumerate(["name", "type", "Gategory", "gathaa", "Nahia", "mohafadha"])}


def run_tool(tool: str, p: dict, src: Layer, centre) -> list:
    if not src.features:
        raise ValueError("لا توجد معالم محفوظة")
    f = lambda k, d: float(p.get(k, d))       # noqa: E731
    if tool == "buffer":
        return [an.multi_ring(src, [f("dist", 200)])]
    if tool == "rings":
        ds = [float(x) for x in str(p.get("dists", "100,300,500")).replace("،", ",").split(",") if x.strip()]
        return [an.multi_ring(src, ds)]
    if tool == "density":
        return [an.density_grid(src, f("cell", 500))]
    if tool == "clusters":
        return an.cluster_layers(src, f("eps", 500), int(f("min", 3)), True)
    if tool == "thiessen":
        return [an.thiessen(src)]
    if tool == "hull":
        h = geoops.convex_hull_feature(src.features)
        if h is None:
            raise ValueError("عدد النقاط غير كافٍ")
        h.name = "الغلاف المحدّب"
        return [_wrap(src, "الغلاف المحدّب", POLYGON, [h])]
    if tool == "hull_sector":
        return [an.hull_by(src, 2)]
    if tool == "bbox":
        return [an.bounding_rectangles(src)]
    if tool == "path":
        return [an.point_path(src, str(p.get("closed", 0)) == "1", str(p.get("byname", 0)) == "1")]
    if tool == "radius":
        return [an.within_radius(src, centre[0], centre[1], f("r", 1000))]
    if tool == "filter":
        idx = FIELDS.get(str(p.get("field", "Gategory")).lower())
        if idx is None:
            raise ValueError("حقل غير معروف")
        return [an.filter_layer(src, idx, str(p.get("text", "")))]
    if tool == "centre":
        c = an.mean_centre(src)
        return [_wrap(src, "المركز الوسطي", POINT, [c])]
    if tool == "ring_area":
        c = Feature.point(centre[0], centre[1], id=Feature.new_id(), name="المركز")
        tmp = _wrap(src, "مركز", POINT, [c])
        return [an.multi_ring(tmp, [f("r", 1000)])]
    raise ValueError("أداة غير معروفة")


_RESULTS: dict = {}


def register(app, layer_fn):
    """layer_fn() ← طبقة المعالم الحالية."""
    # أقضية OSM المحفوظة سابقاً
    try:
        adminfetch.restore(AdminRef.get(), _extras_path())
    except Exception:  # noqa: BLE001
        pass

    # ------------------------------------------------ صور جوية
    @app.get("/api/rasters")
    def rasters_list():
        return jsonify([{"id": i.id, "name": i.name, "bounds": i.bounds(), "opacity": i.opacity, "visible": i.visible, "note": i.note}
                        for i in raster_store().items])

    @app.post("/api/rasters")
    def rasters_add():
        up = request.files.get("file")
        if up is None:
            return jsonify(error="لا يوجد ملف"), 400
        d = tempfile.mkdtemp()
        path = os.path.join(d, os.path.basename(up.filename or "image"))
        up.save(path)
        wf = request.files.get("world")
        if wf is not None:                                            # World file اختياري بجانب الصورة
            wf.save(os.path.splitext(path)[0] + (".tfw" if path.lower().endswith((".tif", ".tiff")) else ".wld"))
        bounds = None
        if request.form.get("bounds"):
            try:
                w, s, e, n = (float(x) for x in request.form["bounds"].split(","))
                bounds = (w, s, e, n)
            except ValueError:
                return jsonify(error="الحدود: west,south,east,north"), 400
        try:
            it = raster_store().import_file(path, up.filename, bounds)
        except (ValueError, IOError) as e:
            return jsonify(error=str(e)), 400
        return jsonify(id=it.id, name=it.name, bounds=it.bounds(), note=it.note)

    @app.get("/api/rasters/<rid>.png")
    def raster_png(rid):
        st = raster_store()
        it = next((i for i in st.items if i.id == rid), None)
        if not it:
            return jsonify(error="غير موجود"), 404
        return send_file(os.path.join(st.folder, it.file), mimetype="image/png")

    @app.post("/api/rasters/<rid>")
    def raster_update(rid):
        j = request.get_json(force=True)
        raster_store().update(rid, opacity=j.get("opacity"), visible=j.get("visible"))
        return jsonify(ok=True)

    @app.delete("/api/rasters/<rid>")
    def raster_del(rid):
        raster_store().remove(rid)
        return jsonify(ok=True)

    # ------------------------------------------------ عناصر الخريطة
    @app.get("/api/annotations")
    def ann_list():
        return jsonify([i.__dict__ for i in load_annotations().items])

    @app.post("/api/annotations")
    def ann_add():
        a = load_annotations()
        if request.files.get("file"):
            up = request.files["file"]
            d = os.path.join(_home(), "ann_files")
            os.makedirs(d, exist_ok=True)
            name = uuid.uuid4().hex + ".png"
            from PIL import Image
            try:
                im = Image.open(up.stream).convert("RGBA")
            except Exception:  # noqa: BLE001
                return jsonify(error="صورة غير صالحة"), 400
            im.thumbnail((800, 800))
            im.save(os.path.join(d, name))
            it = Item(kind=IMAGE, lat=float(request.form["lat"]), lon=float(request.form["lon"]), file=name,
                      width=int(request.form.get("width", 96)))
        else:
            j = request.get_json(force=True)
            col = str(j.get("color", "#000000")).lstrip("#")
            it = Item(kind=TEXT, lat=float(j["lat"]), lon=float(j["lon"]), text=str(j.get("text", "")),
                      size=float(j.get("size", 14)), color=0xFF000000 | int(col, 16))
        a.add(it)
        save_annotations(a)
        return jsonify(it.__dict__)

    @app.get("/api/annotations/<aid>/file")
    def ann_file(aid):
        it = load_annotations().find(aid)
        if not it or not it.file:
            return jsonify(error="غير موجود"), 404
        return send_file(os.path.join(_home(), "ann_files", os.path.basename(it.file)), mimetype="image/png")

    @app.delete("/api/annotations/<aid>")
    def ann_del(aid):
        a = load_annotations()
        a.remove(aid)
        save_annotations(a)
        return jsonify(ok=True)

    # ------------------------------------------------ أقضية OSM
    @app.post("/api/admin/fetch")
    def admin_fetch():
        j = request.get_json(force=True)
        q = (j.get("query") or "").strip()
        if not q:
            return jsonify(error="اكتب اسم القضاء"), 400
        try:
            found = adminfetch.by_name(q + (", Iraq" if "iraq" not in q.lower() else ""))
        except Exception as e:  # noqa: BLE001
            return jsonify(error="تعذّر الاتصال: %s" % e), 502
        if not found:
            return jsonify(error="لم يُعثر على حدود لهذا الاسم"), 404
        f = found[0]
        if j.get("name_ar"):
            f.name_ar = j["name_ar"]
        if j.get("name_en"):
            f.name_en = j["name_en"]
        u = adminfetch.add(AdminRef.get(), f, _extras_path())
        return jsonify(added=bool(u), name=f.name_ar or f.name_en, detail=f.detail)

    @app.post("/api/admin/bulk")
    def admin_bulk():
        if not _BULK["running"]:
            threading.Thread(target=_bulk_job, daemon=True).start()
        return jsonify(started=True)

    @app.get("/api/admin/status")
    def admin_status():
        return jsonify(**{k: v for k, v in _BULK.items()}, total_known=len(AdminRef.get().adm2))

    # ------------------------------------------------ الأدوات
    @app.get("/api/tools")
    def tools_list():
        return jsonify(_tool_defs())

    @app.post("/api/tools/run")
    def tools_run():
        j = request.get_json(force=True)
        try:
            layers = run_tool(j["tool"], j.get("params", {}), layer_fn(), (float(j.get("lat", 0)), float(j.get("lon", 0))))
        except (ValueError, KeyError) as e:
            return jsonify(error=str(e)), 400
        rid = uuid.uuid4().hex[:10]
        if len(_RESULTS) > 20:
            _RESULTS.pop(next(iter(_RESULTS)))
        _RESULTS[rid] = layers
        path = os.path.join(tempfile.mkdtemp(), "r.geojson")
        formats.export_layers(layers, "geojson", path)
        return jsonify(id=rid, geojson=json.load(open(path, encoding="utf-8")),
                       count=sum(len(l.features) for l in layers))

    @app.get("/api/tools/<rid>/export")
    def tools_export(rid):
        layers = _RESULTS.get(rid)
        fmt = request.args.get("format", "geojson")
        if not layers or fmt not in formats.FORMATS:
            return jsonify(error="النتيجة غير متوفرة"), 404
        path = os.path.join(tempfile.mkdtemp(), "result" + formats.EXT[fmt])
        formats.export_layers(layers, fmt, path)
        return send_file(path, as_attachment=True, download_name="result" + formats.EXT[fmt])

    # ------------------------------------------------ الحدود الإدارية للتصدير
    @app.get("/api/admin/export")
    def admin_export():
        level = int(request.args.get("level", 2))
        fmt = request.args.get("format", "geojson")
        if level not in (1, 2) or fmt not in formats.FORMATS:
            return jsonify(error="مدخلات غير صالحة"), 400
        lay = AdminRef.get().layer(level, True, request.args.get("parent") or None)
        if not lay.features:
            return jsonify(error="لا توجد حدود"), 404
        path = os.path.join(tempfile.mkdtemp(), "admin" + formats.EXT[fmt])
        formats.export_layers([lay], fmt, path)
        return send_file(path, as_attachment=True, download_name=("governorates" if level == 1 else "districts") + formats.EXT[fmt])

    @app.get("/api/admin/governorates")
    def admin_govs():
        return jsonify([{"en": g.name_en, "ar": g.name_ar} for g in AdminRef.get().units(1)])

    # ------------------------------------------------ بلاطات الخريطة مع ذاكرة تخزين (تعمل دون اتصال لما سبق عرضه)
    SOURCES = {"osm": "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
               "sat": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"}

    @app.get("/tiles/<src>/<int:z>/<int:x>/<int:y>")
    def tile(src, z, x, y):
        if src not in SOURCES or not (0 <= z <= 19):
            return "", 404
        d = os.path.join(_home(), "tiles", src, str(z), str(x))
        f = os.path.join(d, str(y) + ".png")
        hdr = {"Cache-Control": "public, max-age=86400"}
        if os.path.exists(f):
            return send_file(f, mimetype="image/png"), 200, hdr
        try:
            req = urllib.request.Request(SOURCES[src].format(z=z, x=x, y=y), headers={"User-Agent": "POIExporter/3.6 (personal use)"})
            with urllib.request.urlopen(req, timeout=15) as r:
                data = r.read()
        except Exception:  # noqa: BLE001
            return "", 404
        os.makedirs(d, exist_ok=True)
        with open(f, "wb") as fh:
            fh.write(data)
        return data, 200, {"Content-Type": "image/png", **hdr}

    @app.get("/api/tiles/size")
    def tiles_size():
        tot = n = 0
        for r, _, fs in os.walk(os.path.join(_home(), "tiles")):
            for fn in fs:
                tot += os.path.getsize(os.path.join(r, fn))
                n += 1
        return jsonify(files=n, mb=round(tot / 1048576, 1))

    @app.delete("/api/tiles")
    def tiles_clear():
        import shutil
        shutil.rmtree(os.path.join(_home(), "tiles"), ignore_errors=True)
        return jsonify(ok=True)

    # ------------------------------------------------ ملفات Leaflet المحلية (تُنزَّل أثناء البناء)
    @app.get("/static/leaflet/<path:name>")
    def leaflet_static(name):
        import pkgutil
        if ".." in name or name.startswith("/") or name == ".keep":
            return "", 404
        try:
            data = pkgutil.get_data("poi_exporter", "static/leaflet/" + name)
        except (OSError, ValueError):
            data = None
        if not data:
            return "", 404
        import mimetypes
        return data, 200, {"Content-Type": mimetypes.guess_type(name)[0] or "application/octet-stream", "Cache-Control": "public, max-age=604800"}

    # ------------------------------------------------ بطاقة المركز بطلب واحد (أسرع من طلبين)
    @app.get("/api/center")
    def center():
        from .coords import format_coord
        try:
            lat, lon = float(request.args["lat"]), float(request.args["lon"])
        except (KeyError, ValueError):
            return jsonify(error="?"), 400
        out = {f: format_coord(f, lat, lon) for f in ("DD", "DMS", "DDM", "UTM", "MGRS")}
        try:
            h = AdminRef.get().locate(lat, lon)
            out.update(qadaa=h.qadaa(), governorate=h.governorate_name())
        except Exception:  # noqa: BLE001
            out.update(qadaa="", governorate="")
        return jsonify(out)

    # ------------------------------------------------ قوالب الإدخال السريع
    def _tpl_path():
        return os.path.join(_home(), "templates.json")

    def _tpl_load():
        from .sectors import templates_from_json
        p = _tpl_path()
        return templates_from_json(open(p, encoding="utf-8").read()) if os.path.exists(p) else []

    @app.get("/api/templates")
    def tpl_list():
        return jsonify([t.__dict__ for t in _tpl_load()])

    @app.post("/api/templates")
    def tpl_add():
        from .sectors import Template, templates_to_json
        j = request.get_json(force=True)
        nm = (j.get("name") or "").strip()
        if not nm:
            return jsonify(error="اكتب اسم القالب"), 400
        lst = [t for t in _tpl_load() if t.name != nm]
        lst.append(Template(name=nm, type=(j.get("type") or "").strip(), category=(j.get("category") or "").strip(),
                            nahiya=(j.get("nahiya") or "").strip()))
        open(_tpl_path(), "w", encoding="utf-8").write(templates_to_json(lst))
        return jsonify(ok=True)

    @app.delete("/api/templates/<path:name>")
    def tpl_del(name):
        from .sectors import templates_to_json
        lst = [t for t in _tpl_load() if t.name != name]
        open(_tpl_path(), "w", encoding="utf-8").write(templates_to_json(lst))
        return jsonify(ok=True)

    # ------------------------------------------------ قوالب التقرير
    def _rtpl_path():
        return os.path.join(_home(), "report_templates.json")

    def _rtpl_load():
        try:
            return json.load(open(_rtpl_path(), encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    @app.get("/api/report-templates")
    def rtpl_list():
        return jsonify(_rtpl_load())

    @app.post("/api/report-templates")
    def rtpl_add():
        j = request.get_json(force=True)
        nm = (j.get("name") or "").strip()
        if not nm:
            return jsonify(error="اكتب اسم القالب"), 400
        d = _rtpl_load()
        d[nm] = {k: j.get(k) for k in ("title", "paper", "fmt", "portrait", "grid", "legend", "table", "by_sector", "dpi")}
        json.dump(d, open(_rtpl_path(), "w", encoding="utf-8"), ensure_ascii=False)
        return jsonify(ok=True)

    @app.delete("/api/report-templates/<path:name>")
    def rtpl_del(name):
        d = _rtpl_load()
        d.pop(name, None)
        json.dump(d, open(_rtpl_path(), "w", encoding="utf-8"), ensure_ascii=False)
        return jsonify(ok=True)
