"""الصور الجوية: قارئ TIFF/GeoTIFF بالبايثون (بلا ضغط، LZW، Deflate، PackBits، BigTIFF، مبلّط، Predictor، 8/16/32 بت،
ألوان/رمادي/لوحة/CMYK) + JPG/PNG/WebP/BMP/GIF مع World file أو حدود + مخزن صور + إسقاطها على الخريطة المطبوعة."""
from __future__ import annotations

import json
import os
import re
import struct
import zlib
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from .coords import Crs

MAX_SIDE = 2048

T_W, T_H, T_BITS, T_COMP, T_PHOTO, T_STRIP_OFF, T_SPP, T_ROWS = 256, 257, 258, 259, 262, 273, 277, 278
T_STRIP_CNT, T_PLANAR, T_PRED, T_CMAP, T_TW, T_TH, T_TILE_OFF, T_TILE_CNT = 279, 284, 317, 320, 322, 323, 324, 325
T_EXTRA, T_SFMT, T_SCALE, T_TIE, T_MATRIX, T_GEOKEYS, T_NODATA = 338, 339, 33550, 33922, 34264, 34735, 42113
# نوع TIFF → (حجم، رمز struct)
_TYPES = {1: (1, "B"), 2: (1, "c"), 3: (2, "H"), 4: (4, "I"), 5: (8, None), 6: (1, "b"), 7: (1, "B"), 8: (2, "h"),
          9: (4, "i"), 10: (8, None), 11: (4, "f"), 12: (8, "d"), 13: (4, "I"), 16: (8, "Q"), 17: (8, "q"), 18: (8, "Q")}


@dataclass
class RasterImage:
    src_w: int = 0
    src_h: int = 0
    w: int = 0
    h: int = 0
    step: int = 1
    rgba: Optional[np.ndarray] = None     # h×w×4 uint8
    affine: Optional[List[float]] = None  # x=a*col+b*row+c ; y=d*col+e*row+f (زوايا البكسل)
    epsg: int = 0
    note: str = ""

    def to_pil(self):
        from PIL import Image
        return Image.fromarray(self.rgba, "RGBA")


class TiffError(IOError):
    pass


# ---------------------------------------------------------------------------- فك الضغط
def packbits(data: bytes, need: int) -> bytes:
    out = bytearray()
    i, n = 0, len(data)
    while i < n and len(out) < need:
        c = data[i]
        i += 1
        if c < 128:
            out += data[i:i + c + 1]
            i += c + 1
        elif c > 128:
            if i >= n:
                break
            out += data[i:i + 1] * (257 - c)
            i += 1
    return bytes(out[:need])


def lzw(data: bytes, need: int) -> bytes:
    """LZW الخاص بـ TIFF (MSB أولاً، تغيير مبكر)."""
    out = bytearray()
    table: List[bytes] = [bytes([i]) for i in range(256)] + [b"", b""]
    bits, nbits, buf, pos, prev = 9, 0, 0, 0, None
    n = len(data)
    while True:
        while nbits < bits and pos < n:
            buf = (buf << 8) | data[pos]
            pos += 1
            nbits += 8
        if nbits < bits:
            break
        code = (buf >> (nbits - bits)) & ((1 << bits) - 1)
        nbits -= bits
        buf &= (1 << nbits) - 1
        if code == 257:
            break
        if code == 256:
            table = table[:258]
            bits, prev = 9, None
            continue
        if prev is None:
            if code >= len(table):
                break
            entry = table[code]
        else:
            if code < len(table):
                entry = table[code]
                table.append(prev + entry[:1])
            else:
                entry = prev + prev[:1]
                table.append(entry)
        out += entry
        prev = entry
        ln = len(table)
        bits = 9 if ln < 511 else 10 if ln < 1023 else 11 if ln < 2047 else 12
        if len(out) >= need:
            break
    return bytes(out[:need])


def _inflate(comp: int, buf: bytes, need: int) -> bytes:
    if comp == 1:
        return buf[:need]
    if comp == 5:
        return lzw(buf, need)
    if comp in (8, 32946):
        try:
            return zlib.decompress(buf)[:need]
        except zlib.error:
            d = zlib.decompressobj()
            return d.decompress(buf)[:need]
    if comp == 32773:
        return packbits(buf, need)
    raise TiffError(f"TIFF compression {comp} is not supported")


# ---------------------------------------------------------------------------- IFD
def _read_ifd(f, off: int, e: str, big: bool) -> Dict[int, object]:
    f.seek(off)
    cnt_fmt, ent_size, off_size = (("Q", 20, 8) if big else ("H", 12, 4))
    n = struct.unpack(e + cnt_fmt, f.read(8 if big else 2))[0]
    raw = f.read(n * ent_size)
    tags: Dict[int, object] = {}
    for i in range(n):
        ent = raw[i * ent_size:(i + 1) * ent_size]
        if big:
            tag, typ, count = struct.unpack(e + "HHQ", ent[:12])
            val = ent[12:20]
        else:
            tag, typ, count = struct.unpack(e + "HHI", ent[:8])
            val = ent[8:12]
        if typ not in _TYPES:
            continue
        size, ch = _TYPES[typ]
        total = size * count if typ not in (5, 10) else 8 * count
        if total <= off_size:
            data = val[:total]
        else:
            ptr = struct.unpack(e + ("Q" if big else "I"), val)[0]
            here = f.tell()
            f.seek(ptr)
            data = f.read(total)
            f.seek(here)
        if typ == 2:
            tags[tag] = data.rstrip(b"\0").decode("latin-1")
        elif typ in (5, 10):
            fmt = e + ("II" if typ == 5 else "ii") * count
            v = struct.unpack(fmt, data)
            tags[tag] = [v[k] / v[k + 1] if v[k + 1] else 0.0 for k in range(0, len(v), 2)]
        else:
            tags[tag] = list(struct.unpack(e + ch * count, data[:size * count]))
    return tags


def _one(tags, tag, default):
    v = tags.get(tag)
    return default if not v else (v[0] if isinstance(v, list) else v)


def read_tiff(path: str, max_side: int = MAX_SIDE) -> RasterImage:
    with open(path, "rb") as f:
        head = f.read(8)
        if head[:2] == b"II":
            e = "<"
        elif head[:2] == b"MM":
            e = ">"
        else:
            raise TiffError("Not a TIFF file")
        magic = struct.unpack(e + "H", head[2:4])[0]
        if magic not in (42, 43):
            raise TiffError("Not a TIFF file")
        big = magic == 43
        if big:
            ifd_off = struct.unpack(e + "Q", f.read(8))[0]
        else:
            ifd_off = struct.unpack(e + "I", head[4:8])[0]
        tags = _read_ifd(f, ifd_off, e, big)
        return _decode(f, tags, e, max_side)


def _decode(f, tags, e: str, max_side: int) -> RasterImage:
    W, H = int(_one(tags, T_W, 0)), int(_one(tags, T_H, 0))
    if W <= 0 or H <= 0:
        raise TiffError("Image has no size")
    comp, photo, spp = _one(tags, T_COMP, 1), _one(tags, T_PHOTO, 1), _one(tags, T_SPP, 1)
    planar, pred, sfmt = _one(tags, T_PLANAR, 1), _one(tags, T_PRED, 1), _one(tags, T_SFMT, 1)
    bl = tags.get(T_BITS) or [1]
    bits = bl[0]
    if any(b != bits for b in bl):
        raise TiffError("Mixed sample sizes are not supported")
    if planar != 1:
        raise TiffError("TIFF with separate colour planes is not supported")
    if comp in (7, 6, 34712, 34925, 50000):
        raise TiffError("TIFF compression is not supported (JPEG/JPEG2000/LERC/ZSTD). Convert it first, "
                        "e.g. gdal_translate -co COMPRESS=DEFLATE in.tif out.tif")
    if comp not in (1, 5, 8, 32946, 32773):
        raise TiffError(f"TIFF compression {comp} is not supported")
    if photo in (6, 8, 9, 10):
        raise TiffError("YCbCr/Lab TIFF is not supported")
    if bits not in (1, 8, 16, 32):
        raise TiffError(f"{bits}-bit TIFF is not supported")
    if bits == 32 and sfmt not in (1, 3):
        raise TiffError("32-bit integer TIFF is not supported")
    if (pred == 2 and bits not in (8, 16)) or pred > 2:
        raise TiffError(f"TIFF predictor {pred} is not supported")
    tiled = T_TW in tags and T_TILE_OFF in tags
    offs = tags.get(T_TILE_OFF if tiled else T_STRIP_OFF)
    cnts = tags.get(T_TILE_CNT if tiled else T_STRIP_CNT)
    if not offs:
        raise TiffError("TIFF has no image data")
    uw = int(_one(tags, T_TW, 0)) if tiled else W
    uh = int(_one(tags, T_TH, 0)) if tiled else int(min(H, _one(tags, T_ROWS, H)))
    if uw <= 0 or uh <= 0:
        raise TiffError("Bad TIFF block size")
    if photo == 3 and bits != 8:
        raise TiffError("Palette TIFF must be 8-bit")
    cmap = tags.get(T_CMAP)
    if photo == 3 and not cmap:
        raise TiffError("Palette TIFF without colour map")
    nb = 3 if photo in (2, 5) and spp >= 3 else 1
    step = max(1, int(np.ceil(max(W, H) / max(16, max_side if bits == 8 else min(max_side, 1600)))))
    w, h = (W + step - 1) // step, (H + step - 1) // step
    eight = bits in (1, 8) or photo == 3
    extra = tags.get(T_EXTRA) or []
    alpha = bool(extra) and extra[0] in (1, 2) and ((photo == 2 and spp >= 4) or (photo in (0, 1) and spp == 2))
    nodata = float("nan")
    nd = tags.get(T_NODATA)
    if isinstance(nd, str):
        try:
            nodata = float(nd.replace("|", "").strip())
        except ValueError:
            pass
    row_bytes = (uw * spp * bits + 7) // 8
    ua, ud = (W + uw - 1) // uw, (H + uh - 1) // uh
    if cnts is None and not tiled and len(offs) == 1:
        cnts = [os.fstat(f.fileno()).st_size - offs[0]]
    if cnts is None or len(cnts) < len(offs):
        raise TiffError("TIFF block sizes missing")
    if len(offs) < ua * ud:
        raise TiffError("TIFF has fewer blocks than expected")
    dt = {8: np.uint8, 16: np.dtype(e + ("i2" if sfmt == 2 else "u2")), 32: np.dtype(e + "f4")}.get(bits)
    out = np.zeros((h, w, spp), dtype=np.uint8 if eight else np.float32)
    if not eight:
        out[:] = np.nan
    for u in range(ua * ud):
        ux, uy = u % ua, u // ua
        x0, y0 = ux * uw, uy * uh
        rows = min(uh, H - y0)
        if cnts[u] <= 0:
            continue
        fy, fx = ((y0 + step - 1) // step) * step, ((x0 + step - 1) // step) * step
        if fy >= y0 + rows or fx >= min(W, x0 + uw):
            continue
        f.seek(offs[u])
        raw = _inflate(comp, f.read(cnts[u]), row_bytes * (uh if tiled else rows))
        nrows = uh if tiled else rows
        raw = raw.ljust(row_bytes * nrows, b"\0")
        if bits == 1:
            arr = np.unpackbits(np.frombuffer(raw, np.uint8).reshape(nrows, row_bytes), axis=1)[:, :uw].reshape(nrows, uw, 1)
        else:
            arr = np.frombuffer(raw, dtype=dt).reshape(nrows, uw, spp)
            if pred == 2:
                arr = np.cumsum(arr.astype(np.int64), axis=1).astype(dt) if bits != 8 else np.cumsum(arr, axis=1, dtype=np.uint8)
        sub = arr[fy - y0:rows:step, fx - x0:min(W - x0, uw):step]
        oy, ox = fy // step, fx // step
        out[oy:oy + sub.shape[0], ox:ox + sub.shape[1]] = sub
    if eight:
        rgba = _pixels8(out, bits, photo, spp, cmap, alpha)
    else:
        rgba = _stretch(out[:, :, :nb], nodata, photo == 0)
    img = RasterImage(W, H, w, h, step, rgba)
    _georef(tags, img)
    if step > 1:
        img.note = f"Shown at 1/{step} of the original resolution"
    return img


def _pixels8(a: np.ndarray, bits: int, photo: int, spp: int, cmap, alpha: bool) -> np.ndarray:
    h, w = a.shape[:2]
    rgba = np.full((h, w, 4), 255, np.uint8)
    if bits == 1:
        v = np.where((photo == 0) == (a[:, :, 0] == 1), 0, 255).astype(np.uint8)
        rgba[:, :, :3] = v[:, :, None]
    elif photo == 3:
        n = len(cmap) // 3
        cm = np.array(cmap, np.uint32).reshape(3, n)
        idx = np.minimum(a[:, :, 0].astype(np.int64), n - 1)
        for k in range(3):
            rgba[:, :, k] = ((cm[k][idx] >> 8) & 0xFF).astype(np.uint8)
    elif photo == 2 and spp >= 3:
        rgba[:, :, :3] = a[:, :, :3]
        if alpha:
            rgba[:, :, 3] = a[:, :, 3]
    elif photo == 5 and spp >= 4:
        c, m, y, k = (a[:, :, i].astype(np.int32) for i in range(4))
        rgba[:, :, 0] = ((255 - c) * (255 - k) // 255).astype(np.uint8)
        rgba[:, :, 1] = ((255 - m) * (255 - k) // 255).astype(np.uint8)
        rgba[:, :, 2] = ((255 - y) * (255 - k) // 255).astype(np.uint8)
    else:
        v = a[:, :, 0]
        if photo == 0:
            v = 255 - v
        rgba[:, :, :3] = v[:, :, None]
        if alpha:
            rgba[:, :, 3] = a[:, :, 1]
    return rgba


def _stretch(v: np.ndarray, nodata: float, white_is_zero: bool) -> np.ndarray:
    """تمديد 2%..98% للقيم 16 بت/عشرية؛ NaN وnodata تصبح شفافة."""
    h, w, nb = v.shape
    bad = ~np.isfinite(v)
    if not np.isnan(nodata):
        bad |= v == nodata
    bad_px = bad.any(axis=2)
    good = v[~bad]
    rgba = np.zeros((h, w, 4), np.uint8)
    if good.size == 0:
        return rgba
    mn, mx = float(good.min()), float(good.max())
    rng = max(1e-9, mx - mn)
    hist, _ = np.histogram(good, bins=1024, range=(mn, mn + rng))
    cum = np.cumsum(hist)
    cnt = cum[-1]
    lo_i = int(np.searchsorted(cum, cnt * 0.02))
    hi_i = int(np.searchsorted(cum, cnt * 0.98))
    lo, hi = mn + rng * lo_i / 1024, mn + rng * (hi_i + 1) / 1024
    if hi <= lo:
        lo, hi = mn, max(mx, mn + 1e-9)
    q = np.clip(np.rint((np.nan_to_num(v) - lo) * (255.0 / (hi - lo))), 0, 255).astype(np.uint8)
    if white_is_zero:
        q = 255 - q
    for k in range(3):
        rgba[:, :, k] = q[:, :, k if nb == 3 else 0]
    rgba[:, :, 3] = np.where(bad_px, 0, 255)
    rgba[bad_px, :3] = 0
    return rgba


def _georef(tags, img: RasterImage) -> None:
    m, scale, tie = tags.get(T_MATRIX), tags.get(T_SCALE), tags.get(T_TIE)
    keys = tags.get(T_GEOKEYS)
    point = False
    if keys and len(keys) >= 4:
        n = min(keys[3], (len(keys) - 4) // 4)
        geo = proj = 0
        for i in range(n):
            kid, loc, val = keys[4 + 4 * i], keys[5 + 4 * i], keys[7 + 4 * i]
            if loc != 0:
                continue
            if kid == 1025:
                point = val == 2
            elif kid == 2048:
                geo = val
            elif kid == 3072:
                proj = val
        if 0 < proj < 32767:
            img.epsg = proj
        elif 0 < geo < 32767:
            img.epsg = geo
    a = None
    if m and len(m) >= 16:
        a = [m[0], m[1], m[3], m[4], m[5], m[7]]
    elif scale and len(scale) >= 2 and tie and len(tie) >= 6:
        sx, sy = scale[0], scale[1]
        a = [sx, 0.0, tie[3] - tie[0] * sx, 0.0, -sy, tie[4] + tie[1] * sy]
    if a and point:
        a[2] -= (a[0] + a[1]) / 2
        a[5] -= (a[3] + a[4]) / 2
    img.affine = a


# ---------------------------------------------------------------------------- Georef
def corners(affine: Sequence[float], width: int, height: int, epsg: int = 0) -> List[float]:
    """زوايا الصورة lon,lat: أعلى-يسار، أعلى-يمين، أسفل-يمين، أسفل-يسار."""
    tx = Crs.of(epsg).transformer_to_wgs84() if epsg not in (0, 4326) else None
    out: List[float] = []
    for c, r in ((0, 0), (width, 0), (width, height), (0, height)):
        x = affine[0] * c + affine[1] * r + affine[2]
        y = affine[3] * c + affine[4] * r + affine[5]
        if tx:
            x, y = tx(x, y)
        out += [x, y]
    return out


def parse_world_file(text: str) -> List[float]:
    """ملف World من 6 أسطر (A, D, B, E, C, F) حيث C,F مركز البكسل العلوي الأيسر."""
    v: List[float] = []
    for l in text.strip().splitlines():
        t = l.strip()
        if not t:
            continue
        if len(v) >= 6:
            break
        try:
            v.append(float(t.replace(",", ".")))
        except ValueError:
            raise ValueError(f"World file line {len(v) + 1} is not a number")
    if len(v) < 6:
        raise ValueError("A world file has 6 numbers")
    a, d, b, e, c, f = v
    if (a == 0 and b == 0) or (e == 0 and d == 0):
        raise ValueError("World file has zero pixel size")
    return [a, b, c - a / 2 - b / 2, d, e, f - d / 2 - e / 2]


def from_bounds(west: float, south: float, east: float, north: float, width: int, height: int) -> List[float]:
    return [(east - west) / width, 0.0, west, 0.0, -(north - south) / height, north]


# ---------------------------------------------------------------------------- مخزن الصور
WORLD_EXT = {".jpg": ".jgw", ".jpeg": ".jgw", ".png": ".pgw", ".tif": ".tfw", ".tiff": ".tfw", ".bmp": ".bpw",
             ".gif": ".gfw", ".webp": ".wpw"}


@dataclass
class RasterItem:
    id: str
    name: str
    file: str                       # PNG مصغّر داخل المخزن
    w: int
    h: int
    corners: List[float]            # 4 أزواج lon,lat
    affine: List[float]
    epsg: int = 0
    opacity: float = 0.8
    visible: bool = True
    note: str = ""
    credit: str = ""

    def bounds(self) -> Tuple[float, float, float, float]:
        xs, ys = self.corners[0::2], self.corners[1::2]
        return min(xs), min(ys), max(xs), max(ys)


class RasterStore:
    """يخزّن كل صورة مرة واحدة كـ PNG بحد أقصى 2048 بكسل مع فهرس JSON."""

    def __init__(self, folder: str):
        self.folder = folder
        os.makedirs(folder, exist_ok=True)
        self.index_path = os.path.join(folder, "index.json")
        self.items: List[RasterItem] = []
        if os.path.exists(self.index_path):
            try:
                self.items = [RasterItem(**d) for d in json.load(open(self.index_path, encoding="utf-8"))]
            except (ValueError, TypeError):
                self.items = []

    def _save(self) -> None:
        json.dump([i.__dict__ for i in self.items], open(self.index_path, "w", encoding="utf-8"), ensure_ascii=False)

    def import_file(self, path: str, name: Optional[str] = None, bounds: Optional[Tuple[float, float, float, float]] = None,
                    epsg: Optional[int] = None) -> RasterItem:
        """TIFF/GeoTIFF يُقرأ مرجعه الجغرافي منه؛ بقية الصيغ تحتاج World file بجانبها أو حدوداً (w,s,e,n)."""
        from PIL import Image
        ext = os.path.splitext(path)[1].lower()
        img_note = ""
        if ext in (".tif", ".tiff"):
            try:
                r = read_tiff(path, MAX_SIDE)
                pil, affine, ep, sw, sh, img_note = r.to_pil(), r.affine, r.epsg, r.src_w, r.src_h, r.note
            except TiffError as err:
                if "not supported" in str(err) and ("compression" in str(err) or "YCbCr" in str(err)):
                    pil = Image.open(path).convert("RGBA")       # محاولة أخيرة عبر Pillow (JPEG داخل TIFF …)
                    r = None
                    affine, ep, sw, sh = None, 0, pil.width, pil.height
                    pil.thumbnail((MAX_SIDE, MAX_SIDE))
                else:
                    raise
        else:
            pil = Image.open(path).convert("RGBA")
            affine, ep, sw, sh = None, 0, pil.width, pil.height
            if max(pil.size) > MAX_SIDE:
                pil.thumbnail((MAX_SIDE, MAX_SIDE))
                img_note = f"Shown at reduced resolution ({pil.width}x{pil.height})"
        if bounds:
            affine, ep = from_bounds(*bounds, sw, sh), 0
        elif affine is None:
            wf = os.path.splitext(path)[0] + WORLD_EXT.get(ext, ".wld")
            if not os.path.exists(wf):
                wf = os.path.splitext(path)[0] + ".wld"
            if os.path.exists(wf):
                affine = parse_world_file(open(wf, encoding="utf-8", errors="ignore").read())
                ep = epsg if epsg is not None else 0
            else:
                raise ValueError("الصورة بلا مرجع جغرافي: أضف World file أو حدّد الحدود (west,south,east,north)")
        if epsg is not None:
            ep = epsg
        if ep not in (0, 4326):
            try:
                Crs.of(ep)
            except ValueError:
                raise ValueError(f"نظام الإحداثيات EPSG:{ep} غير معروف؛ حدّد الحدود يدوياً")
        iid = "r%d" % (len(self.items) + 1 + int.from_bytes(os.urandom(2), "big"))
        fn = f"{iid}.png"
        pil.save(os.path.join(self.folder, fn))
        item = RasterItem(iid, name or os.path.basename(path), fn, pil.width, pil.height,
                          corners(affine, sw, sh, ep), list(affine), ep, note=img_note)
        # الصورة المصغّرة: ضبط المصفوفة لتغطي نفس الامتداد
        item.affine = [affine[0] * sw / pil.width, affine[1] * sh / pil.height, affine[2],
                       affine[3] * sw / pil.width, affine[4] * sh / pil.height, affine[5]]
        self.items.append(item)
        self._save()
        return item

    def remove(self, item_id: str) -> None:
        for i in list(self.items):
            if i.id == item_id:
                try:
                    os.remove(os.path.join(self.folder, i.file))
                except OSError:
                    pass
                self.items.remove(i)
        self._save()

    def update(self, item_id: str, opacity: Optional[float] = None, visible: Optional[bool] = None) -> None:
        for i in self.items:
            if i.id == item_id:
                if opacity is not None:
                    i.opacity = max(0.0, min(1.0, opacity))
                if visible is not None:
                    i.visible = visible
        self._save()

    def image(self, item: RasterItem):
        from PIL import Image
        return Image.open(os.path.join(self.folder, item.file)).convert("RGBA")


def warp_to_frame(item: RasterItem, img, shown: Sequence[float], size_px: Tuple[int, int]):
    """يعيد أخذ عيّنات من الصورة داخل إطار الخريطة (west,south,east,north) بحجم size_px؛ يرجع RGBA أو None إن لم يتقاطع."""
    from PIL import Image
    W, H = size_px
    west, south, east, north = shown
    bw, bs, be, bn = item.bounds()
    if be < west or bw > east or bn < south or bs > north:
        return None
    a, b, c, d, e_, f_ = item.affine
    det = a * e_ - b * d
    if det == 0:
        return None
    to_src = Crs.of(item.epsg).transformer_from_wgs84() if item.epsg not in (0, 4326) else None
    gx, gy = max(2, min(W, 48)), max(2, min(H, 48))
    xs = np.linspace(0, W, gx)
    ys = np.linspace(0, H, gy)
    cs = np.zeros((gy, gx))
    rs = np.zeros((gy, gx))
    for j, py in enumerate(ys):
        lat = north - (north - south) * py / H
        for i, px in enumerate(xs):
            lon = west + (east - west) * px / W
            X, Y = to_src(lon, lat) if to_src else (lon, lat)
            cs[j, i] = (e_ * (X - c) - b * (Y - f_)) / det
            rs[j, i] = (-d * (X - c) + a * (Y - f_)) / det
    # استيفاء خطي للشبكة إلى كل بكسل
    full_c = np.empty((H, W))
    full_r = np.empty((H, W))
    px_idx = np.arange(W)
    py_idx = np.arange(H)
    tmp_c = np.array([np.interp(px_idx, xs, cs[j]) for j in range(gy)])
    tmp_r = np.array([np.interp(px_idx, xs, rs[j]) for j in range(gy)])
    for i in range(W):
        full_c[:, i] = np.interp(py_idx, ys, tmp_c[:, i])
        full_r[:, i] = np.interp(py_idx, ys, tmp_r[:, i])
    src = np.asarray(img)
    inside = (full_c >= 0) & (full_c < src.shape[1]) & (full_r >= 0) & (full_r < src.shape[0])
    if not inside.any():
        return None
    ci = np.clip(full_c.astype(int), 0, src.shape[1] - 1)
    ri = np.clip(full_r.astype(int), 0, src.shape[0] - 1)
    out = src[ri, ci].copy()
    out[~inside, 3] = 0
    out[:, :, 3] = (out[:, :, 3] * item.opacity).astype(np.uint8)
    return Image.fromarray(out, "RGBA")
