"""الطباعة والتقارير: خريطة متجهة PDF أو PNG (A5/A4/A3، أفقي/عمودي، مقياس تلقائي أو ثابت، شريط مقياس، سهم الشمال،
شبكة درجات أو UTM، دليل الخريطة) + جدول الخصائص name…link في صفحات لاحقة. لا تُدرج بلاطات الخرائط الأساسية."""
from __future__ import annotations

import io
import math
import os
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from . import landmark, sectors
from .annotations import IMAGE, Item
from .arabic import display
from .coords import Crs, zone_for
from .geo import bbox as feat_bbox
from .model import LINE, POINT, POLYGON, Feature, Layer

# ---------------------------------------------------------------------------- Paper & MapMath
@dataclass(frozen=True)
class Paper:
    name: str
    width_mm: float
    height_mm: float

    def orient(self, landscape: bool) -> "Paper":
        w, h = min(self.width_mm, self.height_mm), max(self.width_mm, self.height_mm)
        return Paper(self.name, h, w) if landscape else Paper(self.name, w, h)

    @property
    def width_pt(self) -> int:
        return round(mm_to_pt(self.width_mm))

    @property
    def height_pt(self) -> int:
        return round(mm_to_pt(self.height_mm))

    def width_px(self, dpi: int) -> int:
        return round(self.width_mm / 25.4 * dpi)

    def height_px(self, dpi: int) -> int:
        return round(self.height_mm / 25.4 * dpi)


A5, A4, A3 = Paper("A5", 148, 210), Paper("A4", 210, 297), Paper("A3", 297, 420)
PAPERS = {"A5": A5, "A4": A4, "A3": A3}


def paper_by_name(n: str) -> Paper:
    return PAPERS.get((n or "").upper(), A4)


def mm_to_pt(mm: float) -> float:
    return mm / 25.4 * 72.0


NICE_SCALES = [1000, 2000, 2500, 5000, 10000, 20000, 25000, 50000, 100000, 200000, 250000, 500000, 1000000, 2000000, 5000000]
_R = 6371008.8


def m_per_deg_lon(lat: float) -> float:
    return math.pi / 180 * _R * math.cos(math.radians(lat))


def m_per_deg_lat() -> float:
    return math.pi / 180 * _R


@dataclass
class Fit:
    exact_scale: float
    nice_scale: float
    shown: Tuple[float, float, float, float]
    width_m: float
    height_m: float

    @property
    def m_per_mm(self) -> float:
        return self.nice_scale / 1000.0


def fit(bbox: Sequence[float], frame_w_mm: float, frame_h_mm: float) -> Fit:
    """أصغر مقياس «جميل» يتسع عنده الصندوق كاملاً؛ وإن لم يوجد فالمقياس الدقيق."""
    lat0 = (bbox[1] + bbox[3]) / 2
    wm = max(1e-6, (bbox[2] - bbox[0]) * m_per_deg_lon(lat0))
    hm = max(1e-6, (bbox[3] - bbox[1]) * m_per_deg_lat())
    exact = max(wm / (frame_w_mm / 1000.0), hm / (frame_h_mm / 1000.0))
    nice = next((s for s in NICE_SCALES if s >= exact), exact)
    sw, sh = frame_w_mm / 1000.0 * nice, frame_h_mm / 1000.0 * nice
    cx = (bbox[0] + bbox[2]) / 2
    dlon, dlat = sw / 2 / m_per_deg_lon(lat0), sh / 2 / m_per_deg_lat()
    return Fit(exact, nice, (cx - dlon, lat0 - dlat, cx + dlon, lat0 + dlat), sw, sh)


def scale_for(m_per_pixel: float, dpi: float) -> float:
    return m_per_pixel * dpi / 0.0254


def m_per_pixel(scale: float, dpi: float) -> float:
    return scale * 0.0254 / dpi


def nice_scale_bar_length(max_m: float) -> float:
    if not max_m >= 1:
        return 1.0
    p = 10 ** math.floor(math.log10(max_m))
    for k in (5, 2, 1):
        if k * p <= max_m * (1 + 1e-12):
            return k * p
    return p


def scale_bar_label(metres: float, arabic: bool = True) -> str:
    if metres >= 1000:
        km = metres / 1000
        s = str(int(km)) if km == round(km) else "%.1f" % km
        return s + (" كم" if arabic else " km")
    return str(int(metres)) + (" م" if arabic else " m")


@dataclass
class GridLine:
    lonlat: List[Tuple[float, float]]
    label: str
    vertical: bool
    value: float


def nice_degree_step(span: float, target: int) -> float:
    raw = span / max(1, target)
    steps = [1 / 3600, 2 / 3600, 5 / 3600, 10 / 3600, 15 / 3600, 30 / 3600, 1 / 60, 2 / 60, 5 / 60, 10 / 60, 15 / 60, 30 / 60, 1, 2, 5, 10, 20, 30]
    return next((s for s in steps if s >= raw * 0.999), 30)


def deg_label(v: float, step: float, lon: bool, dms: bool) -> str:
    h = ("W" if v < 0 else "E") if lon else ("S" if v < 0 else "N")
    a = abs(v)
    if not dms:
        dec = 0 if step >= 1 else 1 if step >= 0.1 else 2 if step >= 0.01 else 3 if step >= 0.001 else 4
        return "%.*f°%s" % (dec, a, h)
    cs = round(a * 3600)
    d, m, s = cs // 3600, (cs % 3600) // 60, cs % 60
    if step >= 1:
        return "%d°%s" % (d, h)
    if step >= 1 / 60 - 1e-9:
        return "%d°%02d'%s" % (d, m, h)
    return "%d°%02d'%02d\"%s" % (d, m, s, h)


def graticule(bbox: Sequence[float], target: int = 6, dms: bool = False) -> List[GridLine]:
    res = []
    step = nice_degree_step(max(bbox[2] - bbox[0], bbox[3] - bbox[1]), target)
    lon = math.ceil(bbox[0] / step - 1e-9) * step
    while lon <= bbox[2] + 1e-12:
        v = round(lon / step) * step
        res.append(GridLine([(v, bbox[1]), (v, bbox[3])], deg_label(v, step, True, dms), True, v))
        lon += step
    lat = math.ceil(bbox[1] / step - 1e-9) * step
    while lat <= bbox[3] + 1e-12:
        v = round(lat / step) * step
        res.append(GridLine([(bbox[0], v), (bbox[2], v)], deg_label(v, step, False, dms), False, v))
        lat += step
    return res


def nice_metre_step(span: float, target: int) -> float:
    raw = span / max(1, target)
    p = 10 ** math.floor(math.log10(raw))
    for k in (1, 2, 5, 10):
        if k * p >= raw * 0.999:
            return k * p
    return 10 * p


def utm_grid(bbox: Sequence[float], utm: Crs, target: int = 6) -> List[GridLine]:
    """خطوط شبكة UTM (كم) كخطوط منحنية بإحداثيات lon/lat."""
    fwd, inv = utm.transformer_from_wgs84(), utm.transformer_to_wgs84()
    n = 20
    pts = [fwd(bbox[0] + (bbox[2] - bbox[0]) * i / n, bbox[1] + (bbox[3] - bbox[1]) * k / n) for i in range(n + 1) for k in range(n + 1)]
    e = (min(p[0] for p in pts), min(p[1] for p in pts), max(p[0] for p in pts), max(p[1] for p in pts))
    step = max(1000.0, nice_metre_step(max(e[2] - e[0], e[3] - e[1]), target))
    res, seg = [], 24
    x = math.ceil(e[0] / step) * step
    while x <= e[2]:
        res.append(GridLine([inv(x, e[1] + (e[3] - e[1]) * i / seg) for i in range(seg + 1)], "%d km E" % round(x / 1000), True, x))
        x += step
    y = math.ceil(e[1] / step) * step
    while y <= e[3]:
        res.append(GridLine([inv(e[0] + (e[2] - e[0]) * i / seg, y) for i in range(seg + 1)], "%d km N" % round(y / 1000), False, y))
        y += step
    return res


def north_arrow_angle(map_rotation: float) -> float:
    a = -map_rotation % 360
    return a + 360 if a < 0 else a


def grid_convergence(lon: float, lat: float, zone: int) -> float:
    cm = (zone - 1) * 6 - 180 + 3
    return math.degrees(math.atan(math.tan(math.radians(lon - cm)) * math.sin(math.radians(lat))))


@dataclass
class LegendEntry:
    label: str
    rgb: int
    geom: int
    count: int


# ---------------------------------------------------------------------------- ReportLayout
MARGIN_PT = mm_to_pt(10)
TITLE_H, FOOTER_H, SCALEBAR_H = 44.0, 22.0, 30.0
ROW_PT = 14.0


def pad_bbox(b: Sequence[float], frac: float) -> List[float]:
    b = list(b)
    w, h = b[2] - b[0], b[3] - b[1]
    min_span = 0.002
    if w < min_span:
        c = (b[0] + b[2]) / 2
        b[0], b[2], w = c - min_span / 2, c + min_span / 2, min_span
    if h < min_span:
        c = (b[1] + b[3]) / 2
        b[1], b[3], h = c - min_span / 2, c + min_span / 2, min_span
    return [b[0] - w * frac, b[1] - h * frac, b[2] + w * frac, b[3] + h * frac]


@dataclass
class ReportLayout:
    paper: Paper
    page_w: float
    page_h: float
    frame_x: float
    frame_y: float
    frame_w: float
    frame_h: float
    fit: Fit
    legend_y: float
    legend_h: float

    @property
    def shown(self):
        return self.fit.shown

    @staticmethod
    def compute(base: Paper, landscape: bool, bbox: Sequence[float], legend_rows: int = 0, fixed_scale: float = 0) -> "ReportLayout":
        p = base.orient(landscape)
        w, h = p.width_pt, p.height_pt
        legend_h = 0 if legend_rows <= 0 else 14 + 13 * min(legend_rows, 12)
        fx, fy = MARGIN_PT, MARGIN_PT + TITLE_H
        fw = w - 2 * MARGIN_PT
        fh = h - fy - MARGIN_PT - FOOTER_H - SCALEBAR_H - legend_h
        wmm, hmm = fw / 72 * 25.4, fh / 72 * 25.4
        if fixed_scale > 0:
            lat0, cx = (bbox[1] + bbox[3]) / 2, (bbox[0] + bbox[2]) / 2
            dlon = wmm / 1000.0 * fixed_scale / 2 / m_per_deg_lon(lat0)
            dlat = hmm / 1000.0 * fixed_scale / 2 / m_per_deg_lat()
            f = Fit(fixed_scale, fixed_scale, (cx - dlon, lat0 - dlat, cx + dlon, lat0 + dlat),
                    wmm / 1000.0 * fixed_scale, hmm / 1000.0 * fixed_scale)
        else:
            f = fit(pad_bbox(bbox, 0.05), wmm, hmm)
        return ReportLayout(p, w, h, fx, fy, fw, fh, f, fy + fh + SCALEBAR_H, legend_h)

    def px(self, lon: float) -> float:
        s = self.shown
        return self.frame_x + (lon - s[0]) / (s[2] - s[0]) * self.frame_w

    def py(self, lat: float) -> float:
        s = self.shown
        return self.frame_y + (s[3] - lat) / (s[3] - s[1]) * self.frame_h

    def bar_points(self, metres: float) -> float:
        return metres / self.fit.m_per_mm / 25.4 * 72

    def scale_bar_metres(self) -> float:
        max_mm = self.frame_w / 72 * 25.4 * 0.35
        return nice_scale_bar_length(max_mm * self.fit.m_per_mm)


def layers_extent(layers: Sequence[Layer]) -> Optional[List[float]]:
    r = None
    for l in layers:
        for f in l.features:
            b = (f.lon, f.lat, f.lon, f.lat) if f.geom == POINT or not f.parts else feat_bbox(f)
            if any(math.isnan(v) for v in b) or abs(b[0]) > 180 or abs(b[1]) > 90 or abs(b[2]) > 180 or abs(b[3]) > 90:
                continue
            r = list(b) if r is None else [min(r[0], b[0]), min(r[1], b[1]), max(r[2], b[2]), max(r[3], b[3])]
    return r


def table_rows(layers: Sequence[Layer], max_rows: int = 3000) -> List[List[str]]:
    rows = [list(landmark.NAMES)]
    for l in layers:
        for f in l.features:
            if f.geom != POINT:
                continue
            if len(rows) > max_rows:
                return rows
            x, y = landmark.xy(f, None)
            rows.append(landmark.text(f) + [landmark.num(x, 0), landmark.num(y, 0), landmark.link(f)])
    return rows


def rows_per_page(paper: Paper, landscape: bool, row_pt: float = ROW_PT) -> int:
    o = paper.orient(landscape)
    return max(5, int((o.height_pt - 2 * MARGIN_PT - 40) / row_pt) - 1)


# ---------------------------------------------------------------------------- ألوان وخطوط
PALETTE = [0xE8590C, 0x1C7ED6, 0x2B8A3E, 0xE03131, 0x862E9C, 0xF59F00, 0x15AABF, 0x5F3DC4]
_FONT_REG = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
_FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def _find_font(bold: bool) -> str:
    for p in ([_FONT_BOLD] if bold else [_FONT_REG]) + ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
              "/Library/Fonts/Arial Unicode.ttf", "C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"]:
        if os.path.exists(p):
            return p
    raise FileNotFoundError("لا يوجد خط يدعم العربية (ثبّت DejaVu Sans)")


def _rgb(c: int) -> Tuple[int, int, int]:
    return (c >> 16) & 255, (c >> 8) & 255, c & 255


# ---------------------------------------------------------------------------- واجهات الرسم
class _Canvas:
    def rect(self, x, y, w, h, fill=None, stroke=None, lw=1.0, alpha=1.0): ...
    def line(self, x1, y1, x2, y2, color=0, lw=1.0, alpha=1.0): ...
    def circle(self, x, y, r, fill=None, stroke=None, lw=1.0, alpha=1.0): ...
    def polyline(self, pts, color=0, lw=1.0, alpha=1.0): ...
    def polygon(self, rings, fill=None, stroke=None, lw=1.0, fill_alpha=1.0, alpha=1.0): ...
    def text(self, x, y, s, size=8, bold=False, color=0, anchor="l"): ...
    def image(self, pil, x, y, w, h, alpha=1.0): ...
    def width(self, s, size, bold=False) -> float: ...
    def new_page(self): ...


class PdfCanvas(_Canvas):
    def __init__(self, target, page_w: float, page_h: float):
        from reportlab.pdfgen import canvas
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        for name, bold in (("RptSans", False), ("RptSansB", True)):
            if name not in pdfmetrics.getRegisteredFontNames():
                pdfmetrics.registerFont(TTFont(name, _find_font(bold)))
        self.W, self.H = page_w, page_h
        self.c = canvas.Canvas(target, pagesize=(page_w, page_h))
        self.c.setTitle("POI Exporter")

    def _y(self, y):
        return self.H - y

    def _set(self, fill, stroke, lw, fa=1.0, sa=1.0):
        c = self.c
        if fill is not None:
            c.setFillColorRGB(*(v / 255 for v in _rgb(fill)))
            c.setFillAlpha(fa)
        if stroke is not None:
            c.setStrokeColorRGB(*(v / 255 for v in _rgb(stroke)))
            c.setStrokeAlpha(sa)
            c.setLineWidth(lw)

    def rect(self, x, y, w, h, fill=None, stroke=None, lw=1.0, alpha=1.0):
        self._set(fill, stroke, lw, alpha, alpha)
        self.c.rect(x, self._y(y + h), w, h, stroke=int(stroke is not None), fill=int(fill is not None))

    def line(self, x1, y1, x2, y2, color=0, lw=1.0, alpha=1.0):
        self._set(None, color, lw, 1, alpha)
        self.c.line(x1, self._y(y1), x2, self._y(y2))

    def circle(self, x, y, r, fill=None, stroke=None, lw=1.0, alpha=1.0):
        self._set(fill, stroke, lw, alpha, alpha)
        self.c.circle(x, self._y(y), r, stroke=int(stroke is not None), fill=int(fill is not None))

    def _path(self, rings, close):
        p = self.c.beginPath()
        for r in rings:
            for i, (x, y) in enumerate(r):
                (p.moveTo if i == 0 else p.lineTo)(x, self._y(y))
            if close:
                p.close()
        return p

    def polyline(self, pts, color=0, lw=1.0, alpha=1.0):
        if len(pts) < 2:
            return
        self._set(None, color, lw, 1, alpha)
        self.c.drawPath(self._path([pts], False), stroke=1, fill=0)

    def polygon(self, rings, fill=None, stroke=None, lw=1.0, fill_alpha=1.0, alpha=1.0):
        self._set(fill, stroke, lw, fill_alpha, alpha)
        self.c.drawPath(self._path(rings, True), stroke=int(stroke is not None), fill=int(fill is not None), fillMode=0)  # 0 = even-odd

    def text(self, x, y, s, size=8, bold=False, color=0, anchor="l"):
        self.c.setFillColorRGB(*(v / 255 for v in _rgb(color)))
        self.c.setFillAlpha(1)
        self.c.setFont("RptSansB" if bold else "RptSans", size)
        s = display(s)
        for k, line in enumerate(s.split("\n")):
            yy = self._y(y + k * size * 1.2)
            if anchor == "c":
                self.c.drawCentredString(x, yy, line)
            elif anchor == "r":
                self.c.drawRightString(x, yy, line)
            else:
                self.c.drawString(x, yy, line)

    def image(self, pil, x, y, w, h, alpha=1.0):
        from reportlab.lib.utils import ImageReader
        self.c.saveState()
        self.c.setFillAlpha(alpha)
        self.c.drawImage(ImageReader(pil.convert("RGBA")), x, self._y(y + h), w, h, mask="auto")
        self.c.restoreState()

    def width(self, s, size, bold=False):
        from reportlab.pdfbase.pdfmetrics import stringWidth
        return max((stringWidth(l, "RptSansB" if bold else "RptSans", size) for l in display(s).split("\n")), default=0)

    def new_page(self):
        self.c.showPage()

    def save(self):
        self.c.save()


class PngCanvas(_Canvas):
    def __init__(self, page_w: float, page_h: float, dpi: int):
        from PIL import Image, ImageDraw
        self.k = dpi / 72.0
        self.img = Image.new("RGBA", (round(page_w * self.k), round(page_h * self.k)), (255, 255, 255, 255))
        self.d = ImageDraw.Draw(self.img, "RGBA")
        self._fonts: Dict[Tuple[int, bool], object] = {}
        self.pages = []

    def _col(self, c, a=1.0):
        r, g, b = _rgb(c)
        return (r, g, b, round(255 * max(0.0, min(1.0, a))))

    def _font(self, size, bold):
        from PIL import ImageFont
        key = (round(size * self.k * 4), bold)
        if key not in self._fonts:
            self._fonts[key] = ImageFont.truetype(_find_font(bold), max(1, round(size * self.k)), layout_engine=ImageFont.Layout.BASIC)
        return self._fonts[key]

    def _w(self, v):
        return max(1, round(v * self.k))

    def rect(self, x, y, w, h, fill=None, stroke=None, lw=1.0, alpha=1.0):
        k = self.k
        box = [x * k, y * k, (x + w) * k, (y + h) * k]
        if fill is not None:
            self.d.rectangle(box, fill=self._col(fill, alpha))
        if stroke is not None:
            self.d.rectangle(box, outline=self._col(stroke, alpha), width=self._w(lw))

    def line(self, x1, y1, x2, y2, color=0, lw=1.0, alpha=1.0):
        k = self.k
        self.d.line([x1 * k, y1 * k, x2 * k, y2 * k], fill=self._col(color, alpha), width=self._w(lw))

    def circle(self, x, y, r, fill=None, stroke=None, lw=1.0, alpha=1.0):
        k = self.k
        self.d.ellipse([(x - r) * k, (y - r) * k, (x + r) * k, (y + r) * k],
                       fill=self._col(fill, alpha) if fill is not None else None,
                       outline=self._col(stroke, alpha) if stroke is not None else None, width=self._w(lw))

    def polyline(self, pts, color=0, lw=1.0, alpha=1.0):
        if len(pts) >= 2:
            self.d.line([(x * self.k, y * self.k) for x, y in pts], fill=self._col(color, alpha), width=self._w(lw), joint="curve")

    def polygon(self, rings, fill=None, stroke=None, lw=1.0, fill_alpha=1.0, alpha=1.0):
        from PIL import Image, ImageChops, ImageDraw
        k = self.k
        if fill is not None and rings:
            xs = [x * k for r in rings for x, _ in r]
            ys = [y * k for r in rings for _, y in r]
            x0, y0 = max(0, int(min(xs)) - 1), max(0, int(min(ys)) - 1)
            x1, y1 = min(self.img.width, int(max(xs)) + 2), min(self.img.height, int(max(ys)) + 2)
            if x1 > x0 and y1 > y0:
                mask = Image.new("L", (x1 - x0, y1 - y0), 0)
                for r in rings:        # زوجي/فردي: XOR بين الحلقات
                    m = Image.new("L", mask.size, 0)
                    ImageDraw.Draw(m).polygon([(x * k - x0, y * k - y0) for x, y in r], fill=255)
                    mask = ImageChops.logical_xor(mask.convert("1"), m.convert("1")).convert("L")
                solid = Image.new("RGBA", mask.size, self._col(fill, fill_alpha))
                a = ImageChops.multiply(mask, Image.new("L", mask.size, solid.getchannel("A").getpixel((0, 0))))
                solid.putalpha(a)
                self.img.alpha_composite(solid, (x0, y0))
        if stroke is not None:
            for r in rings:
                self.d.line([(x * k, y * k) for x, y in r] + [(r[0][0] * k, r[0][1] * k)], fill=self._col(stroke, alpha), width=self._w(lw), joint="curve")

    def text(self, x, y, s, size=8, bold=False, color=0, anchor="l"):
        f = self._font(size, bold)
        s = display(s)
        for i, line in enumerate(s.split("\n")):
            w = self.d.textlength(line, font=f)
            xx = x * self.k - (w / 2 if anchor == "c" else w if anchor == "r" else 0)
            self.d.text((xx, (y + i * size * 1.2) * self.k), line, font=f, fill=self._col(color), anchor="ls")

    def image(self, pil, x, y, w, h, alpha=1.0):
        im = pil.convert("RGBA").resize((max(1, round(w * self.k)), max(1, round(h * self.k))))
        if alpha < 1:
            im.putalpha(im.getchannel("A").point(lambda v: int(v * alpha)))
        self.img.alpha_composite(im, (round(x * self.k), round(y * self.k)))

    def width(self, s, size, bold=False):
        f = self._font(size, bold)
        return max((self.d.textlength(l, font=f) for l in display(s).split("\n")), default=0) / self.k

    def new_page(self):
        from PIL import Image, ImageDraw
        self.pages.append(self.img)
        self.img = Image.new("RGBA", self.img.size, (255, 255, 255, 255))
        self.d = ImageDraw.Draw(self.img, "RGBA")


# ---------------------------------------------------------------------------- المصيّر
GRID_NONE, GRID_GRATICULE, GRID_UTM = 0, 1, 2


@dataclass
class Options:
    title: str = ""
    subtitle: str = ""
    paper: Paper = A4
    landscape: bool = True
    layers: List[Layer] = field(default_factory=list)
    bbox: Optional[Sequence[float]] = None
    fixed_scale: float = 0
    grid: int = GRID_NONE
    legend: bool = True
    table: bool = True
    map_rotation: float = 0.0
    color_by_sector: bool = False
    arabic: bool = True
    snapshot: Optional[object] = None          # PIL.Image: لقطة الخريطة كما ظهرت (مع الخريطة الأساسية)
    snap_m_per_px: float = 0.0
    snap_credit: str = ""
    snapshot_bbox: Optional[Sequence[float]] = None   # إن حُدد: تُوضع اللقطة جغرافياً وتُرسم الطبقات المتجهة فوقها
    notes: List[Item] = field(default_factory=list)
    images: Optional[Callable[[str], object]] = None
    rasters: List[Tuple[object, object]] = field(default_factory=list)   # [(RasterItem, PIL.Image)]


class ReportRenderer:
    def __init__(self, o: Options):
        self.o = o
        self.ar = o.arabic
        self.legend = self._legend_entries()
        bb = o.bbox or (list(o.snapshot_bbox) if o.snapshot_bbox else None) or layers_extent(o.layers)
        if o.rasters and not o.bbox and not bb:
            bb = list(o.rasters[0][0].bounds())
        if bb is None:
            bb = [44.0, 33.0, 44.1, 33.1]
        self.L = ReportLayout.compute(o.paper, o.landscape, bb, len(self.legend) if o.legend else 0, o.fixed_scale)
        self.rows = table_rows(o.layers) if o.table else []

    # --- الدليل والألوان
    def _layer_rgb(self, i: int, l: Layer) -> int:
        return (l.color & 0xFFFFFF) if l.color else PALETTE[i % len(PALETTE)]

    def _legend_entries(self) -> List[LegendEntry]:
        out: List[LegendEntry] = []
        for i, l in enumerate(self.o.layers):
            if self.o.color_by_sector and l.geom == POINT:
                counts: Dict[str, int] = {}
                for f in l.features:
                    counts[f.category] = counts.get(f.category, 0) + 1
                for cat, n in sorted(counts.items(), key=lambda kv: -kv[1]):
                    c = sectors.color_of(cat)
                    out.append(LegendEntry(cat or ("بلا قطاع" if self.ar else "No sector"), c or 0x888888, POINT, n))
            else:
                out.append(LegendEntry(l.label, self._layer_rgb(i, l), l.geom, len(l.features)))
        return out

    def table_pages(self) -> int:
        if len(self.rows) <= 1:
            return 0
        per = rows_per_page(self.o.paper, self.o.landscape)
        return (len(self.rows) - 1 + per - 1) // per

    def page_count(self) -> int:
        return 1 + self.table_pages()

    # --- الصفحات
    def draw_page(self, c: _Canvas, index: int) -> None:
        if index == 0:
            self._map_page(c)
        else:
            self._table_page(c, index - 1)

    def _map_page(self, c: _Canvas) -> None:
        L, o, ar = self.L, self.o, self.ar
        fx, fy, fw, fh = L.frame_x, L.frame_y, L.frame_w, L.frame_h
        snap_mpp = 0.0
        if o.snapshot is not None and o.snapshot_bbox:
            w_, s_, e_, n_ = o.snapshot_bbox
            x0, y0, x1, y1 = L.px(w_), L.py(n_), L.px(e_), L.py(s_)
            c.image(o.snapshot, x0, y0, x1 - x0, y1 - y0)
            self._rasters(c)
            if o.grid != GRID_NONE:
                self._grid(c)
            for i, l in enumerate(o.layers):
                self._layer(c, i, l)
            self._notes(c)
        elif o.snapshot is not None:
            b = o.snapshot
            k = min(fw / b.width, fh / b.height)
            dw, dh = b.width * k, b.height * k
            c.image(b, fx + (fw - dw) / 2, fy + (fh - dh) / 2, dw, dh)
            snap_mpp = o.snap_m_per_px / k
        else:
            self._rasters(c)
            if o.grid != GRID_NONE:
                self._grid(c)
            for i, l in enumerate(o.layers):
                self._layer(c, i, l)
            self._notes(c)
        # قصّ ما خرج عن الإطار بتغطيته بأبيض ثم رسم بقية الصفحة
        W, H = L.page_w, L.page_h
        for r in ((0, 0, W, fy), (0, fy + fh, W, H - fy - fh), (0, fy, fx, fh), (fx + fw, fy, W - fx - fw, fh)):
            c.rect(*r, fill=0xFFFFFF)
        c.text(MARGIN_PT, MARGIN_PT + 18, o.title or ("خريطة" if ar else "Map"), 18, True, 0)
        if o.subtitle:
            c.text(MARGIN_PT, MARGIN_PT + 34, o.subtitle, 10, False, 0x444444)
        c.rect(fx, fy, fw, fh, stroke=0, lw=1.0)
        self._scale_bar(c, snap_mpp)
        self._north_arrow(c)
        if o.legend:
            self._legend(c)
        if o.snapshot is not None and not o.snapshot_bbox:
            scale = round(snap_mpp / (0.0254 / 72))
            foot = ("المقياس التقريبي 1:" if ar else "Approx. scale 1:") + str(scale) + \
                   (" (لقطة للخريطة كما تظهر على الشاشة)" if ar else " (screenshot of the map as displayed)") + \
                   (" — " + o.snap_credit if o.snap_credit else "")
        else:
            base_note = (" — " + o.snap_credit if o.snap_credit else "") if o.snapshot is not None else \
                (" — بيانات الخرائط الأساسية غير مضمنة" if ar else " — no base-map tiles included")
            foot = ("المقياس التقريبي 1:" if ar else "Approx. scale 1:") + str(int(L.fit.nice_scale)) + \
                   (" — الإسقاط: خطوط الطول والعرض المتساوية (WGS84)" if ar else " — plate carrée (WGS84)") + base_note
        c.text(MARGIN_PT, L.page_h - MARGIN_PT, foot, 7, False, 0x666666)

    def _rasters(self, c: _Canvas) -> None:
        from .raster import warp_to_frame
        L = self.L
        for item, img in self.o.rasters:
            if not getattr(item, "visible", True):
                continue
            px_w, px_h = max(2, round(L.frame_w * 2)), max(2, round(L.frame_h * 2))
            w = warp_to_frame(item, img, L.shown, (px_w, px_h))
            if w is not None:
                c.image(w, L.frame_x, L.frame_y, L.frame_w, L.frame_h)

    def _layer(self, c: _Canvas, i: int, l: Layer) -> None:
        L = self.L
        alpha = max(0.0, min(1.0, l.opacity))
        w = max(0.6, l.width * 0.5)
        base = self._layer_rgb(i, l)
        for f in l.features:
            if f.geom == POINT:
                col = (sectors.color_of(f.category) or 0x888888) if self.o.color_by_sector else base
                x, y = L.px(f.lon), L.py(f.lat)
                c.circle(x, y, 3, fill=col, alpha=alpha)
                c.circle(x, y, 3, stroke=0xFFFFFF, lw=0.6)
            elif f.geom == LINE:
                for part in f.parts:
                    c.polyline([(L.px(x), L.py(y)) for x, y in part], base, w, alpha)
            else:
                rings = [[(L.px(x), L.py(y)) for x, y in part] for part in f.parts]
                c.polygon(rings, fill=base, stroke=base, lw=w, fill_alpha=alpha * 0.25, alpha=alpha)

    def _notes(self, c: _Canvas) -> None:
        L = self.L
        for it in self.o.notes:
            x, y = L.px(it.lon), L.py(it.lat)
            if it.kind == IMAGE:
                img = self.o.images(it.file) if self.o.images else None
                if img is None:
                    continue
                w = it.width * 0.75
                h = w * img.height / img.width
                c.image(img, x - w / 2, y - h / 2, w, h)
            else:
                size = it.size * 0.75
                lines = it.text.split("\n")
                tw = max((c.width(l, size) for l in lines), default=0)
                lh, pad = size * 1.2, 3
                h = lh * len(lines)
                if (it.background >> 24) & 255:
                    c.rect(x - tw / 2 - pad, y - h / 2 - pad, tw + 2 * pad, h + 2 * pad, fill=it.background & 0xFFFFFF,
                           alpha=((it.background >> 24) & 255) / 255)
                    c.rect(x - tw / 2 - pad, y - h / 2 - pad, tw + 2 * pad, h + 2 * pad, stroke=0, lw=0.5, alpha=0.33)
                c.text(x, y - h / 2 + size * 0.85, it.text, size, False, it.color & 0xFFFFFF, "c")

    def _grid(self, c: _Canvas) -> None:
        L, o = self.L, self.o
        sb = L.shown
        if o.grid == GRID_UTM:
            lon, lat = (sb[0] + sb[2]) / 2, (sb[1] + sb[3]) / 2
            lines = utm_grid(sb, Crs.utm(zone_for(lon), lat >= 0), 6)
        else:
            lines = graticule(sb, 6, False)
        for g in lines:
            pts = [(L.px(x), L.py(y)) for x, y in g.lonlat]
            c.polyline(pts, 0x8899AA, 0.4)
            if len(pts) >= 2:
                x, y = pts[0]
                if g.vertical:
                    c.text(max(L.frame_x + 2, x + 2), L.frame_y + 8, g.label, 6.5, False, 0x445566)
                else:
                    c.text(L.frame_x + 2, max(L.frame_y + 8, y - 2), g.label, 6.5, False, 0x445566)

    def _scale_bar(self, c: _Canvas, m_per_pt: float) -> None:
        L, ar = self.L, self.ar
        if m_per_pt > 0:
            m = nice_scale_bar_length(L.frame_w * 0.35 * m_per_pt)
            ln = m / m_per_pt
        else:
            m = L.scale_bar_metres()
            ln = L.bar_points(m)
        x, y = L.frame_x, L.frame_y + L.frame_h + 16
        for i in range(4):
            r = (x + ln / 4 * i, y, ln / 4, 5)
            c.rect(*r, fill=0 if i % 2 == 0 else 0xFFFFFF)
            c.rect(*r, stroke=0, lw=0.8)
        c.text(x - 2, y + 15, "0", 8)
        c.text(x + ln - 8, y + 15, scale_bar_label(m, ar), 8)

    def _north_arrow(self, c: _Canvas) -> None:
        L = self.L
        cx, cy = L.frame_x + L.frame_w - 22, L.frame_y + 34
        ang = math.radians(north_arrow_angle(self.o.map_rotation))
        sn, cs = math.sin(ang), math.cos(ang)
        rot = lambda dx, dy: (cx + dx * cs - dy * sn, cy + dx * sn + dy * cs)       # دوران باتجاه عقارب الساعة
        c.polygon([[rot(0, -18), rot(8, 10), rot(0, 5), rot(-8, 10)]], fill=0, fill_alpha=1.0)
        tx, ty = rot(0, -23)
        c.text(tx, ty + 4, "N", 11, True, 0, "c")

    def _legend(self, c: _Canvas) -> None:
        L, ar = self.L, self.ar
        x, y = L.frame_x, L.legend_y + 10
        c.text(x, y, "دليل الخريطة" if ar else "Legend", 9, True)
        y += 4
        shown = min(len(self.legend), 12)
        for e in self.legend[:shown]:
            y += 13
            if e.geom == POINT:
                c.circle(x + 5, y - 3, 3.5, fill=e.rgb)
            elif e.geom == LINE:
                c.line(x, y - 3, x + 10, y - 3, e.rgb, 2)
            else:
                c.rect(x, y - 7, 10, 7, fill=e.rgb)
            c.text(x + 16, y, f"{e.label} ({e.count})", 8)
        if len(self.legend) > shown:
            c.text(x + 16, y + 11, "…", 8)

    def _table_page(self, c: _Canvas, page: int) -> None:
        L, o, ar = self.L, self.o, self.ar
        per = rows_per_page(o.paper, o.landscape)
        m = MARGIN_PT
        usable = L.page_w - 2 * m
        wts = [2.4, 1.6, 1.6, 1.4, 1.4, 1.4, 1.1, 1.2, 1.6]
        tot = sum(wts)
        xs = [0.0]
        for w in wts:
            xs.append(xs[-1] + usable * w / tot)
        y = m + 12
        c.text(m, y, f"{o.title or ('الجدول' if ar else 'Attribute table')} — {page + 1}/{self.table_pages()}", 11, True)
        y += 18
        for i, h in enumerate(self.rows[0]):
            c.text(m + xs[i], y, h, 8, True)
        c.line(m, y + 3, m + usable, y + 3, 0, 0.6)
        lo, hi = 1 + page * per, min(len(self.rows), 1 + page * per + per)
        for r in range(lo, hi):
            y += ROW_PT
            for i, cell in enumerate(self.rows[r]):
                c.text(m + xs[i], y, self._clip(c, cell, xs[i + 1] - xs[i] - 3), 7)
        if len(self.rows) >= 3000 and page == self.table_pages() - 1:
            c.text(m, y + 16, "اقتُطع الجدول عند 3000 صف؛ استخدم التصدير الكامل." if ar else "Table truncated at 3000 rows; use the full export.", 7, False, 0x666666)

    @staticmethod
    def _clip(c: _Canvas, s: str, max_w: float) -> str:
        s = s or ""
        if c.width(s, 7) <= max_w:
            return s
        while s and c.width(s + "…", 7) > max_w:
            s = s[:-1]
        return s + "…"

    # --- المخرجات
    def write_pdf(self, target) -> None:
        pc = PdfCanvas(target, self.L.page_w, self.L.page_h)
        for i in range(self.page_count()):
            self.draw_page(pc, i)
            pc.new_page()
        pc.save()

    def render_page(self, index: int = 0, dpi: int = 100):
        pc = PngCanvas(self.L.page_w, self.L.page_h, dpi)
        self.draw_page(pc, index)
        return pc.img.convert("RGB")

    def write_png(self, target, dpi: int = 150) -> None:
        self.render_page(0, dpi).save(target, "PNG")


def make_report(layers: Sequence[Layer], out_path: str, **kw) -> ReportRenderer:
    """اختصار: يرسم التقرير إلى .pdf أو .png حسب الامتداد. kw → Options."""
    paper = kw.pop("paper", A4)
    if isinstance(paper, str):
        paper = paper_by_name(paper)
    dpi = kw.pop("dpi", 150)
    r = ReportRenderer(Options(layers=list(layers), paper=paper, **kw))
    if out_path.lower().endswith(".png"):
        r.write_png(out_path, dpi)
    else:
        r.write_pdf(out_path)
    return r
