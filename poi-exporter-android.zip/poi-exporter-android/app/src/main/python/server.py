"""يشغّل واجهة Flask داخل التطبيق على 127.0.0.1 (تُستدعى من Kotlin عبر Chaquopy)."""
import os
import threading

from werkzeug.serving import make_server

_srv = None


def start(files_dir, port=8000):
    global _srv
    if _srv is not None:
        return port
    os.environ["HOME"] = files_dir          # لتُحفظ المشاريع والإعدادات في مساحة التطبيق
    os.environ["TMPDIR"] = os.path.join(files_dir, "tmp")
    os.makedirs(os.environ["TMPDIR"], exist_ok=True)
    from poi_exporter.webapp import create_app
    _srv = make_server("127.0.0.1", port, create_app(), threaded=True)
    threading.Thread(target=_srv.serve_forever, daemon=True).start()
    return port
