# مصدّر المعالم — نسخة بايثون (v3.6)

إعادة كتابة كاملة لـ **منطق** تطبيق الأندرويد (Java) بلغة بايثون، مع سطر أوامر وواجهة ويب بديلتين عن واجهة الهاتف.
الاعتماد الإلزامي: `openpyxl` و`numpy` و`Pillow` و`reportlab` (للـPDF) و`scipy` (اختياري لتسريع/ثيسن)؛ `flask` للواجهة.
**لا يحتاج** `shapely` ولا `pyproj`: محرك التراكب الهندسي والإسقاطات مكتوبان داخل الحزمة (pyproj يوسّع الدعم فقط).

```
pip install -r requirements.txt
python -m poi_exporter --help
python -m poi_exporter serve        # واجهة المتصفح http://127.0.0.1:8000
python -m pytest tests              # 42 اختباراً
```

## الأوامر
```
download      تنزيل معالم/طبقات من OSM ثم تصدير           coords        تحويل إحداثيات (DD/DMS/DDM/UTM/MGRS)
convert       تحويل ملف بين الصيغ (+تحقق وإصلاح وتخطي مكرر)    batch-coords  تحويل جدول CSV/Excel دفعةً + ملف أخطاء
report        تقرير PDF/PNG (خريطة + دليل + جدول الخصائص)     crs           بحث في فهرس EPSG (≈4800 نظاماً مدعوماً)
raster        صور جوية TIFF/GeoTIFF/JPG/PNG (add/list/remove)  topology      تداخل/فجوة/تقاطع ذاتي/مكرر للمضلعات
quality       تقرير جودة البيانات                              dashboard     ملخص لوحة المعلومات
analyze       summary | nn | clusters | auto-sector            geoop         buffer | union | hull
locate        القضاء والمحافظة لنقطة (دون اتصال)                admin-fetch   جلب قضاء من OSM (Nominatim) وحفظه
sectors       القطاعات الـ15 وعناصرها                           backup        نسخ احتياطي لكل المشاريع (آخر 14)
```
أمثلة:
```
python -m poi_exporter download --bbox 33.25,44.30,33.40,44.45 --poi school hospital --layers roads_main \
     --offline-admin --format shp --target 32638 -o baghdad.zip
python -m poi_exporter report baghdad.zip -o map.pdf --title "بغداد" --grid utm --by-sector --paper A3
python -m poi_exporter report data.geojson -o map.png --tiles my_area.mbtiles --dpi 200      # خلفية دون اتصال
python -m poi_exporter raster add ortho.tif --store rasters && python -m poi_exporter report data.geojson -o m.pdf --raster
python -m poi_exporter batch-coords points.xlsx -o out.csv --column "الإحداثيات" --target 27038 --errors bad.csv
```

## الوحدات
| الوحدة | المحتوى |
|---|---|
| `model`, `geo` | المعلم/الطبقة، المسافات، المساحة، النقطة التمثيلية، بناء الحلقات، `AreaSpec` (مستطيل/دائرة/مدوّر) |
| `coords`, `proj` | UTM/MGRS وتنسيق الإحداثيات؛ **محرك إسقاط داخلي** يقرأ فهرس EPSG المضمّن (longlat, utm, tmerc, merc, lcc, aea + Helmert للمراجع مثل Nahrwan) |
| `convert` | المحوّل الدقيق: يحترم دقة الإدخال فلا يخترع خانات، تحذير الإزاحة المرجعية، محوّل الدفعات |
| `catalog`, `overpass`, `adminfetch` | فئات المعالم والطبقات، Overpass متوازٍ، جلب الأقضية من OSM/Nominatim |
| `admin`, `sectors`, `landmark` | 18 محافظة + 101 قضاء مضمّنة، القطاعات الـ15 حرفياً، الحقول التسعة الثابتة |
| `formats`, `shapefile`, `wkb` | GeoJSON, KML/KMZ, GPX, Shapefile, CSV, Excel, GeoPackage (قراءة وكتابة) |
| `quality`, `topology`, `analysis`, `stats` | الجودة والمكرر، الطوبولوجيا، DBSCAN وأقرب جار وكثافة وثيسن…، إحصاءات منطقة |
| `overlay`, `geoops`, `geodesy` | اتحاد/تقاطع/فرق/تقسيم/قصّ/Buffer بلا shapely؛ جيوديسيا Vincenty ومساحة على المجسّم |
| `raster` | قارئ TIFF (LZW/Deflate/PackBits/BigTIFF/مبلّط/Predictor/8-16-32 بت/لوحة/CMYK) + World file + مخزن صور + إسقاط على الصفحة |
| `report`, `arabic`, `annotations` | PDF متجه/PNG: A5/A4/A3، مقياس تلقائي أو ثابت، شريط مقياس، سهم الشمال، شبكة درجات/UTM، دليل، جدول الخصائص، عناصر نصية/صور؛ مُشكّل عربي مدمج |
| `offline` | MBTiles/ZIP/SQLite(osmdroid)/GEMF، ذاكرة بلاطات، خرائط أساسية، لقطة خريطة تُدرج في التقرير |
| `workspace`, `appstate`, `dashboard` | مشاريع SQLite مع تراجع/إعادة، نسخ احتياطي تلقائي، إعدادات، سجل أخطاء، لوحة المعلومات |

## إضافات لم تكن في الأصل
- تقرير يدمج **لقطة خريطة جغرافية + طبقات متجهة فوقها** (الأصل يطبع لقطة الشاشة فقط)، وتلوين النقاط حسب القطاع في الخريطة والدليل.
- محرك EPSG داخلي مع بحث بالاسم، واكتشاف نظام ملف `.prj` بالاسم، وكتابة `.prj` لأي نظام مدعوم.
- واجهة ويب: تحويل إحداثيات، تحويل ملفات، تقارير، لوحة معلومات، بحث EPSG. أوامر `topology/geoop/backup/batch-coords/crs`.

## ما لم يُنقل أو يختلف — بصراحة
- **واجهة الأندرويد نفسها** (لمس الخريطة، GPS الحي، الكاميرا وصور المعالم، مشاركة الملفات، الإشعارات) لا معنى لها في بايثون؛ يغطي بعضها سطر الأوامر/الويب فقط.
- **خرائط Google الأساسية**: لم أُدرج عناوين بلاطات Google غير الموثّقة (تخالف شروط الاستخدام). المتاح: OSM وEsri وأي قالب URL تحدده بنفسك (`offline.custom_basemap`) وملفاتك دون اتصال.
- **TIFF**: ضغط JPEG/JPEG2000/LERC/ZSTD وYCbCr غير مدعوم (يُحاول Pillow كملاذ أخير)، مع رسالة تقترح `gdal_translate`.
- **الإسقاطات**: حوالي 4765 من ~5700 نظام؛ الأنواع الأخرى (stere, omerc …) تحتاج `pip install pyproj`.
- **محرك التراكب** مكتوب هنا من الصفر (ترتيب مستوٍ + استخراج وجوه) واختُبر على حالات متنوعة، لكنه ليس JTS: للبيانات الضخمة أو الحالات الشاذة جداً (قطع شبه متطابقة) قد يكون أبطأ أو أقل متانة؛ استخدم shapely إن لزم.
- **قارئ GEMF** لم يُختبر على ملف حقيقي (لا عيّنة متوفرة)؛ MBTiles وZIP وSQLite مختبرة.
- **التنزيل من Overpass/Nominatim/البلاطات** لم يُجرَّب على الشبكة الحقيقية (بيئة الاختبار بلا إنترنت)؛ جُرّب بمُجلِب وهمي.
- الحدود الإدارية **غير رسمية ومُبسَّطة**؛ لا تصلح للمساحة أو الأعمال القانونية.

الترخيص: بيانات الخرائط © مساهمو OpenStreetMap (ODbL)؛ الحدود: geoBoundaries (CC0 / CC BY 3.0 IGO).
