# مصدّر المعالم – أندرويد (Kotlin + Chaquopy)
- `MainActivity.kt` (كوتلن): يشغّل بايثون ثم يعرض الواجهة في WebView.
- `app/src/main/python/poi_exporter`: حزمتك كما هي. `server.py`: يشغّل Flask داخل التطبيق.
## البناء
1. ارفع محتويات هذا المجلد (وليس ملف zip) إلى مستودع GitHub.
2. تبويب Actions ← Build APK ← انتظر ← حمّل POIExporter-debug-apk من Artifacts.
3. فكّ الضغط ثم ثبّت ملف app-debug.apk.
