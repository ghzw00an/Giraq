# مصدّر المعالم – أندرويد (Kotlin + Chaquopy)
- `MainActivity.kt` (كوتلن): يشغّل بايثون ثم يعرض الواجهة في WebView.
- `app/src/main/python/poi_exporter`: حزمتك كما هي. `server.py`: يشغّل Flask داخل التطبيق.
## البناء
1. ارفع محتويات هذا المجلد (وليس ملف zip) إلى مستودع GitHub.
2. تبويب Actions ← Build APK ← انتظر ← حمّل POIExporter-debug-apk من Artifacts.
3. فكّ الضغط ثم ثبّت ملف app-debug.apk.

## الميزات
خريطة بأسلوب الملاحة، مستطيل/دائرة منطقة، تنزيل OSM، معالم بالحقول التسعة والقطاعات، جدول خصائص، استيراد KML/KMZ وغيرها،
تقرير PDF/PNG بمعاينة وزر فتح، تحليل، صور جوية (GeoTIFF وغيرها)، عناصر الخريطة (🚩)، أدوات تحليل (13)، وجلب الأقضية من OSM.
ملاحظة: جلب الأقضية يحتاج إنترنت (Nominatim) ولم يُجرَّب على الشبكة الحقيقية.

## ملاحظة البناء
إن رفعت الملف المضغوط كما هو فاستخدم BUILD_FROM_ZIP.yml (انسخه إلى .github/workflows/build.yml). مكتبة الخرائط MapLibre GL JS مضمّنة داخل الحزمة فلا حاجة لتنزيل شيء أثناء البناء.

## البحث عن المناطق بالعربية (جديد)
- اكتب في شريط البحث من أول حرف (مثلاً «ك» أو «الك») فتظهر مباشرة قائمة بالمحافظات والأقضية (وما يُضاف من بيانات)، وتظهر نقاطها على الخريطة؛ اضغط نتيجة لتنتقل إليها ويُظلَّل حدّها.
- الكود: `places.py` (الفهرس) و`static/app/places.js` (القائمة).
- لإضافة بيانات مستودع iraqi-geography-data:
  `git clone https://github.com/hoshmandent/iraqi-geography-data.git`
  ثم `python tools/build_gazetteer.py iraqi-geography-data` — يكتب `data/iq_places.json` الذي يُضمَّن بالتطبيق.
