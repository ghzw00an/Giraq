#!/usr/bin/env python3
"""يحوّل بيانات iraqi-geography-data (json / geojson / csv) إلى app/.../data/iq_places.json المضمّن في التطبيق.

الاستخدام (على جهازك، بعد git clone للمستودع):
    git clone https://github.com/hoshmandent/iraqi-geography-data.git
    python tools/build_gazetteer.py iraqi-geography-data

يتعرّف تلقائياً على أسماء الحقول الشائعة (name_ar / arabic / lat / lng / type / governorate ...) ويقبل
بنية متداخلة (محافظات ← أقضية ← نواحٍ). السجلات التي بلا إحداثيات ولا تطابق قضاء/محافظة معروفة تُحصى وتُتجاهل.
"""
import csv
import glob
import json
import os
import sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "python")
sys.path.insert(0, ROOT)
from poi_exporter.places import Gazetteer  # noqa: E402


def main(src_dir: str) -> None:
    g = Gazetteer()
    g._load_admin()
    n_files = 0
    for p in sorted(glob.glob(os.path.join(src_dir, "**", "*"), recursive=True)):
        ext = os.path.splitext(p)[1].lower()
        if "node_modules" in p or "/.git/" in p.replace("\\", "/") or ext not in (".json", ".geojson", ".csv"):
            continue
        try:
            if ext == ".csv":
                with open(p, encoding="utf-8-sig", newline="") as fh:
                    g._ingest(list(csv.DictReader(fh)), os.path.relpath(p, src_dir))
            else:
                with open(p, encoding="utf-8-sig") as fh:
                    g._ingest(json.load(fh), os.path.relpath(p, src_dir))
            n_files += 1
        except Exception as e:  # noqa: BLE001
            print("تعذّرت قراءة", p, "-", e)
    g._dedupe()
    out = [{"ar": it["ar"] if it["ar"] != it["en"] else "", "en": it["en"], "type": it["type"], "parent": it["parent"],
            "lat": round(it["lat"], 5), "lon": round(it["lon"], 5)}
           for it in g.items if it["src"] != "admin"]
    dst = os.path.join(ROOT, "poi_exporter", "data", "iq_places.json")
    with open(dst, "w", encoding="utf-8") as fh:
        json.dump({"places": out}, fh, ensure_ascii=False, separators=(",", ":"))
    print(f"ملفات مقروءة: {n_files} | أماكن مضافة: {len(out)} | بلا إحداثيات (متجاهلة): {g.stats['skipped_no_coords']}")
    print("المصادر:", {k: v for k, v in g.stats["sources"].items() if k != "admin"})
    print("كُتب:", os.path.normpath(dst))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("python tools/build_gazetteer.py <مجلد بيانات iraqi-geography-data>")
    main(sys.argv[1])
