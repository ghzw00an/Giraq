import json
from poi_exporter import providers, sector_fetch, sectors, catalog
from poi_exporter.geo import AreaSpec
from poi_exporter.model import Feature
from poi_exporter.webapp import create_app

AREA = AreaSpec.rect(33.30, 44.40, 33.32, 44.42)


def test_telecom_sector_next_to_health():
    names = [s.name for s in sectors.ALL]
    assert "قطاع الاتصالات" in names and len(sectors.COLORS) == len(sectors.ALL)
    from poi_exporter import apiv2
    order = [s.name for _, s in apiv2.ordered_sectors()]
    assert order[order.index("القطاع الصحي") + 1] == "قطاع الاتصالات"
    assert sectors.ALL[names.index("قطاع الاتصالات")].items == ("برج اتصال", "شركة", "بدالة", "برج انترنت")


def test_sector_cats_registered_and_post():
    cid = sector_fetch.cid("قطاع الاتصالات", "برج اتصال")
    assert catalog.poi(cid)
    f = Feature.point(33.31, 44.41, name="Zain tower 4", category="قطاع الاتصالات|برج اتصال")
    sector_fetch.post([f])
    assert f.category == "قطاع الاتصالات" and f.type == "برج اتصال" and f.attrs["operator"] == "Zain IQ"
    g = Feature.point(33.31, 44.41, name="", category="قطاع الاتصالات|برج اتصال")
    g.attrs["operator"] = "Asiacell Telecom"
    sector_fetch.post([g])
    assert g.attrs["operator"] == "Asiacell"


def test_google_places_parse_and_filter():
    calls = []

    def http(url, data=None, headers=None):
        calls.append((url, json.loads(data), headers))
        return {"places": [{"displayName": {"text": "مستشفى الأمل"}, "location": {"latitude": 33.31, "longitude": 44.41}, "formattedAddress": "بغداد"},
                           {"displayName": {"text": "خارج"}, "location": {"latitude": 40, "longitude": 10}}]}
    rows = providers.google_search("KEY", "مستشفى", (33.3, 44.4, 33.32, 44.42), http)
    assert calls[0][2]["X-Goog-Api-Key"] == "KEY" and "rectangle" in calls[0][1]["locationRestriction"]
    feats = providers.fetch_points({"id": "g", "type": "google_places", "key": "K"}, [("مستشفى", "مستشفى", "القطاع الصحي")], AREA,
                                   http=http)
    assert len(feats) == 1 and feats[0].name == "مستشفى الأمل" and feats[0].attrs["address"] == "بغداد" and len(rows) == 2


def test_template_generic_geojson_and_list():
    seen = []

    def http(url, data=None, headers=None):
        seen.append(url)
        return {"results": [{"title": "برج", "lat": 33.31, "lng": 44.41}]}
    prov = {"id": "m", "type": "template", "key": "abc", "url": "https://x/api?bbox={west},{south},{east},{north}&q={q}&k={key}"}
    feats = providers.fetch_points(prov, [("tower", "برج", "قطاع الاتصالات")], AREA, http=http)
    assert feats and "k=abc" in seen[0] and "q=tower" in seen[0]
    gj = providers.parse_generic({"features": [{"geometry": {"type": "Point", "coordinates": [44.41, 33.31]}, "properties": {"name": "A"}}]})
    assert gj[0]["name"] == "A" and gj[0]["lat"] == 33.31


def test_provider_error_message(monkeypatch):
    def http(*a, **k):
        raise IOError("403 Forbidden")
    try:
        providers.fetch_points({"id": "g", "name": "Google", "type": "google_places", "key": "K"}, [("x", "x", "x")], AREA, http=http)
        assert False
    except providers.ProviderError as e:
        assert "Google" in str(e) and "403" in str(e)


def test_download_uses_provider(monkeypatch, tmp_path):
    monkeypatch.setenv("HOME", str(tmp_path))
    from poi_exporter import apiv2
    monkeypatch.setattr(providers, "_http", lambda url, data=None, headers=None: {"places": [{"displayName": {"text": "برج زين"}, "location": {"latitude": 33.31, "longitude": 44.41}}]})
    app = create_app(fetcher=lambda q: (_ for _ in ()).throw(AssertionError("OSM must not be called")))
    c = app.test_client()
    pj = json.dumps([{"id": "g1", "name": "Google", "type": "google_places", "key": "K", "kind": "both"}])
    c.post("/api/settings", json={"providers_json": pj, "data_source": "g1"})
    r = c.post("/api/download", json={"bbox": [33.30, 44.40, 33.32, 44.42], "poi": [sector_fetch.cid("قطاع الاتصالات", "برج اتصال")], "format": "geojson"})
    assert r.status_code == 200, r.data
    gj = json.loads(r.data)
    p = gj["features"][0]["properties"]
    assert p["Gategory"] == "قطاع الاتصالات" and p["type"] == "برج اتصال" and p["name"] == "برج زين"
