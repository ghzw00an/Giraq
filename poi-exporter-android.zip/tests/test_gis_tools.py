import io, json
import pytest
from poi_exporter.webapp import create_app
from poi_exporter import apiv2, routing, polygonize, apiv5
from poi_exporter.model import Feature, Layer, POINT, LINE, POLYGON


@pytest.fixture(scope="module")
def client():
    app = create_app(); app.testing = True
    return app.test_client()


def mk(kind, name, feats):
    w = apiv2._ws()
    try:
        return w.add_layer_with_features(Layer("", name, kind, feats, kind="user")).id
    finally:
        w.close()


def line(pts, name=""):
    f = Feature(geom=LINE, id=Feature.new_id(), name=name); f.add_part(pts); return f


def post(c, url, **j):
    r = c.post(url, json=j); return r.status_code, r.get_json()


def test_along_interval_and_count():
    pts = [(44.0, 33.0), (44.0, 33.01)]       # ~1112 م
    a = apiv5.along([pts], interval=500)
    assert len(a) == 4 and a[0][2] == 0 and abs(a[-1][2] - 1111.9) < 5      # 0,500,1000,نهاية
    b = apiv5.along([pts], count=5)
    assert len(b) == 5 and abs(b[1][2] - b[-1][2] / 4) < 1
    c = apiv5.along([[(44, 33), (44.01, 33), (44.01, 33.01), (44, 33.01)]], count=4, closed=True)
    assert len(c) == 4


def test_polygonize_grid_gives_one_face_and_closed_square():
    grid = [line([(44.0, 33.0), (44.03, 33.0)]), line([(44.0, 33.01), (44.03, 33.01)]),
            line([(44.01, 32.99), (44.01, 33.02)]), line([(44.02, 32.99), (44.02, 33.02)])]
    # شبكة # : وجه واحد مغلق في الوسط (الأذرع تُحذف كنهايات معلّقة)
    r = polygonize.polygonize(grid)
    assert len(r) == 1 and r[0][0] == r[0][-1]
    sq = [line([(44, 33), (44.01, 33), (44.01, 33.01), (44, 33.01), (44, 33)])]
    assert len(polygonize.polygonize(sq)) == 1
    assert polygonize.polygonize([line([(44, 33), (44.01, 33)])]) == []


def test_construct_f2p_p2l_append(client):
    ln = mk(LINE, "طريق", [line([(44.0, 33.0), (44.0, 33.02)], "ش")])
    s, j = post(client, "/api/gis/construct", layer=ln, interval=500)
    assert s == 200 and j["n"] >= 4
    s, j = post(client, "/api/gis/construct", coords=[[33.0, 44.0], [33.0, 44.02]], count=3)
    assert j["n"] == 3
    assert post(client, "/api/gis/construct", layer=ln)[0] == 400
    sq = mk(LINE, "شبكة", [line([(44, 33), (44.01, 33), (44.01, 33.01), (44, 33.01), (44, 33)])])
    s, j = post(client, "/api/gis/feature_to_polygon", layer=sq)
    assert s == 200 and j["n"] == 1
    s, j2 = post(client, "/api/gis/polygon_to_line", layer=j["layer"])
    assert s == 200 and j2["n"] == 1
    assert post(client, "/api/gis/polygon_to_line", layer=ln)[0] == 400
    a = mk(POINT, "أ", [Feature.point(33.1, 44.1, name="x", id="a1")])
    b = mk(POINT, "ب", [Feature.point(33.2, 44.2, name="y", id="b1"), Feature.point(33.1, 44.1, name="x", id="b2")])
    s, j = post(client, "/api/gis/append", target=a, sources=[b], skip_dups=True)
    assert s == 200 and j["added"] == 1 and j["skipped"] == 1
    s, j = post(client, "/api/gis/append", target=a, sources=[ln])
    assert j["added"] == 0 and j["wrong_geom"] == 1


def test_display_xy_csv(client):
    csv = "الاسم,lat,lon,نوع\nمسجد,33.31,44.41,مسجد\nسوق,33.32,44.42,سوق\nخطأ,abc,44,x\n"
    r = client.post("/api/gis/xy/preview", data={"file": (io.BytesIO(csv.encode("utf-8")), "p.csv")}, content_type="multipart/form-data")
    j = r.get_json()
    assert r.status_code == 200 and j["total"] == 3 and j["guess"]["x"] == 2 and j["guess"]["y"] == 1
    s, k = post(client, "/api/gis/xy/run", token=j["token"], x=2, y=1, name=0)
    assert s == 200 and k["n"] == 2 and k["bad"] == 1
    assert post(client, "/api/gis/xy/run", token="nope", x=0, y=1)[0] == 400


def test_spatial_filter(client):
    mk(POINT, "داخل", [Feature.point(33.3, 44.4, name="p", id="in1"), Feature.point(36.3, 43.1, name="m", id="out1")])
    s, j = post(client, "/api/gis/spatial_filter", lat=33.3, lon=44.4, level=2)
    if s == 200:
        assert j["unit"] and "in1" in j["ids"] and "out1" not in j["ids"]
    else:
        assert s in (400, 404)


def test_routing_with_fake_osrm(client, monkeypatch):
    calls = []

    def fake(url):
        calls.append(url)
        if "/route/" in url:
            return {"code": "Ok", "routes": [{"distance": 5000, "duration": 600, "geometry": {"coordinates": [[44.0, 33.0], [44.01, 33.01], [44.02, 33.0]]}, "legs": [{"distance": 5000, "duration": 600}]}]}
        if "/table/" in url:
            n = url.split("?")[0].count(";") + 1
            src = int(url.split("sources=")[1].split("&")[0].count(";")) + 1
            dst = n - src
            return {"code": "Ok", "durations": [[60.0 * (j + 1) for j in range(dst)] for _ in range(src)], "distances": [[1000.0 * (j + 1) for j in range(dst)] for _ in range(src)]}
        return {"code": "NoRoute"}
    monkeypatch.setattr(routing, "_get", fake)
    s, j = post(client, "/api/gis/route", stops=[[33.0, 44.0], [33.0, 44.02]], name="ط")
    assert s == 200 and j["km"] == 5 and j["min"] == 10 and j["layer"]
    assert post(client, "/api/gis/route", stops=[[33, 44]])[0] == 400
    pl = mk(POINT, "منشآت", [Feature.point(33.0 + i / 100, 44.0, name="m%d" % i, id="f%d" % i) for i in range(5)])
    s, j = post(client, "/api/gis/closest", lat=33.0, lon=44.0, layers=[pl], k=2)
    assert s == 200 and len(j["results"]) == 2 and j["results"][0]["name"] == "m0"
    s, j = post(client, "/api/gis/od", layers=[pl])
    assert s == 200 and len(j["minutes"]) == 5
    s, j = post(client, "/api/gis/service_area", lat=33.0, lon=44.0, minutes=[5, 10])
    assert s == 200 and j["n"] == 2
    monkeypatch.setattr(routing, "_get", lambda u: {"code": "NoRoute"})
    s, j = post(client, "/api/gis/route", stops=[[33, 44], [34, 45]])
    assert s == 400 and "طريق" in j["error"]
    monkeypatch.setattr(routing, "_get", lambda u: (_ for _ in ()).throw(OSError("x")))
    assert post(client, "/api/gis/route", stops=[[33, 44], [34, 45]])[0] == 502
