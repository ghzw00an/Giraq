// اختبار دخاني لواجهة Layout: يشغّل التطبيق ويفتح كل القوالب ويصدّر PDF/PNG. الاستخدام: node tests/layout_smoke.js [port]
const { chromium } = require('playwright');
const port = process.argv[2] || 8765;
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await b.newPage({ viewport: { width: 412, height: 860 } });
  const errs = [];
  p.on('pageerror', e => errs.push('PE ' + e.message));
  p.on('console', m => { if (m.type() === 'error' && !/net::|Failed to load|tile|ERR_/.test(m.text())) errs.push('CE ' + m.text()); });
  await p.goto(`http://localhost:${port}/`); await p.waitForTimeout(2500);
  await p.evaluate(() => openLayout()); await p.waitForTimeout(2500);
  const r = await p.evaluate(async () => {
    const o = {};
    for (const k of ['overlay', 'classic', 'side', 'poster', 'table']) { lyTpl(k); o['tpl_' + k] = LY.els.length; }
    for (const k of Object.keys(LYD)) { try { lyAdd(k); } catch (e) { o['add_' + k] = 'ERR ' + e.message; } }
    lyDraw();
    for (const f of ['pdf', 'png']) o[f] = (await lyRender(72, f)).size;
    return o;
  });
  console.log(JSON.stringify(r));
  const bad = Object.entries(r).filter(([k, v]) => String(v).startsWith('ERR') || v === 0);
  if (errs.length || bad.length) { console.error(errs.join('\n'), JSON.stringify(bad)); process.exit(1); }
  console.log('OK'); await b.close();
})();
