import json, os, re, shutil, subprocess
import pytest
from poi_exporter import coords
from poi_exporter.webapp import create_app

STATIC = os.path.join(os.path.dirname(coords.__file__), "static", "app")


def test_utm_roundtrip_baghdad():
    r = coords.utm_from_latlon(33.3152, 44.3661)
    assert r.zone == 38
    lat, lon = coords.utm_to_latlon(r.zone, True, r.easting, r.northing)
    assert abs(lat - 33.3152) < 1e-6 and abs(lon - 44.3661) < 1e-6


@pytest.mark.parametrize("lat,lon", [(36.19, 44.01), (30.5, 47.78), (33.3, 44.4), (35.47, 44.39)])
def test_mgrs_roundtrip(lat, lon):
    m = coords.mgrs_from_latlon(lat, lon)
    la, lo = coords.mgrs_to_latlon(m)
    assert abs(la - lat) < 2e-4 and abs(lo - lon) < 2e-4


def test_parse_formats():
    p = coords.parse_coord("33.3152, 44.3661")
    assert abs(p.lat - 33.3152) < 1e-9 and abs(p.lon - 44.3661) < 1e-9


@pytest.fixture(scope="module")
def client():
    app = create_app()
    app.testing = True
    return app.test_client()


def test_index_and_no_duplicate_ids(client):
    r = client.get("/")
    assert r.status_code == 200
    html = r.get_data(as_text=True)
    ids = re.findall(r'\sid="([^"]+)"', html)
    dup = {i for i in ids if ids.count(i) > 1}
    assert not dup, "معرّفات مكررة: %s" % dup


@pytest.mark.parametrize("f", sorted(os.listdir(STATIC)))
def test_static_served(client, f):
    if f.endswith((".js", ".css")):
        assert client.get("/assets/app/" + f).status_code == 200


@pytest.mark.skipif(not shutil.which("node"), reason="node غير متوفر")
@pytest.mark.parametrize("f", [x for x in sorted(os.listdir(STATIC)) if x.endswith(".js")])
def test_js_syntax(f):
    r = subprocess.run(["node", "--check", os.path.join(STATIC, f)], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


def test_clientstate_roundtrip_and_backup(client):
    st = {"layout2": '{"v":2}', "drawings": "[1,2]"}
    assert client.post("/api/clientstate", json=st).get_json()["ok"]
    assert client.get("/api/clientstate").get_json() == st
    b = client.get("/api/backup")
    assert b.status_code == 200
    import io, zipfile
    z = zipfile.ZipFile(io.BytesIO(b.data))
    assert "client_state.json" in z.namelist()
    r = client.post("/api/restore", data={"file": (io.BytesIO(b.data), "b.poibak")}, content_type="multipart/form-data")
    assert r.get_json()["client"] == st


def test_clientstate_rejects_garbage(client):
    assert client.post("/api/clientstate", data="x", content_type="text/plain").status_code == 400


def test_quality_and_dedupe(client):
    from poi_exporter import apiv2
    from poi_exporter.model import Feature, Layer, POINT
    w = apiv2._ws()
    try:
        fs = [Feature.point(33.3, 44.4, name="مسجد"), Feature.point(33.3, 44.4, name="مسجد"), Feature.point(35.0, 43.0, name="سوق")]
        lay = w.add_layer_with_features(Layer("", "t", POINT, fs, kind="user"))
        lid = lay.id
    finally:
        w.close()
    r = client.get("/api/datasets/%s/quality" % lid).get_json()
    assert r["total"] == 3 and len(r["dup_ids"]) == 1
    assert client.post("/api/datasets/%s/dedupe" % lid).get_json()["removed"] == 1
    assert len(client.get("/api/datasets/%s/quality" % lid).get_json()["dup_ids"]) == 0


def test_diag_and_clienterror(client):
    assert client.post("/api/clienterror", json={"m": "js: boom"}).status_code in (200, 204)
    t = client.get("/api/diag").get_json()["text"]
    assert "version:" in t and "boom" in t


def test_js_files_parse_and_are_all_loaded():
    import glob, shutil, subprocess, re
    root = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "python", "poi_exporter")
    files = sorted(glob.glob(os.path.join(root, "static", "app", "app*.js")))
    assert files
    html = open(os.path.join(root, "ui.py"), encoding="utf8").read()
    for f in files:
        assert "/assets/app/" + os.path.basename(f) in html, "غير محمّل في الواجهة: " + f
    for m in re.findall(r"/assets/app/(app\d*\.js)", html):
        assert os.path.exists(os.path.join(root, "static", "app", m)), m
    node = shutil.which("node")
    if node:
        for f in files:
            r = subprocess.run([node, "--check", f], capture_output=True, text=True)
            assert r.returncode == 0, f + "\n" + r.stderr


def test_export_postgis_and_dxf(tmp_path):
    from poi_exporter import formats
    from poi_exporter.model import Feature, Layer, POINT, LINE, POLYGON
    p = Feature.point(33.3, 44.4, name="مسجد O'Neil", type="t")
    ln = Feature(geom=LINE); ln.add_part([(44.0, 33.0), (44.1, 33.1)])
    pg = Feature(geom=POLYGON); pg.add_part([(44.0, 33.0), (44.1, 33.0), (44.1, 33.1), (44.0, 33.0)])
    lays = [Layer("a", "نقاط", POINT, [p]), Layer("b", "خطوط ومضلعات", LINE, [ln, pg])]
    sql = tmp_path / "o.sql"; formats.export_layers(lays, "sql", str(sql))
    s = sql.read_text(encoding="utf8")
    assert "CREATE EXTENSION IF NOT EXISTS postgis" in s and "ST_GeomFromGeoJSON" in s and "O''Neil" in s and "USING GIST" in s
    assert s.count("CREATE TABLE") == 2
    dxf = tmp_path / "o.dxf"; formats.export_layers(lays, "dxf", str(dxf))
    b = dxf.read_bytes().decode("cp1256")
    assert "POINT" in b and "POLYLINE" in b and "SEQEND" in b and b.rstrip().endswith("EOF")


def test_no_native_dialogs_left():
    import glob
    root = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "python", "poi_exporter", "static", "app")
    import re
    for f in glob.glob(os.path.join(root, "app*.js")):
        for n, line in enumerate(open(f, encoding="utf8"), 1):
            assert not re.search(r"(?<![\w.])(confirm|prompt|alert)\(", line), "%s:%d حوار أصلي (يُظهر 127.0.0.1)" % (os.path.basename(f), n)
