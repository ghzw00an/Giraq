import os, sys, tempfile
ROOT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "python")
sys.path.insert(0, os.path.abspath(ROOT))
_home = tempfile.mkdtemp()
os.environ["HOME"] = _home
os.environ["POI_DB"] = os.path.join(_home, "ws.db")
